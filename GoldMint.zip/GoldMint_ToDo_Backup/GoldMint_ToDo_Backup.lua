local addonName = ...
GoldMintToDoBackupDB = type(GoldMintToDoBackupDB) == "table" and GoldMintToDoBackupDB or {}
GoldMintToDoBackupDB.backups = type(GoldMintToDoBackupDB.backups) == "table" and GoldMintToDoBackupDB.backups or {}
local MAX=10
local function Copy(v) if type(v)~="table" then return v end local t={} for k,x in pairs(v) do t[k]=type(x)=="table" and Copy(x) or x end return t end
local function GM() return _G.GoldMint end
local function MakeBackup(label)
    local gm=GM(); if not gm or not _G.GoldMintDB or not GoldMintDB.todoList then return false end
    local item={label=label or date("%Y-%m-%d %H:%M"), createdAt=time(), data=Copy(GoldMintDB.todoList)}
    table.insert(GoldMintToDoBackupDB.backups, item); while #GoldMintToDoBackupDB.backups>MAX do table.remove(GoldMintToDoBackupDB.backups,1) end
    return true
end
local function Restore(index)
    local b=GoldMintToDoBackupDB.backups[tonumber(index or 0)]; if not b then return false end
    if not _G.GoldMintDB then GoldMintDB={} end
    GoldMintDB.todoList=Copy(b.data)
    if GM() and GM().ToDoPopout then GM().ToDoPopout:Show() end
    return true
end
SLASH_GOLDMINTTODOBACKUP1="/gmb"
SlashCmdList.GOLDMINTTODOBACKUP=function(msg)
    local a,b=string.match(strtrim(msg or ""),"^(%S+)%s*(.*)$"); a=string.lower(a or "")
    if a=="" or a=="backup" then print("|cff33d6ffGoldMint Backup:|r backup saved."); MakeBackup(b~="" and b or nil)
    elseif a=="list" then for i=#GoldMintToDoBackupDB.backups,1,-1 do local x=GoldMintToDoBackupDB.backups[i]; print(string.format("|cff33d6ff[%d]|r %s",i,x.label or "Backup")) end
    elseif a=="restore" then local ok=Restore(tonumber(b)); print(ok and "|cff33d6ffGoldMint Backup:|r restored." or "|cffff4444GoldMint Backup:|r backup not found.")
    else print("/gmb backup [label] | list | restore <index>") end
end
local f=CreateFrame("Frame"); f:RegisterEvent("PLAYER_LOGIN"); f:RegisterEvent("PLAYER_LOGOUT"); f:SetScript("OnEvent",function(_,e) if e=="PLAYER_LOGIN" then C_Timer.After(3,function() MakeBackup("Automatic - "..date("%Y-%m-%d %H:%M")) end) elseif e=="PLAYER_LOGOUT" then MakeBackup("Logout - "..date("%Y-%m-%d %H:%M")) end end)
