local ADDON_NAME, GoldMint = ...

GoldMint.CraftingProfit = {}
local Profit = GoldMint.CraftingProfit

local function GetItemValue(itemID)
    if not itemID or not GoldMint.Market then return nil end

    -- GetUnitValue returns both the value and its source. Capture only the
    -- first return before calling tonumber so Lua does not pass the source
    -- string as tonumber's optional numeric base argument.
    local value = GoldMint.Market:GetUnitValue(itemID)
    return tonumber(value)
end

local function GetReagentCost(reagents)
    local total, missing = 0, false

    for _, reagent in ipairs(reagents or {}) do
        local quantity = tonumber(reagent.quantity) or 0
        local options = reagent.options or {}

        if quantity > 0 and #options > 0 then
            local cheapest
            for _, option in ipairs(options) do
                local value = GetItemValue(option.itemID)
                if value and value > 0 and (not cheapest or value < cheapest) then
                    cheapest = value
                end
            end

            if cheapest then
                total = total + cheapest * quantity
            else
                missing = true
            end
        elseif quantity > 0 then
            missing = true
        end
    end

    return total, missing
end

local function BuildCraftingReagents(recipe)
    local result = {}
    for _, slot in ipairs(recipe and recipe.reagentSlots or {}) do
        local quantity = tonumber(slot.quantityRequired) or tonumber(slot.quantity) or 0
        if quantity > 0 and slot.dataSlotIndex then
            local itemID = nil
            local cheapest = nil
            for _, reagent in ipairs(slot.reagents or {}) do
                local candidate = tonumber(reagent.itemID)
                if candidate then
                    local value = GetItemValue(candidate)
                    if not cheapest or (value and value > 0 and value < cheapest.value) then
                        itemID = candidate
                        cheapest = { itemID = candidate, value = value or math.huge }
                    end
                end
            end
            if itemID then
                result[#result + 1] = {
                    reagent = { itemID = itemID },
                    dataSlotIndex = tonumber(slot.dataSlotIndex),
                    quantity = quantity,
                }
            end
        end
    end
    return result
end

local function GetConcentrationInfo(recipe)
    if not recipe or not recipe.recipeID or not C_TradeSkillUI or not C_TradeSkillUI.GetCraftingOperationInfo then
        return nil
    end

    local craftingReagents = BuildCraftingReagents(recipe)
    if #craftingReagents == 0 then
        return nil
    end

    local ok, info = pcall(C_TradeSkillUI.GetCraftingOperationInfo, tonumber(recipe.recipeID), craftingReagents, nil, true)
    if not ok or type(info) ~= "table" then
        return nil
    end

    local cost = tonumber(info.concentrationCost)
    if not cost or cost <= 0 then
        return nil
    end

    return {
        cost = cost,
        currencyID = tonumber(info.concentrationCurrencyID),
        quality = tonumber(info.craftingQualityID or info.quality),
        skill = tonumber(info.baseSkill),
    }
end

function Profit:GetConcentrationInfo(recipe)
    return GetConcentrationInfo(recipe)
end

function Profit:Calculate(recipe)
    if type(recipe) ~= "table" then return nil end

    -- GoldMint's integrated CraftSim backend is the primary calculator.
    -- The existing GoldMint calculation remains as a safe fallback for old
    -- recipes/data that are not ready for the profession API yet.
    if GoldMint.CraftingIntegration and GoldMint.CraftingIntegration.CalculateRecipe and recipe.recipeID then
        local integrated = GoldMint.CraftingIntegration:CalculateRecipe(recipe.recipeID)
        if integrated then
            return {
                recipeID = tonumber(recipe.recipeID),
                name = integrated.name or recipe.name,
                profession = recipe.profession,
                outputItemID = integrated.outputItemID or tonumber(recipe.outputItemID),
                outputQuantity = tonumber(recipe.outputQuantity) or 1,
                outputUnitValue = integrated.resultValue,
                outputValue = integrated.resultValue,
                reagentCost = integrated.craftingCost,
                profit = integrated.profit,
                missingReagentCosts = false,
                profitable = (integrated.profit or 0) > 0,
                concentrationCost = integrated.concentrationCost,
                craftingQualityID = integrated.quality,
                skill = integrated.skill,
                probability = integrated.probability,
                updatedAt = time(),
            }
        end
    end

    local outputID = tonumber(recipe.outputItemID)
    local outputQuantity = math.max(tonumber(recipe.outputQuantity) or 1, 1)
    if not outputID then return nil end

    local outputValue = GetItemValue(outputID)
    if not outputValue then return nil end

    local reagentCost, missingCosts = GetReagentCost(recipe.reagents)
    local outputTotal = outputValue * outputQuantity
    local profit = outputTotal - reagentCost
    local concentration = GetConcentrationInfo(recipe)

    return {
        recipeID = tonumber(recipe.recipeID),
        name = recipe.name,
        profession = recipe.profession,
        outputItemID = outputID,
        outputQuantity = outputQuantity,
        outputUnitValue = outputValue,
        outputValue = outputTotal,
        reagentCost = reagentCost,
        profit = profit,
        missingReagentCosts = missingCosts,
        profitable = not missingCosts and profit > 0,
        concentrationCost = concentration and concentration.cost or nil,
        concentrationCurrencyID = concentration and concentration.currencyID or nil,
        craftingQualityID = concentration and concentration.quality or nil,
        updatedAt = time(),
    }
end

function Profit:RefreshRecipe(recipeID)
    recipeID = tonumber(recipeID)
    if not recipeID or not C_TradeSkillUI then
        return nil
    end

    local schematic
    if C_TradeSkillUI.GetRecipeSchematic then
        local ok, result = pcall(C_TradeSkillUI.GetRecipeSchematic, recipeID, false)
        if ok and type(result) == "table" then
            schematic = result
        end
    end

    if not schematic then
        return nil
    end

    local outputItemID = tonumber(schematic.outputItemID)
    if not outputItemID then
        local ok, output = pcall(C_TradeSkillUI.GetRecipeOutputItemData, recipeID)
        if ok and type(output) == "table" then
            outputItemID = tonumber(output.itemID)
        end
    end

    if not outputItemID then
        return nil
    end

    local reagents = {}
    for _, slot in ipairs(schematic.reagentSlotSchematics or {}) do
        local quantity = tonumber(slot.quantityRequired) or 0
        local options = {}

        for _, reagent in ipairs(slot.reagents or {}) do
            local itemID = tonumber(reagent.itemID)
            if itemID then
                options[#options + 1] = { itemID = itemID }
            end
        end

        -- Variable quantities can describe the actual reagent choice for
        -- recipes that allow a range. Keep the fixed slot quantity when one
        -- exists; the complete operation UI can refine this later.
        if quantity > 0 and #options > 0 then
            reagents[#reagents + 1] = {
                quantity = quantity,
                options = options,
            }
        end
    end

    local recipes = GoldMintDB and GoldMintDB.recipes
    local record = recipes and recipes[recipeID]
    if record then
        record.outputItemID = outputItemID
        record.outputQuantity = tonumber(schematic.quantityMax or schematic.quantityMin) or 1
        record.reagents = reagents
        record.profitUpdatedAt = time()
    end

    local recipe = {
        recipeID = recipeID,
        name = record and record.name or schematic.name,
        profession = record and (record.professionName or record.profession) or nil,
        outputItemID = outputItemID,
        outputQuantity = tonumber(schematic.quantityMax or schematic.quantityMin) or 1,
        reagents = reagents,
        reagentSlots = schematic.reagentSlotSchematics or {},
    }

    -- Capture the recipe's craft duration when Midnight exposes it.  The
    -- field name has changed across profession API revisions, so probe the
    -- supported recipe info table safely and persist only a real value.
    local craftTime
    if C_TradeSkillUI.GetRecipeInfo then
        local okInfo, recipeInfo = pcall(C_TradeSkillUI.GetRecipeInfo, recipeID)
        if okInfo and type(recipeInfo) == "table" then
            craftTime = tonumber(recipeInfo.craftingTime or recipeInfo.craftTime or recipeInfo.craftingTimeSeconds)
        end
    end
    if craftTime and craftTime > 0 then
        recipe.craftTime = craftTime
        if record then record.craftTime = craftTime end
    elseif record and tonumber(record.craftTime) then
        recipe.craftTime = tonumber(record.craftTime)
    end

    local result = self:Calculate(recipe)
    if result then
        result.craftTime = tonumber(recipe.craftTime)
        if result.craftTime and result.craftTime > 0 and result.profit then
            result.profitPerMinute = (tonumber(result.profit) or 0) * 60 / result.craftTime
        end
    end
    if record then
        record.profit = result
        record.concentrationCost = result and result.concentrationCost or nil
        record.concentrationCurrencyID = result and result.concentrationCurrencyID or nil
        record.craftingQualityID = result and result.craftingQualityID or nil
    end
    return result
end

function Profit:RefreshCurrentProfession()
    -- Profession recipe data can contain entries that are not fully available
    -- to the crafting APIs yet (especially while the Midnight profession UI is
    -- still initializing). Refresh each recipe independently so one protected
    -- or incomplete recipe cannot abort the entire opportunity pass.
    if not C_TradeSkillUI or not C_TradeSkillUI.GetAllRecipeIDs then
        return 0, 0
    end

    local okIDs, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
    if not okIDs or type(ids) ~= "table" then
        return 0, 0
    end

    local refreshed, profitable = 0, 0
    for _, recipeID in ipairs(ids) do
        local ok, result = pcall(self.RefreshRecipe, self, recipeID)
        if ok and result then
            refreshed = refreshed + 1
            if result.profitable then
                profitable = profitable + 1
            end
        end
    end

    return refreshed, profitable
end

function Profit:CompareRecipes(recipes)
    local results = {}
    for _, recipe in ipairs(recipes or {}) do
        local result = self:Calculate(recipe)
        if result then results[#results + 1] = result end
    end
    table.sort(results, function(a, b)
        return (a.profit or 0) > (b.profit or 0)
    end)
    return results
end
