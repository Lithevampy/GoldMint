# GoldMint

GoldMint is a World of Warcraft addon built to keep the stuff I actually care about while playing in one place — gold, farming, professions, world quests, weekly tasks, cooldowns, and a few useful reminders.

The idea is pretty simple: open GoldMint and get a quick look at what's going on without having to dig through a bunch of different addon menus.

## What GoldMint Does

### Dashboard

The dashboard gives you a quick look at your character and the things that may need your attention.

Depending on what you're using, this can include:

- Current gold
- Farming information
- Current tasks
- Next suggestions
- Profession information
- World quests
- Weekly activities
- Cooldowns
- Other tracked activities

### Gold & Farming

GoldMint can track farming sessions and show gold-per-hour information.

It can also keep a recent list of loot from a farming session so you can see what's actually making you money.

Low-value loot can be filtered out if you don't want it filling up the list.

### World Quests

GoldMint looks for World Quests that are worth your time based on your settings.

The World Quests section can look for quests that meet the gold requirement, along with quests involving things such as mounts and achievements.

It is designed to avoid constantly scanning the map and repeatedly alerting you about the same quest.

### Weekly Tasks

The Weekly Task Overview keeps weekly activities together so they're easier to keep track of.

GoldMint can track tasks as you complete them and remove them when they're finished.

### Professions

Profession information is checked when it is actually needed.

GoldMint doesn't need to constantly poll in the background just to see whether the Profession window is open. When the profession interface is opened, GoldMint can update the information it needs.

### Cooldowns

Cooldown tracking is intentionally lightweight.

GoldMint avoids constantly scanning your character every few seconds just to find out whether something changed. Cooldown information is updated when appropriate instead.

### Reminders

GoldMint includes optional reminders such as **Breathe, Stretch and Hydrate**.

These reminders are completely optional. If no reminder is enabled, GoldMint doesn't waste time checking for one in the background.

### Alerts

GoldMint can notify you about useful things, including:

- New World Quests that match your settings
- Valuable BoE items
- Unknown transmogs
- Cooldowns becoming available
- Next suggestions
- Other configured alerts

Alerts can be adjusted or muted through the GoldMint options.

## Performance

Performance is a big part of GoldMint's development.

A lot of the addon is event-driven instead of relying on timers that constantly run in the background. The goal is for GoldMint to do work when something actually changes rather than repeatedly checking the same information.

This is especially important during:

- Dungeons
- World Quests
- Farming
- Combat
- Opening and closing bags

If a feature isn't being used, GoldMint tries not to spend CPU time checking it.

## Slash Commands

The main command is:

```text
/gm
```

This opens the GoldMint interface.

Additional commands may be available depending on the current version.

## Current Status

This build is part of the GoldMint beta line and focuses on keeping background work dormant unless a feature is actually being used.

GoldMint is currently in **Beta**.

Things are still being worked on and changed as features are added, bugs are found, and World of Warcraft changes.

If something isn't working correctly, an error message or screenshot is usually very helpful when reporting the problem.

## Credits

GoldMint is a personal World of Warcraft addon project.

The goal isn't to replace every addon in the game. It's to have one place where the information I actually care about while playing is easy to find.
