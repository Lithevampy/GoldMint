local GoldMint = _G.GoldMint

local WarbandBank = {}
GoldMint.WarbandBank = WarbandBank

local ACCOUNT_BANK_TYPE = (Enum and Enum.BankType and Enum.BankType.Account) or 2
local DEPOSIT_RETRY_DELAY = 0.15
local lastDepositAttempt = 0
local bankOpen = false

local function GetSettings()
    if GoldMint.Options and GoldMint.Options.GetSettings then
        return GoldMint.Options:GetSettings()
    end

    GoldMintDB.settings = type(GoldMintDB and GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    return GoldMintDB.settings
end

local function IsBankOpen()
    if bankOpen then return true end
    if BankFrame and BankFrame.IsShown and BankFrame:IsShown() then return true end
    if BankFrame and BankFrame.IsVisible and BankFrame:IsVisible() then return true end
    return false
end

local function CanDepositToWarband()
    if not C_Bank or type(C_Bank.CanDepositMoney) ~= "function" then return false end
    local ok, canDeposit = pcall(C_Bank.CanDepositMoney, ACCOUNT_BANK_TYPE)
    return ok and canDeposit == true
end

function WarbandBank:GetReserve()
    if GoldMint.Options and GoldMint.Options.GetWarbandGoldReserve then
        return GoldMint.Options:GetWarbandGoldReserve()
    end

    local settings = GetSettings()
    return math.max(0, math.floor(tonumber(settings.warbandGoldReserve) or 0))
end

function WarbandBank:IsEnabled()
    return GetSettings().warbandAutoDepositEnabled == true
end

function WarbandBank:DepositExcess()
    if not self:IsEnabled() then return false end
    if not IsBankOpen() then return false end
    if not CanDepositToWarband() then return false end
    if not C_Bank or type(C_Bank.DepositMoney) ~= "function" then return false end

    local now = (type(GetTimePreciseSec) == "function" and GetTimePreciseSec()) or GetTime()
    if now and (now - lastDepositAttempt) < DEPOSIT_RETRY_DELAY then
        return false
    end

    local currentGold = type(GetMoney) == "function" and (tonumber(GetMoney()) or 0) or 0
    local reserve = self:GetReserve()
    local excess = currentGold - reserve
    if excess <= 0 then return false end

    excess = math.floor(excess)
    if excess <= 0 then return false end

    lastDepositAttempt = now or 0
    local ok = pcall(C_Bank.DepositMoney, ACCOUNT_BANK_TYPE, excess)
    if not ok then
        lastDepositAttempt = 0
        return false
    end

    if GoldMint.Ledger and GoldMint.Ledger.UpdateWarbandGold then
        C_Timer.After(0.15, function()
            if GoldMint.Ledger then
                GoldMint.Ledger:UpdateWarbandGold()
            end
        end)
    end

    return true
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("BANKFRAME_OPENED")
eventFrame:RegisterEvent("BANKFRAME_CLOSED")
eventFrame:RegisterEvent("PLAYER_MONEY")
eventFrame:SetScript("OnEvent", function(_, event)
    if event == "BANKFRAME_OPENED" then
        bankOpen = true
        C_Timer.After(0.15, function()
            if bankOpen then
                WarbandBank:DepositExcess()
            end
        end)
    elseif event == "BANKFRAME_CLOSED" then
        bankOpen = false
    elseif event == "PLAYER_MONEY" and bankOpen then
        -- This also catches newly earned gold while the Warband Bank remains open.
        C_Timer.After(0.05, function()
            if bankOpen then
                WarbandBank:DepositExcess()
            end
        end)
    end
end)

function WarbandBank:GetStatus()
    local reserve = self:GetReserve()
    local current = type(GetMoney) == "function" and (tonumber(GetMoney()) or 0) or 0
    return {
        enabled = self:IsEnabled(),
        reserve = reserve,
        currentGold = current,
        excess = math.max(0, current - reserve),
    }
end
