local GoldMint = _G.GoldMint

-- Unified-folder build: Ledger is loaded by GoldMint.toc before Features.
-- This file remains as a compatibility marker for older module ordering.
if GoldMint and GoldMint.Ledger then
    GoldMint._featuresReady = true
end
