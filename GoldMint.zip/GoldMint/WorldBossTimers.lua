local _, GoldMint = ...

local WorldBossTimers = {}
GoldMint.WorldBossTimers = WorldBossTimers

local function MinToSec(min) return min * 60 end
local MAX_RESPAWN = MinToSec(15) - 1
local MIN_RESPAWN_SHA = MinToSec(10)
local MAX_RESPAWN_SHA = MinToSec(20)
local MIN_RESPAWN_NALAK = MIN_RESPAWN_SHA
local MAX_RESPAWN_NALAK = MAX_RESPAWN_SHA
local IS_RETAIL = WOW_PROJECT_ID == (WOW_PROJECT_MAINLINE or 1)

local function IsSavedWorldBoss(id_wb)
    local n_saved = GetNumSavedWorldBosses and GetNumSavedWorldBosses() or 0
    for i = 1, n_saved do
        local _, id = GetSavedWorldBossInfo(i)
        if id == id_wb then return true end
    end
    return false
end

local function IsSavedDaily(questId)
    return C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted and C_QuestLog.IsQuestFlaggedCompleted(questId) or false
end

local function NeverSaved() return false end

local tracked_bosses = {
    ["Oondasta"] = {
        name = "Oondasta",
        color = "|cff21ffa3",
        ids = {69161},
        is_saved_fcn = function() return IsSavedWorldBoss(4); end,
        min_respawn = MAX_RESPAWN,
        max_respawn = MAX_RESPAWN,
        random_spawn_time = false,
        auto_announce = true,
        map_id = 507,
        perimiter = {
            origin = {
                x = 0.49706578,
                y = 0.56742978,
            },
            radius = 0.07,
        },
    },
    ["Rukhmar"] = {
        name = "Rukhmar",
        color = "|cfffa6e06",
        ids = {83746},
        is_saved_fcn = function() return IsSavedWorldBoss(9); end,
        min_respawn = MAX_RESPAWN,
        max_respawn = MAX_RESPAWN,
        random_spawn_time = false,
        auto_announce = true,
        map_id = 542,
        perimiter = {
            origin = {
                x = 0.37155128,
                y = 0.38439554,
            },
            radius = 0.04,
        },
    },
    ["Galleon"] = {
        name = "Galleon",
        color = "|cffc1f973",
        ids = {62346},
        is_saved_fcn = function() return IsSavedWorldBoss(2); end,
        min_respawn = IS_RETAIL and MAX_RESPAWN or MinToSec(30),
        max_respawn = IS_RETAIL and MAX_RESPAWN or MinToSec(30),
        random_spawn_time = false,
        auto_announce = true,
        map_id = 376,
        perimiter = {
            origin = {
                x = 0.71155238,
                y = 0.63839519,
            },
            radius = 0.04,
        },
    },
    ["Nalak"] = {
        name = "Nalak",
        color = "|cff0081cc",
        ids = {69099},
        is_saved_fcn = function() return IsSavedWorldBoss(3); end,
        min_respawn = MIN_RESPAWN_NALAK,
        max_respawn = MAX_RESPAWN_NALAK,
        random_spawn_time = true,
        auto_announce = true,
        map_id = 504,
        perimiter = {
            origin = {
                x = 0.60369474,
                y = 0.37266934,
            },
            radius = 0.04,
        },
    },
    ["Sha of Anger"] = {
        name = "Sha of Anger",
        color = "|cff8a1a9f",
        ids = {60491},
        is_saved_fcn = function() return IsSavedWorldBoss(1); end,
        min_respawn = MIN_RESPAWN_SHA,
        max_respawn = MAX_RESPAWN_SHA,
        random_spawn_time = true,
        auto_announce = true,
        map_id = 379,
        perimiter = {
            origin = {
                x = 0.53787065,
                y = 0.64697766,
            },
            radius = 0.03,
        },
    },
    ["Huolon"] = {
        name = "Huolon",
        color = "|cfff7f713",
        ids = {73167},
        is_saved_fcn = NeverSaved,
        min_respawn = MinToSec(20) - 1,  -- Then boss is unattackable for 1 min... Could change to 21.
        max_respawn = MinToSec(20) - 1,
        random_spawn_time = true,
        auto_announce = true,
        map_id = 554,
        perimiter = {
            origin = {
                x = 0.66583741,
                y = 0.58253992,
            },
            radius = 0.06,
        },
    },
    ["Rustfeather"] = {
        name = "Rustfeather",
        color = "|cffffe17d",
        ids = {152182},
        is_saved_fcn = function() return IsSavedDaily(55811); end,
        min_respawn = MinToSec(15),
        max_respawn = MinToSec(30),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1462,
        perimiter = {
            origin = {
                x = 0.65564358234406,
                y = 0.78932404518127,
            },
            radius = 0.05,
        },
    },
    ["A. Harvester"] = {
        name = "A. Harvester", -- Shortened to keep GUI text to one line.
        color = "|cffe08748",
        ids = {151934},
        is_saved_fcn = function() return IsSavedDaily(55512); end,
        min_respawn = MinToSec(15),
        max_respawn = MinToSec(40),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1462,
        perimiter = {
            origin = {
                x = 0.52341330,
                y = 0.40851349,
            },
            radius = 0.05,
        },
    },
--  ["Soundless"] = {
--      Won't add. Very long timer and prone to zone resets. Timers will not be reliable.
-- },
    ["Rei Lun"] = {
        name = "Rei Lun",
        color = "|cff23dcfc",
        ids = {157162},
        is_saved_fcn = function() return IsSavedDaily(57346); end,
        min_respawn = MinToSec(30),
        max_respawn = MinToSec(60),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1530,  -- N'Zoth Assault. Old timeline zone has different.
        perimiter = {
            origin = {
                x = 0.21920382,
                y = 0.12227475,
            },
            radius = 0.03,
        },
    },
    ["Ha-Li"] = {
        name = "Ha-Li",
        color = "|cff0394fc",
        ids = {157153},
        is_saved_fcn = function() return IsSavedDaily(57344); end,
        min_respawn = MinToSec(30),
        max_respawn = MinToSec(60),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1530,
        perimiter = {
            origin = {
                x = 0.3437,
                y = 0.3828,
            },
            radius = 0.08,
        },
    },
    ["Anh-De"] = {
        name = "Anh-De",
        color = "|cfffaea75",
        ids = {157466},
        is_saved_fcn = function() return IsSavedDaily(57363); end,
        min_respawn = MinToSec(30),
        max_respawn = MinToSec(60),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1530,
        perimiter = {
            origin = {
                x = 0.3389,
                y = 0.6837,
            },
            radius = 0.02,
        },
    },
    ["Houndlord Ren"] = {
        name = "Houndlord Ren",
        color = "|cfffaab34",
        ids = {157160},
        is_saved_fcn = function() return IsSavedDaily(57345); end,
        min_respawn = MinToSec(30),
        max_respawn = MinToSec(60),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1530,
        perimiter = {
            origin = {
                x = 0.1310,
                y = 0.2600,
            },
            radius = 0.02,
        },
    },
    ["Corpse Eater"] = {
        name = "Corpse Eater",
        color = "|cffa884ff",
        ids = {162147},
        is_saved_fcn = function() return IsSavedDaily(58696); end,
        min_respawn = MinToSec(5),
        max_respawn = MinToSec(30),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1527,
        perimiter = {
            origin = {
                x = 0.3091,
                y = 0.4967,
            },
            radius = 0.02,
        },
    },
    ["Rotfeaster"] = {
        name = "Rotfeaster",
        color = "|cffffc489",
        ids = {157146},
        is_saved_fcn = function() return IsSavedDaily(57273); end,
        min_respawn = MinToSec(30),
        max_respawn = MinToSec(90),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1527,
        perimiter = {
            origin = {
                x = 0.6831,
                y = 0.3188,
            },
            radius = 0.01,
        },
    },
    ["Ishak"] = {
        name = "Ishak",  -- Ishak of the Four Winds
        color = "|cff0394fc",
        ids = {157134},
        is_saved_fcn = function() return IsSavedDaily(57259); end,
        min_respawn = MinToSec(120),  -- 2h
        max_respawn = MinToSec(255),  -- 4h 45m
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1527,
        perimiter = {
            origin = {
                x = 0.7390,
                y = 0.8355,
            },
            radius = 0.02,
        },
    },
    ["Mal'Korak"] = {
        name = "Mal'Korak",  -- Warbringer Mak'Korak
        color = "|cff99ba4e",
        ids = {162819},
        is_saved_fcn = function() return IsSavedDaily(58889); end,
        min_respawn = MinToSec(45),
        max_respawn = MinToSec(90),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1536,
        perimiter = {
            origin = {
                x = 0.3372,
                y = 0.8009,
            },
            radius = 0.01,
        },
    },
    ["Nerissa"] = {
        name = "Nerissa",  -- Nerissa Heartless
        color = "|cffbec0c2",
        ids = {162690},
        is_saved_fcn = function() return IsSavedDaily(58851); end,
        min_respawn = MinToSec(30),
        max_respawn = MinToSec(60),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1536,
        perimiter = {
            origin = {
                x = 0.6605,
                y = 0.3518,
            },
            radius = 0.01,
        },
    },
--  ["Violet Mistake"] = {
--      Won't add. Not limited by respawn time, but by the time and effort it takes to spawn it.
--  },
    ["Hopecrusher"] = {
        name = "Hopecrusher",
        color = "|cfffaab34",
        ids = {166679},
        is_saved_fcn = function() return IsSavedDaily(59900); end,
        min_respawn = MinToSec(60),
        max_respawn = MinToSec(60),
        random_spawn_time = false,
        auto_announce = true,
        map_id = 1525,
        perimiter = {
            origin = {
                x = 0.5197,
                y = 0.5181,
            },
            radius = 0.01,
        },
    },
    ["Famu"] = {
        name = "Famu",  -- Famu the Infinite
        color = "|cff0394fc",
        ids = {166521},
        is_saved_fcn = function() return IsSavedDaily(59869); end,
        min_respawn = MinToSec(25),
        max_respawn = MinToSec(35),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1525,
        perimiter = {
            origin = {
                x = 0.6257,
                y = 0.4723,
            },
            radius = 0.01,
        },
    },
--  ["Gorged Shadehound"] = {
--      Won't add (for now). Apparently the event is bugged.
--  },
--  ["Fallen Charger"] = {
--      Won't add. TLPD-like.
--  },
--  ["Konthrogz the Obliterator"] = {
--      Won't add. Apparently the spawn time is very buggy.
--  },
--  ["Malbog"] = {
--      Won't add. Apparently short respawn of about 5 min.
--  },
    ["Reliwik"] = {
        name = "Reliwik",  -- Reliwik the Defiant
        color = "|cffe147ff",
        ids = {180160},
        is_saved_fcn = function() return IsSavedDaily(64455); end,
        min_respawn = MinToSec(15),
        max_respawn = MinToSec(60),  -- This spawn seems to be bugged. Timer probably inaccurate.
        random_spawn_time = true,
        auto_announce = true,
        map_id = 1961,
        perimiter = {
            origin = {
                x = 0.5620,
                y = 0.6630,
            },
            radius = 0.02,
        },
    },
--  ["Rhuv, Gorger of Ruin"] = {
--      Won't add. Not a fixed respawn time, and shares spawn with other mobs.
--  },
--  ["Hirukon"] = {
--      Won't add. Not limited by respawn time, but by the time and effort it takes to spawn it.
--  },
    ["Breezebiter"] = {
        name = "Breezebiter",
        color = "|cffe147ff",
        ids = {195353},
        is_saved_fcn = function() return false; end,
        min_respawn = MinToSec(60),
        max_respawn = MinToSec(120),
        random_spawn_time = true,
        auto_announce = true,
        map_id = 2024,
        perimiter = {
            origin = {
                x = 0.2980,
                y = 0.4626,
            },
            radius = 0.02,
        },
    },
}

local ZWB_STATIC_DATA = {
    {zone = "JF", map_id = 371, color = "|cff2bce7a", perimiter = {origin = {x = 0.52551341, y = 0.18841952}, radius = 0.03}},
    {zone = "KW", map_id = 418, color = "|cff27b4d1", perimiter = {origin = {x = 0.17448401, y = 0.52911037}, radius = 0.04}},
    {zone = "DW", map_id = 422, color = "|cff8a1a9f", perimiter = {origin = {x = 0.47365963, y = 0.62041634}, radius = 0.03}},
    {zone = "KS", map_id = 379, color = "|cffeab01e", perimiter = {origin = {x = 0.75076747, y = 0.67355406}, radius = 0.03}},
    {zone = "TS", map_id = 388, color = "|cff0cd370", perimiter = {origin = {x = 0.36536807, y = 0.85731047}, radius = 0.03}},
};

local function ZWBName(zone)
    return "ZWB (" .. zone .. ")";
end

local function ZandalariWarbringerFromTemplate(zone, map_id, color, perimiter)
    return {
        name = ZWBName(zone),
        color = color,
        ids = {69769, 69842, 69841},
        is_saved_fcn = NeverSaved,
        min_respawn = MinToSec(20),
        max_respawn = MinToSec(20),
        random_spawn_time = false,
        auto_announce = false,
        map_id = map_id,
        perimiter = perimiter,
    };
end

local function AddZandalariWarbringers()
    for _, data in pairs(ZWB_STATIC_DATA) do
        tracked_bosses[ZWBName(data.zone)] = ZandalariWarbringerFromTemplate(data.zone, data.map_id, data.color, data.perimiter);
    end
end

-- Wait with enabling warbringers in classic MoP until they actually exist, otherwise
-- the "Show GUI only in boss zones" will initially be incorrect.
if IS_RETAIL then
    AddZandalariWarbringers();
end

-- Standalone GoldMint world-boss timer engine.
WorldBossTimers.BossData = tracked_bosses

for name, boss in pairs(tracked_bosses) do
    boss.name_colored = boss.color .. boss.name .. "|r"
end

function WorldBossTimers:GetBoss(name)
    return self.BossData[name]
end

function WorldBossTimers:GetAll()
    return self.BossData
end

function WorldBossTimers:GetBossFromGUID(guid, mapID)
    if type(guid) ~= "string" then return nil end
    local npcID = select(6, strsplit("-", guid))
    if not npcID then return nil end
    npcID = tostring(npcID)
    local fallbackName, fallbackBoss
    for name, boss in pairs(self.BossData) do
        if type(boss.ids) == "table" then
            for _, id in ipairs(boss.ids) do
                if npcID == tostring(id) then
                    if not mapID or boss.map_id == mapID then
                        return name, boss
                    end
                    fallbackName, fallbackBoss = name, boss
                end
            end
        end
    end
    return fallbackName, fallbackBoss
end

local PREFIX = "GoldMintWBT"
local function CurrentMapID()
    return C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player") or nil
end

local function ParseShardID(guid)
    if type(guid) ~= "string" then return nil end
    local unitType = strsplit("-", guid)
    if unitType ~= "Creature" and unitType ~= "Vehicle" then return nil end
    return tonumber(select(5, strsplit("-", guid)))
end

local function GetStore()
    GoldMintDB.worldBossTimers = type(GoldMintDB.worldBossTimers) == "table" and GoldMintDB.worldBossTimers or {}
    local s = GoldMintDB.worldBossTimers
    s.kills = type(s.kills) == "table" and s.kills or {}
    s.settings = type(s.settings) == "table" and s.settings or {}
    local defaults = {
        showOtherShards = true,
        highlightCurrentZone = true,
        showSavedStatus = true,
        showRealm = false,
        cyclic = false,
        soundEnabled = false,
        alertWhenSaved = false,
    }
    for k, v in pairs(defaults) do if s.settings[k] == nil then s.settings[k] = v end end

    return s
end

function WorldBossTimers:GetSettings()
    return GetStore().settings
end

function WorldBossTimers:SetSetting(key, value)
    local s = GetStore().settings
    if key == "showOtherShards" or key == "highlightCurrentZone" or key == "showSavedStatus"
            or key == "showRealm" or key == "cyclic" or key == "soundEnabled" or key == "alertWhenSaved" then
        s[key] = value == true
        return true
    end
    return false
end

local function IsSaved(name)
    local boss = tracked_bosses[name]
    if not boss or type(boss.is_saved_fcn) ~= "function" then return false end
    local ok, result = pcall(boss.is_saved_fcn)
    return ok and result == true
end

local function GetLatestKill(name)
    local store = GetStore()
    local entries = store.kills[name]
    if type(entries) ~= "table" then return nil end
    local now = GetServerTime()
    local currentShard = nil
    -- The current shard is available from any creature GUID while in-world.
    -- Prefer an entry for it, then fall back to the most recently recorded timer.
    local best, bestTime
    for shard, rec in pairs(entries) do
        if type(rec) == "table" and tonumber(rec.death) then
            local death = tonumber(rec.death)
            if death > 0 then
                if not bestTime or death > bestTime then best, bestTime = rec, death end
                if currentShard and tostring(shard) == tostring(currentShard) then best = rec; break end
            end
        end
    end
    return best
end

local function FormatClock(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    local days = math.floor(seconds / 86400)
    seconds = seconds - days * 86400
    local hours = math.floor(seconds / 3600)
    seconds = seconds - hours * 3600
    local mins = math.floor(seconds / 60)
    local secs = seconds % 60
    if days > 0 then return string.format("%dd %02d:%02d", days, hours, mins) end
    if hours > 0 then return string.format("%02d:%02d:%02d", hours, mins, secs) end
    return string.format("%02d:%02d", mins, secs)
end

function WorldBossTimers:GetRows()
    local rows = {}
    local settings = self:GetSettings()
    local now = GetServerTime()
    for name, boss in pairs(self.BossData) do
        local rec = GetLatestKill(name)
        local minRemaining, maxRemaining
        if rec then
            local death = tonumber(rec.death)
            minRemaining = death + (tonumber(boss.min_respawn) or 0) - now
            maxRemaining = death + (tonumber(boss.max_respawn) or 0) - now
        end
        local zone = ""
        if C_Map and C_Map.GetMapInfo and boss.map_id then
            local info = C_Map.GetMapInfo(boss.map_id)
            zone = info and info.name or ""
        end
        local highlight = settings.highlightCurrentZone and boss.map_id == CurrentMapID()
        local saved = settings.showSavedStatus and IsSaved(name) or false
        if settings.cyclic and rec and maxRemaining and maxRemaining < 0 then
            local cycle = tonumber(boss.max_respawn) or 0
            if cycle > 0 then
                local cycles = math.floor((-maxRemaining) / cycle) + 1
                minRemaining = minRemaining + cycles * cycle
                maxRemaining = maxRemaining + cycles * cycle
            end
        end
        local row = {
            name = boss.name or name,
            zone = zone,
            min = minRemaining,
            max = maxRemaining,
            random = (tonumber(boss.min_respawn) or 0) ~= (tonumber(boss.max_respawn) or 0),
            hasTimer = rec ~= nil,
            saved = saved,
            realm = settings.showRealm and rec and rec.realm or nil,
            color = boss.color,
            highlight = highlight,
        }
        rows[#rows + 1] = row
    end
    table.sort(rows, function(a, b)
        local ar = a.hasTimer and math.max(0, tonumber(a.min) or 0) or 999999999
        local br = b.hasTimer and math.max(0, tonumber(b.min) or 0) or 999999999
        if ar ~= br then return ar < br end
        return tostring(a.name) < tostring(b.name)
    end)
    return rows
end

function WorldBossTimers:RecordKill(name, guid)
    local boss = self.BossData[name]
    if not boss then return false end
    local store = GetStore()
    local shard = ParseShardID(guid)
    local key = shard and tostring(shard) or "unknown"
    store.kills[name] = type(store.kills[name]) == "table" and store.kills[name] or {}
    store.kills[name][key] = {
        death = GetServerTime(),
        shard = shard,
        realm = GetRealmName(),
    }
    self:SendTimer(name, store.kills[name][key])
    return true
end

function WorldBossTimers:SendTimer(name, rec, channel, target)
    if not C_ChatInfo or not C_ChatInfo.SendAddonMessage or not rec then return end
    local payload = table.concat({"T", name, tostring(rec.death or 0), tostring(rec.shard or ""), tostring(rec.realm or "")}, "\t")
    pcall(C_ChatInfo.SendAddonMessage, PREFIX, payload, channel or "PARTY", target)
end

function WorldBossTimers:RequestTimers()
    if not C_ChatInfo or not C_ChatInfo.SendAddonMessage then return false end
    pcall(C_ChatInfo.SendAddonMessage, PREFIX, "R", "PARTY")
    pcall(C_ChatInfo.SendAddonMessage, PREFIX, "R", "RAID")
    pcall(C_ChatInfo.SendAddonMessage, PREFIX, "R", "INSTANCE_CHAT")
    return true
end

local alertState = {}

function WorldBossTimers:UpdateAlerts()
    local settings = self:GetSettings()
    if not settings.soundEnabled then return end
    local now = GetServerTime()
    for name, boss in pairs(self.BossData) do
        local rec = GetLatestKill(name)
        if rec and tonumber(rec.death) then
            local remaining = tonumber(rec.death) + (tonumber(boss.max_respawn) or 0) - now
            local shouldAlert = remaining > 0 and remaining <= 5
            local saved = settings.showSavedStatus and IsSaved(name)
            if shouldAlert and (settings.alertWhenSaved or not saved) and not alertState[name] then
                alertState[name] = true
                if PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then
                    pcall(PlaySound, SOUNDKIT.RAID_WARNING, "Master")
                elseif PlaySound then
                    pcall(PlaySound, 8959, "Master")
                end
            elseif remaining > 5 or remaining <= 0 then
                alertState[name] = nil
            end
        end
    end
end

local eventFrame = CreateFrame("Frame")
WorldBossTimers._eventFrame = eventFrame

eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "UNIT_DIED" then
        local guid = ...
        local name = WorldBossTimers:GetBossFromGUID(guid, CurrentMapID())
        if name then WorldBossTimers:RecordKill(name, guid) end
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if prefix ~= PREFIX or not message or sender == UnitName("player") then return end
        local kind, name, death, shard, realm = strsplit("\t", message)
        if kind == "R" then
            for bossName, entries in pairs(GetStore().kills) do
                for _, rec in pairs(entries) do
                    if type(rec) == "table" and tonumber(rec.death) and not (tonumber(rec.death) + (WorldBossTimers.BossData[bossName].max_respawn or 0) < GetServerTime()) then
                        WorldBossTimers:SendTimer(bossName, rec, channel, sender)
                    end
                end
            end
        elseif kind == "T" and WorldBossTimers.BossData[name] and tonumber(death) then
            local key = tonumber(shard) and tostring(tonumber(shard)) or "unknown"
            local store = GetStore()
            store.kills[name] = type(store.kills[name]) == "table" and store.kills[name] or {}
            local existing = store.kills[name][key]
            if not existing or tonumber(death) > tonumber(existing.death or 0) then
                store.kills[name][key] = {death = tonumber(death), shard = tonumber(shard), realm = realm}
            end
        end
    end
end)

eventFrame:RegisterEvent("UNIT_DIED")

local tickFrame = CreateFrame("Frame")
tickFrame:SetScript("OnUpdate", function(self, elapsed)
    self._elapsed = (self._elapsed or 0) + elapsed
    if self._elapsed < 1 then return end
    self._elapsed = 0
    WorldBossTimers:UpdateAlerts()
end)

if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
    eventFrame:RegisterEvent("CHAT_MSG_ADDON")
end

WorldBossTimers.FormatClock = FormatClock
