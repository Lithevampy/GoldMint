local ADDON_NAME, GoldMint = ...

-- GoldMint World Quests List data engine.
-- Player-authored only; completely independent of Routines.lua.
GoldMint.ToDoList = GoldMint.ToDoList or {}
local ToDo = GoldMint.ToDoList

local DATA_VERSION = 1
local MAX_TABS = 20
local MAX_CATEGORIES = 200
local MAX_TASKS = 500

local function Now() return time() end
local function Copy(v)
    if type(v) ~= "table" then return v end
    local t = {}
    for k, x in pairs(v) do t[k] = type(x) == "table" and Copy(x) or x end
    return t
end
local function NewID(prefix, store)
    store.nextID = (tonumber(store.nextID) or 0) + 1
    return prefix .. "-" .. tostring(store.nextID)
end

local function EnsureStore()
    GoldMintDB.todoList = type(GoldMintDB.todoList) == "table" and GoldMintDB.todoList or {}
    local s = GoldMintDB.todoList
    s.version = DATA_VERSION
    s.nextID = tonumber(s.nextID) or 0
    s.activeTab = s.activeTab or "daily"
    s.settings = type(s.settings) == "table" and s.settings or {}
    s.settings.theme = s.settings.theme == "clear" and "clear" or "dark"
    s.settings.opacity = tonumber(s.settings.opacity) or 0.96
    s.settings.fontScale = tonumber(s.settings.fontScale) or 1
    s.settings.hideCompleted = s.settings.hideCompleted == true
    s.settings.screenButton = s.settings.screenButton == true
    s.settings.addToTop = s.settings.addToTop == true
    s.settings.openBehavior = s.settings.openBehavior == "LOW" and "LOW" or "DIALOG"
    s.settings.menuSize = (s.settings.menuSize == "SMALL" or s.settings.menuSize == "LARGE") and s.settings.menuSize or "MEDIUM"
    s.tabs = type(s.tabs) == "table" and s.tabs or {}
    if #s.tabs == 0 then
        s.tabs[1] = {id="daily", name="Daily", reset="daily", categories={}}
        s.tabs[2] = {id="weekly", name="Weekly", reset="weekly", categories={}}
    end
    for _, tab in ipairs(s.tabs) do
        tab.id = tab.id or NewID("tab", s)
        tab.name = tab.name or "Tab"
        tab.reset = tab.reset or "none"
        tab.categories = type(tab.categories) == "table" and tab.categories or {}
    end
    local found = false
    for _, tab in ipairs(s.tabs) do if tab.id == s.activeTab then found = true break end end
    if not found then s.activeTab = s.tabs[1].id end
    return s
end

local function GetTab(tabID)
    local s = EnsureStore()
    tabID = tabID or s.activeTab
    for _, tab in ipairs(s.tabs) do if tab.id == tabID then return tab end end
end

local function WalkCategories(categories, fn)
    for _, cat in ipairs(categories or {}) do
        fn(cat)
        WalkCategories(cat.children, fn)
    end
end

local function FindCategory(tab, id)
    local found
    WalkCategories(tab and tab.categories, function(cat) if cat.id == id then found = cat end end)
    return found
end

local function FindTaskInCategories(categories, id)
    local found
    WalkCategories(categories, function(cat)
        for _, task in ipairs(cat.tasks or {}) do if task.id == id then found = task end end
    end)
    return found
end

local function CountTasks(tab)
    local open, complete = 0, 0
    WalkCategories(tab and tab.categories, function(cat)
        for _, task in ipairs(cat.tasks or {}) do
            if task.completed then complete = complete + 1 else open = open + 1 end
        end
    end)
    return open, complete
end

local function ResetCycleKey(secondsUntilReset, periodSeconds)
    if C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset and periodSeconds == 86400 then
        local remain = tonumber(C_DateAndTime.GetSecondsUntilDailyReset()) or 0
        local resetAt = (GetServerTime and GetServerTime() or Now()) + remain
        return tostring(math.floor(resetAt / periodSeconds))
    end
    if C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset and periodSeconds == 604800 then
        local remain = tonumber(C_DateAndTime.GetSecondsUntilWeeklyReset()) or 0
        local resetAt = (GetServerTime and GetServerTime() or Now()) + remain
        return tostring(math.floor(resetAt / periodSeconds))
    end
    return tostring(math.floor(Now() / periodSeconds))
end
local function DayKey() return ResetCycleKey(nil, 86400) end
local function WeekKey() return ResetCycleKey(nil, 604800) end
local function ResetKey(tab)
    if tab.reset == "daily" then return DayKey() end
    if tab.reset == "weekly" then return WeekKey() end
    if tab.reset == "custom" then return tostring(math.floor(Now() / math.max(60, tonumber(tab.resetSeconds) or 86400))) end
    return nil
end

local function TaskResetKey(task)
    if task.reset == "daily" then return DayKey() end
    if task.reset == "weekly" then return WeekKey() end
    if task.reset == "custom" then return tostring(math.floor(Now() / math.max(3600, (tonumber(task.resetHours) or 24)*3600))) end
    return nil
end
local function ResetCompleted(tab)
    if not tab then return end
    local tabKey = ResetKey(tab)
    if tabKey and tab.lastResetKey and tab.lastResetKey ~= tabKey then
        -- Tab-level resets are organizational; task-level reset rules decide which
        -- checklist items actually reset.
    end
    if tabKey then tab.lastResetKey = tabKey end
    WalkCategories(tab.categories, function(cat)
        for _, task in ipairs(cat.tasks or {}) do
            local key = TaskResetKey(task)
            if key and task.lastResetKey and task.lastResetKey ~= key then task.completed = false end
            if key then task.lastResetKey = key end
        end
    end)
end

function ToDo:Ensure()
    local s = EnsureStore()
    for _, tab in ipairs(s.tabs) do ResetCompleted(tab) end
    return s
end
function ToDo:GetSettings() return self:Ensure().settings end
function ToDo:GetTabs() return Copy(self:Ensure().tabs) end
function ToDo:GetActiveTab() return GetTab(self:Ensure().activeTab) end
function ToDo:SetActiveTab(id)
    local s = self:Ensure()
    if GetTab(id) then s.activeTab = id; return true end
    return false
end
function ToDo:AddTab(name, reset)
    local s = self:Ensure(); if #s.tabs >= MAX_TABS then return nil end
    name = strtrim(tostring(name or "")); if name == "" then return nil end
    local tab = {id=NewID("tab", s), name=name, reset=reset or "none", categories={}}
    s.tabs[#s.tabs+1] = tab; s.activeTab = tab.id
    return Copy(tab)
end
function ToDo:EditTab(id, name, reset)
    local tab = GetTab(id); if not tab then return false end
    name = strtrim(tostring(name or tab.name)); if name == "" then return false end
    tab.name = name; tab.reset = reset or tab.reset
    return true
end
function ToDo:RemoveTab(id)
    local s = self:Ensure(); if #s.tabs <= 1 then return false end
    for i, tab in ipairs(s.tabs) do
        if tab.id == id then table.remove(s.tabs, i); if s.activeTab == id then s.activeTab = s.tabs[math.max(1,i-1)].id end; return true end
    end
    return false
end
function ToDo:AddCategory(tabID, name, parentID, color, icon)
    local tab = GetTab(tabID); if not tab then return nil end
    name = strtrim(tostring(name or "")); if name == "" then return nil end
    local count = 0; WalkCategories(tab.categories, function() count = count + 1 end); if count >= MAX_CATEGORIES then return nil end
    local cat = {id=NewID("cat", self:Ensure()), name=name, color=color, icon=icon, tasks={}, children={}}
    local target = parentID and FindCategory(tab, parentID)
    if target then target.children[#target.children+1] = cat else tab.categories[#tab.categories+1] = cat end
    return Copy(cat)
end
function ToDo:EditCategory(tabID, id, fields)
    local cat = FindCategory(GetTab(tabID), id); if not cat then return false end
    fields = fields or {}
    if fields.name and strtrim(fields.name) ~= "" then cat.name = strtrim(fields.name) end
    if fields.color ~= nil then cat.color = fields.color end
    if fields.icon ~= nil then cat.icon = fields.icon end
    return true
end
function ToDo:RemoveCategory(tabID, id)
    local tab = GetTab(tabID); if not tab then return false end
    local function Remove(list)
        for i, cat in ipairs(list or {}) do
            if cat.id == id then table.remove(list, i); return true end
            if Remove(cat.children) then return true end
        end
        return false
    end
    return Remove(tab.categories)
end
function ToDo:AddTask(tabID, categoryID, title, opts)
    local tab = GetTab(tabID); local cat = FindCategory(tab, categoryID); if not cat then return nil end
    title = strtrim(tostring(title or "")); if title == "" then return nil end
    local total = 0; WalkCategories(tab.categories, function(c) total = total + #(c.tasks or {}) end); if total >= MAX_TASKS then return nil end
    opts = opts or {}
    local task = {
        id=NewID("task", self:Ensure()), title=title, description=opts.description,
        completed=false, favorite=opts.favorite == true, color=opts.color, icon=opts.icon,
        reset=opts.reset or "none", resetHours=tonumber(opts.resetHours) or 24, createdAt=Now(), updatedAt=Now(), order=tonumber(opts.order) or (#cat.tasks + 1),
    }
    cat.tasks[#cat.tasks+1] = task
    return Copy(task)
end
function ToDo:EditTask(tabID, taskID, fields)
    local task = FindTaskInCategories(GetTab(tabID) and GetTab(tabID).categories, taskID); if not task then return false end
    fields = fields or {}
    for _, k in ipairs({"title","description","color","icon","reset","resetHours","colorHex"}) do if fields[k] ~= nil then task[k] = fields[k] end end
    if fields.favorite ~= nil then task.favorite = fields.favorite == true end
    if fields.completed ~= nil then task.completed = fields.completed == true end
    task.updatedAt = Now(); return true
end
function ToDo:ToggleTask(tabID, taskID)
    local task = FindTaskInCategories(GetTab(tabID) and GetTab(tabID).categories, taskID); if not task then return false end
    task.completed = not task.completed; task.updatedAt = Now(); return task.completed
end
function ToDo:RemoveTask(tabID, taskID)
    local tab = GetTab(tabID); if not tab then return false end
    local removed = false
    WalkCategories(tab.categories, function(cat)
        for i = #cat.tasks, 1, -1 do if cat.tasks[i].id == taskID then table.remove(cat.tasks, i); removed = true; break end end
    end)
    return removed
end
function ToDo:MoveTask(tabID, taskID, direction)
    local tab = GetTab(tabID); if not tab then return false end
    local task, cat
    WalkCategories(tab.categories, function(c)
        for _, t in ipairs(c.tasks or {}) do if t.id == taskID then task=t; cat=c end end
    end)
    if not task then return false end
    for i, t in ipairs(cat.tasks) do
        if t.id == taskID then
            local j = direction == "up" and i-1 or i+1
            if j >= 1 and j <= #cat.tasks then cat.tasks[i], cat.tasks[j] = cat.tasks[j], cat.tasks[i]; return true end
        end
    end
    return false
end
function ToDo:GetView(tabID)
    local tab = GetTab(tabID) or self:GetActiveTab(); if not tab then return {} end
    ResetCompleted(tab)
    return Copy(tab)
end
function ToDo:GetCounts(tabID)
    local tab = GetTab(tabID) or self:GetActiveTab(); if not tab then return 0,0 end
    return CountTasks(tab)
end
function ToDo:GetAllTasks(tabID)
    local tab = GetTab(tabID) or self:GetActiveTab(); local out={}
    WalkCategories(tab and tab.categories, function(cat) for _, task in ipairs(cat.tasks or {}) do out[#out+1]=Copy(task) end end)
    return out
end
function ToDo:ResetTab(tabID)
    local tab = GetTab(tabID); if not tab then return false end
    WalkCategories(tab.categories, function(cat) for _, task in ipairs(cat.tasks or {}) do if task.reset ~= "none" then task.completed=false end end end)
    tab.lastResetKey = ResetKey(tab); return true
end

-- Compatibility for existing GoldMint surfaces that used the original manual-task API.
local Workflow = GoldMint.WorkflowState
if Workflow then
    function Workflow:GetManualTodos()
        local out = {}
        for _, task in ipairs(ToDo:GetAllTasks()) do out[#out+1] = task end
        table.sort(out, function(a,b) return (a.completed and 1 or 0) < (b.completed and 1 or 0) end)
        return out
    end
    function Workflow:AddManualTodo(title)
        local tab = ToDo:GetActiveTab(); if not tab then return nil end
        local cat = tab.categories[1]
        if not cat then cat = ToDo:AddCategory(tab.id, "General") end
        return ToDo:AddTask(tab.id, cat.id, title)
    end
    function Workflow:ToggleManualTodo(id) return ToDo:ToggleTask(ToDo:GetActiveTab().id, id) end
    function Workflow:RemoveManualTodo(id) return ToDo:RemoveTask(ToDo:GetActiveTab().id, id) end
    function Workflow:ClearCompletedManualTodos()
        local count=0; for _, task in ipairs(ToDo:GetAllTasks()) do if task.completed and ToDo:RemoveTask(ToDo:GetActiveTab().id, task.id) then count=count+1 end end; return count
    end
end
