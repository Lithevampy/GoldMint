local ADDON_NAME, GoldMint = ...

-- GoldMint contextual alert layer.
-- Alerts are intentionally evidence-based: this module only surfaces facts already
-- recorded by WorkflowState (and later feature modules). It never invents mail,
-- auction, loot, or market conditions.

GoldMint.Alerts = {}
local Alerts = GoldMint.Alerts

local MAX_VISIBLE = 4
local MAX_QUEUE = 20
local ALERT_TTL = 18

local queue = {}
local frame
local cards = {}
local initialized = false
local refreshTimer
local Refresh
local loginAlertShown = false
local WELCOME_MIN_GAP = 15 * 60
local previewAlert
local previewSerial = 0

local DEFAULT_POINT = "TOPRIGHT"
local DEFAULT_X = -28
local DEFAULT_Y = -115

local function NotificationAllowed(priority)
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    if GoldMintDB.settings.alertEnabled == false then return false end
    if GoldMintDB.settings.alertMuted == true then return false end
    local mode = GoldMintDB.settings.notificationIntensity or "NORMAL"
    local p = tonumber(priority) or 50
    if mode == "SILENT" then return false end
    if mode == "MINIMAL" then return p >= 85 end
    if mode == "DETAILED" then return true end
    return p >= 35
end

local function Now()
    return GetTime and GetTime() or 0
end

local function RemoveAt(index)
    table.remove(queue, index)
end

local function TrimQueue()
    while #queue > MAX_QUEUE do
        RemoveAt(1)
    end
end

local function FormatGold(copper)
    if GoldMint.Ledger and GoldMint.Ledger.FormatGoldFull then
        return GoldMint.Ledger:FormatGoldFull(copper or 0)
    end
    return tostring(copper or 0)
end

local function GetSettings()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    return GoldMintDB.settings
end

local function ApplyPosition()
    if not frame then return end
    local settings = GetSettings()
    local point = settings.alertPoint or DEFAULT_POINT
    local x = tonumber(settings.alertX) or DEFAULT_X
    local y = tonumber(settings.alertY) or DEFAULT_Y
    frame:ClearAllPoints()
    frame:SetPoint(point, UIParent, point, x, y)
end

local function SavePosition()
    if not frame then return end
    local point, _, _, x, y = frame:GetPoint(1)
    local settings = GetSettings()
    settings.alertPoint = point or DEFAULT_POINT
    settings.alertX = x or DEFAULT_X
    settings.alertY = y or DEFAULT_Y
end

local function IsUnlocked()
    return GetSettings().alertUnlocked == true
end

local function CreateCard(index)
    local card = CreateFrame("Frame", nil, frame)
    card:SetSize(330, 94)

    -- The supplied artwork is the complete card surface. Keep it on the
    -- ARTWORK layer so it is guaranteed to render above the frame surface,
    -- while the title/body/close button remain above it.
    card.art = card:CreateTexture(nil, "ARTWORK", nil, -8)
    card.art:SetAllPoints(card)
    card.art:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\AlertsBackground.tga")
    card.art:SetTexCoord(0, 1, 0, 1)
    card.art:SetVertexColor(1, 1, 1, 1)
    card.art:Show()
    card:SetPoint("TOPRIGHT", 0, -((index - 1) * 102))

    card.title = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    card.title:SetPoint("TOPLEFT", 70, -8)
    card.title:SetWidth(246)
    card.title:SetJustifyH("CENTER")
    card.title:SetTextColor(1.0, 0.82, 0.25)
    card.title:SetShadowColor(0, 0, 0, 0.95)
    card.title:SetShadowOffset(1, -1)

    card.body = card:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    card.body:SetPoint("TOPLEFT", 72, -30)
    card.body:SetPoint("RIGHT", -12, 0)
    card.body:SetHeight(56)
    card.body:SetJustifyH("CENTER")
    card.body:SetJustifyV("TOP")
    card.body:SetTextColor(0.96, 0.96, 0.96)
    card.body:SetShadowColor(0, 0, 0, 0.95)
    card.body:SetShadowOffset(1, -1)

    card.close = CreateFrame("Button", nil, card, "BackdropTemplate")
    card.close:SetSize(22, 22)
    card.close:SetPoint("TOPRIGHT", -7, -7)
    card.close:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    card.close:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
    card.close:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
    card.close.text = card.close:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    card.close.text:SetPoint("CENTER")
    card.close.text:SetText("×")
    card.close.text:SetTextColor(0.60, 0.74, 0.88)
    card.close:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
        self:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
        self.text:SetTextColor(1.0, 0.86, 0.38)
    end)
    card.close:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        self:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
        self.text:SetTextColor(0.60, 0.74, 0.88)
    end)
    card.close:SetScript("OnClick", function()
        if card.alertID then
            Alerts:Dismiss(card.alertID)
        end
    end)

    cards[index] = card
    return card
end

local function StopRefreshTimer()
    if refreshTimer and refreshTimer.Cancel then
        refreshTimer:Cancel()
    end
    refreshTimer = nil
end

local function ScheduleRefreshTimer()
    if refreshTimer or #queue == 0 or not (C_Timer and C_Timer.NewTimer) then return end
    refreshTimer = C_Timer.NewTimer(1.0, function()
        refreshTimer = nil
        Refresh()
    end)
end

function Refresh()
    if not frame then return end

    local now = Now()
    for i = #queue, 1, -1 do
        local alert = queue[i]
        if alert.expiresAt and alert.expiresAt <= now then
            RemoveAt(i)
        end
    end

    if #queue == 0 then
        StopRefreshTimer()
    end

    local unlockedPreview = (#queue == 0 and IsUnlocked() and not previewAlert)
    local shouldCaptureMouse = (#queue > 0) or previewAlert or unlockedPreview
    if shouldCaptureMouse then
        frame:EnableMouse(true)
        frame:Show()
    else
        frame:EnableMouse(false)
        frame:Hide()
    end
    for index = 1, MAX_VISIBLE do
        local card = cards[index] or CreateCard(index)
        local alert = queue[index]
        if alert then
            card.alertID = alert.id
            card.title:ClearAllPoints()
            card.title:SetPoint("TOPLEFT", 70, -8)
            card.title:SetWidth(246)
            card.title:SetJustifyH("CENTER")
            card.title:SetTextColor(1.0, 0.82, 0.25)
            card.title:SetText(alert.title or "GoldMint")
            card.body:SetTextColor(0.96, 0.96, 0.96)
            card.body:SetText(alert.body or "")
            card:Show()
        elseif previewAlert and index == 1 then
            card.alertID = nil
            card.title:ClearAllPoints()
            card.title:SetPoint("TOPLEFT", 70, -8)
            card.title:SetWidth(246)
            card.title:SetJustifyH("CENTER")
            card.title:SetText(previewAlert.title or "GoldMint — Alert Preview")
            card.body:SetText(previewAlert.body or "")
            card:Show()
        elseif unlockedPreview and index == 1 then
            card.alertID = nil
            -- Unlock mode shows a clean positioning preview.
            card.title:ClearAllPoints()
            card.title:SetPoint("TOPLEFT", 70, -8)
            card.title:SetWidth(246)
            card.title:SetJustifyH("CENTER")
            card.title:SetText("GoldMint — Alert Preview")
            card.body:SetText("")
            card:Show()
        else
            card.alertID = nil
            card:Hide()
        end
    end

    if #queue > 0 then
        ScheduleRefreshTimer()
    end
end

local function EnsureFrame()
    if frame then return end

    frame = CreateFrame("Frame", "GoldMintAlertFrame", UIParent)
    frame:SetSize(330, MAX_VISIBLE * 102)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        if IsUnlocked() then self:StartMoving() end
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SavePosition()
    end)
    ApplyPosition()
    -- This container must never intercept world clicks while there is no visible
    -- alert.  The alert cards are children of this frame, so leaving the empty
    -- parent mouse-enabled would create an invisible click-blocking rectangle
    -- over the game world.
    frame:EnableMouse(false)
    frame:Hide()

    -- Alert expiry only needs periodic work while there are visible/queued alerts.
    -- Use a one-shot timer so the alert layer is completely idle when empty.
    initialized = true
end

function Alerts:Initialize()
    EnsureFrame()
    initialized = true
    return true
end

function Alerts:Preview(kind)
    EnsureFrame()
    local previews = {
        valuable = {
            title = "VALUABLE LOOT",
            body = "Azure Silk Robe x1\n125g unit • 125g total\nAbove your value threshold",
        },
        transmog = {
            title = "NEW TRANSMOG",
            body = "Runecloth Cowl x1\n42g unit • 42g total\nAppearance not collected",
        },
        cooldown = {
            title = "COOLDOWN READY",
            body = "Alchemy cooldown is ready.\nCraft your most profitable available recipe.",
        },
        nextSuggestion = {
            title = "NEXT SUGGESTION",
            body = "Review your current farming task.\nGoldMint has a new workflow suggestion ready.",
        },
        welcomeBack = {
            title = "WELCOME BACK",
            body = "No unfinished task recorded.\nGoal: Current Gold Goal • 91%\nMethod: Craft Broad Salt\nNext: Continue toward your goal.",
        },
    }
    local preview = previews[kind]
    if not preview then return false end
    previewSerial = previewSerial + 1
    local serial = previewSerial
    previewAlert = { title = preview.title, body = preview.body }
    Refresh()
    if C_Timer and C_Timer.After then
        C_Timer.After(8, function()
            if serial == previewSerial then
                previewAlert = nil
                Refresh()
            end
        end)
    end
    return true
end

function Alerts:ClearPreview()
    previewSerial = previewSerial + 1
    previewAlert = nil
    Refresh()
end

function Alerts:SetUnlocked(unlocked)
    GetSettings().alertUnlocked = unlocked == true
    EnsureFrame()
    Refresh()
end

function Alerts:IsUnlocked()
    return IsUnlocked()
end

function Alerts:ResetPosition()
    local settings = GetSettings()
    settings.alertPoint = nil
    settings.alertX = nil
    settings.alertY = nil
    EnsureFrame()
    ApplyPosition()
end

function Alerts:Push(title, body, options)
    EnsureFrame()
    options = type(options) == "table" and options or {}
    if not NotificationAllowed(options.priority) then return false end

    local id = options.id or ("alert-" .. tostring(time()) .. "-" .. tostring(math.random(1000, 9999)))
    local alert = {
        id = tostring(id),
        title = tostring(title or "GoldMint"),
        body = tostring(body or ""),
        createdAt = time(),
        expiresAt = Now() + (tonumber(options.ttl) or ALERT_TTL),
        priority = tonumber(options.priority) or 50,
        category = options.category,
    }

    for i = #queue, 1, -1 do
        if queue[i].id == alert.id then
            RemoveAt(i)
        end
    end

    if options.dedupeKey then
        for i = #queue, 1, -1 do
            if queue[i].dedupeKey == options.dedupeKey then
                RemoveAt(i)
            end
        end
        alert.dedupeKey = tostring(options.dedupeKey)
    end

    queue[#queue + 1] = alert
    if options.sound ~= false and GoldMint.Sounds and GoldMint.Sounds.Play then
        GoldMint.Sounds:Play("alert")
    end
    table.sort(queue, function(a, b)
        if a.priority ~= b.priority then return a.priority > b.priority end
        return (a.createdAt or 0) > (b.createdAt or 0)
    end)
    TrimQueue()
    Refresh()
    ScheduleRefreshTimer()
    return alert
end

function Alerts:Dismiss(alertID)
    if not alertID then return false end
    alertID = tostring(alertID)
    for i = #queue, 1, -1 do
        if tostring(queue[i].id) == alertID then
            RemoveAt(i)
            Refresh()
            ScheduleRefreshTimer()
            return true
        end
    end
    return false
end

function Alerts:Clear()
    queue = {}
    StopRefreshTimer()
    Refresh()
end

function Alerts:GetAll()
    local result = {}
    for _, alert in ipairs(queue) do
        result[#result + 1] = alert
    end
    return result
end

function Alerts:GetCount()
    return #queue
end

function Alerts:Evaluate(reason)
    EnsureFrame()
    if not GoldMint.WorkflowState then return false end

    local state = GoldMint.WorkflowState:GetWelcomeBackState()
    if not state then return false end

    local added = false
    local task = state.task
    local nextAction = state.nextAction
    local lastSession = state.lastSession
    local reminders = state.reminders or {}

    -- On login, give the player one compact "where was I?" card, but only when
    -- this is actually a return to the game rather than a quick /reload. The
    -- last welcome time is persisted so the accessibility layer stays helpful
    -- without becoming another source of notification clutter.
    if reason == "login" and not loginAlertShown then
        loginAlertShown = true
        local settings = GoldMintDB.settings
        settings = type(settings) == "table" and settings or {}
        GoldMintDB.settings = settings
        local now = time()
        local lastWelcomeAt = tonumber(settings.lastWelcomeBackAt) or 0
        local returning = (lastWelcomeAt <= 0) or ((now - lastWelcomeAt) >= WELCOME_MIN_GAP)

        if returning and (lastSession or task or nextAction or #reminders > 0) then
            local body = ""
            if task then
                body = "Current task: " .. tostring(task.title)
            elseif lastSession and lastSession.lastTask then
                body = "Last task: " .. tostring(lastSession.lastTask.title)
            else
                body = "No unfinished task recorded."
            end

            local chain = GoldMint.Accessibility
                and GoldMint.Accessibility.GetGoalWorkflowSummary
                and GoldMint.Accessibility:GetGoalWorkflowSummary()
            if chain and chain.hasGoal and chain.goal then
                local pct = math.floor(math.max(0, math.min(1, tonumber(chain.progress) or 0)) * 100 + 0.5)
                body = body .. "\nGoal: " .. tostring(chain.goal.name or "Active goal") .. " • " .. tostring(pct) .. "%"
                if chain.method then
                    body = body .. "\nMethod: " .. tostring(chain.method.title or chain.method.method or "Choose method")
                end
            end

            if nextAction then
                body = body .. "\nNext: " .. tostring(nextAction.title)
            elseif lastSession and lastSession.nextAction then
                body = body .. "\nNext: " .. tostring(lastSession.nextAction.title)
            end

            self:Push("WELCOME BACK", body, {
                id = "welcome-back-" .. tostring(GoldMint.characterKey or "character") .. "-" .. tostring(now),
                dedupeKey = "welcome-back",
                priority = 100,
                ttl = 18,
                category = "workflow",
            })
            settings.lastWelcomeBackAt = now
            added = true
        elseif returning then
            -- Even when there is no workflow to surface, record the visit so a
            -- later /reload during the same play session remains quiet.
            settings.lastWelcomeBackAt = now
        end
    end

    -- The welcome-back card is the single login-level accessibility summary.
    -- Do not immediately stack reminder/mail/logistics cards on top of it; the
    -- dashboard contains the full detail and workflow remains available.
    local compactWelcomeShown = added and reason == "login"

    -- A reminder deserves its own actionable-looking card, but only when one exists.
    if #reminders > 0 and (reason == "workflow" or reason == "reminder" or (reason == "login" and not compactWelcomeShown)) then
        local reminder = reminders[1]
        local text = tostring(reminder.text or "Reminder")
        if reminder.dueAt and tonumber(reminder.dueAt) then
            text = text .. "\nDue: " .. date("%Y-%m-%d %H:%M", tonumber(reminder.dueAt))
        end
        self:Push("REMINDER", text, {
            id = "reminder-" .. tostring(reminder.id),
            dedupeKey = "reminder-" .. tostring(reminder.id),
            priority = 90,
            ttl = 24,
            category = "reminder",
        })
        added = true
    end

    -- Mail is surfaced only from an observed mailbox scan. This keeps the alert
    -- factual: a persisted inbox snapshot is never treated as live mail data.
    if GoldMint.MailTracking and reason == "mail-received" then
        local mail = GoldMint.MailTracking:GetSummary()
        if mail and mail.lastScanAt and mail.lastScanAt > 0 then
            local parts = {}
            if (mail.attachmentCount or 0) > 0 then
                parts[#parts + 1] = tostring(mail.attachmentCount) .. " item(s)"
            end
            if (mail.moneyTotal or 0) > 0 then
                parts[#parts + 1] = FormatGold(mail.moneyTotal) .. " attached"
            end
            if (mail.internalCount or 0) > 0 then
                parts[#parts + 1] = tostring(mail.internalCount) .. " from known characters"
            end
            if #parts == 0 and (mail.mailCount or 0) > 0 then
                parts[#parts + 1] = tostring(mail.mailCount) .. " message(s)"
            end
            if #parts > 0 then
                self:Push("MAIL", table.concat(parts, "\n"), {
                    id = "mail-summary-" .. tostring(GoldMint.characterKey or "character"),
                    dedupeKey = "mail-summary",
                    priority = 85,
                    ttl = 22,
                    category = "mail",
                })
                added = true
            end
        end
    end

    -- When a next action is explicitly recorded during play, surface it as a
    -- dedicated suggestion alert. The setting is separate from the global toast
    -- switch so players can keep other GoldMint notifications while silencing
    -- workflow suggestions.
    if nextAction and (reason == "workflow-next" or reason == "workflow") then
        local settings = GoldMintDB.settings or {}
        if settings.nextSuggestionAlert ~= false then
            self:Push("NEXT SUGGESTION", tostring(nextAction.title) .. (nextAction.details and "\n" .. tostring(nextAction.details) or ""), {
                id = "next-suggestion-" .. tostring(nextAction.updatedAt or nextAction.title),
                dedupeKey = "next-suggestion",
                priority = 80,
                ttl = 20,
                category = "workflow",
            })
            added = true
        end
    end

    -- Mail/Auction Logistics turns observed backend state into one compact
    -- accessibility prompt. It never claims an auction should be posted unless
    -- GoldMint has actually observed a sellable candidate in the player's bags.
    if GoldMint.Logistics and (reason == "logistics" or (reason == "login" and not compactWelcomeShown) or reason == "workflow") then
        local summary = GoldMint.Logistics:GetSummary()
        if summary then
            if (summary.pendingMail or 0) > 0 then
                self:Push("MAIL DELIVERY", string.format("%d outgoing mail item(s) are still waiting for delivery to be observed.", summary.pendingMail), {
                    id = "logistics-mail-delivery", dedupeKey = "logistics-mail-delivery",
                    priority = 75, ttl = 24, category = "logistics",
                })
                added = true
            -- Auction posting candidates are intentionally NOT surfaced as
            -- gameplay toasts. They remain available in the Dashboard/Logistics
            -- page, but they should never interrupt farming or looting.
            end
        end
    end

    return added
end

function Alerts:ShowSessionPulse()
    if not GoldMint.Ledger or not GoldMint.Ledger.session then return false end
    local session = GoldMint.Ledger.session
    local net = tonumber(session.netGold) or 0
    if net == 0 then return false end

    self:Push("SESSION", string.format("%s net\n%s / hr", net >= 0 and "+" .. FormatGold(net) or "-" .. FormatGold(math.abs(net)), FormatGold(session.goldPerHour or 0)), {
        id = "session-pulse",
        dedupeKey = "session-pulse",
        priority = 35,
        ttl = 8,
        category = "economy",
    })
    return true
end

function Alerts:ShowNextSuggestion(action)
    if type(action) ~= "table" or not action.title then return false end
    local settings = GoldMintDB.settings or {}
    if settings.nextSuggestionAlert == false then return false end
    return self:Push("NEXT SUGGESTION", tostring(action.title) .. (action.details and "\n" .. tostring(action.details) or ""), {
        id = "next-suggestion-" .. tostring(action.updatedAt or action.title),
        dedupeKey = "next-suggestion",
        priority = 80,
        ttl = 20,
        category = "workflow",
    }) ~= false
end

function Alerts:Toggle()
    EnsureFrame()
    if #queue > 0 then
        self:Clear()
    else
        self:Evaluate("workflow")
    end
end
