local ADDON_NAME, addon = ...

local GoldMint = addon or {}
_G[ADDON_NAME] = GoldMint

GoldMint.VERSION = "0.5.62-beta-504"
GoldMint.DB_VERSION = 50

local eventFrame = CreateFrame("Frame")
GoldMint._eventFrame = eventFrame
GoldMint._lifecycleGeneration = GoldMint._lifecycleGeneration or 0

-- Runtime containment: addon module failures should be isolated so one bad
-- callback cannot escape into Blizzard UI/event dispatch or abort unrelated
-- scheduled work.
function GoldMint:SafeCall(label, fn, ...)
    if type(fn) ~= "function" then return false end
    local args = {...}
    local ok, err = xpcall(function()
        return fn(unpack(args))
    end, function(message)
        return debugstack and debugstack(2, 8, 8) or tostring(message)
    end)
    if not ok and self.Print then
        self.Print("GoldMint " .. tostring(label or "callback") .. " failed safely.")
    end
    return ok
end

function GoldMint:ScheduleGuardedCallback(owner, key, delay, fn, isAlive)
    owner = owner or self
    owner._callbackGeneration = owner._callbackGeneration or {}
    local generation = (owner._callbackGeneration[key] or 0) + 1
    owner._callbackGeneration[key] = generation
    local lifecycle = self._lifecycleGeneration or 0
    C_Timer.After(delay or 0, function()
        if self._lifecycleGeneration ~= lifecycle then return end
        if owner._callbackGeneration[key] ~= generation then return end
        if isAlive and not isAlive() then return end
        self:SafeCall(key, fn)
    end)
    return generation
end

function GoldMint:IsMerchantOpen()
    return self._merchantOpen == true
        or (MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown()) == true
end

-- Bag opening/closing is a latency-sensitive UI operation.  Do not perform
-- GoldMint's inventory/valuation work while Blizzard's bag UI is visible.
-- Those scans can call item/tooltip APIs for dozens or hundreds of slots and
-- all execute on WoW's main thread.  Queue the settled refresh for after the
-- player closes the bags instead.
function GoldMint:IsBagUIOpen()
    if ContainerFrameCombinedBags and ContainerFrameCombinedBags.IsShown
        and ContainerFrameCombinedBags:IsShown() then
        return true
    end
    if ContainerFrame1 and ContainerFrame1.IsShown and ContainerFrame1:IsShown() then
        return true
    end
    if ContainerFrame2 and ContainerFrame2.IsShown and ContainerFrame2:IsShown() then
        return true
    end
    if ContainerFrame3 and ContainerFrame3.IsShown and ContainerFrame3:IsShown() then
        return true
    end
    if ContainerFrame4 and ContainerFrame4.IsShown and ContainerFrame4:IsShown() then
        return true
    end
    if ContainerFrame5 and ContainerFrame5.IsShown and ContainerFrame5:IsShown() then
        return true
    end
    return false
end

function GoldMint:ScheduleBagRefresh(delay)
    if self._bagRefreshPending then return end
    self._bagRefreshPending = true
    self._bagRefreshGeneration = (self._bagRefreshGeneration or 0) + 1
    local generation = self._bagRefreshGeneration
    self:ScheduleGuardedCallback(self, "consolidated bag refresh", delay or 0.30, function()
        if generation ~= self._bagRefreshGeneration then return end
        self._bagRefreshPending = false
        if self:IsMerchantOpen() then return end
        if self:IsCraftSimActive() then
            -- CraftSim owns the hot profession/bag workflow while its profession
            -- frame is open.  Defer GoldMint's consolidated inventory/economy
            -- pass until the profession closes instead of doing the same work
            -- in the middle of CraftSim's recalculation cycle.
            self._bagRefreshAfterProfession = true
            return
        end
        if self:IsBagUIOpen() then
            -- Keep the inventory dirty, but absolutely do not scan while the
            -- bag UI is animating/open. BAG_CLOSED will request the refresh.
            self._bagRefreshPending = false
            return
        end

        -- Bag changes only mark inventory as stale. Do NOT scan bags here.
        -- The Live Inventory panel owns its scan and the user explicitly starts
        -- it with SCAN BAGS. This keeps Baganator/Syndicator inventory bursts
        -- from causing GoldMint to walk every bag in the background.
        if self.Logistics and self.Logistics.Refresh then
            self.Logistics:Refresh("bags")
        end
        if self.Accessibility and self.Accessibility.PrepareSmartDump then
            local store = GoldMintDB and GoldMintDB.accessibility
            if store and store.mail and store.mail.enabled then
                self.Accessibility:PrepareSmartDump()
            end
        end
        -- Item-duration tooltips are intentionally NOT scanned here.  The
        -- item-duration snapshot is captured once when bags are opened; doing
        -- it again on BAG_UPDATE_DELAYED/BAG_CLOSED would defeat that design.
        if self.Economy then
            self.Economy:ScheduleRefresh("bags")
        end
        if self.Milestones and self.Milestones.CaptureSnapshot then
            self.Milestones:CaptureSnapshot(false)
        end
        if self.Dashboard then
            self.Dashboard._inventoryData = nil
            self.Dashboard._inventoryDirty = true
            if self.Dashboard.Refresh and self.Dashboard.IsShown and self.Dashboard:IsShown() then
                self.Dashboard:Refresh()
            end
        end
    end)
end

function GoldMint:SchedulePostMerchantRefresh(delay)
    if self._postMerchantRefreshPending then return end
    self._postMerchantRefreshPending = true
    self:ScheduleGuardedCallback(self, "post-merchant refresh", delay or 0.60, function()
            self._postMerchantRefreshPending = false
        if self:IsMerchantOpen() then return end

        -- Do not automatically scan bags after closing a merchant. Inventory
        -- scans are user initiated from the Live Inventory panel.
        if self.Logistics and self.Logistics.Refresh then
            self.Logistics:Refresh("merchant_closed")
        end
        -- Smart-Dump may have been dirtied by bag events that occurred while
        -- the merchant was open. Rebuild it once against the settled inventory.
        if self.Accessibility and self.Accessibility.PrepareSmartDump then
            local store = GoldMintDB and GoldMintDB.accessibility
            if store and store.mail and store.mail.enabled then
                self.Accessibility:PrepareSmartDump()
            end
        end
        if self.Economy then
            self.Economy:Refresh("merchant_closed")
        end
        if self.Milestones and self.Milestones.CaptureSnapshot then
            self.Milestones:CaptureSnapshot(false)
        end
        if self.Dashboard and self.Dashboard.Refresh then
            self.Dashboard:Refresh()
        end
    end)
end

local recipeScanPending = false
local lastRecipeScanAt = 0
local lastRecipeSkillLineID = nil
local professionWasVisible = false

-- Dashboard status for the automatic profession scan.  This is informational
-- only; the scan itself remains driven by the profession window lifecycle.
GoldMint.CraftingAutoScan = GoldMint.CraftingAutoScan or {}
GoldMint.CraftingAutoScan.lastScanned = nil

local function HandleLootOpenedTrend()
    if GoldMint.Ledger and GoldMint.Ledger.RecordLootGoldTrend then
        -- LOOT_OPENED is the authoritative point at which automatic gold loot
        -- is visible. Record the current character balance only when loot is
        -- actually opened; ordinary PLAYER_MONEY changes do not feed the trend.
        local moneyBefore = GoldMint.Ledger.session and GoldMint.Ledger.session.lastGold or nil
        local moneyNow = type(GetMoney) == "function" and GetMoney() or nil
        if moneyBefore and moneyNow and moneyNow > moneyBefore then
            GoldMint.Ledger:RecordLootGoldTrend()
        else
            -- Some client paths update PLAYER_MONEY before LOOT_OPENED. Inspect
            -- the loot window for an actual money slot before recording.
            local hasMoney = false
            if GetNumLootItems and GetLootSlotType and LOOT_SLOT_MONEY then
                for i = 1, GetNumLootItems() do
                    if GetLootSlotType(i) == LOOT_SLOT_MONEY then
                        hasMoney = true
                        break
                    end
                end
            end
            if hasMoney then
                GoldMint.Ledger:RecordLootGoldTrend()
            end
        end
    end
end

local function BeginMerchantTrend()
    if GoldMint.Ledger and GoldMint.Ledger.BeginMerchantTrendContext then
        GoldMint.Ledger:BeginMerchantTrendContext()
    end
end

local function EndMerchantTrend()
    if GoldMint.Ledger and GoldMint.Ledger.EndMerchantTrendContext then
        GoldMint.Ledger:EndMerchantTrendContext()
    end
end

local function GetOpenProfessionKey()
    if not C_TradeSkillUI then
        return nil
    end

    -- Midnight's profession UI uses the modern base/child profession APIs.
    -- GetTradeSkillLine() is not reliable for detecting the open ProfessionsFrame.
    if C_TradeSkillUI.GetBaseProfessionInfo then
        local base = C_TradeSkillUI.GetBaseProfessionInfo()
        if base and base.professionID then
            local child = C_TradeSkillUI.GetChildProfessionInfo and C_TradeSkillUI.GetChildProfessionInfo() or nil
            return (child and child.professionID) or base.professionID
        end
    end

    if C_TradeSkillUI.GetTradeSkillLine then
        local skillLineID = C_TradeSkillUI.GetTradeSkillLine()
        return skillLineID
    end

    return nil
end

local function IsProfessionFrameVisible()
    return ProfessionsFrame and ProfessionsFrame.IsShown and ProfessionsFrame:IsShown()
end

-- External profession/auction addons can react to the same Blizzard events as
-- GoldMint.  CraftSim, in particular, listens to profession and bag changes,
-- while Auctionator listens heavily to auction/search result events.  GoldMint
-- should not compete with those addons during their active UI workflows.
local function IsAddOnLoadedSafe(name)
    if C_AddOns and type(C_AddOns.IsAddOnLoaded) == "function" then
        local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, name)
        if ok then return loaded == true end
    elseif type(IsAddOnLoaded) == "function" then
        local ok, loaded = pcall(IsAddOnLoaded, name)
        if ok then return loaded == true end
    end
    return false
end

function GoldMint:IsCraftSimActive()
    return IsAddOnLoadedSafe("CraftSim") and IsProfessionFrameVisible()
end

function GoldMint:IsAuctionatorActive()
    local ahOpen = AuctionHouseFrame and AuctionHouseFrame.IsShown and AuctionHouseFrame:IsShown()
    return IsAddOnLoadedSafe("Auctionator") and ahOpen == true
end

function GoldMint:IsExternalEconomyUIBusy()
    return self:IsCraftSimActive() or self:IsAuctionatorActive()
end

local function RefreshDashboardAfterProfessionScan()
    if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
        GoldMint.Dashboard:Refresh()
    end
end

local function ScheduleRecipeScan()
    if recipeScanPending or not GoldMint.Recipes or not IsProfessionFrameVisible() then
        return
    end

    local skillLineID = GetOpenProfessionKey()
    if not skillLineID then
        return
    end

    local now = GetTime()
    -- Reopening the same profession should not rescan the entire recipe book.
    -- Blizzard can fire several profession-selection/open callbacks while the
    -- window settles, so keep the automatic scan quiet for one minute.
    if lastRecipeSkillLineID == skillLineID and now - lastRecipeScanAt < 60 then
        return
    end

    recipeScanPending = true
    GoldMint:ScheduleGuardedCallback(GoldMint, "recipe scan", 1.00, function()
        recipeScanPending = false

        if not IsProfessionFrameVisible() or not GoldMint.Recipes then
            return
        end

        local currentSkillLineID = GetOpenProfessionKey()
        if not currentSkillLineID or currentSkillLineID ~= skillLineID then
            return
        end

        -- Automatic profession opening scans ONLY the profession currently shown
        -- in Blizzard's profession UI.  Do not switch expansion/child skill lines
        -- in the background: Midnight's live UI can reject those selections and
        -- that caused the old variant pass to repeatedly fail while the window
        -- remained open.  The established variant scanner remains available for
        -- explicit/manual recipe scans.
        local scanned, learned, profession = GoldMint.Recipes:ScanCurrentProfession()
        scanned = tonumber(scanned) or 0
        learned = tonumber(learned) or 0

        -- Do not start the expansion-variant scanner automatically here.
        -- Midnight's live profession window can reject child-skill-line changes
        -- while it is opening, which produced the misleading
        -- "profession-variant-start failed safely" message.  The currently
        -- opened profession is scanned above; the explicit recipe-scan command
        -- remains available for a full historical/variant pass.

        -- Do not repaint the whole GoldMint dashboard here. Profession scans are
        -- data work only. Rebuilding the Operations page during crafting can
        -- allocate hundreds of UI objects and is a major source of CPU/memory
        -- churn. The visible Crafting page will refresh when the player opens it.
        -- If Home is currently visible, a single lightweight dashboard refresh is
        -- useful for its profession summary; otherwise there is nothing to paint.
        if GoldMint.Dashboard and GoldMint.Dashboard.IsShown and GoldMint.Dashboard:GetActiveNavKey() == "dashboard" then
            GoldMint:SafeCall("dashboard profession summary refresh", RefreshDashboardAfterProfessionScan)
        end

        -- Record the scan even when zero recipes are currently exposed. This
        -- prevents the OnUpdate safety net from retrying the same profession
        -- every half-second while Blizzard is still displaying an empty state.
        lastRecipeScanAt = GetTime()
        lastRecipeSkillLineID = currentSkillLineID
        GoldMint.CraftingAutoScan = GoldMint.CraftingAutoScan or {}
        GoldMint.CraftingAutoScan.lastScanned = {
            totalScanned = scanned,
            totalKnown = learned,
            profession = profession,
            at = GetTime(),
        }
    end)
end

local function OnProfessionOpened()
    professionWasVisible = true
    if GoldMint.WorkflowState then
        GoldMint.WorkflowState:TouchActivity("profession", "Working in a profession")
    end
    ScheduleRecipeScan()
end

local function OnProfessionClosed()
    professionWasVisible = false
    recipeScanPending = false
    if GoldMint._bagRefreshAfterProfession then
        GoldMint._bagRefreshAfterProfession = false
        GoldMint:ScheduleBagRefresh(0.75)
    end
    if GoldMint.Economy and GoldMint.Economy._refreshAfterProfession then
        GoldMint.Economy._refreshAfterProfession = false
        GoldMint.Economy:ScheduleRefresh("profession_closed", 0.50)
    end
end

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff7fd8ffGoldMint|r: " .. tostring(msg))
end

GoldMint.Print = Print

function GoldMint:GetCharacterKey()
    local name = UnitName("player") or "Unknown"
    local realm = (GetNormalizedRealmName and GetNormalizedRealmName()) or GetRealmName() or "Unknown"
    return realm .. "-" .. name, name, realm
end

function GoldMint:GetGoldMakingGuild()
    local settings = type(GoldMintDB) == "table" and type(GoldMintDB.settings) == "table" and GoldMintDB.settings or nil
    local selected = settings and settings.goldMakingGuild
    if type(selected) ~= "table" or not selected.name or selected.name == "" then
        return nil
    end
    return {name = selected.name, realm = selected.realm or "Unknown"}
end

function GoldMint:IsCharacterInGoldMakingGuild(characterKey)
    local selected = self:GetGoldMakingGuild()
    if not selected then return false end
    local character = self.CharacterTracking and self.CharacterTracking:Get(characterKey) or nil
    if not character then return false end
    return string.lower(tostring(character.guildName or "")) == string.lower(tostring(selected.name or ""))
        and string.lower(tostring(character.guildRealm or character.realm or "")) == string.lower(tostring(selected.realm or ""))
end

function GoldMint:InitializeDB()
    -- GoldMintDB is declared in the TOC as a SavedVariable. WoW restores it
    -- before PLAYER_LOGIN, so this table survives logout, /reload, and
    -- character changes. Never replace an existing table here: the recipe
    -- database is intentionally cumulative across the account.
    if type(GoldMintDB) ~= "table" then
        GoldMintDB = {}
    end

    local previousVersion = tonumber(GoldMintDB.version) or 0
    GoldMintDB.version = self.DB_VERSION
    GoldMintDB.characters = type(GoldMintDB.characters) == "table" and GoldMintDB.characters or {}
    GoldMintDB.sessions = type(GoldMintDB.sessions) == "table" and GoldMintDB.sessions or {}
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    if GoldMintDB.settings.dashboardLocked == nil then GoldMintDB.settings.dashboardLocked = false end
    if GoldMintDB.settings.minimapButtonShown == nil then GoldMintDB.settings.minimapButtonShown = true end
    if GoldMintDB.settings.minimapButtonAngle == nil then GoldMintDB.settings.minimapButtonAngle = 45 end
    if GoldMintDB.settings.goldMakingGuild == nil then GoldMintDB.settings.goldMakingGuild = nil end
    GoldMintDB.recipes = type(GoldMintDB.recipes) == "table" and GoldMintDB.recipes or {}
    GoldMintDB.craftingQueue = type(GoldMintDB.craftingQueue) == "table" and GoldMintDB.craftingQueue or {}
    GoldMintDB.recipeSpellIndex = type(GoldMintDB.recipeSpellIndex) == "table" and GoldMintDB.recipeSpellIndex or {}
    GoldMintDB.market = type(GoldMintDB.market) == "table" and GoldMintDB.market or {}
    GoldMintDB.cooldowns = type(GoldMintDB.cooldowns) == "table" and GoldMintDB.cooldowns or {}
    GoldMintDB.economy = type(GoldMintDB.economy) == "table" and GoldMintDB.economy or {}
    GoldMintDB.valuation = type(GoldMintDB.valuation) == "table" and GoldMintDB.valuation or {}
    GoldMintDB.milestones = type(GoldMintDB.milestones) == "table" and GoldMintDB.milestones or {}
    GoldMintDB.lootAlerts = type(GoldMintDB.lootAlerts) == "table" and GoldMintDB.lootAlerts or {}
    GoldMintDB.accessibility = type(GoldMintDB.accessibility) == "table" and GoldMintDB.accessibility or {}
    GoldMintDB.workflowState = type(GoldMintDB.workflowState) == "table" and GoldMintDB.workflowState or {}
    GoldMintDB.mailTracking = type(GoldMintDB.mailTracking) == "table" and GoldMintDB.mailTracking or {}
    GoldMintDB.farmTracker = type(GoldMintDB.farmTracker) == "table" and GoldMintDB.farmTracker or {}
    GoldMintDB.logistics = type(GoldMintDB.logistics) == "table" and GoldMintDB.logistics or {}
    GoldMintDB.dailyLedger = type(GoldMintDB.dailyLedger) == "table" and GoldMintDB.dailyLedger or {}
    GoldMintDB.worldBossTimers = type(GoldMintDB.worldBossTimers) == "table" and GoldMintDB.worldBossTimers or {}
    GoldMintDB.rareRecipeAlerts = type(GoldMintDB.rareRecipeAlerts) == "table" and GoldMintDB.rareRecipeAlerts or {}
    GoldMintDB.dailyLedger.history = type(GoldMintDB.dailyLedger.history) == "table" and GoldMintDB.dailyLedger.history or {}

    -- Database migrations are deliberately small, idempotent, and data-preserving.
    -- Never replace user data just because the addon version changed.
    local schemaVersion = tonumber(GoldMintDB.schemaVersion) or previousVersion or 0

    -- v39: normalize fields introduced by the correctness/performance passes.
    -- Older sessions did not persist sourceTotals; keep the historical record
    -- intact and simply provide an empty breakdown for old sessions.
    if schemaVersion < 39 then
        for _, session in ipairs(GoldMintDB.sessions) do
            if type(session) == "table" and type(session.sourceTotals) ~= "table" then
                session.sourceTotals = {}
            end
        end

        -- New valuation containers are optional and are populated by scans. Do
        -- not fabricate values for containers that have never been observed.
        if type(GoldMintDB.valuation) ~= "table" then
            GoldMintDB.valuation = {}
        end
        GoldMintDB.valuation.characters = type(GoldMintDB.valuation.characters) == "table"
            and GoldMintDB.valuation.characters or {}
        GoldMintDB.valuation.accountBank = type(GoldMintDB.valuation.accountBank) == "table"
            and GoldMintDB.valuation.accountBank or {}
        GoldMintDB.valuation.guildBanks = type(GoldMintDB.valuation.guildBanks) == "table"
            and GoldMintDB.valuation.guildBanks or {}

        if type(GoldMintDB.market) ~= "table" then
            GoldMintDB.market = {}
        end
        GoldMintDB.market.fullScan = type(GoldMintDB.market.fullScan) == "table"
            and GoldMintDB.market.fullScan or {}
    end

    -- v40: compact legacy collections at load time. Runtime writers already
    -- enforce their limits, but older SavedVariables can predate those guards.
    -- Keep the newest records and never discard the current character.
    if schemaVersion < 40 then
        local function TrimNewestFirst(list, maxCount)
            if type(list) ~= "table" then return {} end
            while #list > maxCount do
                table.remove(list, 1)
            end
            return list
        end

        GoldMintDB.sessions = TrimNewestFirst(GoldMintDB.sessions, 30)
        GoldMintDB.milestones.history = TrimNewestFirst(
            type(GoldMintDB.milestones.history) == "table" and GoldMintDB.milestones.history or {}, 180
        )

        local workflow = GoldMintDB.workflowState
        if type(workflow) == "table" then
            workflow.history = TrimNewestFirst(type(workflow.history) == "table" and workflow.history or {}, 50)
            workflow.reminders = TrimNewestFirst(type(workflow.reminders) == "table" and workflow.reminders or {}, 50)
            if type(workflow.characters) == "table" then
                for _, character in pairs(workflow.characters) do
                    if type(character) == "table" and type(character.history) == "table" then
                        character.history = TrimNewestFirst(character.history, 50)
                    end
                end
            end
        end
    end

    -- v41: API compatibility hardening did not require data migration.
    -- v42: event payload/ordering hardening is also runtime-only.
    -- v43: protected/profession API hardening is runtime-only.
    -- v44: normalize nested SavedVariable containers before modules consume them.
    -- A single malformed child table must never cascade into another module.
    if schemaVersion < 44 then
        local function EnsureTable(parent, key)
            if type(parent[key]) ~= "table" then
                parent[key] = {}
            end
            return parent[key]
        end

        local market = EnsureTable(GoldMintDB, "market")
        EnsureTable(market, "items")
        EnsureTable(market, "matrix")
        EnsureTable(market, "ownedAuctionsByCharacter")
        EnsureTable(market, "activeAuctionsByCharacter")
        EnsureTable(market, "salesByItem")
        EnsureTable(market, "salesSeen")
        EnsureTable(market, "tokenHistory")
        EnsureTable(market, "fullScan")
        EnsureTable(market, "characterPools")
        EnsureTable(market.fullScan, "lastQueue")

        local valuation = EnsureTable(GoldMintDB, "valuation")
        EnsureTable(valuation, "containers")
        EnsureTable(valuation, "characters")
        EnsureTable(valuation, "accountBank")
        EnsureTable(valuation, "guildBanks")
        EnsureTable(valuation, "scanState")

        local cooldowns = EnsureTable(GoldMintDB, "cooldowns")
        EnsureTable(cooldowns, "recipes")
        EnsureTable(cooldowns, "tracking")

        local workflow = EnsureTable(GoldMintDB, "workflowState")
        EnsureTable(workflow, "characters")
        EnsureTable(workflow, "history")
        EnsureTable(workflow, "reminders")
        EnsureTable(workflow, "current")
        EnsureTable(workflow, "lastSession")

        local mail = EnsureTable(GoldMintDB, "mailTracking")
        EnsureTable(mail, "characters")

        local logistics = EnsureTable(GoldMintDB, "logistics")
        EnsureTable(logistics, "outgoing")
        EnsureTable(logistics, "auctionCandidates")

        local accessibility = EnsureTable(GoldMintDB, "accessibility")
        EnsureTable(accessibility, "mail")
        EnsureTable(accessibility.mail, "queue")
        EnsureTable(accessibility, "stretch")
        EnsureTable(accessibility, "tags")
        EnsureTable(accessibility, "notes")

        local milestones = EnsureTable(GoldMintDB, "milestones")
        EnsureTable(milestones, "goals")
        EnsureTable(milestones, "snapshots")
        EnsureTable(milestones, "history")

        local lootAlerts = EnsureTable(GoldMintDB, "lootAlerts")
        EnsureTable(lootAlerts, "history")
        EnsureTable(lootAlerts, "pending")
        EnsureTable(lootAlerts, "settings")

        local recipes = EnsureTable(GoldMintDB, "recipes")
        local recipeIndex = EnsureTable(GoldMintDB, "recipeSpellIndex")
        -- Keep these references explicit so malformed top-level values are
        -- repaired once at load rather than repeatedly by individual modules.
        _ = recipes
        _ = recipeIndex
    end

    -- v47: persist the last successful Market material pool per character so
    -- the Market page can restore known data after a reload without requiring
    -- another Auction House/profession scan.
    if schemaVersion < 47 then
        local market = GoldMintDB.market
        if type(market.characterPools) ~= "table" then market.characterPools = {} end
        if type(market.fullScan) ~= "table" then market.fullScan = {} end
        if type(market.fullScan.lastQueue) ~= "table" then market.fullScan.lastQueue = {} end
    end

    -- v50: runtime market-data retention is handled incrementally by Market.lua.
    -- Do not walk a large market database during login; that would trade memory
    -- savings for a login-time CPU spike. The Market module performs a guarded,
    -- sliced cleanup after the UI is settled.

    -- v49: compact Market's historical/deduplication data. Older builds could
    -- accumulate a very large salesSeen map and 60 observations per item/source.
    -- Keep the useful recent history while bounding SavedVariables memory. This
    -- is data-preserving for current values; only old redundant observations and
    -- expired auction IDs are discarded.
    if schemaVersion < 49 then
        local market = GoldMintDB.market
        local function TrimHistory(history, maxCount)
            if type(history) ~= "table" then return end
            while #history > maxCount do table.remove(history, 1) end
        end
        for _, record in pairs(type(market.items) == "table" and market.items or {}) do
            if type(record) == "table" then
                if type(record.ah) == "table" then TrimHistory(record.ah.history, 30) end
                if type(record.tsm) == "table" then TrimHistory(record.tsm.history, 30) end
            end
        end
        for _, record in pairs(type(market.salesByItem) == "table" and market.salesByItem or {}) do
            if type(record) == "table" then TrimHistory(record.history, 50) end
        end
        local seen = type(market.salesSeen) == "table" and market.salesSeen or {}
        local cutoff = time() - (45 * 86400)
        local keys = {}
        for key, stamp in pairs(seen) do
            if tonumber(stamp) and tonumber(stamp) < cutoff then
                seen[key] = nil
            else
                keys[#keys + 1] = {key = key, stamp = tonumber(stamp) or 0}
            end
        end
        if #keys > 10000 then
            table.sort(keys, function(a,b) return a.stamp < b.stamp end)
            local removeCount = #keys - 10000
            for i = 1, removeCount do seen[keys[i].key] = nil end
        end
        market.salesSeen = seen
    end

    GoldMintDB.schemaVersion = self.DB_VERSION

    local key, name, realm = self:GetCharacterKey()
    self.characterKey = key
    self.characterName = name
    self.characterRealm = realm

    -- Mark the current character as active before other systems begin reading
    -- the shared character database. CharacterTracking is a presentation/data
    -- facade only; the existing character records remain authoritative.
    if self.CharacterTracking then
        self.CharacterTracking:MarkAllInactive()
    end

    GoldMintDB.characters[key] = GoldMintDB.characters[key] or {
        name = name,
        realm = realm,
        gold = 0,
        lastSeen = 0,
        level = UnitLevel("player") or 0,
    }

    local character = GoldMintDB.characters[key]
    character.name = name
    character.realm = realm
    character.level = UnitLevel("player") or character.level or 0
    character.lastSeen = time()

    self.db = GoldMintDB

    if self.CharacterTracking then
        self.CharacterTracking:SyncCurrent()
        self.CharacterTracking:PruneOldRecords()
    end
end

function GoldMint:OnLogin()
    self._lifecycleGeneration = (self._lifecycleGeneration or 0) + 1
    self:InitializeDB()

    -- Show the command-center hint when GoldMint finishes logging in.
    -- This is intentionally a login message rather than a one-time account
    -- message, so it is still visible when returning to the game later.
    C_Timer.After(2.0, function()
        if GoldMint and GoldMint.Print then
            GoldMint.Print("Welcome to GoldMint! Type /gm hub to see commands for opening the Dashboard, To-Do List, and Farming Tracker.")
        end
    end)

    if self.ToDoList and self.ToDoList.Ensure then
        self.ToDoList:Ensure()
    end

    -- Initialize the dashboard UI before creating the minimap button.
    -- The minimap button is intentionally independent of the dashboard's
    -- visibility, so it must exist even while the main window is hidden.
    if self.Dashboard then
        if self.Dashboard.Initialize then
            self.Dashboard:Initialize()
        end
        if self.Dashboard.BuildMinimapButton then
            C_Timer.After(0.1, function()
                if self.Dashboard and self.Dashboard.BuildMinimapButton then
                    self.Dashboard:BuildMinimapButton()
                    if self.FarmTracker and self.FarmTracker.Reanchor then
                        self.FarmTracker:Reanchor()
                    end
                end
            end)
        end
    end
    if self.Ledger and self.Ledger.UpdateWarbandGold then
        self.Ledger:UpdateWarbandGold()
    end
    self.Ledger:BeginSession()

    if self.Market then
        self.Market:Initialize()
    end

    if self.Valuation then
        self.Valuation:Initialize()
    end

    if self.Economy then
        self.Economy:Initialize()
    end

    if self.Milestones then
        self.Milestones:Initialize()
    end

    if self.LootAlerts then
        self.LootAlerts:Initialize()
    end

    if self.Accessibility then
        self.Accessibility:Initialize()
    end

    if self.Cooldowns then
        self.Cooldowns:Initialize()
    end

    if self.Routines then
        self.Routines:Initialize()
    end

    if self.ContentProgression then
        self.ContentProgression:Initialize()
    end

    if self.RoutineState then
        self.RoutineState:Initialize()
    end

    if self.WorkflowState then
        self.WorkflowState:OnCharacterContextReady()
    end

    if self.MailTracking then
        self.MailTracking:Initialize()
    end

    if self.Logistics then
        self.Logistics:Initialize()
    end

    if self.Alerts then
        self.Alerts:Initialize()
        C_Timer.After(1.0, function()
            if GoldMint.Alerts then
                GoldMint.Alerts:Evaluate("login")
            end
        end)
    end

    if self.RareRecipeAlerts then
        self.RareRecipeAlerts:Initialize()
    end

    if self.CharacterTracking then
        self.CharacterTracking:Initialize()
    end

    if self.Hub then
        self.Hub:Initialize()
    end

    if self.TaskPopout then
        self.TaskPopout:Initialize()
        local settings = GoldMintDB and GoldMintDB.settings
        if settings and settings.taskPopoutEnabled == true then
            C_Timer.After(1.2, function()
                if GoldMint.TaskPopout then
                    GoldMint.TaskPopout:Show()
                end
            end)
        end
    end

    -- The modern profession UI is driven by EventRegistry callbacks rather than
    -- the legacy TRADE_SKILL_SHOW event. Register both the callback and a frame
    -- hook so GoldMint works across UI loading orders.
    if EventRegistry then
        EventRegistry:RegisterCallback("ProfessionsFrame.Show", function()
            OnProfessionOpened()
        end, self)
        EventRegistry:RegisterCallback("ProfessionsFrame.Hide", function()
            OnProfessionClosed()
        end, self)
        EventRegistry:RegisterCallback("Professions.ProfessionSelected", function()
            OnProfessionOpened()
        end, self)
        EventRegistry:RegisterCallback("ProfessionsFrame.TabSet", function()
            if IsProfessionFrameVisible() then
                ScheduleRecipeScan()
            end
        end, self)
    end

    if ProfessionsFrame and ProfessionsFrame.HookScript then
        ProfessionsFrame:HookScript("OnShow", OnProfessionOpened)
        ProfessionsFrame:HookScript("OnHide", OnProfessionClosed)
    end
end

function GoldMint:OnLogout()
    self._lifecycleGeneration = (self._lifecycleGeneration or 0) + 1

    -- Force the active farming session to SavedVariables on logout. Normal
    -- farming updates are intentionally throttled, but logout is a final
    -- persistence boundary and should never discard the last few seconds.
    if self.FarmTracker and self.FarmTracker.SaveActiveSession then
        self.FarmTracker:SaveActiveSession(true)
    end
    if self.WorkflowState and self.Ledger and self.Ledger.session then
        local session = self.Ledger.session
        self.WorkflowState:RecordSessionSummary({
            startedAt = session.startedAtWall,
            endedAt = time(),
            startingGold = session.startingGold,
            endingGold = session.endingGold,
            netGold = session.netGold,
            income = session.income,
            spending = session.spending,
            goldPerHour = session.goldPerHour,
            velocityGoldPerHour = session.velocityGoldPerHour or 0,
            transferIn = session.transferIn or 0,
            transferOut = session.transferOut or 0,
            goldMakingGuild = session.goldMakingGuild,
            goldMakingGuildActive = session.goldMakingGuildActive == true,
            sourceTotals = session.sourceTotals or {},
            transactions = session.transactions or {},
        })
    end

    if self.Ledger then
        self.Ledger:EndSession()
    end
end

function GoldMint:OnTradeSkillShow()
    OnProfessionOpened()
end

function GoldMint:OnTradeSkillClose()
    OnProfessionClosed()
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    GoldMint:SafeCall("event " .. tostring(event), function(...)
    if event == "PLAYER_LOGIN" then
        GoldMint:OnLogin()
    elseif event == "PLAYER_LOGOUT" then
        GoldMint:OnLogout()
    elseif event == "MERCHANT_SHOW" then
        GoldMint._merchantOpen = true
        BeginMerchantTrend()
        if GoldMint.Ledger then GoldMint.Ledger:SetTransactionContext("Vendor", 3600) end
    elseif event == "MERCHANT_CLOSED" then
        GoldMint._merchantOpen = false
        EndMerchantTrend()
        if GoldMint.Ledger then GoldMint.Ledger:ClearTransactionContext("Vendor") end
        -- Let the merchant UI finish closing before any inventory/economy work.
        GoldMint:SchedulePostMerchantRefresh(0.60)
    elseif event == "LOOT_OPENED" then
        if GoldMint.Ledger then GoldMint.Ledger:SetTransactionContext("Looted Gold", 1.5) end
        HandleLootOpenedTrend()
        -- Loot can fire in bursts. Avoid rebuilding the full Economy/Dashboard
        -- synchronously here; PLAYER_MONEY/BAG_UPDATE_DELAYED and the normal
        -- Economy ticker already keep those surfaces current.
    elseif event == "PLAYER_MONEY" then
        if GoldMint.WorkflowState then
            GoldMint.WorkflowState:TouchActivity("money", "Managing gold")
        end
        if GoldMint.Ledger then
            -- Refresh the shared Warband balance before comparing wallet deltas.
            -- Character <-> Warbank transfers can update PLAYER_MONEY before the
            -- account-bank slot event, so relying only on the cached balance can
            -- temporarily classify an internal transfer as income/spending.
            if GoldMint.Ledger.UpdateWarbandGold then
                GoldMint.Ledger:UpdateWarbandGold()
            end
            GoldMint.Ledger:UpdateCharacterGold()
        end
        -- The farming tracker owns its own session baseline. Feed the
        -- authoritative PLAYER_MONEY value directly into it instead of relying
        -- on a UI refresh to discover the wallet change. This keeps gold
        -- tracking working even when the tracker window is hidden.
        if GoldMint.FarmTracker then
            local currentMoney = type(GetMoney) == "function" and (tonumber(GetMoney()) or 0) or 0
            if GoldMint.FarmTracker.RecordMoneyChange then
                GoldMint.FarmTracker:RecordMoneyChange(currentMoney, "PLAYER_MONEY")
            end
        end
        if GoldMint.Economy then
            if GoldMint:IsMerchantOpen() then
                GoldMint._moneyEconomyRefreshPending = true
            else
                GoldMint.Economy:ScheduleRefresh("money")
            end
        end
    elseif event == "BAG_OPEN" then
        -- Capture item-duration tooltips once per bag-opening session.  BAG_OPEN
        -- can fire for several individual bags, so schedule only one snapshot
        -- and let the short delay allow Blizzard to finish populating them.
        GoldMint._bagsWereOpened = true
        GoldMint._itemDurationBagScanScheduled = GoldMint._itemDurationBagScanScheduled or false
        if not GoldMint._itemDurationBagScanScheduled then
            GoldMint._itemDurationBagScanScheduled = true
            GoldMint._itemDurationBagScanGeneration = (GoldMint._itemDurationBagScanGeneration or 0) + 1
            local generation = GoldMint._itemDurationBagScanGeneration
            C_Timer.After(0.25, function()
                if generation ~= GoldMint._itemDurationBagScanGeneration then return end
                if GoldMint.Cooldowns and GoldMint.Cooldowns.ScanItemCooldowns then
                    GoldMint.Cooldowns:ScanItemCooldowns(true, {Bags = true})
                end
                if GoldMint.Dashboard and GoldMint.Dashboard.Refresh and GoldMint.Dashboard:IsShown() then
                    GoldMint.Dashboard:Refresh()
                end
            end)
        end
        if GoldMint.WorkflowState then
            GoldMint.WorkflowState:TouchActivity("bags", "Managing bags")
        end
    elseif event == "BAG_CLOSED" then
        GoldMint._bagsWereOpened = false
        GoldMint._itemDurationBagScanScheduled = false
        GoldMint._itemDurationBagScanGeneration = (GoldMint._itemDurationBagScanGeneration or 0) + 1
        -- The normal consolidated inventory refresh still happens after the
        -- bags close, but it no longer performs another item-duration tooltip scan.
        GoldMint:ScheduleBagRefresh(0.90)
    elseif event == "BAG_UPDATE_DELAYED" then
        if GoldMint.WorkflowState then
            GoldMint.WorkflowState:TouchActivity("bags", "Managing bags")
        end
        GoldMint:ScheduleBagRefresh(0.75)
    elseif event == "BANKFRAME_OPENED" then
        if GoldMint.Ledger and GoldMint.Ledger.UpdateWarbandGold then
            GoldMint.Ledger:UpdateWarbandGold()
        end
        if GoldMint.WorkflowState then
            GoldMint.WorkflowState:TouchActivity("bank", "Managing bank items")
        end
        if GoldMint.Economy then
            GoldMint.Economy:ScheduleRefresh("bank_open")
        end
    elseif event == "PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED" then
        -- Blizzard updates the shared Warband balance as the account-bank UI
        -- changes. Refresh the cached balance here, rather than from ordinary
        -- wallet/dashboard reads.
        if GoldMint.Ledger and GoldMint.Ledger.UpdateWarbandGold then
            GoldMint.Ledger:UpdateWarbandGold()
        end
        if GoldMint.Economy then
            GoldMint.Economy:ScheduleRefresh("account_bank")
        end
    elseif event == "MAIL_SHOW" then
        if GoldMint.Ledger then GoldMint.Ledger:SetTransactionContext("Mail Received", 3600) end
        if GoldMint.MailTracking then
            GoldMint.MailTracking:OnMailShow()
        end
    elseif event == "MAIL_INBOX_UPDATE" then
        if GoldMint.MailTracking then
            GoldMint.MailTracking:OnMailInboxUpdate()
        end
    elseif event == "UPDATE_PENDING_MAIL" then
        if GoldMint.MailTracking then
            GoldMint.MailTracking:OnPendingMailUpdate()
        end
    elseif event == "MAIL_CLOSED" then
        if GoldMint.Ledger then GoldMint.Ledger:ClearTransactionContext("Mail Received") end
        if GoldMint.MailTracking then
            GoldMint.MailTracking:OnMailClosed()
        end
    elseif event == "AUCTION_HOUSE_CLOSED" then
        if GoldMint.Economy and GoldMint.Economy._refreshAfterAuctionHouse then
            GoldMint.Economy._refreshAfterAuctionHouse = false
            GoldMint.Economy:ScheduleRefresh("auction_house_closed", 0.50)
        end
    elseif event == "AUCTION_HOUSE_SHOW" then
        if GoldMint.Ledger then GoldMint.Ledger:SetTransactionContext("Auction House", 3600) end
        if GoldMint.WorkflowState then
            GoldMint.WorkflowState:TouchActivity("auction-house", "Working at the Auction House")
        end
        if GoldMint.Economy then
            GoldMint.Economy:ScheduleRefresh("auction_house")
        end
        if GoldMint.Alerts then
            GoldMint.Alerts:Evaluate("workflow")
        end
    elseif event == "TRADE_SHOW" then
        if GoldMint.Ledger then
            GoldMint.Ledger:SetTransactionContext("Trade", 3600)
            if GoldMint.Ledger.BeginTradeTracking then GoldMint.Ledger:BeginTradeTracking() end
        end
    elseif event == "TRADE_CLOSED" then
        if GoldMint.Ledger then
            -- Keep the snapshot through the wallet update so PLAYER_MONEY can
            -- attribute the gold change even after the trade window closes.
            if GoldMint.Ledger.EndTradeTracking then
                local snapshot = GoldMint.Ledger._tradeSnapshot
                GoldMint.Ledger._lastTradeSnapshot = snapshot
                GoldMint:ScheduleGuardedCallback(GoldMint.Ledger, "trade snapshot cleanup", 2, function()
                    if GoldMint.Ledger then GoldMint.Ledger._lastTradeSnapshot = nil end
                end, function() return GoldMint.Ledger ~= nil end)
            end
            GoldMint.Ledger:ClearTransactionContext("Trade")
        end
    elseif event == "QUEST_TURNED_IN" or event == "QUEST_COMPLETE" then
        if GoldMint.Ledger then
            local questIDValue = select(1, ...)
            local questID = tonumber(questIDValue)
            local questTitle
            if questID and C_QuestLog and type(C_QuestLog.GetTitleForQuestID) == "function" then
                local ok, title = pcall(C_QuestLog.GetTitleForQuestID, questID)
                if ok then questTitle = title end
            end
            -- QUEST_COMPLETE is a UI-state event and does not carry a questID.
            -- Do not replace a more precise QUEST_TURNED_IN context with a
            -- nameless context that could misattribute a later PLAYER_MONEY event.
            if questID or event == "QUEST_TURNED_IN" then
                GoldMint.Ledger:SetTransactionContext("Quest Reward", 3, {
                    questID = questID,
                    questTitle = questTitle,
                    event = event,
                    confidence = questID and "quest-event" or "quest-complete",
                })
            end
        end
    elseif event == "GUILD_ROSTER_UPDATE" or event == "PLAYER_GUILD_UPDATE" then
        if GoldMint.CharacterTracking then
            GoldMint.CharacterTracking:SyncCurrent()
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        -- Flush background work that was deliberately deferred during combat.
        if GoldMint.Economy then
            GoldMint.Economy:ScheduleRefresh("post_combat", 0.20)
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- Periodic modules independently check combat state before doing work.
        -- This event is intentionally a lightweight marker only.
    elseif event == "PLAYER_ENTERING_WORLD" then
        if GoldMint.Ledger and GoldMint.Ledger.UpdateWarbandGold then
            GoldMint.Ledger:UpdateWarbandGold()
        end
        if GoldMint.CharacterTracking then
            GoldMint.CharacterTracking:SyncCurrent()
        end
        if GoldMint.Economy then
            GoldMint.Economy:ScheduleRefresh("world")
        end
    elseif event == "TRADE_SKILL_SHOW" then
        GoldMint:OnTradeSkillShow()
    elseif event == "TRADE_SKILL_CLOSE" then
        GoldMint:OnTradeSkillClose()
    end
    end, ...)
end)

eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_GUILD_UPDATE")
eventFrame:RegisterEvent("GUILD_ROSTER_UPDATE")
eventFrame:RegisterEvent("PLAYER_LOGOUT")
eventFrame:RegisterEvent("PLAYER_MONEY")
eventFrame:RegisterEvent("MERCHANT_SHOW")
eventFrame:RegisterEvent("MERCHANT_CLOSED")
eventFrame:RegisterEvent("LOOT_OPENED")
eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
eventFrame:RegisterEvent("BAG_OPEN")
eventFrame:RegisterEvent("BAG_CLOSED")
eventFrame:RegisterEvent("BANKFRAME_OPENED")
eventFrame:RegisterEvent("PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED")
eventFrame:RegisterEvent("MAIL_SHOW")
eventFrame:RegisterEvent("MAIL_INBOX_UPDATE")
eventFrame:RegisterEvent("UPDATE_PENDING_MAIL")
eventFrame:RegisterEvent("MAIL_CLOSED")
eventFrame:RegisterEvent("AUCTION_HOUSE_SHOW")
eventFrame:RegisterEvent("AUCTION_HOUSE_CLOSED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
eventFrame:RegisterEvent("TRADE_SKILL_SHOW")
eventFrame:RegisterEvent("TRADE_SKILL_CLOSE")
eventFrame:RegisterEvent("TRADE_SHOW")
eventFrame:RegisterEvent("TRADE_CLOSED")
eventFrame:RegisterEvent("QUEST_TURNED_IN")
eventFrame:RegisterEvent("QUEST_COMPLETE")

-- Profession visibility is event-driven. The modern ProfessionsFrame callbacks and
-- OnShow/OnHide hooks registered during initialization handle transitions without
-- a background polling timer.

