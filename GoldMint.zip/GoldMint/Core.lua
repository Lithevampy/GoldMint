local ADDON_NAME, addon = ...

local GoldMint = addon or {}
_G[ADDON_NAME] = GoldMint

GoldMint.VERSION = "0.5.86-beta"
GoldMint.DB_VERSION = 50

-- Shared lightweight chat output. Some UI modules call GoldMint.Print directly
-- during onboarding and normal dashboard actions, so keep this available before
-- any module is initialized.
function GoldMint.Print(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99GoldMint|r " .. tostring(message or ""))
    elseif type(print) == "function" then
        print("GoldMint " .. tostring(message or ""))
    end
end

local eventFrame = CreateFrame("Frame")
GoldMint._eventFrame = eventFrame
GoldMint._lifecycleGeneration = GoldMint._lifecycleGeneration or 0

-- Runtime containment: addon module failures should be isolated so one bad
-- callback cannot escape into Blizzard UI/event dispatch or abort unrelated
-- scheduled work.
function GoldMint:SafeCall(label, fn, ...)
    if type(fn) ~= "function" then return false end
    local args = {...}
    local ok, err = xpcall(function()
        return fn(unpack(args))
    end, function(message)
        return debugstack and debugstack(2, 8, 8) or tostring(message)
    end)
    if not ok and self.Print then
        self.Print("GoldMint " .. tostring(label or "callback") .. " failed safely.")
    end
    return ok
end

function GoldMint:ScheduleGuardedCallback(owner, key, delay, fn, isAlive)
    owner = owner or self
    owner._callbackGeneration = owner._callbackGeneration or {}
    local generation = (owner._callbackGeneration[key] or 0) + 1
    owner._callbackGeneration[key] = generation
    local lifecycle = self._lifecycleGeneration or 0
    C_Timer.After(delay or 0, function()
        if self._lifecycleGeneration ~= lifecycle then return end
        if owner._callbackGeneration[key] ~= generation then return end
        if isAlive and not isAlive() then return end
        self:SafeCall(key, fn)
    end)
    return generation
end

function GoldMint:IsMerchantOpen()
    return self._merchantOpen == true
        or (MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown()) == true
end

local function HandleLootOpenedTrend()
    if GoldMint.Ledger and GoldMint.Ledger.RecordLootGoldTrend then
        -- LOOT_OPENED is the authoritative point at which automatic gold loot
        -- is visible. Record the current character balance only when loot is
        -- actually opened; ordinary PLAYER_MONEY changes do not feed the trend.
        local moneyBefore = GoldMint.Ledger.session and GoldMint.Ledger.session.lastGold or nil
        local moneyNow = type(GetMoney) == "function" and GetMoney() or nil
        if moneyBefore and moneyNow and moneyNow > moneyBefore then
            GoldMint.Ledger:RecordLootGoldTrend()
        else
            -- Some client paths update PLAYER_MONEY before LOOT_OPENED. Inspect
            -- the loot window for an actual money slot before recording.
            local hasMoney = false
            if GetNumLootItems and GetLootSlotType and LOOT_SLOT_MONEY then
                for i = 1, GetNumLootItems() do
                    if GetLootSlotType(i) == LOOT_SLOT_MONEY then
                        hasMoney = true
                        break
                    end
                end
            end
            if hasMoney then
                GoldMint.Ledger:RecordLootGoldTrend()
            end
        end
    end
end

local function BeginMerchantTrend()
    if GoldMint.Ledger and GoldMint.Ledger.BeginMerchantTrendContext then
        GoldMint.Ledger:BeginMerchantTrendContext()
    end
end

local function EndMerchantTrend()
    if GoldMint.Ledger and GoldMint.Ledger.EndMerchantTrendContext then
        GoldMint.Ledger:EndMerchantTrendContext()
    end
end

-- Return the stable per-character key used by all GoldMint SavedVariables.
-- Keep this in Core so it is available during PLAYER_LOGIN before any optional
-- feature module is initialized.
function GoldMint:GetCharacterKey()
    local name = (type(UnitName) == "function" and UnitName("player")) or "Unknown"
    local realm = nil
    if type(GetNormalizedRealmName) == "function" then
        realm = GetNormalizedRealmName()
    end
    if not realm or realm == "" then
        realm = (type(GetRealmName) == "function" and GetRealmName()) or "Unknown"
    end
    if not realm or realm == "" then realm = "Unknown" end

    return tostring(name) .. "-" .. tostring(realm), tostring(name), tostring(realm)
end

function GoldMint:InitializeDB()
    -- GoldMintDB is declared in the TOC as a SavedVariable. WoW restores it
    -- before PLAYER_LOGIN, so this table survives logout, /reload, and
    -- character changes. Never replace an existing table here: the recipe
    -- database is intentionally cumulative across the account.
    if type(GoldMintDB) ~= "table" then
        GoldMintDB = {}
    end

    local previousVersion = tonumber(GoldMintDB.version) or 0
    GoldMintDB.version = self.DB_VERSION
    GoldMintDB.characters = type(GoldMintDB.characters) == "table" and GoldMintDB.characters or {}
    GoldMintDB.sessions = type(GoldMintDB.sessions) == "table" and GoldMintDB.sessions or {}
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    if GoldMintDB.settings.dashboardLocked == nil then GoldMintDB.settings.dashboardLocked = false end
    if GoldMintDB.settings.minimapButtonShown == nil then GoldMintDB.settings.minimapButtonShown = true end
    if GoldMintDB.settings.minimapButtonAngle == nil then GoldMintDB.settings.minimapButtonAngle = 45 end
    if GoldMintDB.settings.goldMakingGuild == nil then GoldMintDB.settings.goldMakingGuild = nil end
    -- Market, crafting, and inventory/valuation data are intentionally retired.
    -- Nil them so WoW stops serializing the old datasets on the next logout.
    GoldMintDB.market = nil
    GoldMintDB.recipes = nil
    GoldMintDB.craftingQueue = nil
    GoldMintDB.recipeSpellIndex = nil
    GoldMintDB.crafting = nil
    GoldMintDB.valuation = nil
    GoldMintDB.economy = nil
    GoldMintDB.logistics = nil
    GoldMintDB.cooldowns = type(GoldMintDB.cooldowns) == "table" and GoldMintDB.cooldowns or {}
    GoldMintDB.milestones = type(GoldMintDB.milestones) == "table" and GoldMintDB.milestones or {}
    GoldMintDB.lootAlerts = type(GoldMintDB.lootAlerts) == "table" and GoldMintDB.lootAlerts or {}
    GoldMintDB.accessibility = type(GoldMintDB.accessibility) == "table" and GoldMintDB.accessibility or {}
    GoldMintDB.workflowState = type(GoldMintDB.workflowState) == "table" and GoldMintDB.workflowState or {}
    GoldMintDB.mailTracking = type(GoldMintDB.mailTracking) == "table" and GoldMintDB.mailTracking or {}
    GoldMintDB.farmTracker = type(GoldMintDB.farmTracker) == "table" and GoldMintDB.farmTracker or {}
    GoldMintDB.dailyLedger = type(GoldMintDB.dailyLedger) == "table" and GoldMintDB.dailyLedger or {}
    GoldMintDB.worldBossTimers = type(GoldMintDB.worldBossTimers) == "table" and GoldMintDB.worldBossTimers or {}
    GoldMintDB.rareRecipeAlerts = type(GoldMintDB.rareRecipeAlerts) == "table" and GoldMintDB.rareRecipeAlerts or {}
    GoldMintDB.dailyLedger.history = type(GoldMintDB.dailyLedger.history) == "table" and GoldMintDB.dailyLedger.history or {}

    -- Legacy migrations which walked Market/session history are intentionally no longer
    -- performed during login. The retired Market database is discarded above, while
    -- lightweight schema containers are created lazily by the modules which use them.

    GoldMintDB.schemaVersion = self.DB_VERSION

    local key, name, realm = self:GetCharacterKey()
    self.characterKey = key
    self.characterName = name
    self.characterRealm = realm

    -- Mark the current character as active before other systems begin reading
    -- the shared character database. CharacterTracking is a presentation/data
    -- facade only; the existing character records remain authoritative.
    if self.CharacterTracking then
        self.CharacterTracking:MarkAllInactive()
    end

    GoldMintDB.characters[key] = GoldMintDB.characters[key] or {
        name = name,
        realm = realm,
        gold = 0,
        lastSeen = 0,
        level = UnitLevel("player") or 0,
    }

    local character = GoldMintDB.characters[key]
    character.name = name
    character.realm = realm
    character.level = UnitLevel("player") or character.level or 0
    character.lastSeen = time()

    self.db = GoldMintDB

    if self.CharacterTracking then
        self.CharacterTracking:SyncCurrent()
        self.CharacterTracking:PruneOldRecords()
    end
end

function GoldMint:LoadAddon(addonName)
    if type(addonName) ~= "string" or addonName == "" then
        return false
    end

    -- GoldMint is distributed as one addon folder now. The former
    -- GoldMint_Features, GoldMint_Ledger, GoldMint_UI, and GoldMint_Commands
    -- addons are internal modules, so their old lazy-load calls simply resolve
    -- to the already-loaded GoldMint addon. Keeping this compatibility shim
    -- avoids having to rewrite every command/UI call site.
    if addonName == ADDON_NAME
        or addonName == "GoldMint_Features"
        or addonName == "GoldMint_Ledger"
        or addonName == "GoldMint_UI"
        or addonName == "GoldMint_Commands" then
        return true
    end

    if C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded(addonName) then
        return true
    end
    local loader = C_AddOns and C_AddOns.LoadAddOn or LoadAddOn
    if type(loader) ~= "function" then
        return false
    end
    local ok = pcall(loader, addonName)
    return ok and ((not C_AddOns) or (not C_AddOns.IsAddOnLoaded) or C_AddOns.IsAddOnLoaded(addonName))
end

function GoldMint:BuildLightweightMinimapButton()
    if not Minimap then return nil end

    local settings = GoldMintDB and GoldMintDB.settings or {}
    local button = self._lightMinimapButton

    if not button then
        button = CreateFrame("Button", "GoldMintMinimapButton", UIParent)
        button:SetSize(48, 48)
        button:SetFrameStrata("HIGH")
        button:SetFrameLevel(100)
        button:SetClampedToScreen(true)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
        button:RegisterForDrag("LeftButton")

        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintMinimap.tga")
        icon:SetAllPoints(button)
        icon:SetTexCoord(0, 1, 0, 1)
        button._icon = icon

        button:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")

        button._dragging = false
        button._moved = false
        button._startX = 0
        button._startY = 0

        local function Position()
            if not Minimap or not button then return end
            local angle = math.rad(tonumber(GoldMintDB and GoldMintDB.settings and GoldMintDB.settings.minimapButtonAngle) or 45)
            local mapSize = tonumber(Minimap:GetWidth()) or 176
            local radius = (mapSize * 0.5) + 30
            button:ClearAllPoints()
            button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
        end
        button._position = Position

        button:SetScript("OnMouseDown", function(self, click)
            if click ~= "LeftButton" then return end
            local x, y = GetCursorPosition()
            local scale = UIParent:GetEffectiveScale()
            self._startX, self._startY = x / scale, y / scale
            self._moved = false
            self._dragging = true
        end)

        button:SetScript("OnUpdate", function(self)
            if not self._dragging or not IsMouseButtonDown("LeftButton") or not Minimap then return end
            local x, y = GetCursorPosition()
            local scale = UIParent:GetEffectiveScale()
            x, y = x / scale, y / scale
            local centerX, centerY = Minimap:GetCenter()
            if not centerX or not centerY then return end

            local dx, dy = x - centerX, y - centerY
            if math.abs(x - self._startX) > 4 or math.abs(y - self._startY) > 4 then
                self._moved = true
            end
            if self._moved then
                GoldMintDB.settings.minimapButtonAngle = math.deg(math.atan2(dy, dx))
                Position()
            end
        end)

        button:SetScript("OnMouseUp", function(self, click)
            if click == "LeftButton" then self._dragging = false end
        end)

        button:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            GameTooltip:SetText("GoldMint")
            GameTooltip:AddLine("Left-click: Open Dashboard", 0.72, 0.84, 0.96)
            GameTooltip:AddLine("Right-click: Gold Per Hour", 0.72, 0.84, 0.96)
            GameTooltip:AddLine("Middle-click: World Quests List", 0.72, 0.84, 0.96)
            GameTooltip:AddLine("Drag: Move around the minimap", 0.72, 0.84, 0.96)
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", function() GameTooltip:Hide() end)

        button:SetScript("OnClick", function(self, click)
            if self._moved then
                self._moved = false
                return
            end

            if click == "LeftButton" then
                if GoldMint.Dashboard and GoldMint.Dashboard.Toggle then
                    GoldMint.Dashboard:Toggle()
                elseif GoldMint.LoadAddon and GoldMint:LoadAddon("GoldMint_UI") and GoldMint.Dashboard and GoldMint.Dashboard.Toggle then
                    GoldMint.Dashboard:Toggle()
                end
            elseif click == "RightButton" then
                if GoldMint.FarmTracker then
                    if GoldMint.FarmTracker.EnsureFrame then GoldMint.FarmTracker:EnsureFrame() end
                    if GoldMint.FarmTracker.OnMinimapClick then
                        GoldMint.FarmTracker:OnMinimapClick()
                    elseif GoldMint.FarmTracker.Toggle then
                        GoldMint.FarmTracker:Toggle()
                    end
                end
            elseif click == "MiddleButton" then
                if GoldMint.ToDoPopout and GoldMint.ToDoPopout.Toggle then
                    GoldMint.ToDoPopout:Toggle()
                elseif GoldMint.LoadAddon and GoldMint:LoadAddon("GoldMint_UI") and GoldMint.ToDoPopout and GoldMint.ToDoPopout.Toggle then
                    GoldMint.ToDoPopout:Toggle()
                end
            end
            self._moved = false
        end)

        button:SetScript("OnEvent", function()
            Position()
            button:SetShown((GoldMintDB and GoldMintDB.settings and GoldMintDB.settings.minimapButtonShown) ~= false)
        end)
        button:RegisterEvent("PLAYER_ENTERING_WORLD")
        button:RegisterEvent("MINIMAP_UPDATE_ZOOM")

        self._lightMinimapButton = button
    end

    if button._position then button._position() end
    button:SetShown(settings.minimapButtonShown ~= false)
    return button
end

-- Slash commands are a tiny trampoline in the login-loaded core. The full
-- command parser (and its ledger dependency) is loaded only when a command is
-- actually used.
SLASH_GOLDMINT1 = "/goldmint"
SLASH_GOLDMINT2 = "/gm"
SLASH_GOLDMINTTODO1 = "/tdl"
SLASH_GOLDMINTTODO2 = "/goldminttodo"

local function DispatchLazyCommand(addonName, handlerName, message)
    if not GoldMint:LoadAddon(addonName) then
        GoldMint.Print("GoldMint command module could not be loaded.")
        return
    end
    local handler = GoldMint[handlerName]
    if type(handler) == "function" then
        handler(message or "")
    end
end

SlashCmdList.GOLDMINT = function(message)
    DispatchLazyCommand("GoldMint_Commands", "HandleGoldMintCommand", message)
end
SlashCmdList.GOLDMINTTODO = function(message)
    DispatchLazyCommand("GoldMint_Commands", "HandleGoldMintTodoCommand", message)
end

function GoldMint:OnLogin()
    self._lifecycleGeneration = (self._lifecycleGeneration or 0) + 1
    self:InitializeDB()

    -- Start a fresh live gold-making session after the character has a stable
    -- wallet baseline. The rolling Wealth velocity must measure real wallet
    -- changes that happen after login, not the amount of gold the character
    -- already owned.
    if self.Ledger and self.Ledger.BeginSession then
        self.Ledger:BeginSession()
    end

    -- Lightweight startup contract: Core initializes the character/session and
    -- creates the tiny minimap button. Market, Crafting, Inventory, AH scans,
    -- profession scans, and TSM pricing are not part of GoldMint anymore.
    self:BuildLightweightMinimapButton()
end

function GoldMint:OnLogout()
    self._lifecycleGeneration = (self._lifecycleGeneration or 0) + 1

    -- Force the active farming session to SavedVariables on logout. Normal
    -- farming updates are intentionally throttled, but logout is a final
    -- persistence boundary and should never discard the last few seconds.
    if self.FarmTracker and self.FarmTracker.SaveActiveSession then
        self.FarmTracker:SaveActiveSession(true)
    end
    if self.WorkflowState and self.Ledger and self.Ledger.session then
        local session = self.Ledger.session
        self.WorkflowState:RecordSessionSummary({
            startedAt = session.startedAtWall,
            endedAt = time(),
            startingGold = session.startingGold,
            endingGold = session.endingGold,
            netGold = session.netGold,
            income = session.income,
            spending = session.spending,
            goldPerHour = session.goldPerHour,
            velocityGoldPerHour = session.velocityGoldPerHour or 0,
            transferIn = session.transferIn or 0,
            transferOut = session.transferOut or 0,
            goldMakingGuild = session.goldMakingGuild,
            goldMakingGuildActive = session.goldMakingGuildActive == true,
            sourceTotals = session.sourceTotals or {},
            transactions = session.transactions or {},
        })
    end

    if self.Ledger then
        self.Ledger:EndSession()
    end
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        GoldMint:SafeCall("login", function() GoldMint:OnLogin() end)
    elseif event == "PLAYER_LOGOUT" then
        GoldMint:SafeCall("logout", function() GoldMint:OnLogout() end)
    elseif event == "PLAYER_MONEY" then
        if GoldMint.Ledger and GoldMint.Ledger.OnMoneyChanged then GoldMint.Ledger:OnMoneyChanged() end
    elseif event == "LOOT_OPENED" then
        HandleLootOpenedTrend()
    elseif event == "MERCHANT_SHOW" then
        GoldMint._merchantOpen = true
        BeginMerchantTrend()
    elseif event == "MERCHANT_CLOSED" then
        GoldMint._merchantOpen = false
        EndMerchantTrend()
    elseif event == "MAIL_SHOW" then
        if GoldMint.Ledger then GoldMint.Ledger:SetTransactionContext("Mail Received", 3600) end
        if GoldMint.MailTracking then GoldMint.MailTracking:OnMailShow() end
    elseif event == "MAIL_INBOX_UPDATE" then
        if GoldMint.MailTracking then GoldMint.MailTracking:OnMailInboxUpdate() end
    elseif event == "UPDATE_PENDING_MAIL" then
        if GoldMint.MailTracking then GoldMint.MailTracking:OnPendingMailUpdate() end
    elseif event == "MAIL_CLOSED" then
        if GoldMint.Ledger then GoldMint.Ledger:ClearTransactionContext("Mail Received") end
        if GoldMint.MailTracking then GoldMint.MailTracking:OnMailClosed() end
    elseif event == "TRADE_SHOW" then
        if GoldMint.Ledger then
            GoldMint.Ledger:SetTransactionContext("Trade", 3600)
            if GoldMint.Ledger.BeginTradeTracking then GoldMint.Ledger:BeginTradeTracking() end
        end
    elseif event == "TRADE_CLOSED" then
        if GoldMint.Ledger then
            if GoldMint.Ledger.EndTradeTracking then GoldMint.Ledger:EndTradeTracking() end
            GoldMint.Ledger:ClearTransactionContext("Trade")
        end
    elseif event == "QUEST_TURNED_IN" or event == "QUEST_COMPLETE" then
        if GoldMint.Ledger then
            local questIDValue = select(1, ...)
            local questID = tonumber(questIDValue)
            local questTitle
            if questID and C_QuestLog and type(C_QuestLog.GetTitleForQuestID) == "function" then
                local ok, title = pcall(C_QuestLog.GetTitleForQuestID, questID)
                if ok then questTitle = title end
            end
            if questID or event == "QUEST_TURNED_IN" then
                GoldMint.Ledger:SetTransactionContext("Quest Reward", 3, {questID=questID, questTitle=questTitle, event=event})
            end
        end
    elseif event == "GUILD_ROSTER_UPDATE" or event == "PLAYER_GUILD_UPDATE" then
        if GoldMint.CharacterTracking then GoldMint.CharacterTracking:SyncCurrent() end
    elseif event == "PLAYER_ENTERING_WORLD" then
        if GoldMint.Ledger and GoldMint.Ledger.UpdateWarbandGold then GoldMint.Ledger:UpdateWarbandGold() end
        if GoldMint.CharacterTracking then GoldMint.CharacterTracking:SyncCurrent() end
    end
end)

eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_GUILD_UPDATE")
eventFrame:RegisterEvent("GUILD_ROSTER_UPDATE")
eventFrame:RegisterEvent("PLAYER_LOGOUT")
eventFrame:RegisterEvent("PLAYER_MONEY")
eventFrame:RegisterEvent("MERCHANT_SHOW")
eventFrame:RegisterEvent("MERCHANT_CLOSED")
eventFrame:RegisterEvent("LOOT_OPENED")
eventFrame:RegisterEvent("MAIL_SHOW")
eventFrame:RegisterEvent("MAIL_INBOX_UPDATE")
eventFrame:RegisterEvent("UPDATE_PENDING_MAIL")
eventFrame:RegisterEvent("MAIL_CLOSED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("TRADE_SHOW")
eventFrame:RegisterEvent("TRADE_CLOSED")
eventFrame:RegisterEvent("QUEST_TURNED_IN")
eventFrame:RegisterEvent("QUEST_COMPLETE")


