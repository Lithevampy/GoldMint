local ADDON_NAME, GoldMint = ...

GoldMint.RareRecipeAlerts = {}
local Rare = GoldMint.RareRecipeAlerts

local DEFAULT_SETTINGS = {
    enabled = false,
    soundEnabled = true,
    leadMinutes = 5,
    watches = {},
}

local scanFrame
local ticker

local function EnsureStore()
    GoldMintDB.rareRecipeAlerts = type(GoldMintDB.rareRecipeAlerts) == "table" and GoldMintDB.rareRecipeAlerts or {}
    local store = GoldMintDB.rareRecipeAlerts
    if store.enabled == nil then store.enabled = DEFAULT_SETTINGS.enabled end
    if store.soundEnabled == nil then store.soundEnabled = DEFAULT_SETTINGS.soundEnabled end
    store.leadMinutes = math.max(0, tonumber(store.leadMinutes) or DEFAULT_SETTINGS.leadMinutes)
    store.watches = type(store.watches) == "table" and store.watches or {}
    return store
end

local function Now()
    return time()
end

local function PlayAlertSound()
    if not EnsureStore().soundEnabled then return end
    if GoldMint.Sounds and GoldMint.Sounds.Play then
        GoldMint.Sounds:Play("alert")
    end
end

local function PushAlert(watch, minutes)
    local name = watch.name or "Rare Recipe Source"
    local body
    if minutes <= 0 then
        body = name .. " should be spawning now."
    elseif minutes == 1 then
        body = name .. " is expected to spawn in about 1 minute."
    else
        body = name .. " is expected to spawn in about " .. tostring(minutes) .. " minutes."
    end

    if GoldMint.Alerts and GoldMint.Alerts.Push then
        GoldMint.Alerts:Push("RARE RECIPE SPAWN", body, {
            id = "rare-recipe-" .. tostring(watch.id),
            dedupeKey = "rare-recipe-" .. tostring(watch.id) .. "-" .. tostring(watch.nextSpawn or 0),
            priority = 95,
            category = "recipe",
            ttl = 18,
            sound = false,
        })
    end
    PlayAlertSound()
end

local function ExtractNPCIDFromGUID(guid)
    if type(guid) ~= "string" then return nil end
    local unitType, _, _, _, _, npcID = strsplit("-", guid)
    if unitType ~= "Creature" and unitType ~= "Vehicle" then return nil end
    return tonumber(npcID)
end

local function MatchWatch(watch, npcID)
    return tonumber(watch.npcID) and tonumber(watch.npcID) == tonumber(npcID)
end

local function RecordSpawn(watch)
    local now = Now()
    local interval = math.max(1, tonumber(watch.respawnMinutes) or 60) * 60

    -- Do not keep restarting the timer while the same vignette remains visible.
    if watch.lastDetected and (now - tonumber(watch.lastDetected)) < 30 then
        return false
    end

    watch.lastDetected = now
    watch.nextSpawn = now + interval
    watch.alerted = false
    return true
end

local function ScanVignettes()
    local store = EnsureStore()
    if not store.enabled or #store.watches == 0 then return end
    if not C_VignetteInfo or not C_VignetteInfo.GetVignettes or not C_VignetteInfo.GetVignetteInfo then return end

    local ok, vignetteIDs = pcall(C_VignetteInfo.GetVignettes)
    if not ok or type(vignetteIDs) ~= "table" then return end

    for _, vignetteID in ipairs(vignetteIDs) do
        local okInfo, info = pcall(C_VignetteInfo.GetVignetteInfo, vignetteID)
        if okInfo and type(info) == "table" then
            local npcID = tonumber(info.creatureID) or ExtractNPCIDFromGUID(info.objectGUID)
            if npcID then
                for _, watch in ipairs(store.watches) do
                    if MatchWatch(watch, npcID) then
                        if RecordSpawn(watch) then
                            watch.lastSeenName = info.name or watch.name
                        end
                    end
                end
            end
        end
    end
end

local function EvaluateTimers()
    local store = EnsureStore()
    if not store.enabled then return end
    local now = Now()
    local lead = math.max(0, tonumber(store.leadMinutes) or 0) * 60

    for _, watch in ipairs(store.watches) do
        local nextSpawn = tonumber(watch.nextSpawn)
        if nextSpawn and nextSpawn > 0 and not watch.alerted then
            if now >= (nextSpawn - lead) then
                local remaining = math.max(0, nextSpawn - now)
                local minutes = math.ceil(remaining / 60)
                PushAlert(watch, minutes)
                watch.alerted = true
            end
        end
    end
end

function Rare:GetSettings()
    return EnsureStore()
end

function Rare:SetSetting(name, value)
    local store = EnsureStore()
    if name == "enabled" or name == "soundEnabled" then
        store[name] = value == true
    elseif name == "leadMinutes" then
        store.leadMinutes = math.max(0, math.min(60, tonumber(value) or DEFAULT_SETTINGS.leadMinutes))
    end
    return store[name]
end

function Rare:GetWatches()
    return EnsureStore().watches
end

function Rare:AddWatch(name, npcID, respawnMinutes)
    name = strtrim(tostring(name or ""))
    npcID = tonumber(npcID)
    respawnMinutes = tonumber(respawnMinutes)
    if name == "" then return nil, "Recipe source name is required." end
    if not npcID or npcID <= 0 then return nil, "NPC ID must be greater than 0." end
    if not respawnMinutes or respawnMinutes <= 0 then return nil, "Respawn minutes must be greater than 0." end

    local store = EnsureStore()
    for _, watch in ipairs(store.watches) do
        if tonumber(watch.npcID) == npcID then
            watch.name = name
            watch.respawnMinutes = respawnMinutes
            return watch
        end
    end

    local watch = {
        id = tostring(npcID) .. "-" .. tostring(Now()),
        name = name,
        npcID = npcID,
        respawnMinutes = respawnMinutes,
        lastDetected = nil,
        nextSpawn = nil,
        alerted = false,
    }
    store.watches[#store.watches + 1] = watch
    return watch
end

function Rare:RemoveWatch(id)
    local store = EnsureStore()
    for i, watch in ipairs(store.watches) do
        if tostring(watch.id) == tostring(id) then
            table.remove(store.watches, i)
            return true
        end
    end
    return false
end

function Rare:ClearWatches()
    EnsureStore().watches = {}
end

function Rare:CaptureTarget()
    if not UnitExists or not UnitExists("target") then
        return nil, "Target a rare recipe source first."
    end
    local guid = UnitGUID and UnitGUID("target")
    local npcID = ExtractNPCIDFromGUID(guid)
    if not npcID then
        return nil, "The current target does not expose a creature NPC ID."
    end
    local name = UnitName("target") or ("NPC " .. tostring(npcID))
    return {name = name, npcID = npcID}
end

function Rare:GetNextSpawn()
    local nextWatch, nextTime
    local now = Now()
    for _, watch in ipairs(EnsureStore().watches) do
        local t = tonumber(watch.nextSpawn)
        if t and t > now and (not nextTime or t < nextTime) then
            nextWatch, nextTime = watch, t
        end
    end
    return nextWatch, nextTime
end

function Rare:FormatRemaining(timestamp)
    local seconds = math.max(0, (tonumber(timestamp) or 0) - Now())
    local minutes = math.floor(seconds / 60)
    local secs = math.floor(seconds % 60)
    if minutes >= 60 then
        return string.format("%dh %02dm", math.floor(minutes / 60), minutes % 60)
    end
    return string.format("%dm %02ds", minutes, secs)
end

function Rare:Initialize()
    EnsureStore()
    if scanFrame then return end

    scanFrame = CreateFrame("Frame")
    scanFrame:RegisterEvent("VIGNETTES_UPDATED")
    scanFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    scanFrame:SetScript("OnEvent", function()
        ScanVignettes()
        EvaluateTimers()
    end)

    ticker = C_Timer.NewTicker(2, function()
        ScanVignettes()
        EvaluateTimers()
    end)
end

return Rare
