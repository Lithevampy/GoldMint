local ADDON_NAME, GoldMint = ...

-- GoldMint routine-state resolver.
--
-- The catalog describes activities. This module resolves that catalog against
-- the current character's saved level and any quest-backed evidence GoldMint
-- has actually observed. It intentionally does NOT assume that a character
-- can access an activity merely because the activity exists in the catalog.
--
-- No PvP activities are surfaced here.

GoldMint.RoutineState = {}
local State = GoldMint.RoutineState

local STATE_VERSION = 3
local FREQUENCY_DAILY = 1
local FREQUENCY_WEEKLY = 2
local FREQUENCY_SCHEDULED = 3

local function EnsureStore()
    GoldMintDB.routineState = type(GoldMintDB.routineState) == "table" and GoldMintDB.routineState or {}
    local savedVersion = tonumber(GoldMintDB.routineState.version) or 0
    GoldMintDB.routineState.version = math.max(savedVersion, STATE_VERSION)
    GoldMintDB.routineState.characters = type(GoldMintDB.routineState.characters) == "table" and GoldMintDB.routineState.characters or {}
    return GoldMintDB.routineState
end

local function CurrentCharacterKey()
    return GoldMint.characterKey
end

local function CurrentLevel(characterKey)
    characterKey = characterKey or CurrentCharacterKey()
    local record = GoldMintDB.characters and GoldMintDB.characters[characterKey]
    if record and tonumber(record.level) then
        return tonumber(record.level)
    end
    return 0
end

local function GetCatalog()
    return GoldMint.RoutineCatalog
end

local function GetContentCapability(characterKey)
    if GoldMint.ContentProgression and GoldMint.ContentProgression.GetCapability then
        return GoldMint.ContentProgression:GetCapability(characterKey)
    end
    return nil
end

local function GetCharacterProfessions(characterKey)
    characterKey = characterKey or CurrentCharacterKey()
    local record = GoldMintDB.characters and GoldMintDB.characters[characterKey]
    if not record or type(record.professions) ~= "table" then
        return nil, 0
    end

    local professions = {}
    local count = 0
    for professionID, profession in pairs(record.professions) do
        local name = tostring((profession and profession.name) or ""):lower()
        if name ~= "" then
            professions[name] = true
            professions[tostring(professionID)] = true
            count = count + 1
        end
    end

    return professions, count
end

local function HasProfessionRequirement(activity, characterKey)
    local required = activity and activity.professions
    if type(required) ~= "table" or #required == 0 then
        return true, false
    end

    local professions, count = GetCharacterProfessions(characterKey)
    if not professions or count == 0 then
        -- We have not observed this character's professions yet. Do not claim
        -- that the activity is unavailable; leave the activity unresolved.
        return true, true
    end

    for _, requirement in ipairs(required) do
        local key = tostring(requirement):lower()
        if professions[key] then
            return true, false
        end
        for known in pairs(professions) do
            if type(known) == "string" and known:find(key, 1, true) then
                return true, false
            end
        end
    end

    return false, false
end

local function IsPvP(entry)
    local category = tostring(entry.category or ""):lower()
    local title = tostring(entry.title or ""):lower()
    local id = tostring(entry.id or ""):lower()
    return category == "pvp"
        or category == "battleground"
        or category == "arena"
        or title:find("pvp", 1, true) ~= nil
        or id:find("pvp", 1, true) ~= nil
end

local function FindQuestRecordForActivity(activity)
    local catalog = GetCatalog()
    if not catalog or type(catalog.quests) ~= "table" then
        return nil
    end

    local activityID = activity.id
    local activityName = tostring(activity.title or "")

    for questID, quest in pairs(catalog.quests) do
        if quest.activity == activityID or quest.activity == activityName then
            local record = GoldMintDB.routines and GoldMintDB.routines.quests and GoldMintDB.routines.quests[tonumber(questID)]
            if record then
                return record
            end
        end
    end

    if GoldMintDB.routines and GoldMintDB.routines.quests then
        for _, record in pairs(GoldMintDB.routines.quests) do
            if record.activity == activityID or record.activity == activityName then
                return record
            end
        end
    end

    return nil
end

local function FrequencyName(frequency)
    if frequency == FREQUENCY_DAILY or frequency == "Daily" then
        return "Daily"
    elseif frequency == FREQUENCY_WEEKLY or frequency == "Weekly" then
        return "Weekly"
    elseif frequency == FREQUENCY_SCHEDULED or frequency == "Scheduled" then
        return "Scheduled"
    end
    return ""
end

local function CharacterHasEvidence(record, characterKey)
    if not record or not record.characters then
        return false
    end
    return record.characters[characterKey] ~= nil
end

local function ResolveActivity(activity, characterKey)
    if not activity or IsPvP(activity) then
        return nil
    end

    local level = CurrentLevel(characterKey)
    local minLevel = tonumber(activity.minLevel)
    if minLevel and level > 0 and level < minLevel then
        return nil
    end

    local professionAllowed, professionUnknown = HasProfessionRequirement(activity, characterKey)
    if not professionAllowed then
        return nil
    end

    local capability = GetContentCapability(characterKey)
    if capability and GoldMint.ContentProgression and GoldMint.ContentProgression.IsActivityAccessible then
        local accessible = GoldMint.ContentProgression:IsActivityAccessible(activity, characterKey, capability)
        if accessible == false then
            return nil
        end
    end

    local result = {
        id = activity.id,
        title = activity.title,
        expansionID = tonumber(activity.expansionID),
        expansionName = activity.expansionName,
        season = tonumber(activity.season),
        category = activity.category,
        frequency = FrequencyName(activity.frequency),
        minLevel = minLevel,
        characterLevel = level,
        status = "unknown",
        observed = false,
        professionUnknown = professionUnknown,
        contentAccess = capability and capability.access or nil,
        landingPages = capability and capability.landingPages or nil,
        observedExpansions = capability and capability.observedExpansions or nil,
    }

    local record = FindQuestRecordForActivity(activity)
    if record and CharacterHasEvidence(record, characterKey) and GoldMint.Routines then
        result.observed = true
        result.status = GoldMint.Routines:GetStatus(record, characterKey)
        result.questID = record.questID
        result.lastCompleted = record.characters[characterKey].lastCompleted
        result.questLevel = record.questLevel
    end

    return result
end

function State:SyncCharacter()
    local store = EnsureStore()
    local key = CurrentCharacterKey()
    if not key then
        return nil
    end

    local character = store.characters[key] or {}
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.level = CurrentLevel(key)
    character.currentExpansion = (GetExpansionLevel and tonumber(GetExpansionLevel())) or character.currentExpansion
    character.lastSync = time()

    -- Persist a compact backend snapshot for this character. The snapshot is
    -- rebuilt silently from the resolver and gives the future UI one stable
    -- source of character-specific routine state.
    local activities = self:GetRelevantActivities(key)
    local snapshot = {
        updatedAt = time(),
        level = character.level,
        currentExpansion = character.currentExpansion,
        activities = {},
    }

    for _, activity in ipairs(activities) do
        snapshot.activities[#snapshot.activities + 1] = {
            id = activity.id,
            title = activity.title,
            expansionID = activity.expansionID,
            expansionName = activity.expansionName,
            season = activity.season,
            category = activity.category,
            frequency = activity.frequency,
            status = activity.status,
            observed = activity.observed == true,
            questID = activity.questID,
            questLevel = activity.questLevel,
            lastCompleted = activity.lastCompleted,
        }
    end

    character.snapshot = snapshot
    store.characters[key] = character
    return character
end

function State:GetCharacterLevel(characterKey)
    return CurrentLevel(characterKey)
end

function State:GetRelevantActivities(characterKey, options)
    characterKey = characterKey or CurrentCharacterKey()
    options = options or {}

    local catalog = GetCatalog()
    if not catalog or type(catalog.activities) ~= "table" then
        return {}
    end

    local result = {}
    for _, activity in ipairs(catalog.activities) do
        if not IsPvP(activity) then
            local include = true

            if options.currentOnly and tonumber(activity.expansionID) ~= 11 then
                include = false
            end
            if options.season and tonumber(activity.season) ~= tonumber(options.season) then
                include = false
            end
            if options.observedOnly then
                local resolved = ResolveActivity(activity, characterKey)
                include = include and resolved ~= nil and resolved.observed
                if include then
                    result[#result + 1] = resolved
                end
            elseif include then
                local resolved = ResolveActivity(activity, characterKey)
                if resolved then
                    result[#result + 1] = resolved
                end
            end
        end
    end

    table.sort(result, function(a, b)
        local ao = a.observed and 0 or 1
        local bo = b.observed and 0 or 1
        if ao ~= bo then
            return ao < bo
        end
        local af = a.frequency or ""
        local bf = b.frequency or ""
        if af ~= bf then
            return af < bf
        end
        return (a.title or "") < (b.title or "")
    end)

    return result
end

function State:GetReadyActivities(characterKey, options)
    options = options or {}
    options.observedOnly = true
    local activities = self:GetRelevantActivities(characterKey, options)
    local result = {}
    for _, activity in ipairs(activities) do
        if activity.status == "ready" then
            result[#result + 1] = activity
        end
    end
    return result
end

function State:GetSummary(characterKey)
    characterKey = characterKey or CurrentCharacterKey()
    local all = self:GetRelevantActivities(characterKey, { currentOnly = true, season = 2 })
    local observed, ready, completed = 0, 0, 0

    for _, activity in ipairs(all) do
        if activity.observed then
            observed = observed + 1
            if activity.status == "ready" then
                ready = ready + 1
            elseif activity.status == "completed" then
                completed = completed + 1
            end
        end
    end

    return {
        level = self:GetCharacterLevel(characterKey),
        totalCatalog = #all,
        observed = observed,
        ready = ready,
        completed = completed,
    }
end

function State:Initialize()
    if self._initialized then
        return
    end
    self._initialized = true
    EnsureStore()
    self:SyncCharacter()
end
