local ADDON_NAME, GoldMint = ...

-- ============================================================================
-- GOLDMINT DASHBOARD
-- ============================================================================
-- Presentation layer only. All values come from the existing GoldMint systems.
-- The dashboard is deliberately data-driven so later pages can reuse the same
-- APIs without moving ownership of ledger, market, routine, mail, or milestone
-- state into the UI.
-- ============================================================================

GoldMint.Dashboard = {}
local Dashboard = GoldMint.Dashboard

local frame
local labels = {}
local bars = {}
local buttons = {}
local panels = {}
Dashboard.panels = panels
local initialized = false
local minimapButton

-- The dashboard is authored on a 1400x840 design canvas.  All pages live
-- inside this same frame, so the safest responsive strategy is to scale the
-- complete canvas as one unit when the available UI space is smaller.  This
-- keeps every page's internal proportions/anchors intact while preventing
-- panels and text from colliding on smaller resolutions or larger WoW UI
-- scales.
local DASHBOARD_BASE_WIDTH = 1400
local DASHBOARD_BASE_HEIGHT = 840
local DASHBOARD_SCREEN_MARGIN = 24

local function UpdateResponsiveScale()
    if not frame or not UIParent then return end

    local uiWidth = tonumber(UIParent:GetWidth()) or DASHBOARD_BASE_WIDTH
    local uiHeight = tonumber(UIParent:GetHeight()) or DASHBOARD_BASE_HEIGHT
    local availableWidth = math.max(1, uiWidth - (DASHBOARD_SCREEN_MARGIN * 2))
    local availableHeight = math.max(1, uiHeight - (DASHBOARD_SCREEN_MARGIN * 2))

    local scaleX = availableWidth / DASHBOARD_BASE_WIDTH
    local scaleY = availableHeight / DASHBOARD_BASE_HEIGHT
    local scale = math.min(1, scaleX, scaleY)

    -- Never allow an invalid/vanishing scale if WoW reports dimensions during
    -- a display transition.
    if scale ~= scale or scale <= 0 then
        scale = 1
    end

    frame:SetScale(scale)
    frame._goldMintResponsiveScale = scale
end
local OpenGoalEditor
local OpenProjects
local OpenPlanner
local OpenOperations
local navButtons = {}
local activeNavKey = "dashboard"

local GOLD = {1.0, 0.82, 0.25}
local CYAN = {0.20, 0.78, 1.0}
local GREEN = {0.25, 1.0, 0.55}
local RED = {1.0, 0.35, 0.35}
local MUTED = {0.60, 0.74, 0.88}
local DARK = {0.006, 0.028, 0.050, 0.965}

local function ApplyNavState(button, active, hover)
    if not button then return end
    if active then
        button:SetBackdropColor(0.08, 0.18, 0.28, 0.62)
        if button.text then button.text:SetTextColor(unpack(GOLD)) end
        if button.icon then
            button.icon:SetVertexColor(1.0, 0.82, 0.25, 1.0)
            if button.iconGlow then button.iconGlow:Hide() end
        end
        if button.accent then button.accent:Show() end
    elseif hover then
        -- Hover should illuminate the icon only; do not show a rectangular
        -- button/background box over the navigation pane.
        button:SetBackdropColor(0, 0, 0, 0)
        if button.text then button.text:SetTextColor(unpack(GOLD)) end
        if button.icon then
            button.icon:SetVertexColor(0.35, 0.85, 1.0, 1.0)
        end
        if button.accent then button.accent:Hide() end
    else
        button:SetBackdropColor(0, 0, 0, 0)
        if button.text then button.text:SetTextColor(unpack(MUTED)) end
        if button.icon then
            button.icon:SetVertexColor(1.0, 1.0, 1.0, 1.0)
            if button.iconGlow then button.iconGlow:Hide() end
        end
        if button.accent then button.accent:Hide() end
    end
end
local wealthLiveLabels = {}
local cooldownFilterMenu

local function SetNavigationActive(key)
    activeNavKey = key or "dashboard"
    for navKey, b in pairs(navButtons) do
        ApplyNavState(b, navKey == activeNavKey, false)
    end
end

local function FormatGold(amount)
    if GoldMint.Ledger and GoldMint.Ledger.FormatGoldFull then
        return GoldMint.Ledger:FormatGoldFull(tonumber(amount) or 0)
    end
    return tostring(math.floor(tonumber(amount) or 0)) .. "g"
end

local function FormatWealthAmount(amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then
        return "0"
    end
    return FormatGold(amount)
end

local function FormatWholeGold(amount)
    amount = math.floor((tonumber(amount) or 0) / 10000)
    local s = tostring(amount)
    local out = s
    while true do
        local n; out, n = string.gsub(out, "^(%-?%d+)(%d%d%d)", "%1,%2")
        if n == 0 then break end
    end
    return out
end

local function FormatRate(amount)
    if GoldMint.Ledger and GoldMint.Ledger.FormatRate then
        return GoldMint.Ledger:FormatRate(tonumber(amount) or 0)
    end
    return tostring(math.floor(tonumber(amount) or 0)) .. "g"
end

-- Profit/loss values need to inherit the FontString color. GetMoneyString()
-- embeds Blizzard's gold/silver/copper color escape codes, which override
-- SetTextColor() and can make a positive value appear red or otherwise ignore
-- GoldMint's profit/loss color rules. Use the plain ledger formatter for
-- dashboard P&L values so positive is always green and negative is red.
local function FormatProfitGold(amount)
    amount = tonumber(amount) or 0
    if GoldMint.Ledger and GoldMint.Ledger.FormatGold then
        return GoldMint.Ledger:FormatGold(amount)
    end
    return tostring(math.floor(amount)) .. "g"
end

-- Token prices are plain numbers in the header card.  Do not use GetMoneyString
-- here because its second argument adds a gold-coin texture underneath/after
-- the value, which is not appropriate for the WoW Token tracker.
local function FormatTokenPrice(amount)
    amount = math.floor(tonumber(amount) or 0)
    if BreakUpLargeNumbers then
        return BreakUpLargeNumbers(amount)
    end
    local text = tostring(amount)
    local changed
    repeat
        text, changed = text:gsub("^(%d+)(%d%d%d)", "%1,%2")
    until changed == 0
    return text
end

local function ShortGold(amount)
    amount = tonumber(amount) or 0
    local abs = math.abs(amount)
    if abs >= 1000000 then
        return string.format("%.2fm", amount / 1000000)
    elseif abs >= 1000 then
        return string.format("%.1fk", amount / 1000)
    end
    return string.format("%.0f", amount)
end

local function MakeLabel(parent, template, text, width)
    local label = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormal")
    label:SetJustifyH("LEFT")
    label:SetText(text or "")
    if width then label:SetWidth(width) end
    return label
end

local function Panel(parent, width, height, point, x, y, borderColor)
    local p = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    p:SetSize(width, height)
    p:SetPoint(point, parent, point, x or 0, y or 0)
    p:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = {left = 5, right = 5, top = 5, bottom = 5},
    })
    p:SetBackdropColor(0.006, 0.018, 0.032, 0.985)
    local c = borderColor or {0.10, 0.34, 0.52, 0.90}
    p:SetBackdropBorderColor(c[1], c[2], c[3], c[4] or 0.90)
    return p
end

local function Accent(parent, point, x, y, width, color)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetColorTexture(color[1], color[2], color[3], color[4] or 1)
    t:SetSize(width, 2)
    t:SetPoint(point, parent, point, x, y)
    return t
end

local function MakeButton(parent, text, width, height, variant)
    -- GoldMint standard button: dark navy body, cyan border, gold hover glow.
    -- All action buttons use the same visual language; variant is retained only
    -- for compatibility with existing callers.
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height)
    b:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })

    local textLabel = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    textLabel:SetPoint("CENTER")
    textLabel:SetText(text)
    textLabel:SetTextColor(unpack(MUTED))
    b.text = textLabel

    local function ApplyNormal()
        b:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        b:SetBackdropBorderColor(unpack(CYAN))
        b.text:SetTextColor(unpack(GOLD))
    end

    local function ApplyHover()
        b:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
        b:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
        b.text:SetTextColor(1.0, 0.86, 0.38)
    end

    ApplyNormal()
    -- Explicitly opt every GoldMint button into mouse interaction.  This is
    -- important for dynamically-created buttons inside the project editor,
    -- where parent/child frame layering can otherwise make the button appear
    -- clickable without reliably receiving the click.
    b:EnableMouse(true)
    b:RegisterForClicks("LeftButtonUp")
    b:SetFrameLevel((parent:GetFrameLevel() or 0) + 2)
    b:SetScript("OnEnter", ApplyHover)
    b:SetScript("OnLeave", ApplyNormal)
    return b
end

local function SetBar(bar, fraction)
    fraction = math.max(0, math.min(1, tonumber(fraction) or 0))
    bar:SetValue(fraction)
end

local function SetText(name, text)
    if labels[name] then labels[name]:SetText(text or "") end
end

local function SetStatus(label, state)
    if not label then return end
    if state == "ahead" or state == "profit" or state == "ready" then
        label:SetTextColor(unpack(GREEN))
    elseif state == "behind" or state == "warning" then
        label:SetTextColor(unpack(RED))
    elseif state == "gold" then
        label:SetTextColor(unpack(GOLD))
    else
        label:SetTextColor(unpack(MUTED))
    end
end

local function AddSectionTitle(parent, key, text, color, x, y)
    labels[key] = MakeLabel(parent, "GameFontNormalLarge", text)
    labels[key]:SetPoint("TOPLEFT", x or 18, y or -14)
    labels[key]:SetTextColor(unpack(color or CYAN))
    labels[key]:SetShadowOffset(1, -1)
    local titleColor = color or CYAN
    local titleX = x or 18
    local titleY = y or -14
    Accent(parent, "TOPLEFT", titleX, titleY - 18, 38, titleColor)
end

local ACTIVE_COOLDOWN_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintActiveCooldowns.tga"

local function AddActiveCooldownIcon(parent, x, y, size)
    local icon = parent:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(ACTIVE_COOLDOWN_ICON)
    local s = size or 20
    icon:SetSize(s, s)
    icon:SetPoint("TOP", parent, "TOP", x or 0, y or 0)
    icon:SetTexCoord(0, 1, 0, 1)
    return icon
end

local RECENT_PROFIT_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintRecent.tga"
local MILESTONE_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintMilestone.tga"
local SHIELD_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintShield.tga"

local function AddUtilityIcon(parent, texturePath, x, y, size)
    local icon = parent:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(texturePath)
    local s = size or 18
    icon:SetSize(s, s)
    icon:SetPoint("LEFT", parent, "TOPLEFT", x or 12, y or -14)
    icon:SetTexCoord(0, 1, 0, 1)
    return icon
end

-- ============================================================================
-- GOLDMINT CUSTOM SCROLL FRAME
-- Replaces Blizzard's default UIPanelScrollFrameTemplate with the thin,
-- dark-navy/cyan scrollbar shown in the GoldMint visual references.
-- ============================================================================
local function CreateGoldMintScrollFrame(parent, topLeftX, topLeftY, bottomRightX, bottomRightY, contentWidth)
    local scroll = CreateFrame("ScrollFrame", nil, parent)
    scroll:SetPoint("TOPLEFT", topLeftX or 0, topLeftY or 0)
    scroll:SetPoint("BOTTOMRIGHT", bottomRightX or 0, bottomRightY or 0)
    scroll:EnableMouseWheel(true)

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(contentWidth or 600, 1)
    scroll:SetScrollChild(content)

    local bar = CreateFrame("Frame", nil, parent)
    bar:SetWidth(16)
    bar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -3, topLeftY or 0)
    bar:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -3, bottomRightY or 0)
    bar:EnableMouse(true)

    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0.008, 0.030, 0.050, 0.92)
    track:SetPoint("TOPLEFT", 4, 0)
    track:SetPoint("BOTTOMRIGHT", -4, 0)

    local trackLine = bar:CreateTexture(nil, "ARTWORK")
    trackLine:SetColorTexture(0.08, 0.34, 0.52, 0.85)
    trackLine:SetWidth(2)
    trackLine:SetPoint("TOP", bar, "TOP", 0, 0)
    trackLine:SetPoint("BOTTOM", bar, "BOTTOM", 0, 0)

    local innerLine = bar:CreateTexture(nil, "ARTWORK")
    innerLine:SetColorTexture(0.20, 0.78, 1.0, 0.42)
    innerLine:SetWidth(1)
    innerLine:SetPoint("TOP", bar, "TOP", 0, 0)
    innerLine:SetPoint("BOTTOM", bar, "BOTTOM", 0, 0)

    local thumb = CreateFrame("Button", nil, bar)
    thumb:SetWidth(8)
    thumb:SetHeight(44)
    thumb:SetPoint("TOP", bar, "TOP", 0, 0)
    thumb:EnableMouse(true)

    local thumbBG = thumb:CreateTexture(nil, "BACKGROUND")
    thumbBG:SetColorTexture(0.015, 0.075, 0.115, 0.96)
    thumbBG:SetAllPoints()

    local thumbLine = thumb:CreateTexture(nil, "ARTWORK")
    thumbLine:SetColorTexture(0.20, 0.78, 1.0, 0.95)
    thumbLine:SetWidth(2)
    thumbLine:SetPoint("TOP", thumb, "TOP", 0, 0)
    thumbLine:SetPoint("BOTTOM", thumb, "BOTTOM", 0, 0)

    local thumbEdge = thumb:CreateTexture(nil, "OVERLAY")
    thumbEdge:SetColorTexture(0.10, 0.34, 0.52, 0.9)
    thumbEdge:SetWidth(1)
    thumbEdge:SetPoint("TOP", thumb, "TOP", -3, 0)
    thumbEdge:SetPoint("BOTTOM", thumb, "BOTTOM", -3, 0)
    local thumbEdge2 = thumb:CreateTexture(nil, "OVERLAY")
    thumbEdge2:SetColorTexture(0.10, 0.34, 0.52, 0.9)
    thumbEdge2:SetWidth(1)
    thumbEdge2:SetPoint("TOP", thumb, "TOP", 3, 0)
    thumbEdge2:SetPoint("BOTTOM", thumb, "BOTTOM", 3, 0)

    local function UpdateBar()
        if not scroll:IsShown() then return end
        local range = math.max(0, scroll:GetVerticalScrollRange() or 0)
        local viewport = math.max(1, scroll:GetHeight() or 1)
        local trackHeight = math.max(1, bar:GetHeight() or 1)
        if range <= 0 then
            bar:Hide()
            return
        end
        bar:Show()
        local thumbHeight = math.max(34, math.min(trackHeight, math.floor((viewport / (viewport + range)) * trackHeight)))
        thumb:SetHeight(thumbHeight)
        local travel = math.max(0, trackHeight - thumbHeight)
        local frac = math.max(0, math.min(1, (scroll:GetVerticalScroll() or 0) / range))
        thumb:ClearAllPoints()
        thumb:SetPoint("TOP", bar, "TOP", 0, -travel * frac)
    end

    scroll.UpdateGoldMintScrollBar = UpdateBar
    scroll._goldMintBar = bar
    scroll._goldMintThumb = thumb
    scroll._goldMintContent = content

    scroll:SetScript("OnMouseWheel", function(self, delta)
        local step = math.max(24, self:GetHeight() * 0.18)
        local current = self:GetVerticalScroll() or 0
        local range = self:GetVerticalScrollRange() or 0
        self:SetVerticalScroll(math.max(0, math.min(range, current - delta * step)))
        UpdateBar()
    end)
    scroll:SetScript("OnVerticalScroll", function()
        UpdateBar()
    end)
    scroll:SetScript("OnSizeChanged", function()
        UpdateBar()
    end)
    scroll:SetScript("OnShow", function()
        C_Timer.After(0, UpdateBar)
    end)

    local dragging = false
    local dragStartY = 0
    local dragStartScroll = 0
    thumb:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        dragging = true
        dragStartY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        dragStartScroll = scroll:GetVerticalScroll() or 0
        self:SetAlpha(1.0)
    end)
    thumb:SetScript("OnMouseUp", function()
        dragging = false
    end)
    thumb:SetScript("OnHide", function()
        dragging = false
    end)
    bar:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local barTop = select(2, bar:GetTop()) or 0
        local localY = barTop - cursorY
        local trackHeight = math.max(1, bar:GetHeight())
        local thumbHeight = math.max(1, thumb:GetHeight())
        local travel = math.max(1, trackHeight - thumbHeight)
        local target = math.max(0, math.min(1, (localY - thumbHeight / 2) / travel))
        local range = scroll:GetVerticalScrollRange() or 0
        scroll:SetVerticalScroll(target * range)
        UpdateBar()
    end)
    thumb:SetScript("OnUpdate", function()
        if not dragging then return end
        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local delta = dragStartY - cursorY
        local travel = math.max(1, bar:GetHeight() - thumb:GetHeight())
        local range = scroll:GetVerticalScrollRange() or 0
        scroll:SetVerticalScroll(math.max(0, math.min(range, dragStartScroll + (delta / travel) * range)))
        UpdateBar()
    end)

    -- Row/layout changes are event-driven; avoid a per-frame size poll for the
    -- scrollbar.  Every content resize now updates the bar immediately.
    content:SetScript("OnSizeChanged", function(self)
        self._goldMintLastContentHeight = self:GetHeight()
        UpdateBar()
    end)

    C_Timer.After(0, UpdateBar)
    return scroll, content
end

local function BuildHeader()
    -- Dedicated top bar matching the reference: deep navy, subtle cyan framing,
    -- gold branding, and separated metric blocks.  It is a texture on the main
    -- frame so it can never cover the labels that sit above it.
    -- Build the header as three artwork sections so the decorative left and
    -- right ends stay visually intact while only the middle stretches to fit
    -- the dashboard width. This avoids the "single stretched box" look.
    local headerLeft = frame:CreateTexture(nil, "ARTWORK")
    headerLeft:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeader")
    headerLeft:SetPoint("TOPLEFT", -24, 22)
    headerLeft:SetSize(434, 115)
    headerLeft:SetTexCoord(0, 0.288, 0, 1)

    local headerCenter = frame:CreateTexture(nil, "ARTWORK")
    headerCenter:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeader")
    headerCenter:SetPoint("TOPLEFT", 410, 22)
    headerCenter:SetSize(580, 115)
    headerCenter:SetTexCoord(0.288, 0.712, 0, 1)

    local headerRight = frame:CreateTexture(nil, "ARTWORK")
    headerRight:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeader")
    headerRight:SetPoint("TOPLEFT", 990, 22)
    headerRight:SetSize(434, 115)
    headerRight:SetTexCoord(0.712, 1, 0, 1)

    panels.header = headerCenter
    panels.headerLeft = headerLeft
    panels.headerRight = headerRight

    local separatorXs = {690, 920, 1145}
    for _, x in ipairs(separatorXs) do
        local line = frame:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(0.14, 0.40, 0.58, 0.55)
        line:SetSize(1, 54)
        line:SetPoint("TOPLEFT", x, -15)
    end

    -- Supplied combined GoldMint header branding.  This replaces the separate
    -- logo/title/subtitle so the artwork stays proportioned as one coherent mark.
    local headerBrand = frame:CreateTexture(nil, "OVERLAY")
    headerBrand:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeaderBrand")
    headerBrand:SetSize(310, 99)
    headerBrand:SetPoint("TOPLEFT", 20, 14)
    headerBrand:SetTexCoord(0, 1, 0, 1)
    panels.headerBrand = headerBrand

    local coin = frame:CreateTexture(nil, "ARTWORK")
    coin:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintGoldCoin")
    coin:SetSize(22, 22)
    coin:SetPoint("TOPLEFT", 460, -17)
    labels.headerCoin = coin

    labels.headerGold = MakeLabel(frame, "GameFontHighlightLarge", "0g")
    labels.headerGold:SetPoint("TOPLEFT", 492, -20)
    labels.headerGold:SetWidth(235)
    labels.headerGold:SetTextColor(unpack(GOLD))
    labels.headerValue = MakeLabel(frame, "GameFontNormal", "Total Gold")
    labels.headerValue:SetPoint("TOPLEFT", 494, -51)
    labels.headerValue:SetWidth(220)
    labels.headerValue:SetTextColor(unpack(MUTED))

    -- Intention header card: frame the live Daily Focus intention so it reads
    -- as a deliberate header metric rather than loose text.  The card stays
    -- inside the existing header spacing and does not alter the label/value
    -- positions.
    local intentionCard = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    intentionCard:SetSize(218, 62)
    intentionCard:SetPoint("TOPLEFT", 702, -10)
    intentionCard:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 8, edgeSize = 10,
        insets = {left = 2, right = 2, top = 2, bottom = 2},
    })
    intentionCard:SetBackdropBorderColor(0.04, 0.30, 0.48, 0.95)
    panels.intentionCard = intentionCard

    labels.headerWeek = MakeLabel(frame, "GameFontHighlight", "—")
    labels.headerWeek:SetPoint("TOPLEFT", 718, -20)
    labels.headerWeek:SetTextColor(unpack(GREEN))
    labels.headerWeekLabel = MakeLabel(frame, "GameFontNormal", "Intention")
    labels.headerWeekLabel:SetPoint("TOPLEFT", 720, -51)
    labels.headerWeekLabel:SetTextColor(unpack(MUTED))

    -- Mail header card: keep the existing metric-card footprint, but use it
    -- as a simple current-character mail indicator. Daily Profit already has
    -- a dedicated place in the Overview, so it does not need to be duplicated
    -- in the header.
    local mailCard = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    mailCard:SetSize(166, 62)
    mailCard:SetPoint("TOPLEFT", 928, -10)
    mailCard:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 8, edgeSize = 10,
        insets = {left = 2, right = 2, top = 2, bottom = 2},
    })
    mailCard:SetBackdropBorderColor(0.04, 0.30, 0.48, 0.95)
    panels.mailCard = mailCard

    labels.mailTitle = MakeLabel(mailCard, "GameFontNormalSmall", "Mail", 146)
    labels.mailTitle:SetPoint("TOPLEFT", 10, -10)
    labels.mailTitle:SetTextColor(unpack(MUTED))
    labels.mailTitle:SetWordWrap(false)

    -- The supplied envelope artwork is shown only when mail is actually waiting.
    -- Keep the existing card footprint; the icon is an indicator, not a replacement
    -- for the mailbox status text.
    local mailIcon = mailCard:CreateTexture(nil, "ARTWORK")
    mailIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintMail")
    mailIcon:SetSize(46, 31)
    mailIcon:SetPoint("TOPLEFT", 7, -22)
    mailIcon:Hide()
    labels.mailIcon = mailIcon

    labels.mailStatus = MakeLabel(mailCard, "GameFontHighlightLarge", "—", 92)
    labels.mailStatus:SetPoint("TOPLEFT", 65, -27)
    labels.mailStatus:SetTextColor(unpack(MUTED))
    labels.mailStatus:SetWordWrap(false)

    labels.mailDetail = MakeLabel(mailCard, "GameFontNormalSmall", "Mailbox not scanned", 146)
    labels.mailDetail:SetPoint("TOPLEFT", 10, -48)
    labels.mailDetail:SetTextColor(unpack(MUTED))
    labels.mailDetail:SetWordWrap(false)

    -- Header metric cards use the compact glassy card treatment: framed graph
    -- tile, title, live value, and a real up/down artwork indicator.
    local function CreateHeaderMetricCard(key, x, accentColor)
        local card = CreateFrame("Frame", nil, frame, "BackdropTemplate")
        card:SetSize(198, 62)
        card:SetPoint("TOPLEFT", x, -10)
        card:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 8, edgeSize = 10,
            insets = {left = 2, right = 2, top = 2, bottom = 2},
        })
        card:SetBackdropColor(0.004, 0.018, 0.032, 0.82)
        card:SetBackdropBorderColor(0.04, 0.30, 0.48, 0.95)

        local iconBox = CreateFrame("Frame", nil, card, "BackdropTemplate")
        iconBox:SetSize(72, 52)
        iconBox:SetPoint("LEFT", 5, 0)
        iconBox:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = true, tileSize = 8, edgeSize = 1,
        })
        iconBox:SetBackdropColor(0.008, 0.035, 0.058, 0.94)
        iconBox:SetBackdropBorderColor(0.05, 0.32, 0.48, 0.95)

        local iconBase = iconBox:CreateTexture(nil, "ARTWORK")
        iconBase:SetColorTexture(0.01, 0.055, 0.085, 0.80)
        iconBase:SetPoint("TOPLEFT", 2, -2)
        iconBase:SetPoint("BOTTOMRIGHT", -2, 2)

        local graphLines = {}
        for i = 1, 7 do
            local line = iconBox:CreateTexture(nil, "OVERLAY")
            line:SetColorTexture(accentColor[1], accentColor[2], accentColor[3], 0.95)
            line:SetHeight(2)
            line:Hide()
            graphLines[i] = line
        end

        local title = MakeLabel(card, "GameFontNormal", "")
        title:SetPoint("TOPLEFT", 84, -13)
        title:SetWidth(104)
        title:SetTextColor(unpack(MUTED))

        local valueTemplate = key == "token" and "GameFontNormal" or "GameFontHighlightLarge"
        local value = MakeLabel(card, valueTemplate, "—")
        value:SetPoint("TOPLEFT", 84, -31)
        value:SetWidth(key == "token" and 100 or 84)
        value:SetMaxLines(1)
        value:SetWordWrap(false)
        value:SetTextColor(unpack(accentColor))

        local trend = card:CreateTexture(nil, "OVERLAY")
        trend:SetSize(18, 18)
        -- Keep the trend arrow beside the token value, but place it below the
        -- number so it does not compete with the price text.
        trend:SetPoint("TOPRIGHT", -10, -43)
        trend:Hide()

        labels[key .. "Card"] = card
        labels[key .. "IconBox"] = iconBox
        labels[key .. "IconBase"] = iconBase
        labels[key .. "GraphLines"] = graphLines
        labels[key .. "Title"] = title
        labels[key .. "Value"] = value
        labels[key .. "Trend"] = trend
        return card
    end

    CreateHeaderMetricCard("token", 1100, GOLD)

    labels.tokenTitle:SetText("|TInterface\\Icons\\WoW_Token01:16:16:0:0|t WoW Token")
    labels.tokenValue:SetText("—")

    -- Blizzard-style settings control in the former refresh-button position.
    -- The old red close X is intentionally removed; the dashboard is now
    -- visually controlled by the single circular gear button.
    local gear = CreateFrame("Button", "GoldMintDashboardSettingsButton", frame)
    gear:SetSize(34, 34)
    gear:SetPoint("TOPRIGHT", -48, -6)
    gear:SetFrameLevel(frame:GetFrameLevel() + 20)

    local gearIcon = gear:CreateTexture(nil, "ARTWORK")
    gearIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintSettingsGear")
    gearIcon:SetAllPoints(gear)

    gear:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    gear:SetScript("OnClick", function()
        if GoldMint.OpenOptions then
            GoldMint:OpenOptions()
        elseif InterfaceOptionsFrame_OpenToCategory then
            InterfaceOptionsFrame_OpenToCategory("GoldMint")
        else
            GoldMint.Print("GoldMint settings are not available yet.")
        end
    end)
    buttons.refresh = gear
    buttons.settings = gear
end

local function UpdateGoldProgress(widget, current, maxVal)
    current = tonumber(current) or 0
    maxVal = tonumber(maxVal) or 0
    local percentage = maxVal > 0 and math.min(math.max(current / maxVal, 0), 1.0) or 0

    local progressArc = widget and widget.ProgressArc
    if progressArc then
        progressArc:SetMinMaxValues(0, 100)
        progressArc:SetValue(percentage * 100)
        if progressArc.Fill then
            progressArc.Fill:Hide()
        end
    end

    -- The supplied glow line is the precise tracker for the current goal.
    if widget and widget.ProgressLine then
        widget.ProgressLine:SetMinMaxValues(0, 1)
        widget.ProgressLine:SetValue(percentage)
    end

    -- Legacy fallback segments are retained only for compatibility with older
    -- saved UI state/builds. The new glow line is the visible tracker.
    local segments = progressArc and progressArc._fallbackSegments or nil
    if segments then
        for _, seg in ipairs(segments) do seg:Hide() end
    end

    return percentage
end

local function CreateGoalWidget(parent)
    -- Pure-Lua goal tracker. The goal graph is a circular progress ring made
    -- entirely from Lua-created textures. The supplied line_graph.tga is used
    -- as the glowing blue artwork for every segment of the ring.
    local widget = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    widget:SetSize(440, 160)

    local leftBracket = widget:CreateTexture(nil, "BORDER")
    leftBracket:SetTexture("Interface\\Artifacts\\ArtifactTextures")
    leftBracket:SetSize(40, 140)
    leftBracket:SetPoint("CENTER", widget, "CENTER", -100, 15)
    leftBracket:SetTexCoord(0.45, 0.55, 0.10, 0.90)
    leftBracket:SetVertexColor(0.15, 0.25, 0.35, 0.80)
    widget.LeftBracket = leftBracket

    local rightBracket = widget:CreateTexture(nil, "BORDER")
    rightBracket:SetTexture("Interface\\Artifacts\\ArtifactTextures")
    rightBracket:SetSize(40, 140)
    rightBracket:SetPoint("CENTER", widget, "CENTER", 100, 15)
    rightBracket:SetTexCoord(0.55, 0.45, 0.10, 0.90)
    rightBracket:SetVertexColor(0.15, 0.25, 0.35, 0.80)
    widget.RightBracket = rightBracket

    -- Goal coin artwork sits immediately beside the left edge of the goal
    -- title. Keep a small gap so the icon never overlaps the "Y" in YOUR.
    local goalCoins = widget:CreateTexture(nil, "ARTWORK")
    goalCoins:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintGoalCoins.tga")
    goalCoins:SetSize(42, 37)
    goalCoins:SetPoint("TOPLEFT", widget, "TOPLEFT", 10, -1)
    goalCoins:SetTexCoord(0, 1, 0, 1)
    goalCoins:SetVertexColor(1, 1, 1, 1)
    widget.GoalCoins = goalCoins

    local title = widget:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetSize(350, 20)
    title:SetPoint("TOPLEFT", widget, "TOPLEFT", 60, -7)
    title:SetJustifyH("LEFT")
    title:SetTextColor(unpack(CYAN))
    widget.Title = title

    -- Underline the "YOU" portion of YOUR GOAL with a thick cyan rule.
    -- Keep it as its own texture so the underline remains fixed even when
    -- the active goal name changes.
    local goalUnderline = widget:CreateTexture(nil, "ARTWORK")
    goalUnderline:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 1)
    -- Match the standard dashboard section-title accent used by the other
    -- Home panels: identical width and thickness for a clean, symmetrical rail.
    goalUnderline:SetSize(38, 2)
    goalUnderline:SetPoint("TOPLEFT", widget, "TOPLEFT", 60, -27)
    widget.GoalYouUnderline = goalUnderline

    --------------------------------------------------------------------------
    -- Circular goal graph
    --
    -- WoW StatusBars are rectangular, so a circular graph is built from a
    -- ring of small textures. Each texture uses Assets/line_graph.tga and is
    -- rotated around the center. This keeps the exact supplied glow artwork
    -- while giving us a true circular 0-100% progress display.
    --------------------------------------------------------------------------
    local progressArc = CreateFrame("Frame", nil, widget)
    progressArc:SetSize(150, 150)
    progressArc:SetPoint("CENTER", widget, "CENTER", 0, -30)
    progressArc:SetFrameLevel(widget:GetFrameLevel() + 2)

    local RING_TEXTURE = "Interface\\AddOns\\GoldMint\\Assets\\line_graph"
    local SEGMENTS = 96
    local RADIUS = 58
    local SEGMENT_W = 7
    local SEGMENT_H = 8
    local TAU = math.pi * 2

    local ringBackground = {}
    local ringProgress = {}

    local function PositionRingSegment(tex, index)
        local angle = ((index - 1) / SEGMENTS) * TAU - (math.pi / 2)
        local x = math.cos(angle) * RADIUS
        local y = math.sin(angle) * RADIUS
        tex:SetPoint("CENTER", progressArc, "CENTER", x, y)
        tex:SetRotation(angle + (math.pi / 2))
    end

    local function CreateRingSegment(layer, index)
        local tex = progressArc:CreateTexture(nil, layer)
        tex:SetTexture(RING_TEXTURE)
        tex:SetSize(SEGMENT_W, SEGMENT_H)
        -- line_graph.tga is a large transparent canvas with the actual glow
        -- occupying only a narrow strip near the lower-middle of the image.
        -- Crop to the real glow artwork before rotating each progress segment.
        tex:SetTexCoord(0.281, 0.719, 0.500, 0.527)
        tex:SetBlendMode("ADD")
        PositionRingSegment(tex, index)
        return tex
    end

    for i = 1, SEGMENTS do
        -- Background is intentionally a plain, dim ring. Do NOT use the glow
        -- texture for the background or a 0% goal will look like a full ring.
        local bg = progressArc:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(0.035, 0.12, 0.16, 0.55)
        bg:SetSize(SEGMENT_W, 3)
        PositionRingSegment(bg, i)
        ringBackground[i] = bg

        local fill = CreateRingSegment("ARTWORK", i)
        fill:SetVertexColor(0.0, 0.75, 1.0, 0.98)
        fill:Hide()
        ringProgress[i] = fill
    end

    -- Compatibility methods keep the existing Refresh/update pipeline intact.
    function progressArc:SetMinMaxValues(minValue, maxValue)
        self._minValue = tonumber(minValue) or 0
        self._maxValue = tonumber(maxValue) or 100
    end

    function progressArc:SetValue(value)
        local minValue = self._minValue or 0
        local maxValue = self._maxValue or 100
        local numeric = tonumber(value) or minValue
        local range = maxValue - minValue
        local fraction = range > 0 and ((numeric - minValue) / range) or 0
        fraction = math.max(0, math.min(1, fraction))
        self._fraction = fraction

        local visible = math.floor((fraction * SEGMENTS) + 0.5)
        for i = 1, SEGMENTS do
            ringProgress[i]:SetShown(i <= visible)
        end
    end

    function progressArc:GetValue()
        return self._fraction or 0
    end

    progressArc:SetMinMaxValues(0, 100)
    progressArc:SetValue(0)
    progressArc.RingBackground = ringBackground
    progressArc.RingProgress = ringProgress
    progressArc._fallbackSegments = {}
    widget.ProgressArc = progressArc

    -- Percentage centered inside the circular graph.
    local percent = progressArc:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    percent:SetSize(200, 20)
    percent:SetPoint("CENTER", progressArc, "CENTER", 0, 0)
    percent:SetJustifyH("CENTER")
    percent:SetText("0%")
    percent:SetTextColor(unpack(GOLD))
    percent:SetShadowOffset(1, -1)
    progressArc.Text = percent

    -- Retained as a hidden compatibility handle. The line_graph texture is now
    -- used by the circular ring itself rather than a separate horizontal bar.
    local progressLine = CreateFrame("StatusBar", nil, widget)
    progressLine:SetSize(1, 1)
    progressLine:SetMinMaxValues(0, 1)
    progressLine:SetValue(0)
    progressLine:SetStatusBarTexture(RING_TEXTURE)
    progressLine:Hide()
    widget.ProgressLine = progressLine

    local pacing = widget:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    pacing:SetSize(300, 14)
    pacing:SetPoint("BOTTOMLEFT", widget, "BOTTOMLEFT", 16, -35)
    pacing:SetJustifyH("LEFT")
    pacing:SetText("Current Pacing: —")
    pacing:SetTextColor(unpack(MUTED))
    widget.PacingText = pacing

    local estimate = widget:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    estimate:SetSize(300, 14)
    estimate:SetPoint("BOTTOMLEFT", widget, "BOTTOMLEFT", 16, -47)
    estimate:SetJustifyH("LEFT")
    estimate:SetText("Goal Est: —")
    estimate:SetTextColor(unpack(MUTED))
    widget.EstText = estimate

    local manageBtn = CreateFrame("Button", nil, widget, "BackdropTemplate")
    manageBtn:SetSize(104, 24)
    manageBtn:SetPoint("BOTTOMRIGHT", widget, "BOTTOMRIGHT", -16, -47)
    manageBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true,
        tileSize = 8,
        edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    manageBtn:SetBackdropColor(0.03, 0.07, 0.10, 0.92)
    manageBtn:SetBackdropBorderColor(unpack(CYAN))

    local manageText = manageBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    manageText:SetPoint("CENTER")
    manageText:SetText("MANAGE GOAL")
    manageText:SetTextColor(unpack(GOLD))
    manageBtn:SetFontString(manageText)
    manageBtn:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(1, 0.82, 0.0, 1)
    end)
    manageBtn:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(unpack(CYAN))
    end)
    manageBtn:SetScript("OnClick", function()
        OpenGoalEditor()
    end)
    widget.ManageButton = manageBtn

    return widget
end

local function BuildGoalPanel()
    local p = Panel(frame, 445, 235, "TOPLEFT", 225, -126, {0.16, 0.38, 0.58, 0.95})
    panels.goal = p

    local goalWidget = CreateGoalWidget(p)
    goalWidget:SetPoint("TOPLEFT", 2, -12)
    goalWidget:SetFrameLevel(p:GetFrameLevel() + 1)
    panels.goalWidget = goalWidget

    bars.goalCircle = goalWidget.ProgressArc
    bars.goalSegments = goalWidget.ProgressArc._fallbackSegments
    bars.goalWidget = goalWidget

    labels.goalName = goalWidget.Title
    labels.goalTarget = goalWidget.ProgressArc.Text
    labels.goalProgressLine = goalWidget.ProgressLine
    labels.goalProgress = goalWidget.ProgressArc.Text
    labels.goalRemaining = goalWidget.EstText
    labels.checkpoint = goalWidget.PacingText
    labels.checkpointDistance = goalWidget.EstText
    labels.pacing = goalWidget.PacingText
    labels.goalAction = goalWidget.Title

    -- Hidden compatibility bar retained for older dashboard code.
    bars.goal = CreateFrame("StatusBar", nil, p)
    bars.goal:SetSize(1, 1)
    bars.goal:SetMinMaxValues(0, 1)
    bars.goal:Hide()
end

local goalEditor
local goalFields = {}

local function MakeEditBox(parent, labelText, width, y, numeric)
    local label = MakeLabel(parent, "GameFontNormal", labelText)
    label:SetPoint("TOPLEFT", 24, y)
    label:SetTextColor(unpack(MUTED))

    local edit = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    edit:SetSize(width, 30)
    edit:SetPoint("TOPLEFT", 22, y - 24)
    edit:SetAutoFocus(false)
    edit:SetTextInsets(8, 8, 0, 0)
    if numeric then
        edit:SetNumeric(true)
    end
    return edit
end

local function ParseGoldInput(text)
    text = tostring(text or "")
    text = text:gsub("[, ]", "")
    local n = tonumber(text)
    if not n then return nil end
    return math.floor(n * 10000)
end

local function ParseDaysInput(text)
    text = tostring(text or ""):gsub("[, ]", "")
    if text == "" then return nil end
    local n = tonumber(text)
    if not n or n < 1 then return nil end
    return math.floor(n)
end

local function CloseGoalEditor()
    if goalEditor then goalEditor:Hide() end
end

OpenGoalEditor = function()
    if not goalEditor then
        goalEditor = CreateFrame("Frame", "GoldMintGoalEditor", frame, "BackdropTemplate")
        goalEditor:SetSize(620, 610)
        goalEditor:SetPoint("CENTER")
        goalEditor:SetFrameStrata("DIALOG")
        goalEditor:SetFrameLevel(250)
        if UISpecialFrames then
            tinsert(UISpecialFrames, "GoldMintGoalEditor")
        end
        goalEditor:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 18,
            insets = {left = 6, right = 6, top = 6, bottom = 6},
        })
        goalEditor:SetBackdropColor(0.004, 0.010, 0.016, 1.0)
        goalEditor:SetBackdropBorderColor(0.10, 0.42, 0.66, 0.98)

        AddSectionTitle(goalEditor, "goalEditorTitle", "PROJECT MANAGEMENT", CYAN)

        goalFields.name = MakeEditBox(goalEditor, "Project Name", 572, -52, false)
        goalFields.target = MakeEditBox(goalEditor, "Target Gold", 260, -122, true)

        local deadlineLabel = MakeLabel(goalEditor, "GameFontNormal", "Deadline (days, optional)")
        deadlineLabel:SetPoint("TOPLEFT", 324, -122)
        deadlineLabel:SetTextColor(unpack(MUTED))
        goalFields.deadline = CreateFrame("EditBox", nil, goalEditor, "InputBoxTemplate")
        goalFields.deadline:SetSize(260, 30)
        goalFields.deadline:SetPoint("TOPLEFT", 322, -146)
        goalFields.deadline:SetAutoFocus(false)
        goalFields.deadline:SetNumeric(true)
        goalFields.deadline:SetTextInsets(8, 8, 0, 0)

        local projectTypeLabel = MakeLabel(goalEditor, "GameFontNormal", "Project Type")
        projectTypeLabel:SetPoint("TOPLEFT", 24, -202)
        projectTypeLabel:SetTextColor(unpack(MUTED))
        local projectTypes = { "Gold Goal", "Stockpile", "Buy & Resell", "Crafting", "Market Investment" }
        local selectedProjectType = "Gold Goal"
        local projectTypeButtons = {}
        local function SelectProjectType(value)
            selectedProjectType = value
            for typeName, button in pairs(projectTypeButtons) do
                if typeName == selectedProjectType then
                    button:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
                    button:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
                    button.text:SetTextColor(1.0, 0.86, 0.38)
                else
                    button:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
                    button:SetBackdropBorderColor(unpack(CYAN))
                    button.text:SetTextColor(unpack(MUTED))
                end
            end
        end
        -- Five project-type buttons must fit inside the 620px editor without
        -- touching the dialog border.  Keep a compact 8px gap and leave a
        -- consistent 18px inset on both sides.
        local projectTypeButtonWidth = 104
        local projectTypeGap = 8
        for i, typeName in ipairs(projectTypes) do
            local b = MakeButton(goalEditor, typeName, projectTypeButtonWidth, 28, "secondary")
            b:SetPoint("TOPLEFT", 18 + (i - 1) * (projectTypeButtonWidth + projectTypeGap), -218)
            projectTypeButtons[typeName] = b
            b:SetScript("OnClick", function(self, button)
                if button == "LeftButton" then
                    SelectProjectType(typeName)
                end
            end)
        end
        SelectProjectType(selectedProjectType)

        goalFields.budget = MakeEditBox(goalEditor, "Capital Budget (optional)", 260, -266, true)
        goalFields.expectedRevenue = MakeEditBox(goalEditor, "Expected Revenue (optional)", 260, -266, true)
        goalFields.expectedRevenue:SetPoint("TOPLEFT", 322, -290)
        goalFields.expectedRevenue:SetTextInsets(8, 8, 0, 0)

        goalFields.expectedCost = MakeEditBox(goalEditor, "Expected Cost (optional)", 260, -336, true)
        goalFields.nextAction = MakeEditBox(goalEditor, "Next Action (optional)", 260, -336, false)
        goalFields.nextAction:SetPoint("TOPLEFT", 322, -360)
        goalFields.nextAction:SetTextInsets(8, 8, 0, 0)

        local checkpointLabel = MakeLabel(goalEditor, "GameFontNormal", "Checkpoint (optional)")
        checkpointLabel:SetPoint("TOPLEFT", 24, -404)
        checkpointLabel:SetTextColor(unpack(MUTED))

        goalFields.checkpoint = CreateFrame("EditBox", nil, goalEditor, "InputBoxTemplate")
        goalFields.checkpoint:SetSize(260, 30)
        goalFields.checkpoint:SetPoint("TOPLEFT", 22, -428)
        goalFields.checkpoint:SetAutoFocus(false)
        goalFields.checkpoint:SetNumeric(true)
        goalFields.checkpoint:SetTextInsets(8, 8, 0, 0)

        goalFields.checkpointName = CreateFrame("EditBox", nil, goalEditor, "InputBoxTemplate")
        goalFields.checkpointName:SetSize(260, 30)
        goalFields.checkpointName:SetPoint("TOPLEFT", 322, -428)
        goalFields.checkpointName:SetAutoFocus(false)
        goalFields.checkpointName:SetTextInsets(8, 8, 0, 0)

        local cpHint = MakeLabel(goalEditor, "GameFontNormalSmall", "Gold amount     Checkpoint name")
        cpHint:SetPoint("TOPLEFT", 28, -462)
        cpHint:SetTextColor(unpack(MUTED))

        -- Keep all four actions on one clean row with fixed spacing.
        -- The previous positions caused CANCEL and MARK COMPLETE to overlap.
        -- Four actions, equal visual spacing, and no overlap.
        local save = MakeButton(goalEditor, "SAVE GOAL", 120, 34, "primary")
        save:SetPoint("BOTTOMLEFT", 18, 18)

        local cancel = MakeButton(goalEditor, "CANCEL", 90, 34, "secondary")
        cancel:SetPoint("BOTTOMLEFT", 146, 18)

        local complete = MakeButton(goalEditor, "MARK COMPLETE", 120, 34, "secondary")
        complete:SetPoint("BOTTOMLEFT", 244, 18)

        local clear = MakeButton(goalEditor, "CLEAR GOAL", 110, 34, "secondary")
        clear:SetPoint("BOTTOMLEFT", 372, 18)

        local function RefreshEditorFields()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                goalFields.name:SetText(active.name or "")
                goalFields.target:SetText(tostring(math.floor((tonumber(active.target) or 0) / 10000)))
                local days = active.deadline and math.ceil(math.max(0, (tonumber(active.deadline) - time()) / 86400)) or nil
                goalFields.deadline:SetText(days and tostring(days) or "")
                selectedProjectType = active.projectType or "Gold Goal"
                SelectProjectType(selectedProjectType)
                goalFields.budget:SetText((tonumber(active.budget) or 0) > 0 and tostring(math.floor((tonumber(active.budget) or 0) / 10000)) or "")
                goalFields.expectedRevenue:SetText((tonumber(active.expectedRevenue) or 0) > 0 and tostring(math.floor((tonumber(active.expectedRevenue) or 0) / 10000)) or "")
                goalFields.expectedCost:SetText((tonumber(active.expectedCost) or 0) > 0 and tostring(math.floor((tonumber(active.expectedCost) or 0) / 10000)) or "")
                goalFields.nextAction:SetText(active.nextAction or "")
                if active.nextCheckpoint then
                    goalFields.checkpoint:SetText(tostring(math.floor((tonumber(active.nextCheckpoint.amount) or 0) / 10000)))
                    goalFields.checkpointName:SetText(active.nextCheckpoint.name or "")
                else
                    goalFields.checkpoint:SetText("")
                    goalFields.checkpointName:SetText("")
                end
            else
                goalFields.name:SetText("")
                goalFields.target:SetText("")
                goalFields.deadline:SetText("")
                selectedProjectType = "Gold Goal"
                SelectProjectType(selectedProjectType)
                goalFields.budget:SetText("")
                goalFields.expectedRevenue:SetText("")
                goalFields.expectedCost:SetText("")
                goalFields.nextAction:SetText("")
                goalFields.checkpoint:SetText("")
                goalFields.checkpointName:SetText("")
            end
        end

        save:SetScript("OnClick", function()
            local name = strtrim(goalFields.name:GetText() or "")
            local target = ParseGoldInput(goalFields.target:GetText())
            local days = ParseDaysInput(goalFields.deadline:GetText())
            if name == "" then
                GoldMint.Print("Goal name is required.")
                return
            end
            if not target or target <= 0 then
                GoldMint.Print("Target gold must be greater than 0.")
                return
            end

            local deadline = days and (time() + days * 86400) or nil
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            local result, err
            if active then
                result, err = GoldMint.Milestones:UpdateGoal(active.id, {
                    name = name, target = target, deadline = deadline, type = "gold",
                    projectType = selectedProjectType,
                    budget = ParseGoldInput(goalFields.budget:GetText()) or 0,
                    expectedRevenue = ParseGoldInput(goalFields.expectedRevenue:GetText()) or 0,
                    expectedCost = ParseGoldInput(goalFields.expectedCost:GetText()) or 0,
                    nextAction = strtrim(goalFields.nextAction:GetText() or "") ~= "" and strtrim(goalFields.nextAction:GetText()) or nil,
                })
            else
                result, err = GoldMint.Milestones:CreateGoal(name, target, {
                    type = "gold", deadline = deadline,
                    projectType = selectedProjectType,
                    budget = ParseGoldInput(goalFields.budget:GetText()) or 0,
                    expectedRevenue = ParseGoldInput(goalFields.expectedRevenue:GetText()) or 0,
                    expectedCost = ParseGoldInput(goalFields.expectedCost:GetText()) or 0,
                    nextAction = strtrim(goalFields.nextAction:GetText() or "") ~= "" and strtrim(goalFields.nextAction:GetText()) or nil,
                })
            end
            if not result then
                GoldMint.Print("Unable to save goal: " .. tostring(err))
                return
            end

            local cp = ParseGoldInput(goalFields.checkpoint:GetText())
            local cpName = strtrim(goalFields.checkpointName:GetText() or "")
            if cp then
                if cp >= target then
                    GoldMint.Print("Checkpoint must be below the goal target.")
                    return
                end
                local current = GoldMint.Milestones:GetActiveGoal()
                if current then
                    local cpResult, cpErr = GoldMint.Milestones:SetCheckpoint(current.id, cp, cpName ~= "" and cpName or nil)
                    if not cpResult then
                        GoldMint.Print("Unable to save checkpoint: " .. tostring(cpErr))
                    end
                end
            end

            CloseGoalEditor()
            Refresh()
            GoldMint.Print("Project saved: " .. name .. " | Target: " .. FormatGold(target))
        end)

        cancel:SetScript("OnClick", CloseGoalEditor)

        clear:SetScript("OnClick", function()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:DeleteGoal(active.id)
                CloseGoalEditor()
                Refresh()
                GoldMint.Print("Active project cleared.")
            else
                GoldMint.Print("No active project to clear.")
            end
        end)

        complete:SetScript("OnClick", function()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:CompleteGoal(active.id, "manual")
                CloseGoalEditor()
                Refresh()
                GoldMint.Print("Project marked complete: " .. tostring(active.name))
            else
                GoldMint.Print("No active project to complete.")
            end
        end)

        goalEditor:SetScript("OnShow", RefreshEditorFields)
    end

    goalEditor:Show()
    goalEditor:Raise()
end

local function BuildMomentumPanel()
    local p = Panel(frame, 300, 235, "TOPLEFT", 685, -126, {0.10, 0.45, 0.42, 0.95})
    panels.momentum = p
    -- Profit & Velocity uses the supplied market-growth artwork immediately
    -- beside the P in the section title.  The source image is stored as a
    -- transparent TGA so WoW can render it without a black background.
    local profitVelocityIcon = p:CreateTexture(nil, "ARTWORK")
    profitVelocityIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintProfitVelocity.tga")
    profitVelocityIcon:SetSize(22, 20)
    profitVelocityIcon:SetPoint("TOPLEFT", p, "TOPLEFT", 18, -12)
    profitVelocityIcon:SetTexCoord(0, 1, 0, 1)
    labels.momentumProfitVelocityIcon = profitVelocityIcon

    AddSectionTitle(p, "momentumTitle", "PROFIT & VELOCITY", CYAN, 44, -14)

    labels.momentumStatus = MakeLabel(p, "GameFontNormalSmall", "This Week", 250)
    labels.momentumStatus:SetPoint("TOPLEFT", 18, -39)
    labels.momentumStatus:SetTextColor(unpack(MUTED))

    labels.momentumHint = MakeLabel(p, "GameFontNormalSmall", "", 250)
    labels.momentumHint:SetPoint("TOPLEFT", 18, -207)
    labels.momentumHint:SetTextColor(unpack(MUTED))
    labels.momentumHint:SetJustifyH("CENTER")

    labels.momentumEarnedValue = MakeLabel(p, "GameFontHighlightLarge", "+0g", 260)
    labels.momentumEarnedValue:SetPoint("TOPLEFT", 18, -59)
    labels.momentumEarnedValue:SetTextColor(unpack(GREEN))
    labels.momentumEarnedValue:SetJustifyH("CENTER")

    labels.momentumSpentValue = MakeLabel(p, "GameFontNormalSmall", "Hourly Rate: —", 260)
    labels.momentumSpentValue:SetPoint("TOPLEFT", 18, -171)
    labels.momentumSpentValue:SetTextColor(unpack(MUTED))
    labels.momentumSpentValue:SetJustifyH("CENTER")

    labels.momentumNetValue = MakeLabel(p, "GameFontNormalSmall", "", 1)
    labels.momentumNetValue:Hide()

    -- Seven-point profit trend. Render this as a compact dashboard graph:
    -- subtle grid, translucent area fill, a thin trend line, and glowing
    -- point markers. The data still comes from the same saved history.
    labels.momentumGraphLines = {}
    labels.momentumGraphPoints = {}
    labels.momentumGraphFill = {}
    labels.momentumGraphGrid = {}

    local gx, gy, gw, gh = 24, 91, 252, 60

    -- Grid: four horizontal guides and six vertical guides, kept deliberately
    -- faint so the profit trend remains the visual focus.
    for i = 0, 4 do
        local grid = p:CreateTexture(nil, "BACKGROUND")
        grid:SetColorTexture(0.16, 0.27, 0.32, 0.42)
        grid:SetSize(gw, 1)
        grid:SetPoint("TOPLEFT", p, "TOPLEFT", gx, -(gy + (gh * i / 4)))
        labels.momentumGraphGrid[#labels.momentumGraphGrid + 1] = grid
    end
    for i = 0, 6 do
        local grid = p:CreateTexture(nil, "BACKGROUND")
        grid:SetColorTexture(0.16, 0.27, 0.32, 0.30)
        grid:SetSize(1, gh)
        grid:SetPoint("TOPLEFT", p, "TOPLEFT", gx + (gw * i / 6), -gy)
        labels.momentumGraphGrid[#labels.momentumGraphGrid + 1] = grid
    end

    -- Translucent area under the seven-point trend. Each vertical strip is
    -- clipped to the graph bounds and sized from the baseline to the line.
    for i = 0, gw - 1, 2 do
        local fill = p:CreateTexture(nil, "ARTWORK")
        fill:SetColorTexture(0.05, 0.34, 0.43, 0.18)
        fill:SetWidth(2)
        fill:SetPoint("TOPLEFT", p, "TOPLEFT", gx + i, -(gy + gh))
        fill:SetHeight(1)
        fill:Hide()
        labels.momentumGraphFill[#labels.momentumGraphFill + 1] = fill
    end

    -- Six line segments connect the seven data points.
    for i = 1, 6 do
        local line = p:CreateTexture(nil, "OVERLAY")
        line:SetColorTexture(0.70, 0.82, 0.84, 0.90)
        line:SetHeight(2)
        line:Hide()
        labels.momentumGraphLines[i] = line
    end

    -- Small outer glow + bright center for each data point.
    for i = 1, 7 do
        local glow = p:CreateTexture(nil, "OVERLAY")
        glow:SetColorTexture(0.18, 0.72, 0.82, 0.16)
        glow:SetSize(12, 12)
        glow:Hide()

        local dot = p:CreateTexture(nil, "OVERLAY")
        dot:SetColorTexture(0.78, 0.90, 0.91, 0.98)
        dot:SetSize(6, 6)
        dot:Hide()

        labels.momentumGraphPoints[i] = {glow = glow, dot = dot}
    end

    labels.momentumGraphArea = {x=gx, y=gy, w=gw, h=gh}

    labels.momentumAxisLeft = MakeLabel(p, "GameFontNormalSmall", "7 Day", 45)
    labels.momentumAxisLeft:SetPoint("TOPLEFT", 18, -151)
    labels.momentumAxisLeft:SetTextColor(unpack(MUTED))
    labels.momentumAxisRight = MakeLabel(p, "GameFontNormalSmall", "7 Day", 45)
    labels.momentumAxisRight:SetPoint("TOPRIGHT", -18, -151)
    labels.momentumAxisRight:SetTextColor(unpack(MUTED))
    labels.momentumWeekTotal = MakeLabel(p, "GameFontNormalSmall", "Total Week: —", 260)
    labels.momentumWeekTotal:SetPoint("TOPLEFT", 18, -188)
    labels.momentumWeekTotal:SetTextColor(unpack(MUTED))
    labels.momentumWeekTotal:SetJustifyH("CENTER")

    -- Preserve the old row keys for compatibility with refresh logic, but keep
    -- them visually subordinate to the new hero graph.
    for _, key in ipairs({"momentumEarnedName", "momentumSpentName", "momentumNetName"}) do
        if labels[key] then labels[key]:Hide() end
    end
end

local function GetOnboardingState()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    local state = GoldMintDB.settings.onboarding
    if type(state) ~= "table" then
        state = {}
        GoldMintDB.settings.onboarding = state
    end
    state.version = tonumber(state.version) or 1
    state.skipped = type(state.skipped) == "table" and state.skipped or {}
    return state
end

local function GetOnboardingSteps()
    local characterKey = GoldMint.characterKey
    local character = characterKey and GoldMintDB.characters and GoldMintDB.characters[characterKey] or nil
    local valuationCharacter = characterKey and GoldMintDB.valuation and GoldMintDB.valuation.characters and GoldMintDB.valuation.characters[characterKey] or nil
    local mailCharacter = characterKey and GoldMintDB.mailTracking and GoldMintDB.mailTracking.characters and GoldMintDB.mailTracking.characters[characterKey] or nil
    local market = GoldMintDB.market or {}
    local fullScan = market.fullScan or {}

    local professionReady = character and tonumber(character.lastRecipeScan or 0) > 0
    local professionCount = 0
    if character and type(character.professions) == "table" then
        for _ in pairs(character.professions) do professionCount = professionCount + 1 end
    end

    return {
        {
            id = "inventory",
            title = "Scan your inventory",
            detail = "GoldMint needs one inventory scan for accurate item and wealth tracking.",
            done = (valuationCharacter and tonumber(valuationCharacter.scannedAt or 0) > 0) or (character and tonumber(character.scannedAt or 0) > 0),
            open = function()
                OpenOperations("inventory")
            end,
        },
        {
            id = "professions",
            title = professionCount > 0 and "Scan your professions" or "Open a profession",
            detail = professionCount > 0 and "Open each profession you use once so GoldMint can learn recipes and cooldowns." or "Open a profession once so GoldMint can learn its recipes and cooldowns.",
            done = professionReady,
            open = function()
                GoldMint.Print("Open your WoW Profession window. GoldMint will scan the profession automatically while it is open.")
            end,
        },
        {
            id = "mail",
            title = "Scan your mailbox",
            detail = "Open your mailbox once so incoming gold and items can be tracked.",
            done = mailCharacter and tonumber(mailCharacter.lastScanAt or 0) > 0,
            open = function()
                GoldMint.Print("Open your WoW mailbox. GoldMint will scan incoming gold and items automatically while it is open.")
            end,
        },
        {
            id = "market",
            title = "Initialize market data",
            detail = "Visit the Auction House once to let GoldMint build its first live market snapshot.",
            done = tonumber(fullScan.lastCompletedAt or 0) > 0 or tonumber(market.lastAuctionScanAt or 0) > 0,
            open = function()
                GoldMint.Print("Visit the Auction House once. GoldMint will build its live market snapshot automatically.")
            end,
        },
    }
end

local function GetNextOnboardingStep()
    local state = GetOnboardingState()
    for _, step in ipairs(GetOnboardingSteps()) do
        if step.done then
            state.skipped[step.id] = nil
        elseif not state.skipped[step.id] then
            return step
        end
    end
    return nil
end

local NEXT_STEP_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNextStep.tga"

local function BuildNextStepPanel()
    local p = Panel(frame, 445, 220, "TOPLEFT", 225, -382, {0.45, 0.34, 0.10, 0.95})
    panels.next = p

    local icon = p:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(NEXT_STEP_ICON)
    icon:SetSize(28, 34)
    icon:SetPoint("TOPLEFT", p, "TOPLEFT", 18, -7)
    icon:SetTexCoord(0, 1, 0, 1)
    icon:SetVertexColor(1, 1, 1, 1)
    panels.nextStepIcon = icon

    labels.nextTitle = MakeLabel(p, "GameFontNormalLarge", "YOUR NEXT STEP")
    labels.nextTitle:SetPoint("TOPLEFT", p, "TOPLEFT", 52, -14)
    -- Match the cyan section-header treatment used by the other dashboard panels.
    labels.nextTitle:SetTextColor(unpack(CYAN))
    labels.nextTitle:SetShadowOffset(1, -1)
    Accent(p, "TOPLEFT", 52, -32, 38, CYAN)

    labels.nextText = MakeLabel(p, "GameFontHighlight", "No immediate recommendation")
    labels.nextText:SetPoint("TOPLEFT", 20, -54)
    labels.nextText:SetWidth(400)
    labels.nextText:SetHeight(48)

    labels.nextDetail = MakeLabel(p, "GameFontNormal", "")
    labels.nextDetail:SetPoint("TOPLEFT", 20, -108)
    labels.nextDetail:SetWidth(400)
    labels.nextDetail:SetHeight(62)
    labels.nextDetail:SetTextColor(unpack(MUTED))
    labels.nextDetail:SetWordWrap(true)

    buttons.next = MakeButton(p, "DO THIS", 145, 30, "primary")
    buttons.next:SetPoint("BOTTOMLEFT", 20, 20)
    buttons.next:Disable()

    buttons.nextLater = MakeButton(p, "NOT NOW", 145, 30, "secondary")
    buttons.nextLater:SetPoint("BOTTOMRIGHT", -20, 20)
end

local function BuildLiveInventoryPanel()
    -- Live Inventory sits directly to the right of YOUR NEXT STEP.  It is a
    -- lightweight current-character bag snapshot: no bank/alt traversal and
    -- no periodic ticker.  It only rescans when the bags actually change or
    -- when the user presses SCAN BAGS.
    local p = Panel(frame, 320, 220, "TOPLEFT", 680, -382, {0.10, 0.34, 0.52, 0.95})
    panels.liveInventory = p

    AddUtilityIcon(p, "Interface\\AddOns\\GoldMint\\Assets\\GoldMintBag.tga", 14, -20, 20)
    labels.liveInventoryTitle = MakeLabel(p, "GameFontNormalSmall", "LIVE INVENTORY / BAG VALUE", 270)
    labels.liveInventoryTitle:SetPoint("TOPLEFT", 42, -15)
    labels.liveInventoryTitle:SetTextColor(unpack(CYAN))
    labels.liveInventoryTitle:SetWordWrap(false)

    labels.liveInventoryBag = MakeLabel(p, "GameFontNormalSmall", "Bag Space: —", 165)
    labels.liveInventoryBag:SetPoint("TOPLEFT", 18, -49)
    labels.liveInventoryBag:SetTextColor(unpack(MUTED))
    labels.liveInventoryBag:SetWordWrap(false)

    labels.liveInventoryVendor = MakeLabel(p, "GameFontNormalSmall", "Vendor Value: —", 145)
    labels.liveInventoryVendor:SetPoint("TOPLEFT", 18, -78)
    labels.liveInventoryVendor:SetTextColor(unpack(MUTED))
    labels.liveInventoryVendor:SetWordWrap(false)

    labels.liveInventoryAH = MakeLabel(p, "GameFontNormalSmall", "Est. AH Value: —", 145)
    labels.liveInventoryAH:SetPoint("TOPLEFT", 18, -101)
    labels.liveInventoryAH:SetTextColor(unpack(GREEN))
    labels.liveInventoryAH:SetWordWrap(false)

    labels.liveInventoryRows = {}
    for i = 1, 3 do
        local row = CreateFrame("Frame", nil, p)
        row:SetSize(138, 22)
        row:SetPoint("TOPLEFT", 168, -67 - ((i - 1) * 27))

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", 0, 0)
        icon:SetTexture(134400)
        row.icon = icon

        local name = MakeLabel(row, "GameFontNormalSmall", "—", 112)
        name:SetPoint("LEFT", 26, 0)
        name:SetTextColor(unpack(MUTED))
        name:SetWordWrap(false)
        name:SetNonSpaceWrap(false)
        row.name = name
        labels.liveInventoryRows[i] = row
    end

    local scan = MakeButton(p, "SCAN BAGS", 110, 24, "secondary")
    scan:SetPoint("BOTTOMLEFT", 14, 14)
    scan:SetScript("OnClick", function()
        if panels.liveInventory and panels.liveInventory.Refresh then
            panels.liveInventory:Refresh(true)
        end
    end)
    labels.liveInventoryScan = scan

    local function GetBagItemInfo(itemID, bag, slot)
        itemID = tonumber(itemID)
        if not itemID then return nil, nil, 0 end

        local name, icon, sellPrice
        if C_Item and C_Item.GetItemNameByID then
            local ok, value = pcall(C_Item.GetItemNameByID, itemID)
            if ok then name = value end
        end
        if C_Item and C_Item.GetItemIconByID then
            local ok, value = pcall(C_Item.GetItemIconByID, itemID)
            if ok then icon = value end
        end
        if C_Item and C_Item.GetItemInfo then
            local ok, n, _, _, _, _, _, _, _, _, sell = pcall(C_Item.GetItemInfo, itemID)
            if ok then
                name = name or n
                sellPrice = tonumber(sell) or 0
            end
        end
        if (not name or not icon) and C_Item and C_Item.RequestLoadItemDataByID then
            pcall(C_Item.RequestLoadItemDataByID, itemID)
        end
        return name, icon, sellPrice or 0
    end

    local function ScanBags()
        local totalSlots, freeSlots = 0, 0
        local items = {}

        if C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo then
            for bag = 0, 5 do
                local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, bag)
                local slots = okSlots and (tonumber(rawSlots) or 0) or 0
                if slots > 0 then
                    totalSlots = totalSlots + slots
                    if C_Container.GetContainerNumFreeSlots then
                        local okFree, rawFree = pcall(C_Container.GetContainerNumFreeSlots, bag)
                        if okFree then freeSlots = freeSlots + (tonumber(rawFree) or 0) end
                    end
                    for slot = 1, slots do
                        local okInfo, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
                        if okInfo and info and info.itemID and (tonumber(info.stackCount) or 0) > 0 then
                            local id = tonumber(info.itemID)
                            local count = tonumber(info.stackCount) or 0
                            local e = items[id]
                            if not e then
                                local name, icon, sell = GetBagItemInfo(id, bag, slot)
                                e = {itemID=id, count=0, sellPrice=sell or 0, name=name, icon=icon}
                                items[id] = e
                            end
                            e.count = e.count + count
                            if (not e.name or not e.icon) then
                                local name, icon, sell = GetBagItemInfo(id, bag, slot)
                                e.name = e.name or name
                                e.icon = e.icon or icon
                                if (tonumber(sell) or 0) > 0 then e.sellPrice = tonumber(sell) end
                            end
                        end
                    end
                end
            end
        end

        local usedSlots = math.max(0, totalSlots - freeSlots)
        local vendorValue, ahValue = 0, 0
        local ranked = {}
        for _, e in pairs(items) do
            e.vendorValue = (tonumber(e.sellPrice) or 0) * (tonumber(e.count) or 0)
            local unit, source = GoldMint.Market and GoldMint.Market.GetUnitValue and GoldMint.Market:GetUnitValue(e.itemID) or nil, nil
            e.ahSource = source
            e.ahUnit = (source ~= "vendor") and (tonumber(unit) or 0) or 0
            e.ahValue = e.ahUnit * (tonumber(e.count) or 0)
            vendorValue = vendorValue + e.vendorValue
            ahValue = ahValue + e.ahValue
            if e.ahValue > 0 then ranked[#ranked + 1] = e end
        end
        table.sort(ranked, function(a, b) return (a.ahValue or 0) > (b.ahValue or 0) end)

        return {
            totalSlots = totalSlots,
            freeSlots = freeSlots,
            usedSlots = usedSlots,
            vendorValue = vendorValue,
            ahValue = ahValue,
            top = ranked,
        }
    end

    local function ApplyInventoryData(data)
        if not data then return end
        labels.liveInventoryBag:SetText(string.format("Bag Space: %d / %d Slots", data.usedSlots or 0, data.totalSlots or 0))
        labels.liveInventoryVendor:SetText("Vendor Value: " .. FormatGold(data.vendorValue or 0))
        labels.liveInventoryAH:SetText("Est. AH Value: " .. FormatGold(data.ahValue or 0))

        local top = data.top or {}
        for i, row in ipairs(labels.liveInventoryRows) do
            local e = top[i]
            if e then
                row:Show()
                local displayName = e.name or ("Item " .. tostring(e.itemID))
                if #displayName > 16 then displayName = string.sub(displayName, 1, 15) .. "…" end
                row.name:SetText(displayName .. " x" .. tostring(e.count or 0))
                row.name:SetTextColor(unpack(MUTED))
                row.icon:SetTexture(e.icon or 134400)
                row:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_TOP")
                    GameTooltip:SetText(e.name or ("Item " .. tostring(e.itemID)), 0.92, 0.94, 0.98)
                    GameTooltip:AddLine("Quantity: " .. tostring(e.count or 0), 0.60, 0.74, 0.88)
                    GameTooltip:AddLine("Vendor Value: " .. FormatGold(e.vendorValue or 0), 1.0, 0.82, 0.25)
                    if (e.ahValue or 0) > 0 then
                        GameTooltip:AddLine("Est. AH Value: " .. FormatGold(e.ahValue), 0.25, 1.0, 0.55)
                    end
                    GameTooltip:Show()
                end)
                row:SetScript("OnLeave", function() GameTooltip:Hide() end)
            else
                row:Hide()
            end
        end
    end

    p._inventoryDirty = true
    p.Refresh = function(self, force)
        if force then self._inventoryDirty = true end
        if not self._inventoryDirty and self._inventoryData then return end
        self._inventoryData = ScanBags()
        self._inventoryDirty = false
        ApplyInventoryData(self._inventoryData)
    end

    p:RegisterEvent("PLAYER_ENTERING_WORLD")
    p:SetScript("OnEvent", function(self)
        self._inventoryDirty = true
        if self:IsShown() and self.Refresh then self:Refresh(false) end
    end)

    p:SetScript("OnShow", function(self)
        if self.Refresh then self:Refresh(false) end
    end)
end

local function BuildSessionPanel()
    local p = Panel(frame, 325, 235, "TOPLEFT", 1010, -126, {0.10, 0.45, 0.42, 0.95})
    panels.session = p

    -- Session Momentum icon: the user-supplied stopwatch artwork is loaded
    -- from the addon assets and sits immediately to the left of the S.
    local sessionMomentumIcon = p:CreateTexture(nil, "ARTWORK")
    sessionMomentumIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintSessionMomentum.tga")
    sessionMomentumIcon:SetSize(24, 24)
    sessionMomentumIcon:SetPoint("TOPLEFT", p, "TOPLEFT", 16, -8)
    sessionMomentumIcon:SetTexCoord(0, 1, 0, 1)
    labels.sessionMomentumIcon = sessionMomentumIcon

    AddSectionTitle(p, "sessionTitle", "SESSION MOMENTUM", CYAN, 46, -14)

    labels.sessionNet = MakeLabel(p, "GameFontHighlightLarge", "+0g", 285)
    labels.sessionNet:SetPoint("TOPLEFT", 18, -48)
    labels.sessionNet:SetJustifyH("CENTER")
    labels.sessionNet:SetTextColor(unpack(GOLD))

    labels.sessionStartName = MakeLabel(p, "GameFontNormalSmall", "SESSION PROFIT", 285)
    labels.sessionStartName:SetPoint("TOPLEFT", 18, -84)
    labels.sessionStartName:SetJustifyH("CENTER")
    labels.sessionStartName:SetTextColor(unpack(MUTED))

    labels.sessionRate = MakeLabel(p, "GameFontNormal", "+0g/hr", 285)
    labels.sessionRate:SetPoint("TOPLEFT", 18, -116)
    labels.sessionRate:SetJustifyH("CENTER")
    labels.sessionRate:SetTextColor(unpack(GREEN))

    labels.sessionEndName = MakeLabel(p, "GameFontNormalSmall", "Current Hourly Rate", 285)
    labels.sessionEndName:SetPoint("TOPLEFT", 18, -142)
    labels.sessionEndName:SetJustifyH("CENTER")
    labels.sessionEndName:SetTextColor(unpack(MUTED))

    labels.sessionStart = MakeLabel(p, "GameFontNormalSmall", "", 1)
    labels.sessionStart:Hide()
    labels.sessionEnd = MakeLabel(p, "GameFontNormalSmall", "", 1)
    labels.sessionEnd:Hide()

    labels.sessionTopSources = MakeLabel(p, "GameFontNormalSmall", "Sources: —", 285)
    labels.sessionTopSources:SetPoint("TOPLEFT", 18, -174)
    labels.sessionTopSources:SetJustifyH("CENTER")
    labels.sessionTopSources:SetTextColor(unpack(MUTED))

    labels.sessionNetDetail = MakeLabel(p, "GameFontNormalSmall", "", 285)
    labels.sessionNetDetail:SetPoint("TOPLEFT", 18, -202)
    labels.sessionNetDetail:SetJustifyH("CENTER")
    labels.sessionNetDetail:SetTextColor(unpack(MUTED))
end

local function BuildBottomPanels()
    -- Home uses the same four-card utility rail as the Routines page.
    -- Keep the geometry and bottom anchor identical so the utility cards have
    -- one consistent position everywhere they appear. The rail starts at the
    -- same left edge as Home's "YOUR NEXT STEP" panel.
    local rail = CreateFrame("Frame", nil, frame)
    rail:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 225, 32)
    rail:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 32)
    rail:SetHeight(150)
    rail:SetFrameLevel(frame:GetFrameLevel() + 4)
    panels.homeUtilityRail = rail

    local function HomeCard(w, x, h)
        return Panel(rail, w, h or 114, "BOTTOMLEFT", x, 0, {0.08,0.30,0.46,0.92})
    end

    -- The utility rail now gives the Auction House Watchlist enough width and
    -- height for five compact rows while preserving the other home cards.
    panels.cooldowns = HomeCard(252, 0, 150)
    panels.profit = HomeCard(300, 262, 150)
    panels.milestone = HomeCard(252, 572, 150)
    panels.shield = HomeCard(312, 834, 150)

    local p = panels.cooldowns
    -- Place the hourglass immediately beside the "A" in ACTIVE COOLDOWNS.
    -- The previous centered/top anchor could leave the icon visually detached
    -- from the title depending on the card width.
    local cooldownTitleIcon = AddActiveCooldownIcon(p, 0, 0, 18)
    cooldownTitleIcon:ClearAllPoints()
    cooldownTitleIcon:SetPoint("TOPLEFT", p, "TOPLEFT", 14, -13)
    labels.cooldownsTitle = MakeLabel(p, "GameFontNormalSmall", "ACTIVE COOLDOWNS", 202)
    labels.cooldownsTitle:SetPoint("TOPLEFT", 34, -15)
    labels.cooldownsTitle:SetTextColor(unpack(CYAN))
    labels.cooldownsTitle:SetWordWrap(false)
    labels.cooldownsReady = MakeLabel(p, "GameFontNormal", "0 Ready", 110)
    labels.cooldownsReady:SetPoint("TOPLEFT", 14, -42)
    labels.cooldownsReady:SetTextColor(unpack(GREEN))
    labels.cooldownsActive = MakeLabel(p, "GameFontNormalSmall", "0 In Progress", 115)
    labels.cooldownsActive:SetPoint("TOPLEFT", 124, -42)
    labels.cooldownsActive:SetTextColor(unpack(GOLD))
    labels.cooldownsDetail = MakeLabel(p, "GameFontNormalSmall", "0 Overdue", 115)
    labels.cooldownsDetail:SetPoint("TOPLEFT", 14, -68)
    labels.cooldownsDetail:SetWidth(220)
    labels.cooldownsDetail:SetWordWrap(false)
    labels.cooldownsDetail:SetTextColor(unpack(RED))

    -- Surface the best known profitable cooldown that is ready anywhere on
    -- the account.  The button stays hidden when there is no qualifying
    -- cooldown, so the home card remains compact and quiet.
    local craftNowBtn = MakeButton(p, "CRAFT NOW", 118, 24, "secondary")
    craftNowBtn:SetPoint("TOPLEFT", 14, -88)
    craftNowBtn:Hide()
    craftNowBtn._recipeID = nil
    craftNowBtn._recipeName = nil
    craftNowBtn._characterName = nil
    craftNowBtn:SetScript("OnClick", function(self)
        local recipeID = self._recipeID
        if recipeID and GoldMint.Dashboard and GoldMint.Dashboard.OpenCooldownRecipe then
            GoldMint.Dashboard:OpenCooldownRecipe(recipeID)
        end
    end)
    craftNowBtn:SetScript("OnEnter", function(self)
        if not self._recipeName then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("PROFITABLE COOLDOWN READY", 0.25, 1.0, 0.55)
        GameTooltip:AddLine(self._recipeName, 0.92, 0.94, 0.98)
        if self._characterName then
            GameTooltip:AddLine(self._characterName, 0.60, 0.74, 0.88)
        end
        if self._profit then
            GameTooltip:AddLine("Profit  +" .. FormatGold(self._profit), 1.0, 0.82, 0.25)
        end
        GameTooltip:AddLine("Click to open this cooldown.", 0.68, 0.78, 0.88)
        GameTooltip:Show()
    end)
    craftNowBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    labels.cooldownsCraftNow = craftNowBtn

    local cooldownBtn = MakeButton(p, "TRACK CDs", 80, 24, "secondary")
    cooldownBtn:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -14, 12)
    cooldownBtn:SetScript("OnClick", function()
        if GoldMint.Cooldowns and GoldMint.Cooldowns.OpenTracker then
            GoldMint.Cooldowns:OpenTracker()
        end
    end)

    -- Dedicated Auction House flip panel. This is intentionally dynamic:
    -- it ranks the latest known AH prices against market value and only shows
    -- items that are sufficiently below market to leave room for the AH cut.
    p = panels.profit
    AddUtilityIcon(p, "Interface\\AddOns\\GoldMint\\Assets\\GoldMintMarket.tga", 14, -22, 24)
    labels.homeWatchTitle = MakeLabel(p, "GameFontNormalLarge", "AUCTION HOUSE FLIPS", 460)
    labels.homeWatchTitle:SetPoint("TOPLEFT", 38, -15)
    labels.homeWatchTitle:SetTextColor(unpack(CYAN))
    labels.homeWatchTitle:SetWordWrap(false)
    labels.homeWatchTitle:SetShadowOffset(1, -1)
    Accent(p, "TOPLEFT", 38, -32, 38, CYAN)

    -- Column headers for the flip list. Keep these aligned exactly with the
    -- values rendered in each row so the panel reads like a compact table.
    labels.homeWatchHeaders = {}

    local hItem = MakeLabel(p, "GameFontNormalSmall", "Item", 250)
    hItem:SetPoint("TOPLEFT", 14, -36)
    hItem:SetTextColor(unpack(MUTED))
    hItem:SetWordWrap(false)
    labels.homeWatchHeaders.item = hItem

    local hAH = MakeLabel(p, "GameFontNormalSmall", "AH Price", 80)
    hAH:SetPoint("TOPLEFT", 290, -36)
    hAH:SetJustifyH("RIGHT")
    hAH:SetTextColor(unpack(MUTED))
    hAH:SetWordWrap(false)
    labels.homeWatchHeaders.ah = hAH

    local hMarket = MakeLabel(p, "GameFontNormalSmall", "Market Value", 100)
    hMarket:SetPoint("TOPLEFT", 380, -36)
    hMarket:SetJustifyH("RIGHT")
    hMarket:SetTextColor(unpack(MUTED))
    hMarket:SetWordWrap(false)
    labels.homeWatchHeaders.market = hMarket

    local hProfit = MakeLabel(p, "GameFontNormalSmall", "Profit", 90)
    hProfit:SetPoint("TOPLEFT", 480, -36)
    hProfit:SetJustifyH("RIGHT")
    hProfit:SetTextColor(unpack(MUTED))
    hProfit:SetWordWrap(false)
    labels.homeWatchHeaders.profit = hProfit

    labels.homeWatchRows = {}
    for i = 1, 5 do
        local y = -54 - ((i - 1) * 18)
        local row = CreateFrame("Button", nil, p)
        row:SetSize(492, 18)
        row:SetPoint("TOPLEFT", 14, y)
        row:SetHighlightTexture("Interface\\Buttons\\WHITE8X8")
        row:GetHighlightTexture():SetVertexColor(0.08, 0.25, 0.38, 0.25)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(16, 16)
        icon:SetPoint("LEFT", 0, 0)
        icon:SetTexture(134400)
        row.icon = icon

        local name = MakeLabel(row, "GameFontNormalSmall", "—", 275)
        name:SetPoint("LEFT", 20, 0)
        name:SetTextColor(unpack(MUTED))
        name:SetWordWrap(false)
        name:SetNonSpaceWrap(false)
        row.name = name

        local current = MakeLabel(row, "GameFontNormalSmall", "—", 80)
        current:SetPoint("LEFT", 290, 0)
        current:SetJustifyH("RIGHT")
        current:SetTextColor(unpack(GOLD))
        current:SetWordWrap(false)
        row.current = current

        local market = MakeLabel(row, "GameFontNormalSmall", "—", 100)
        market:SetPoint("LEFT", 380, 0)
        market:SetJustifyH("RIGHT")
        market:SetTextColor(unpack(CYAN))
        market:SetWordWrap(false)
        row.market = market

        local profit = MakeLabel(row, "GameFontNormalSmall", "—", 90)
        profit:SetPoint("LEFT", 480, 0)
        profit:SetJustifyH("RIGHT")
        profit:SetTextColor(unpack(GREEN))
        profit:SetWordWrap(false)
        row.profit = profit

        row._itemID = nil
        row:SetScript("OnEnter", function(self)
            if not self._itemID then return end
            local record = GoldMint.Market and GoldMint.Market.GetRecord and GoldMint.Market:GetRecord(self._itemID)
            if not record then return end
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(record.name or ("Item " .. tostring(self._itemID)), 0.92, 0.94, 0.98)
            GameTooltip:AddLine("AH Price: " .. (self._currentText or "—"), 1.0, 0.82, 0.25)
            if self._ahAge and self._ahAge > 0 then
                GameTooltip:AddLine(string.format("AH price observed %.1f min ago", self._ahAge / 60), 0.60, 0.74, 0.88)
            end
            GameTooltip:AddLine("TSM Market Value: " .. (self._marketText or "—"), 0.35, 0.85, 1.0)
            if self._supportedSaleText and self._supportedSaleText ~= "—" then
                GameTooltip:AddLine("Supported Sale Value: " .. self._supportedSaleText, 0.60, 0.90, 0.65)
            end
            GameTooltip:AddLine("Net Flip Profit: " .. (self._profitText or "—"), 0.25, 1.0, 0.55)
            if self._roi then
                GameTooltip:AddLine(string.format("ROI: %.1f%%", self._roi * 100), 0.60, 0.74, 0.88)
            end
            if self._volume and self._volume > 0 then
                GameTooltip:AddLine(string.format("Regional sales/day: %.1f", self._volume), 0.60, 0.74, 0.88)
            end
            if self._valuationWarning then
                GameTooltip:AddLine("WARNING: TSM valuation is not well supported by sales data.", 1.0, 0.78, 0.25)
                if self._saleAvg and self._saleAvg > 0 then
                    GameTooltip:AddLine("Regional sale average: " .. short(self._saleAvg), 0.78, 0.82, 0.90)
                end
                if self._regionMarket and self._regionMarket > 0 then
                    GameTooltip:AddLine("Regional market average: " .. short(self._regionMarket), 0.78, 0.82, 0.90)
                end
                if self._saleRate and self._saleRate > 0 then
                    GameTooltip:AddLine(string.format("Regional sale rate: %.1f%%", self._saleRate * 100), 0.78, 0.82, 0.90)
                end
                for _, reason in ipairs(self._valuationReasons or {}) do
                    GameTooltip:AddLine("• " .. reason, 1.0, 0.78, 0.25, true)
                end
                GameTooltip:AddLine("Treat the displayed profit as speculative until the AH price and sales data support it.", 0.78, 0.82, 0.90, true)
            end
            GameTooltip:AddLine("Based on the latest known market scan.", 0.68, 0.78, 0.88)
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        labels.homeWatchRows[i] = row
    end

    labels.homeWatchEmpty = MakeLabel(p, "GameFontNormalSmall", "No verified AH flip opportunities found. Scan the AH to refresh prices.", 492)
    labels.homeWatchEmpty:SetPoint("TOPLEFT", 14, -55)
    labels.homeWatchEmpty:SetTextColor(unpack(MUTED))
    labels.homeWatchEmpty:SetWordWrap(false)

    -- Swap the Home utility positions: Live Inventory occupies the lower
    -- utility rail slot, while Auction House Flips sits to the right of
    -- YOUR NEXT STEP in the main Home layout.
    if panels.liveInventory and panels.profit then
        panels.liveInventory:ClearAllPoints()
        panels.liveInventory:SetParent(rail)
        panels.liveInventory:SetSize(300, 150)
        panels.liveInventory:SetPoint("BOTTOMLEFT", rail, "BOTTOMLEFT", 262, 0)

        panels.profit:ClearAllPoints()
        panels.profit:SetParent(frame)
        panels.profit:SetSize(620, 220)
        panels.profit:SetPoint("TOPLEFT", frame, "TOPLEFT", 680, -382)
    end

    p = panels.milestone
    AddUtilityIcon(p, MILESTONE_ICON, 14, -16, 17)
    labels.milestoneTitle = MakeLabel(p, "GameFontNormalSmall", "NEXT MILESTONE", 202)
    labels.milestoneTitle:SetPoint("TOPLEFT", 37, -15)
    labels.milestoneTitle:SetTextColor(unpack(CYAN))
    labels.milestoneTitle:SetWordWrap(false)
    labels.milestone = MakeLabel(p, "GameFontNormalLarge", "—", 228)
    labels.milestone:SetPoint("TOPLEFT", 14, -43)
    labels.milestone:SetTextColor(unpack(GOLD))
    labels.milestoneDetail = MakeLabel(p, "GameFontNormalSmall", "No active goal", 228)
    labels.milestoneDetail:SetPoint("TOPLEFT", 14, -84)
    labels.milestoneDetail:SetTextColor(unpack(MUTED))

    -- The milestone progress bar exists for the home utility card, but stays
    -- completely hidden until an active goal has a real target to progress toward.
    labels.milestoneTrack = p:CreateTexture(nil, "ARTWORK")
    labels.milestoneTrack:SetColorTexture(0.06, 0.16, 0.22, 0.9)
    labels.milestoneTrack:SetSize(228, 6)
    labels.milestoneTrack:SetPoint("TOPLEFT", 14, -67)
    labels.milestoneTrack:Hide()
    labels.milestoneFill = p:CreateTexture(nil, "ARTWORK")
    labels.milestoneFill:SetColorTexture(0.25, 0.92, 0.55, 0.95)
    labels.milestoneFill:SetSize(1, 6)
    labels.milestoneFill:SetPoint("TOPLEFT", 14, -67)
    labels.milestoneFill:Hide()

    p = panels.shield
    AddUtilityIcon(p, SHIELD_ICON, 14, -16, 17)
    labels.shieldTitle = MakeLabel(p, "GameFontNormalSmall", "TIME-BLINDNESS SHIELD", 268)
    labels.shieldTitle:SetPoint("TOPLEFT", 37, -15)
    labels.shieldTitle:SetTextColor(unpack(CYAN))
    labels.shieldTitle:SetWordWrap(false)
    labels.shield = MakeLabel(p, "GameFontNormal", "Building baseline", 288)
    labels.shield:SetPoint("TOPLEFT", 14, -43)
    labels.shield:SetTextColor(unpack(GREEN))
    labels.shieldDetail = MakeLabel(p, "GameFontNormalSmall", "More 7-day history is needed.", 288)
    labels.shieldDetail:SetPoint("TOPLEFT", 14, -70)
    labels.shieldDetail:SetTextColor(unpack(MUTED))
end

local function RefreshHomeWatchlist()
    if not labels.homeWatchRows or not GoldMint.Market or not GoldMint.Market.GetAuctionHouseFlipOpportunities then return end
    local rows = GoldMint.Market:GetAuctionHouseFlipOpportunities(5) or {}
    local short = function(value)
        value = tonumber(value) or 0
        if value <= 0 then return "—" end
        if value >= 1000000 then return string.format("%.1fm", value / 1000000) end
        if value >= 100000 then return string.format("%.1fk", value / 1000) end
        return string.format("%.0f", value / 10000) .. "g"
    end
    for i, row in ipairs(labels.homeWatchRows) do
        local data = rows[i]
        if data then
            row._itemID = data.itemID
            row._currentText = short(data.current)
            row._marketText = short(data.marketValue)
            row._supportedSaleText = short(data.supportedSaleValue)
            row._profitText = "+" .. short(data.profit)
            row._roi = tonumber(data.roi) or 0
            row._volume = tonumber(data.volume) or 0
            row._saleAvg = tonumber(data.saleAvg) or 0
            row._saleRate = tonumber(data.saleRate) or 0
            row._regionMarket = tonumber(data.regionMarket) or 0
            row._ahAge = tonumber(data.ahAge) or 0
            row._ahSource = data.ahSource
            row._valuationWarning = data.valuationWarning == true
            row._valuationReasons = data.valuationReasons or {}

            local icon = 134400
            local name = data.name
            if C_Item and C_Item.GetItemIconByID then
                local ok, texture = pcall(C_Item.GetItemIconByID, data.itemID)
                if ok and texture then icon = texture end
            end
            if C_Item and C_Item.GetItemNameByID then
                local ok, value = pcall(C_Item.GetItemNameByID, data.itemID)
                if ok and value then name = value end
            end
            if (not name or not icon) and C_Item and C_Item.RequestLoadItemDataByID then
                pcall(C_Item.RequestLoadItemDataByID, data.itemID)
            end
            row.icon:SetTexture(icon)
            local displayName = name or ("Item " .. tostring(data.itemID))
            if row._valuationWarning then
                displayName = "|cffffcc00[VERIFY]|r " .. displayName
            end
            row.name:SetText(displayName)
            row.current:SetText(row._currentText)
            row.market:SetText(row._marketText)
            row.profit:SetText(row._profitText)
            row:Show()
        else
            row._itemID = nil
            row:Hide()
        end
    end
    if labels.homeWatchEmpty then labels.homeWatchEmpty:SetShown(#rows == 0) end
end

local function SetHomePanelsShown(shown)
    if panels.homeUtilityRail then
        if shown then panels.homeUtilityRail:Show() else panels.homeUtilityRail:Hide() end
    end
    local homePanels = {
        panels.goal, panels.momentum, panels.next, panels.session,
        panels.cooldowns, panels.profit, panels.milestone, panels.shield,
        panels.liveInventory, panels.homePopupButtons,
    }
    for _, p in ipairs(homePanels) do
        if p then
            if shown then p:Show() else p:Hide() end
        end
    end
end

OpenProjects = function()
    if not panels.projectsView then
        local view = CreateFrame("Frame", "GoldMintProjectsView", frame, "BackdropTemplate")
        view:SetPoint("TOPLEFT", frame, "TOPLEFT", 225, -126)
        view:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, -18)
        view:SetFrameStrata("DIALOG")
        view:SetFrameLevel(120)
        view:SetBackdrop(nil)

        local function PL(parent, text, x, y, w, color, font, justify)
            local l = MakeLabel(parent, font or "GameFontNormal", text or "", w)
            l:SetPoint("TOPLEFT", x, y)
            l:SetTextColor(unpack(color or MUTED))
            if justify then l:SetJustifyH(justify) end
            return l
        end

        local function PCard(parent, w, h, x, y, border)
            return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
        end

        local function PButton(parent, text, w, h, x, y, kind)
            local b = MakeButton(parent, text, w, h or 28, kind or "secondary")
            b:SetPoint("TOPLEFT", x, y)
            return b
        end

        local function Checkbox(parent, x, y, checked)
            -- Use Blizzard's native check-button template so the checked state
            -- renders with the standard WoW check mark instead of a text glyph
            -- that can appear as a square on some clients/fonts.
            local box = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
            box:SetSize(18,18)
            box:SetPoint("TOPLEFT", x, y)
            box:SetChecked(checked and true or false)

            -- Keep Blizzard's native check mark, but tint the mark green.
            -- This preserves the standard WoW checkbox artwork while avoiding
            -- the square/text-glyph appearance of a custom check character.
            local checkTexture = box:GetCheckedTexture()
            if checkTexture then
                checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
            end

            return box
        end

        -- Wide project banner. It intentionally uses native GoldMint surfaces
        -- rather than external artwork so the page remains self-contained.
        local banner = CreateFrame("Frame", nil, view, "BackdropTemplate")
        banner:SetSize(1136, 104)
        banner:SetPoint("TOPLEFT", 0, -2)
        banner:SetBackdrop({
            bgFile="Interface\\Buttons\\WHITE8X8",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true, tileSize=16, edgeSize=12,
            insets={left=5,right=5,top=5,bottom=5},
        })
        banner:SetBackdropColor(0.008,0.030,0.058,0.98)
        banner:SetBackdropBorderColor(0.10,0.38,0.62,0.95)
        -- Keep the entire banner on one uniform background.
        -- The previous right-side overlay made the panel appear split into
        -- two different background colors.
        PL(banner, "PROJECT WORKSPACE", 20, -20, 300, CYAN, "GameFontNormalLarge")
        local workspaceAccent = banner:CreateTexture(nil, "ARTWORK")
        workspaceAccent:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], CYAN[4] or 1)
        workspaceAccent:SetSize(28, 2)
        workspaceAccent:SetPoint("TOPLEFT", banner, "TOPLEFT", 20, -36)
        PL(banner, "Long-term goals, farming plans, investments, and the next action.", 20, -49, 620, MUTED, "GameFontNormal")
        PL(banner, "KEEP THE PLAN VISIBLE • KEEP THE NEXT STEP SMALL", 20, -76, 500, GOLD, "GameFontNormalSmall")

        local manage = PButton(view, "MANAGE PROJECT", 140, 28, 974, -20, "primary")
        manage:SetScript("OnClick", function()
            if GoldMint.OpenOptions then
                GoldMint:OpenOptions("manageproject")
            else
                OpenGoalEditor()
            end
        end)

        local projectStatus = PL(banner, "", 560, -20, 92, MUTED, "GameFontNormalSmall", "RIGHT")

        local cards = {}
        local rows = {}

        local function ClearRows()
            for _, r in ipairs(rows) do
                if r.Hide then r:Hide() end
            end
            wipe(rows)
        end

        local function ItemInfo(itemID)
            itemID = tonumber(itemID)
            if not itemID then return nil end
            local name
            if C_Item and C_Item.GetItemNameByID then
                local okName, value = pcall(C_Item.GetItemNameByID, itemID)
                if okName then name = value end
            end
            local icon
            if C_Item and C_Item.GetItemIconByID then
                local okIcon, value = pcall(C_Item.GetItemIconByID, itemID)
                if okIcon then icon = value end
            end
            local okCount, rawCount = false, 0
            if C_Item and C_Item.GetItemCount then okCount, rawCount = pcall(C_Item.GetItemCount, itemID, true, true, true, true) end
            local count = okCount and (tonumber(rawCount) or 0) or 0
            return name or ("Item " .. tostring(itemID)), icon, tonumber(count) or 0
        end

        local function FindProjectRecipe(goal)
            -- A manually tracked recipe takes priority for the Materials
            -- Gathering Tracker. Tracking a recipe is an explicit request to
            -- show the reagents needed for that craftable, even when there is
            -- no matching active project goal.
            if GoldMint.Cooldowns and GoldMint.Cooldowns.GetMaterialsRecipe then
                local tracked = GoldMint.Cooldowns:GetMaterialsRecipe()
                if tracked and type(tracked.reagents) == "table" and #tracked.reagents > 0 then
                    return tracked
                end
            end

            if not goal or not goal.itemID or not GoldMintDB or not GoldMintDB.recipes then return nil end
            local best
            for recipeID, record in pairs(GoldMintDB.recipes) do
                if tonumber(record.outputItemID) == tonumber(goal.itemID) and type(record.reagents) == "table" then
                    local current = record.characters and record.characters[GoldMint.characterKey]
                    if current and current.learned then
                        return record
                    end
                    best = best or record
                end
            end
            return best
        end

        local function RefreshProjects()
            ClearRows()

            local milestone = GoldMint.Milestones
            local goals = milestone and milestone.GetGoals and milestone:GetGoals() or {}
            local active = milestone and milestone.GetActiveGoal and milestone:GetActiveGoal() or nil
            local completed = 0
            local activeCount = 0
            local capital = 0
            local revenue = 0
            local cost = 0
            for _, goal in ipairs(goals) do
                if goal.completeAt or goal.progress >= 1 then
                    completed = completed + 1
                else
                    activeCount = activeCount + 1
                    capital = capital + (tonumber(goal.budget) or 0)
                    revenue = revenue + (tonumber(goal.expectedRevenue) or 0)
                    cost = cost + (tonumber(goal.expectedCost) or 0)
                end
            end
            local expectedProfit = revenue - cost
            local profitState = expectedProfit > 0 and GREEN or (expectedProfit < 0 and RED or MUTED)

            if active then
                local pct = math.floor(math.max(0, math.min(1, tonumber(active.progress) or 0)) * 100 + 0.5)
                projectStatus:SetText(string.format("%d%% • ACTIVE", pct))
                projectStatus:SetTextColor(unpack(GREEN))
            else
                projectStatus:SetText(completed > 0 and (tostring(completed) .. " COMPLETED") or "NO ACTIVE PROJECT")
                projectStatus:SetTextColor(unpack(MUTED))
            end

            for _, card in ipairs(cards) do card:Hide() end
            wipe(cards)

            -- Compact project metrics strip: this is the quick gold-farmer readout.
            local metricData = {
                { label = "ACTIVE PROJECTS", value = tostring(activeCount), color = CYAN },
                { label = "CAPITAL COMMITTED", value = capital > 0 and FormatGold(capital) or "Not set", color = capital > 0 and GOLD or CYAN },
                { label = "EXPECTED REVENUE", value = revenue > 0 and FormatGold(revenue) or "Not set", color = CYAN },
                { label = "EXPECTED PROFIT", value = expectedProfit ~= 0 and FormatGold(expectedProfit) or "Not set", color = expectedProfit ~= 0 and profitState or CYAN },
            }
            for i, metric in ipairs(metricData) do
                local x = (i - 1) * 284
                local card = PCard(view, 270, 62, x, -116, {0.08,0.30,0.44,0.90})
                cards[#cards + 1] = card
                local metricHeader = PL(card, metric.label, 14, -12, 240, CYAN, "GameFontNormal")
                PL(card, metric.value, 14, -34, 240, metric.color, "GameFontHighlight")
            end

            local goalCard = PCard(view, 527, 190, 0, -188, {0.38,0.30,0.08,0.95})
            cards[#cards+1] = goalCard
            local activeProjectHeader = PL(goalCard, "ACTIVE PROJECT", 16, -18, 360, CYAN, "GameFontNormalLarge")
            activeProjectHeader:SetShadowOffset(1, -1)
            local activeProjectAccent = Accent(goalCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if activeProjectHeader and activeProjectAccent then
                    local font, size, flags = activeProjectHeader:GetFont()
                    if font and size then
                        local measure = goalCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("Act")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        activeProjectAccent:SetWidth(width)
                    end
                end
            end)
            if active then
                local current = tonumber(active.currentValue) or 0
                local target = tonumber(active.target) or 0
                local pct = math.max(0, math.min(1, tonumber(active.progress) or 0))
                local nextCP = active.nextCheckpoint
                PL(goalCard, tostring(active.name or "Active Project"), 16, -50, 340, GOLD, "GameFontHighlight")
                PL(goalCard, tostring(active.projectType or "Gold Goal"), 16, -74, 180, CYAN, "GameFontNormalSmall")
                PL(goalCard, FormatGold(current) .. " / " .. FormatGold(target), 16, -98, 250, MUTED, "GameFontNormal")
                PL(goalCard, string.format("%d%% complete", math.floor(pct * 100 + 0.5)), 285, -98, 100, CYAN, "GameFontNormalSmall", "RIGHT")
                local barBG = goalCard:CreateTexture(nil,"ARTWORK")
                barBG:SetColorTexture(0.03,0.08,0.12,0.95)
                barBG:SetSize(495,8)
                barBG:SetPoint("TOPLEFT", 16, -120)
                local bar = goalCard:CreateTexture(nil,"ARTWORK")
                bar:SetColorTexture(GREEN[1],GREEN[2],GREEN[3],0.85)
                bar:SetSize(math.max(4,495*pct),8)
                bar:SetPoint("TOPLEFT", 16, -120)
                local milestoneText = nextCP and ("Next milestone: " .. tostring(nextCP.name or FormatGold(nextCP.amount))) or "No milestone set"
                PL(goalCard, milestoneText, 16, -140, 300, nextCP and CYAN or MUTED, "GameFontNormalSmall")
                if active.deadline then
                    local days = math.ceil(math.max(0, (tonumber(active.deadline) - time()) / 86400))
                    PL(goalCard, days > 0 and (tostring(days) .. " days remaining") or "Deadline reached", 350, -140, 145, days > 0 and MUTED or RED, "GameFontNormalSmall", "RIGHT")
                end
                PL(goalCard, active.remaining > 0 and (FormatGold(active.remaining) .. " remaining") or "Goal reached", 16, -164, 300, active.remaining > 0 and MUTED or GREEN, "GameFontNormalSmall")
            else
                PL(goalCard, "No active project", 16, -56, 350, GOLD, "GameFontHighlight")
                PL(goalCard, "Create a project to give GoldMint a clear destination.", 16, -84, 450, MUTED, "GameFontNormal")
                local create = PButton(goalCard, "CREATE PROJECT", 132, 28, 16, -124, "secondary")
                create:SetScript("OnClick", OpenGoalEditor)
            end

            local nextCard = PCard(view, 586, 190, 550, -188, {0.08,0.38,0.58,0.95})
            cards[#cards+1] = nextCard
            local nextStepHeader = PL(nextCard, "THE ‘NEXT STEP’ ACTION BOX", 16, -18, 365, CYAN, "GameFontNormalLarge")
            nextStepHeader:SetShadowOffset(1, -1)
            local nextStepAccent = Accent(nextCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if nextStepHeader and nextStepAccent then
                    local font, size, flags = nextStepHeader:GetFont()
                    if font and size then
                        local measure = nextCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("THE")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        nextStepAccent:SetWidth(width)
                    end
                end
            end)
            local action = GoldMint.WorkflowState and GoldMint.WorkflowState.GetNextAction and GoldMint.WorkflowState:GetNextAction() or nil
            local task = GoldMint.WorkflowState and GoldMint.WorkflowState.GetCurrentTask and GoldMint.WorkflowState:GetCurrentTask() or nil
            local actionTitle = (active and active.nextAction) or (action and action.title)
            local actionDetail = action and action.details
            if not actionTitle and active then
                if active.nextCheckpoint then
                    actionTitle = "Reach " .. tostring(active.nextCheckpoint.name or FormatGold(active.nextCheckpoint.amount))
                    actionDetail = FormatGold(active.nextCheckpoint.remaining) .. " remaining to the next milestone."
                else
                    actionTitle = "Continue toward " .. tostring(active.name or "your project")
                    actionDetail = active.remaining > 0 and (FormatGold(active.remaining) .. " remaining toward the project target.") or "Goal reached."
                end
            end
            if not actionTitle and task then
                actionTitle = task.title
                actionDetail = task.details
            end
            if actionTitle then
                PL(nextCard, actionTitle, 18, -55, 390, GOLD, "GameFontHighlight")
                PL(nextCard, actionDetail or "One clear action keeps the project moving.", 18, -82, 390, MUTED, "GameFontNormalSmall")
                local track = PButton(nextCard, "TRACK NOW", 112, 28, 18, -122, "primary")
                track:SetScript("OnClick", function()
                    if GoldMint.WorkflowState and GoldMint.WorkflowState.SetNextAction then
                        GoldMint.WorkflowState:SetNextAction(actionTitle, active and active.id or nil, actionDetail)
                        GoldMint.Print("Project next step tracked: " .. tostring(actionTitle))
                    end
                end)
                local one = Checkbox(nextCard, 148, -128, false)
                PL(nextCard, "Keep this as the only visible step", 172, -124, 205, MUTED, "GameFontNormalSmall")
            else
                PL(nextCard, "No next action is currently set.", 18, -55, 390, MUTED, "GameFontHighlight")
                PL(nextCard, "Use MANAGE PROJECT to define the next action.", 18, -84, 390, MUTED, "GameFontNormalSmall")
            end

            -- Detailed farming controls live in the dedicated minimap farming tool.
            -- Projects only keeps the measured farming performance summary below.
            local tracker = GoldMint.FarmTracker
            local performance = tracker and tracker.GetRoutePerformance and tracker:GetRoutePerformance() or nil
            local historicalGPH = tracker and tracker.GetHistoricalGPH and tracker:GetHistoricalGPH() or nil

            -- WorthIt-derived route intelligence. The route library is bundled
            -- inside GoldMint, so this panel never requires WorthIt at runtime.
            local worthCard = PCard(view, 527, 178, 0, -390, {0.08,0.38,0.58,0.95})
            cards[#cards+1] = worthCard
            local worthHeader = PL(worthCard, "WORTHIT INTELLIGENCE", 16, -18, 360, CYAN, "GameFontNormalLarge")
            worthHeader:SetShadowOffset(1, -1)
            local worthAccent = Accent(worthCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if worthHeader and worthAccent then
                    local font, size, flags = worthHeader:GetFont()
                    if font and size then
                        local measure = worthCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("WOR")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        worthAccent:SetWidth(width)
                    end
                end
            end)

            local routeDB = GoldMint.FarmRoutes
            local routeList = {}
            local routeCount, waypointCount, targetCount = 0, 0, 0
            local seenTargets = {}
            if routeDB and type(routeDB.routes) == "table" then
                for routeID, route in pairs(routeDB.routes) do
                    if type(route) == "table" then
                        routeCount = routeCount + 1
                        waypointCount = waypointCount + (tonumber(route.waypointCount) or (type(route.waypoints) == "table" and #route.waypoints or 0))
                        for _, itemID in ipairs(route.targetItemIDs or {}) do
                            if not seenTargets[itemID] then
                                seenTargets[itemID] = true
                                targetCount = targetCount + 1
                            end
                        end
                        routeList[#routeList+1] = { id = routeID, route = route }
                    end
                end
            end
            table.sort(routeList, function(a, b)
                local an = tostring((a.route and a.route.mapKey) or "") .. "|" .. tostring((a.route and a.route.name) or a.id)
                local bn = tostring((b.route and b.route.mapKey) or "") .. "|" .. tostring((b.route and b.route.name) or b.id)
                return an < bn
            end)

            PL(worthCard, string.format("%d imported routes  •  %d waypoints  •  %d targets", routeCount, waypointCount, targetCount), 16, -46, 490, MUTED, "GameFontNormalSmall")
            PL(worthCard, "WorthIt reference data is bundled in GoldMint. Your results stay separate.", 16, -68, 490, MUTED, "GameFontNormalSmall")

            local selectedRoute = routeList[1] and routeList[1].route or nil
            local selectedRouteLabel = worthCard:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            selectedRouteLabel:SetPoint("TOPLEFT", 16, -92)
            selectedRouteLabel:SetWidth(310)
            selectedRouteLabel:SetJustifyH("LEFT")
            selectedRouteLabel:SetTextColor(unpack(GOLD))

            local selectedRouteInfo = worthCard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            selectedRouteInfo:SetPoint("TOPLEFT", 16, -116)
            selectedRouteInfo:SetWidth(490)
            selectedRouteInfo:SetJustifyH("LEFT")
            selectedRouteInfo:SetTextColor(unpack(MUTED))

            local function UpdateWorthRoute(route)
                selectedRoute = route
                if not route then
                    selectedRouteLabel:SetText("No imported route data")
                    selectedRouteInfo:SetText("Import data is unavailable.")
                    return
                end
                local targets = type(route.targetNames) == "table" and #route.targetNames > 0 and table.concat(route.targetNames, ", ") or "General farming"
                selectedRouteLabel:SetText(tostring(route.name or route.key or "Imported Route"))
                selectedRouteInfo:SetText(string.format("%s  •  %d waypoints  •  targets: %s", tostring(route.mapKey or "Unknown zone"), tonumber(route.waypointCount) or (type(route.waypoints) == "table" and #route.waypoints or 0), targets))
            end
            UpdateWorthRoute(selectedRoute)

            local routePicker = PButton(worthCard, "NEXT ROUTE", 104, 26, 402, -88, "secondary")
            routePicker:SetScript("OnClick", function()
                if #routeList == 0 then return end
                local currentID = selectedRoute and selectedRoute.id
                local index = 1
                for i, entry in ipairs(routeList) do
                    if entry.id == currentID then index = i break end
                end
                index = (index % #routeList) + 1
                UpdateWorthRoute(routeList[index].route)
            end)

            local useRoute = PButton(worthCard, "USE ROUTE", 104, 26, 402, -126, "primary")
            useRoute:SetScript("OnClick", function()
                if not selectedRoute or not GoldMint.FarmTracker or not GoldMint.FarmTracker.SetRoute then return end
                local route = {}
                for k, v in pairs(selectedRoute) do route[k] = v end
                route.itemID = route.targetItemIDs and route.targetItemIDs[1] or nil
                route.itemName = route.targetNames and route.targetNames[1] or route.name
                route.routeID = route.id or route.key
                GoldMint.FarmTracker:SetRoute(route)
                if GoldMint.Print then
                    GoldMint.Print("Imported route selected for the farming tool: " .. tostring(route.name or route.key or "route"))
                end
            end)

            local farmDataCard = PCard(view, 586, 178, 550, -390, {0.38,0.30,0.08,0.90})
            cards[#cards+1] = farmDataCard
            local farmingHeader = PL(farmDataCard, "FARMING PERFORMANCE", 16, -18, 360, CYAN, "GameFontNormalLarge")
            farmingHeader:SetShadowOffset(1, -1)
            local farmingAccent = Accent(farmDataCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if farmingHeader and farmingAccent then
                    local font, size, flags = farmingHeader:GetFont()
                    if font and size then
                        local measure = farmDataCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("FAR")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        farmingAccent:SetWidth(width)
                    end
                end
            end)
            if performance then
                PL(farmDataCard, "MEASURED FARM PERFORMANCE", 16, -50, 280, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, FormatGold(performance.valuePerHour) .. "/hr", 16, -72, 220, GREEN, "GameFontHighlight")
                PL(farmDataCard, string.format("%d sessions", tonumber(performance.sessions) or 0), 410, -72, 145, CYAN, "GameFontNormalSmall", "RIGHT")
                PL(farmDataCard, "Items / hour", 16, -104, 150, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, string.format("%.1f", tonumber(performance.itemsPerHour) or 0), 16, -126, 120, CYAN, "GameFontHighlight")
                PL(farmDataCard, "Confidence", 205, -104, 120, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, string.format("%.0f%%", tonumber(performance.averageConfidence) or 0), 205, -126, 120, CYAN, "GameFontHighlight")
                local routeText = performance.zone and (tostring(performance.zone) .. (performance.area and (" • " .. tostring(performance.area)) or "")) or "Measured route history"
                PL(farmDataCard, routeText, 16, -154, 530, MUTED, "GameFontNormalSmall")
            elseif historicalGPH then
                PL(farmDataCard, "HISTORICAL FARM DATA", 16, -50, 280, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, FormatGold(historicalGPH) .. "/hr", 16, -72, 220, CYAN, "GameFontHighlight")
                PL(farmDataCard, "Keep farming this route to build measured evidence.", 16, -108, 500, MUTED, "GameFontNormalSmall")
            else
                PL(farmDataCard, "BUILD YOUR FARMING DATA", 16, -50, 300, GOLD, "GameFontHighlight")
                PL(farmDataCard, "GoldMint records loot, expenses, route time, and", 16, -78, 500, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, "route performance during farm sessions.", 16, -100, 500, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, "Measured GPH appears after real sessions — no invented estimates.", 16, -132, 540, CYAN, "GameFontNormalSmall")
            end

        end

        view:SetScript("OnShow", RefreshProjects)
        panels.projectsView = view
        panels.projectsRefresh = RefreshProjects
    end
    SetHomePanelsShown(false)
    if panels.operationsView then panels.operationsView:Hide() end
    panels.projectsView:Show()
    panels.projectsView:Raise()
    -- Rebuild immediately on every Projects navigation click.  Relying only
    -- on OnShow is not sufficient because the frame may already be shown
    -- when the player returns to Projects, and the first navigation can also
    -- occur during frame creation.
    if panels.projectsRefresh then
        panels.projectsRefresh()
    end
    SetNavigationActive("projects")
end

OpenPlanner = function(section)
    if not panels.plannerView then
        local view = CreateFrame("Frame", "GoldMintPlannerView", frame, "BackdropTemplate")
        view:SetPoint("TOPLEFT", frame, "TOPLEFT", 210, -126)
        view:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, -18)
        view:SetFrameStrata("DIALOG")
        view:SetFrameLevel(320)
        view:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8, edgeSize=1})
        view:SetBackdropColor(0.004,0.012,0.022,0.99)
        view:SetBackdropBorderColor(0.10,0.42,0.66,0.98)
        if UISpecialFrames then tinsert(UISpecialFrames, "GoldMintPlannerView") end

        local title=MakeLabel(view,"GameFontNormalLarge","GOLDMINT PLANNER")
        title:SetPoint("TOPLEFT",22,-18); title:SetTextColor(unpack(CYAN))
        local sub=MakeLabel(view,"GameFontNormal","One decision at a time. Choose how much time or attention you have.")
        sub:SetPoint("TOPLEFT",22,-48); sub:SetTextColor(unpack(MUTED))

        local focus=MakeButton(view,"FOCUS MODE",125,28,"secondary"); focus:SetPoint("TOPRIGHT",-116,-16)

        local body=CreateFrame("Frame",nil,view); body:SetPoint("TOPLEFT",22,-82); body:SetPoint("BOTTOMRIGHT",-22,48)
        local left=Panel(body,235,438,"TOPLEFT",0,0,{0.08,0.28,0.42,0.9})
        local right=Panel(body,535,438,"TOPRIGHT",0,0,{0.08,0.28,0.42,0.9})
        local modeTitle=MakeLabel(left,"GameFontHighlight","ENERGY / PLAY STYLE"); modeTitle:SetPoint("TOPLEFT",16,-16); modeTitle:SetTextColor(unpack(GOLD))
        local modeDesc=MakeLabel(left,"GameFontNormalSmall","Recommendations adapt to effort, not just gold/hour.",190); modeDesc:SetPoint("TOPLEFT",16,-42); modeDesc:SetTextColor(unpack(MUTED)); modeDesc:SetJustifyH("LEFT")
        local modes={"Maximum Gold","Sustainable","Relaxed","Maintenance"}
        local modeButtons={}
        local render
        local function getSettings()
            GoldMintDB.settings=GoldMintDB.settings or {}
            GoldMintDB.settings.playStyle=GoldMintDB.settings.playStyle or "Sustainable"
            return GoldMintDB.settings
        end
        local function setMode(m)
            getSettings().playStyle=m
            for k,b in pairs(modeButtons) do b:SetBackdropBorderColor(k==m and 1.0 or 0.10,k==m and 0.78 or 0.34,k==m and 0.20 or 0.52,1) end
            render()
        end
        for i,m in ipairs(modes) do
            local b=MakeButton(left,m,195,30,"secondary"); b:SetPoint("TOPLEFT",16,-78-(i-1)*42); b:SetScript("OnClick",function() setMode(m) end); modeButtons[m]=b
        end
        local quickTitle=MakeLabel(left,"GameFontHighlight","I HAVE..."); quickTitle:SetPoint("TOPLEFT",16,-258); quickTitle:SetTextColor(unpack(CYAN))
        local quick={ {"5 MINUTES",5},{"10 MINUTES",10},{"20 MINUTES",20},{"30 MINUTES",30},{"1 HOUR",60} }
        local selectedMinutes=10
        for i,q in ipairs(quick) do
            local b=MakeButton(left,q[1],195,27,"secondary"); b:SetPoint("TOPLEFT",16,-284-(i-1)*31); b:SetScript("OnClick",function() selectedMinutes=q[2]; render() end)
        end

        local contentTitle=MakeLabel(right,"GameFontNormalLarge","WHAT SHOULD I DO?"); contentTitle:SetPoint("TOPLEFT",18,-16); contentTitle:SetTextColor(unpack(CYAN))
        local content=MakeLabel(right,"GameFontNormal","",480); content:SetPoint("TOPLEFT",18,-52); content:SetTextColor(unpack(MUTED)); content:SetJustifyH("LEFT"); content:SetWordWrap(true)
        local idea=CreateFrame("EditBox",nil,right,"InputBoxTemplate"); idea:SetSize(300,28); idea:SetPoint("BOTTOMLEFT",320,18); idea:SetAutoFocus(false); idea:SetTextInsets(8,8,0,0); idea:SetText("")
        local ideaAdd=MakeButton(right,"SAVE IDEA",105,30,"secondary"); ideaAdd:SetPoint("BOTTOMRIGHT",-18,18)
        local action=MakeButton(right,"USE THIS PLAN",150,30,"secondary"); action:SetPoint("BOTTOMLEFT",18,18)
        local later=MakeButton(right,"PUT IN LATER",135,30,"secondary"); later:SetPoint("BOTTOMLEFT",178,18)
        ideaAdd:SetScript("OnClick",function()
            local text=idea:GetText()
            if text and text ~= "" and GoldMint.WorkflowState and GoldMint.WorkflowState.AddReminder then
                GoldMint.WorkflowState:AddReminder(text,nil,"idea:"..string.lower((text:gsub("[^%w]+","_"))))
                idea:SetText("")
                GoldMint.Print("Saved idea for later: "..text)
            end
        end)

        local function currentData()
            local goal=GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil
            local ready,active=0,0
            if GoldMint.Cooldowns and GoldMint.Cooldowns.GetSummary then ready,active=GoldMint.Cooldowns:GetSummary() end
            local mail=GoldMint.MailTracking and GoldMint.MailTracking.GetSummary and GoldMint.MailTracking:GetSummary() or nil
            local routines=GoldMint.RoutineState and GoldMint.RoutineState.GetSummary and GoldMint.RoutineState:GetSummary() or nil
            return goal,tonumber(ready) or 0,tonumber(active) or 0,mail,routines
        end
        render=function()
            local goal,ready,active,mail,routines=currentData()
            local mode=getSettings().playStyle
            local lines={"MODE: "..mode,"TIME BUDGET: "..selectedMinutes.." minutes",""}
            if section == "inventory" then
                lines[#lines+1] = "INVENTORY RESET"
                lines[#lines+1] = "Review items without forcing a decision."
                lines[#lines+1] = "SELL  •  BANK  •  CRAFT  •  MAIL  •  VENDOR  •  DECIDE LATER"
                lines[#lines+1] = ""
            elseif section == "recipes" then
                lines[#lines+1] = "CRAFTING WORKBENCH"
                lines[#lines+1] = "Find the best crafting opportunities from your scanned profession data."
                lines[#lines+1] = ""
            elseif section == "market" then
                lines[#lines+1] = "MARKET CHECK"
                lines[#lines+1] = "Use tracked auction benchmarks and volatility before committing attention."
                lines[#lines+1] = ""
            elseif section == "wealth" then
                lines[#lines+1] = "WEALTH SNAPSHOT"
                lines[#lines+1] = "Gold, session velocity, and project pacing stay together."
                lines[#lines+1] = ""
            elseif section == "routines" then
                lines[#lines+1] = "CURRENT + LEGACY ROUTINES"
                lines[#lines+1] = "GoldMint separates current-expansion work from legacy work to reduce clutter."
                lines[#lines+1] = ""
            end
            local welcome=GoldMint.WorkflowState and GoldMint.WorkflowState.GetWelcomeBackState and GoldMint.WorkflowState:GetWelcomeBackState() or nil
            if welcome and welcome.task and welcome.task.title then
                lines[#lines+1]="WELCOME BACK"
                lines[#lines+1]="You were working on: "..tostring(welcome.task.title)
                if welcome.nextAction and welcome.nextAction.title then lines[#lines+1]="Next: "..tostring(welcome.nextAction.title) end
                lines[#lines+1]=""
            end
            local task,why="",""
            if ready>0 and selectedMinutes>=4 then
                task="Collect ready cooldowns (~4 min)"
                why=string.format("%d cooldown%s are ready now.",ready,ready==1 and " is" or "s are")
            elseif mail and tonumber(mail.attachmentCount or 0)>0 then
                task="Review incoming mail"
                why=string.format("%d attachment%s need attention.",tonumber(mail.attachmentCount or 0),tonumber(mail.attachmentCount or 0)==1 and " is" or "s are")
            elseif routines and tonumber(routines.ready or 0)>0 then
                task="Review ready routines"
                why=string.format("%d routine item%s are ready.",tonumber(routines.ready or 0),tonumber(routines.ready or 0)==1 and " is" or "s are")
            elseif goal then
                task="Continue toward "..tostring(goal.name)
                why=goal.nextCheckpoint and ("Next checkpoint: "..tostring(goal.nextCheckpoint.name or ShortGold(goal.nextCheckpoint.amount))) or "Your active savings goal is the current priority."
            else
                task="Create your first savings goal"
                why="A goal gives GoldMint a reason to prioritize your next action."
            end
            if selectedMinutes < 4 then task="Just check in"; why="No task is required for a tiny check-in." end
            lines[#lines+1]="NEXT: "..task
            lines[#lines+1]=""
            lines[#lines+1]="WHY THIS?"
            lines[#lines+1]=why
            lines[#lines+1]=""
            lines[#lines+1]="Principle: optimize gold per unit of attention, not gold/hour alone."
            content:SetText(table.concat(lines,"\n"))
            local taskID="planner:"..string.lower((task:gsub("[^%w]+","_")))
            action:SetScript("OnClick",function()
                if GoldMint.WorkflowState then
                    GoldMint.WorkflowState:SetCurrentTask(task,taskID,{reason=why,minutes=selectedMinutes,mode=mode})
                    GoldMint.WorkflowState:SetNextAction(task,taskID,{reason=why,minutes=selectedMinutes,mode=mode})
                end
                view:Hide(); Refresh(); GoldMint.Print("Current task set: "..task)
            end)
            later:SetScript("OnClick",function()
                if GoldMint.WorkflowState and GoldMint.WorkflowState.AddReminder then GoldMint.WorkflowState:AddReminder(task,nil,taskID) end
                GoldMint.Print("Saved for later: "..task)
            end)
            for k,b in pairs(modeButtons) do local activeMode=(k==mode); b:SetBackdropBorderColor(activeMode and 1.0 or 0.10,activeMode and 0.78 or 0.34,activeMode and 0.20 or 0.52,1) end
        end
        focus:SetScript("OnClick",function()
            local goal,ready=GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil,0
            if GoldMint.Cooldowns and GoldMint.Cooldowns.GetSummary then ready=GoldMint.Cooldowns:GetSummary() end
            local task=(ready and ready>0) and "Collect ready cooldowns" or (goal and "Continue toward "..tostring(goal.name) or "Create your first savings goal")
            content:SetText("FOCUS MODE\n\n"..task.."\n\nOne next action.\nNo unrelated tasks.\nNo extra notifications.")
        end)
        view:SetScript("OnShow",function() render() end)
        panels.plannerView=view
    end
    panels.plannerView:Show(); panels.plannerView:Raise()
end


OpenOperations = function(section)
    if cooldownFilterMenu then cooldownFilterMenu:Hide() end
    if not panels.operationsView then
        local view = CreateFrame("Frame", "GoldMintOperationsView", frame)
        view:SetPoint("TOPLEFT", frame, "TOPLEFT", 210, -126)
        view:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, -18)
        view:SetFrameStrata("DIALOG"); view:SetFrameLevel(120)
        local title=MakeLabel(view,"GameFontNormalLarge","GOLDMINT OPERATIONS"); title:SetPoint("TOPLEFT",22,-18); title:SetTextColor(unpack(CYAN))
        local sub=MakeLabel(view,"GameFontNormal","Inventory, mail, crafting, market, routines, and gentle maintenance tools."); sub:SetPoint("TOPLEFT",22,-48); sub:SetTextColor(unpack(MUTED))
        local content=CreateFrame("Frame",nil,view); content:SetPoint("TOPLEFT",22,-130); content:SetPoint("BOTTOMRIGHT",-22,22)
        local tabs={"wealth","cooldowns","inventory","recipes","market","routines"}; local tabButtons={}
        local function wipeContent() for _,c in ipairs({content:GetChildren()}) do c:Hide() end end
        local function L(text,x,y,w,color,font) local l=MakeLabel(content,font or "GameFontNormal",text,w); l:SetPoint("TOPLEFT",x,y); l:SetTextColor(unpack(color or MUTED)); return l end
        local show
        local function inventory()
            -- Dedicated Inventory page.  This follows the supplied GoldMint
            -- inventory reference: summary/list on the left, storage distribution
            -- and session context on the right, then a wide restock/attention area.
            for _, b in pairs(tabButtons) do b:Hide() end
            title:SetText("")
            sub:SetText("")
            content:ClearAllPoints()
            -- Align the Inventory page's two top panels with the top edge of
            -- the left navigation rail. The operations view already shares the
            -- navigation rail's TOPLEFT anchor, so zero top inset keeps the
            -- panel tops on the same horizontal baseline.
            content:SetPoint("TOPLEFT", view, "TOPLEFT", 0, 0)
            content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)

            local page = CreateFrame("Frame", nil, content)
            page:SetAllPoints(content)
            -- Keep the page surface transparent. The individual inventory cards
            -- provide their own dark panels while the supplied dashboard artwork
            -- remains visible in the space between them.

            local function IL(parent, text, x, y, w, color, font, justify)
                local l = MakeLabel(parent, font or "GameFontNormal", text, w)
                l:SetPoint("TOPLEFT", x, y)
                l:SetTextColor(unpack(color or MUTED))
                if justify then l:SetJustifyH(justify) end
                return l
            end

            local function Card(parent, w, h, x, y, border)
                return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
            end

            local function TinyButton(parent, text, w, x, y)
                local b = MakeButton(parent, text, w, 28, "secondary")
                b:SetPoint("TOPLEFT", x, y)
                return b
            end

            local filterCard = Card(page, 1036, 46, 6, 0, {0.08,0.38,0.58,0.95})
            local filterSearch = CreateFrame("EditBox", nil, filterCard, "InputBoxTemplate")
            filterSearch:SetSize(210, 24)
            filterSearch:SetPoint("TOPLEFT", 12, -9)
            filterSearch:SetText("Search Inventory...")
            filterSearch:SetTextColor(unpack(MUTED))
            filterSearch:SetScript("OnEditFocusGained", function(self)
                if self:GetText() == "Search Inventory..." then self:SetText(""); self:SetTextColor(1,1,1) end
            end)
            filterSearch:SetScript("OnEditFocusLost", function(self)
                if self:GetText() == "" then self:SetText("Search Inventory..."); self:SetTextColor(unpack(MUTED)) end
            end)
            filterSearch:SetAutoFocus(false)
            filterSearch:SetTextInsets(7, 7, 0, 0)
            filterSearch:SetText("")

            local categoryButton = TinyButton(filterCard, "ALL CATEGORIES", 118, 244, -9)
            local locationButton = TinyButton(filterCard, "ALL LOCATIONS", 112, 368, -9)
            local sortButton = TinyButton(filterCard, "SORT: VALUE", 104, 488, -9)
            local refreshFilter = TinyButton(filterCard, "REFRESH", 72, 600, -9)

            local listCard = Card(page, 700, 300, 6, -54, {0.08,0.38,0.58,0.95})
            local inventoryHeader = IL(listCard, "INVENTORY OVERVIEW", 18, -18, 330, CYAN, "GameFontNormalLarge")
            local inventoryAccent = Accent(listCard, "TOPLEFT", 18, -36, 38, CYAN)
            C_Timer.After(0, function()
                if inventoryHeader and inventoryAccent then
                    local prefix = "INV"
                    local font, size, flags = inventoryHeader:GetFont()
                    if font and size then
                        local measure = listCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText(prefix)
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        inventoryAccent:SetWidth(width)
                    end
                end
            end)
            local summaryLabel = IL(listCard, "Items Summary:", 18, -70, 105, MUTED, "GameFontNormal", "LEFT")
            summaryLabel:SetWordWrap(false)
            summaryLabel:SetNonSpaceWrap(false)

            local inventoryData = nil
            local categoryFilter = "All Categories"
            local locationFilter = "All Locations"
            local sortMode = "Value"
            local selectedItem = nil

            local function ItemCategory(e)
                -- Prefer Blizzard's item class/subclass data. The older text-only
                -- classifier could return "Miscellaneous" for items whose item
                -- data had not finished loading, making the category button appear
                -- to remove everything.
                local classText = string.lower(tostring(e.itemType or ""))
                local subText = string.lower(tostring(e.itemSubType or ""))
                if string.find(classText, "trade goods", 1, true) or string.find(classText, "profession", 1, true)
                    or string.find(classText, "material", 1, true) or string.find(subText, "reagent", 1, true)
                    or string.find(subText, "trade goods", 1, true) then
                    return "Materials"
                elseif string.find(classText, "consumable", 1, true) or string.find(subText, "potion", 1, true)
                    or string.find(subText, "elixir", 1, true) or string.find(subText, "food", 1, true) then
                    return "Consumables"
                elseif string.find(classText, "armor", 1, true) or string.find(classText, "weapon", 1, true)
                    or string.find(classText, "equipment", 1, true) then
                    return "Equipment"
                end
                return "Miscellaneous"
            end

            local function HasLocation(e, loc)
                if loc == "All Locations" then return true end
                if loc == "Inventory" then return (e.bagCount or 0) > 0 end
                if loc == "Bank" then return (e.bankCount or 0) > 0 end
                if loc == "Guild Bank" then return (e.guildBankCount or 0) > 0 end
                if loc == "Warband" then return (e.warbandCount or 0) > 0 end
                if loc == "Alts" then return (e.altCount or 0) > 0 end
                return true
            end

            local RefreshList

            -- Use small anchored menus rather than cycling silently through values.
            -- Each click now opens a real choice list, and selecting an option
            -- immediately rebuilds the visible inventory rows.
            local openFilterMenu
            local function MakeFilterMenu(button, options, setter)
                local menu = CreateFrame("Frame", nil, filterCard, "BackdropTemplate")
                menu:SetFrameStrata("TOOLTIP")
                menu:SetFrameLevel(200)
                menu:SetSize(button:GetWidth(), math.min(230, 26 * #options + 8))
                menu:SetBackdrop({
                    bgFile="Interface\\Buttons\\WHITE8X8",
                    edgeFile="Interface\\Buttons\\WHITE8X8",
                    tile=true, tileSize=8, edgeSize=1,
                })
                menu:SetBackdropColor(0.006,0.028,0.050,0.99)
                menu:SetBackdropBorderColor(0.10,0.55,0.80,1)
                menu:Hide()
                for i, option in ipairs(options) do
                    local item = MakeButton(menu, option:upper(), menu:GetWidth()-8, 24, "secondary")
                    item:SetPoint("TOPLEFT", 4, -4-(i-1)*26)
                    item:SetScript("OnClick", function()
                        setter(option)
                        menu:Hide()
                        if RefreshList then RefreshList(false) end
                    end)
                end
                button:SetScript("OnClick", function()
                    if openFilterMenu and openFilterMenu ~= menu then openFilterMenu:Hide() end
                    if menu:IsShown() then menu:Hide(); openFilterMenu=nil; return end
                    menu:ClearAllPoints()
                    menu:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -2)
                    menu:Show()
                    openFilterMenu=menu
                end)
                return menu
            end

            local categoryMenu = MakeFilterMenu(categoryButton,
                {"All Categories", "Materials", "Consumables", "Equipment", "Miscellaneous"},
                function(option)
                    categoryFilter=option
                    categoryButton:SetText(option:upper())
                end)
            local locationMenu = MakeFilterMenu(locationButton,
                {"All Locations", "Inventory", "Bank", "Guild Bank", "Warband", "Alts"},
                function(option)
                    locationFilter=option
                    locationButton:SetText(option:upper())
                end)
            local sortMenu = MakeFilterMenu(sortButton,
                {"Value", "Name", "Quantity", "Location"},
                function(option)
                    sortMode=option
                    sortButton:SetText("SORT: "..option:upper())
                end)

            categoryButton:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText("Choose an item category")
                GameTooltip:Show()
            end)
            categoryButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
            locationButton:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText("Choose a storage location")
                GameTooltip:Show()
            end)
            locationButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
            sortButton:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText("Choose how inventory is sorted")
                GameTooltip:Show()
            end)
            sortButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

            local search = filterSearch
            search:SetScript("OnTextChanged", function(self, userInput)
                if RefreshList then RefreshList(false) end
            end)

            local ahTotalLabel = IL(listCard, "AH Value: 0", 455, -18, 220, GOLD, "GameFontNormalSmall", "RIGHT")
            ahTotalLabel:SetWordWrap(false)
            ahTotalLabel:SetNonSpaceWrap(false)
            local vendorTotalLabel = IL(listCard, "Vendor Value: 0", 455, -34, 220, GOLD, "GameFontNormalSmall", "RIGHT")
            vendorTotalLabel:SetWordWrap(false)
            vendorTotalLabel:SetNonSpaceWrap(false)
            local totalLabel = IL(listCard, "Total Inventory Value: 0", 455, -50, 220, GOLD, "GameFontNormalSmall", "RIGHT")
            totalLabel:SetWordWrap(false)
            totalLabel:SetNonSpaceWrap(false)
            local divider = listCard:CreateTexture(nil, "ARTWORK")
            divider:SetColorTexture(0.08,0.25,0.38,0.82)
            divider:SetSize(1,1)
            divider:SetPoint("TOPLEFT", 18, -84)
            divider:SetPoint("TOPRIGHT", -18, -84)
            IL(listCard, "Item", 18, -98, 210, MUTED, "GameFontNormalSmall")
            IL(listCard, "Value", 270, -98, 120, MUTED, "GameFontNormalSmall")
            IL(listCard, "Location", 500, -98, 160, MUTED, "GameFontNormalSmall")

            local scroll, rows = CreateGoldMintScrollFrame(listCard, 10, -112, -22, 14, 632)
            listCard.scroll = scroll
            listCard.rows = rows
            listCard.rowWidgets = {}

            -- Storage Distribution mirrors the reference: a compact, tall card with
            -- all six storage locations visible at once. Guild Bank is last, after AH.
            local storageCard = Card(page, 330, 300, 712, -54, {0.08,0.38,0.58,0.95})
            local storageHeader = IL(storageCard, "STORAGE DISTRIBUTION", 18, -18, 270, CYAN, "GameFontNormalLarge")
            local storageAccent = Accent(storageCard, "TOPLEFT", 18, -36, 38, CYAN)
            C_Timer.After(0, function()
                local font, size, flags = storageHeader:GetFont()
                local measure = storageCard:CreateFontString(nil, "OVERLAY")
                measure:SetFont(font, size, flags); measure:SetText("STO")
                storageAccent:SetWidth(math.max(1, math.ceil(measure:GetStringWidth()))); measure:Hide()
            end)
            IL(storageCard, "Items", 184, -40, 50, GOLD, "GameFontNormalSmall", "RIGHT")
            IL(storageCard, "Gold", 255, -40, 40, CYAN, "GameFontNormalSmall", "RIGHT")

            local distribution = {}
            for i, name in ipairs({"Bag", "Bank", "Warband", "Alts", "Auction House", "Guild Bank"}) do
                local y = -58 - (i-1)*28
                local itemBar = storageCard:CreateTexture(nil, "ARTWORK")
                itemBar:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 0.80)
                itemBar:SetPoint("TOPLEFT", 92, y-2)
                itemBar:SetSize(100, 7)
                local goldBar = storageCard:CreateTexture(nil, "ARTWORK")
                goldBar:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 0.80)
                goldBar:SetPoint("TOPLEFT", 92, y-13)
                goldBar:SetSize(100, 5)
                distribution[name] = {
                    label = IL(storageCard, name, 18, y, 70, MUTED, "GameFontNormalSmall"),
                    item = IL(storageCard, "0%", 205, y+1, 42, GOLD, "GameFontNormalSmall", "RIGHT"),
                    gold = IL(storageCard, "0%", 260, y+1, 42, CYAN, "GameFontNormalSmall", "RIGHT"),
                    itemBar = itemBar,
                    goldBar = goldBar,
                }
            end

            local detailCard = Card(page, 1036, 126, 6, -366, {0.08,0.48,0.28,0.95})
            local detailHeader = IL(detailCard, "ITEM DETAILS", 18, -18, 270, CYAN, "GameFontNormalLarge")
            local detailAccent = Accent(detailCard, "TOPLEFT", 18, -36, 38, CYAN)
            C_Timer.After(0, function()
                local font, size, flags = detailHeader:GetFont()
                local measure = detailCard:CreateFontString(nil, "OVERLAY")
                measure:SetFont(font, size, flags); measure:SetText("ITE")
                detailAccent:SetWidth(math.max(1, math.ceil(measure:GetStringWidth()))); measure:Hide()
            end)
            local detailEmpty = IL(detailCard, "Select an item to view its details.", 18, -46, 400, MUTED, "GameFontNormalSmall")
            local detailIcon = detailCard:CreateTexture(nil, "ARTWORK")
            detailIcon:SetSize(58,58); detailIcon:SetPoint("TOPLEFT", 18, -46); detailIcon:SetTexture(134400); detailIcon:Hide()
            local detailName = IL(detailCard, "", 92, -46, 360, GOLD, "GameFontHighlight")
            detailName:SetWordWrap(false); detailName:SetNonSpaceWrap(false)
            local detailQty = IL(detailCard, "", 92, -68, 220, MUTED, "GameFontNormalSmall")
            local detailLocation = IL(detailCard, "", 92, -86, 360, MUTED, "GameFontNormalSmall")
            local detailSource = IL(detailCard, "", 92, -104, 650, CYAN, "GameFontNormalSmall")
            detailSource:SetWordWrap(false); detailSource:SetNonSpaceWrap(false)
            local detailValue = IL(detailCard, "", 500, -50, 220, GOLD, "GameFontNormalSmall")
            local detailVendor = IL(detailCard, "", 500, -70, 220, MUTED, "GameFontNormalSmall")
            local detailStatus = IL(detailCard, "", 760, -50, 220, GREEN, "GameFontNormalSmall")
            local detailTracked = IL(detailCard, "", 760, -70, 220, GREEN, "GameFontNormalSmall")

            local restock = Card(page, 1036, 160, 6, -500, {0.08,0.38,0.58,0.95})
            local restockHeader = IL(restock, "RESTOCK CALCULATOR", 18, -18, 350, CYAN, "GameFontNormalLarge")
            local restockAccent = Accent(restock, "TOPLEFT", 18, -36, 38, CYAN)
            C_Timer.After(0, function()
                local font, size, flags = restockHeader:GetFont()
                local measure = restock:CreateFontString(nil, "OVERLAY")
                measure:SetFont(font, size, flags); measure:SetText("RES")
                restockAccent:SetWidth(math.max(1, math.ceil(measure:GetStringWidth()))); measure:Hide()
            end)
            IL(restock, "Stock the items GoldMint has actually observed selling on the Auction House.", 18, -45, 620, MUTED, "GameFontNormalSmall")
            local restockLeft = CreateFrame("Frame", nil, restock)
            restockLeft:SetSize(480, 88)
            restockLeft:SetPoint("TOPLEFT", 18, -66)
            local restockRight = CreateFrame("Frame", nil, restock)
            restockRight:SetSize(420, 88)
            restockRight:SetPoint("TOPLEFT", 520, -66)
            IL(restockLeft, "TOP SELLERS • LAST 30 DAYS", 0, 0, 470, CYAN, "GameFontHighlight")
            IL(restockRight, "RESTOCK TARGETS", 0, 0, 400, CYAN, "GameFontHighlight")
            local sellerRows, targetRows = {}, {}
            local sellerStatus = IL(restockLeft, "No AH sales observed yet. GoldMint will learn from your sold auctions.", 0, -28, 470, MUTED, "GameFontNormalSmall")
            local targetStatus = IL(restockRight, "No restock recommendation yet.", 0, -28, 400, MUTED, "GameFontNormalSmall")
            local prep = TinyButton(restock, "PREPARE CLEANUP", 150, 18, -124)
            prep:SetScript("OnClick", function()
                if GoldMint.Accessibility and GoldMint.Accessibility.PrepareSmartDump then
                    GoldMint.Accessibility:PrepareSmartDump()
                    if restock.Refresh then restock:Refresh() end
                end
            end)
            local marketBtn = TinyButton(restock, "VIEW MARKET", 125, 178, -124)
            marketBtn:SetScript("OnClick", function() if show then show("market") end end)

            local function ClearRows(list)
                for _, row in ipairs(list) do row:Hide() end
                wipe(list)
            end

            local function BuildRestockRows()
                ClearRows(sellerRows)
                ClearRows(targetRows)
                local top = GoldMint.Market and GoldMint.Market.GetTopSellers and GoldMint.Market:GetTopSellers(4, 30) or {}
                local targets = GoldMint.Market and GoldMint.Market.GetRestockRecommendations and GoldMint.Market:GetRestockRecommendations(4, 30) or {}
                if #top == 0 then
                    sellerStatus:SetText("No AH sales observed yet. GoldMint will learn from your sold auctions.")
                else
                    sellerStatus:SetText("")
                    for i, row in ipairs(top) do
                        local text = string.format("%d. %s • %dx sold • %s", i, row.name or ("Item "..row.itemID), row.unitsSold or 0, FormatGold(row.revenue or 0))
                        local l = IL(restockLeft, text, 0, -((i-1)*20)-26, 380, i==1 and GOLD or MUTED, "GameFontNormalSmall")
                        l:SetWordWrap(false)
                        sellerRows[#sellerRows+1] = l
                    end
                end
                local shown=0
                for _, row in ipairs(targets) do
                    if (row.need or 0) > 0 and shown < 4 then
                        shown=shown+1
                        local text = string.format("%s • need %d • %d/%d", row.name or ("Item "..row.itemID), row.need or 0, row.stock or 0, row.target or 0)
                        local l = IL(restockRight, text, 0, -((shown-1)*20)-26, 250, shown==1 and GOLD or MUTED, "GameFontNormalSmall")
                        l:SetWordWrap(false)
                        targetRows[#targetRows+1] = l
                    end
                end
                if shown == 0 then targetStatus:SetText("You're stocked on the best observed sellers.") else targetStatus:SetText("") end
            end

            local function GetItemInfo(itemID)
                itemID = tonumber(itemID)
                if not itemID then return nil end
                if C_Item and C_Item.GetItemInfo then
                    local ok, name, link, quality, _, _, _, _, _, icon = pcall(C_Item.GetItemInfo, itemID)
                    if ok then return name, link, quality, icon end
                elseif GetItemInfo then
                    local ok, name, link, quality, _, _, _, _, _, icon = pcall(GetItemInfo, itemID)
                    if ok then return name, link, quality, icon end
                end
                return nil
            end

            local function CollectInventory()
                local items = {}

                -- Warbound-until-equipped gear is intentionally excluded from
                -- Inventory totals/listings.  It is transferable until equipped,
                -- and should not be treated as normal inventory value here.
                -- Once equipped it becomes soulbound, so this predicate naturally
                -- stops filtering it after that transition.
                local function IsWarboundUntilEquipped(itemID, containerID, slot)
                    itemID = tonumber(itemID)
                    if not itemID then return false end

                    -- Blizzard's tooltip binding data is the most reliable discriminator
                    -- for WuE.  WuE can report the generic BindOnEquip bindType from
                    -- C_Item.GetItemInfo(), so bindType alone cannot distinguish it from
                    -- a normal auctionable BoE. TooltipData explicitly reports
                    -- AccountUntilEquipped (9) / BindToAccountUntilEquipped (10).
                    local function TooltipSaysWuE(data)
                        if type(data) ~= "table" or type(data.lines) ~= "table" then return false end
                        for _, line in ipairs(data.lines) do
                            if type(line) == "table" then
                                local bonding = tonumber(line.bonding)
                                if bonding == 9 or bonding == 10 then return true end
                            end
                        end
                        return false
                    end

                    -- For a live inventory/bank slot, inspect the actual bag tooltip.
                    if containerID ~= nil and slot ~= nil and C_TooltipInfo and C_TooltipInfo.GetBagItem then
                        local ok, data = pcall(C_TooltipInfo.GetBagItem, containerID, slot)
                        if ok and TooltipSaysWuE(data) then return true end
                    end

                    -- The ItemLocation predicate is still useful and catches WuE when
                    -- tooltip data has not been populated yet.
                    if containerID ~= nil and slot ~= nil and ItemLocation and ItemLocation.CreateFromBagAndSlot and C_Item then
                        local okLocation, itemLocation = pcall(ItemLocation.CreateFromBagAndSlot, containerID, slot)
                        if okLocation and itemLocation and C_Item.IsBoundToAccountUntilEquip then
                            local ok, result = pcall(C_Item.IsBoundToAccountUntilEquip, itemLocation)
                            if ok and result == true then return true end
                        end
                    end

                    -- Blizzard's own Auction House validation is a final live-slot
                    -- guard. WuE items must never appear in the inventory-to-sell list.
                    if containerID ~= nil and slot ~= nil and C_AuctionHouse and C_AuctionHouse.IsSellItemValid
                        and ItemLocation and ItemLocation.CreateFromBagAndSlot then
                        local okLocation, itemLocation = pcall(ItemLocation.CreateFromBagAndSlot, containerID, slot)
                        if okLocation and itemLocation then
                            local ok, valid = pcall(C_AuctionHouse.IsSellItemValid, itemLocation, false)
                            if ok and valid == false then return true end
                        end
                    end

                    -- For stored/offline inventory data, use item-level tooltip data.
                    if C_TooltipInfo and C_TooltipInfo.GetItemByID then
                        local ok, data = pcall(C_TooltipInfo.GetItemByID, itemID)
                        if ok and TooltipSaysWuE(data) then return true end
                    end
                    if C_Item and C_Item.IsItemBindToAccountUntilEquip then
                        local ok, result = pcall(C_Item.IsItemBindToAccountUntilEquip, itemID)
                        if ok and result == true then return true end
                    end
                    return false
                end

                local function IsLockbox(itemID)
                    itemID = tonumber(itemID)
                    if not itemID then return false end

                    -- Lockboxes are not auctionable, so keep them out of the
                    -- inventory-to-sell view.  Use the item's actual Blizzard
                    -- classification/name rather than a hardcoded item-ID list.
                    local name, _, _, _, _, itemType, itemSubType
                    if C_Item and C_Item.GetItemInfo then
                        local ok
                        ok, name, _, _, _, _, itemType, itemSubType = pcall(C_Item.GetItemInfo, itemID)
                        if not ok then name, itemType, itemSubType = nil, nil, nil end
                    end

                    local function HasLockboxText(value)
                        if type(value) ~= "string" then return false end
                        value = string.lower(value)
                        return string.find(value, "lockbox", 1, true) ~= nil
                    end

                    if HasLockboxText(itemSubType) or HasLockboxText(name) then
                        return true
                    end

                    -- Also check the numeric classification when the localized
                    -- subtype text is available through the item-class API.
                    if C_Item and C_Item.GetItemInfoInstant and C_Item.GetItemSubClassInfo then
                        local ok, _, _, _, _, _, classID, subclassID = pcall(C_Item.GetItemInfoInstant, itemID)
                        if ok and classID ~= nil and subclassID ~= nil then
                            local okSub, subclassName = pcall(C_Item.GetItemSubClassInfo, classID, subclassID)
                            if okSub and HasLockboxText(subclassName) then return true end
                        end
                    end

                    return false
                end

                local function IsInventorySellable(itemID, containerID, slot)
                    itemID = tonumber(itemID)
                    if not itemID then return false end

                    -- Inventory is a sell/auction view: keep items that can actually
                    -- be posted to the Auction House or sold to a vendor.
                    -- For live bag/bank slots, ask Blizzard's AH validator directly.
                    if containerID ~= nil and slot ~= nil and C_AuctionHouse and C_AuctionHouse.IsSellItemValid
                        and ItemLocation and ItemLocation.CreateFromBagAndSlot then
                        local okLocation, itemLocation = pcall(ItemLocation.CreateFromBagAndSlot, containerID, slot)
                        if okLocation and itemLocation then
                            local okAH, validAH = pcall(C_AuctionHouse.IsSellItemValid, itemLocation, false)
                            if okAH and validAH == true then return true end
                        end
                    end

                    -- Bind-on-Pickup items are not part of this sellable inventory view.
                    -- Read the actual Blizzard bindType instead of relying on tooltip text.
                    if C_Item and C_Item.GetItemInfo then
                        local ok, name, link, quality, itemLevel, minLevel, itemType, itemSubType, stackCount, equipLoc, icon, sellPrice, classID, subclassID, bindType = pcall(C_Item.GetItemInfo, itemID)
                        if ok then
                            bindType = tonumber(bindType)
                            if bindType == 1 then return false end
                            sellPrice = tonumber(sellPrice) or 0
                            if sellPrice > 0 then return true end
                        end
                    end

                    -- If Blizzard has not loaded the item data yet, don't make the
                    -- item disappear prematurely; the existing item-data request below
                    -- will populate it on refresh.
                    return true
                end

                local function add(itemID, count, location, containerID, slot)
                    itemID = tonumber(itemID); count = tonumber(count) or 0
                    if not itemID or count <= 0 or IsLockbox(itemID) or IsWarboundUntilEquipped(itemID, containerID, slot)
                        or not IsInventorySellable(itemID, containerID, slot) then return end
                    local e = items[itemID]
                    if not e then
                        e = {itemID=itemID, count=0, bagCount=0, bankCount=0, guildBankCount=0, altCount=0, warbandCount=0, value=0, sources={}}
                        items[itemID] = e
                    end
                    e.count = e.count + count
                    if containerID ~= nil and slot ~= nil then
                        e.sources[#e.sources + 1] = {location=location, bag=containerID, slot=slot, count=count}
                    end
                    if location == "bag" then e.bagCount=e.bagCount+count
                    elseif location == "bank" then e.bankCount=e.bankCount+count
                    elseif location == "guildbank" then e.guildBankCount=e.guildBankCount+count
                    elseif location == "warband" then e.warbandCount=e.warbandCount+count
                    else e.altCount=e.altCount+count end
                end

                if C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo then
                    for bag=0,5 do
                        local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, bag)
                        local slots=okSlots and (tonumber(rawSlots) or 0) or 0
                        for slot=1,slots do
                            local okInfo, info=pcall(C_Container.GetContainerItemInfo, bag,slot)
                            if not okInfo then info=nil end
                            if info and info.itemID then add(info.itemID, info.stackCount, "bag", bag, slot) end
                        end
                    end
                    for _,bag in ipairs({-1,-2,6,7,8,9,10,11}) do
                        local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, bag)
                        local slots=okSlots and (tonumber(rawSlots) or 0) or 0
                        for slot=1,slots do
                            local okInfo, info=pcall(C_Container.GetContainerItemInfo, bag,slot)
                            if not okInfo then info=nil end
                            if info and info.itemID then add(info.itemID, info.stackCount, "bank", bag, slot) end
                        end
                    end
                    for bag=12,17 do
                        local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, bag)
                        local slots=okSlots and (tonumber(rawSlots) or 0) or 0
                        for slot=1,slots do
                            local okInfo, info=pcall(C_Container.GetContainerItemInfo, bag,slot)
                            if not okInfo then info=nil end
                            if info and info.itemID then add(info.itemID, info.stackCount, "warband", bag, slot) end
                        end
                    end
                end

                -- Stored data gives us the account-wide/alt inventory picture even
                -- when those characters are not currently logged in.
                local store = GoldMintDB and GoldMintDB.valuation and GoldMintDB.valuation.characters or {}
                for key, character in pairs(store) do
                    if type(character)=="table" and key ~= GoldMint.characterKey then
                        for itemID,count in pairs(character.inventory or {}) do add(itemID,count,"alt") end
                        for itemID,count in pairs(character.bank or {}) do add(itemID,count,"alt") end
                    end
                end
                local accountBank = GoldMintDB and GoldMintDB.valuation and GoldMintDB.valuation.accountBank or {}
                for itemID,count in pairs(accountBank) do add(itemID,count,"warband") end

                -- If a Gold-making guild is selected in Options, include the
                -- latest scanned contents of that guild bank. The guild bank
                -- scanner itself runs when the guild bank is opened/updated;
                -- this makes the stored scan part of the Inventory page too.
                local selectedGuild = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
                if selectedGuild and GoldMintDB and GoldMintDB.valuation then
                    local guildBanks = GoldMintDB.valuation.guildBanks or {}
                    local guildKey = string.lower(tostring(selectedGuild.realm or "Unknown")) .. "|" .. string.lower(tostring(selectedGuild.name or ""))
                    local guildRecord = guildBanks[guildKey]
                    if type(guildRecord) == "table" and guildRecord.tracked == true then
                        for itemID,count in pairs(guildRecord.items or {}) do
                            add(itemID,count,"guildbank")
                        end
                    end
                end

                local out={}
                for _,e in pairs(items) do
                    local name, link, quality, _, _, itemType, itemSubType, _, _, icon = GetItemInfo(e.itemID)
                    e.itemType = itemType or e.itemType
                    e.itemSubType = itemSubType or e.itemSubType
                    if (not icon) and C_Item and C_Item.GetItemIconByID then
                        local okIcon, value = pcall(C_Item.GetItemIconByID, e.itemID)
                        if okIcon and value then icon = value end
                    end
                    if (not name or not icon) and C_Item and C_Item.RequestLoadItemDataByID then
                        pcall(C_Item.RequestLoadItemDataByID, e.itemID)
                    end
                    e.name = name or (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(e.itemID)) or ("Item "..tostring(e.itemID))
                    e.link = link
                    e.quality = tonumber(quality) or 0
                    e.icon = icon or 134400
                    local unit = GoldMint.Market and GoldMint.Market.GetUnitValue and GoldMint.Market:GetUnitValue(e.itemID) or 0
                    e.unitValue = tonumber(unit) or 0
                    e.value = e.unitValue * e.count
                    if C_Item and C_Item.GetItemInfo then
                        local okInfo, _, _, _, _, _, _, _, _, _, _, sellPrice, _, _, bindType = pcall(C_Item.GetItemInfo, e.itemID)
                        if okInfo then
                            e.vendorPrice = tonumber(sellPrice) or 0
                            e.bindType = tonumber(bindType) or 0
                        end
                    end
                    e.category = ItemCategory(e)
                    out[#out+1]=e
                end
                table.sort(out,function(a,b)
                    if sortMode == "Name" then return string.lower(a.name or "") < string.lower(b.name or "") end
                    if sortMode == "Quantity" then return (a.count or 0) > (b.count or 0) end
                    if sortMode == "Location" then return string.lower((a.guildBankCount or 0)>0 and "Guild Bank" or (a.warbandCount or 0)>0 and "Warband" or (a.bankCount or 0)>0 and "Bank" or (a.bagCount or 0)>0 and "Inventory" or "Alts") < string.lower((b.guildBankCount or 0)>0 and "Guild Bank" or (b.warbandCount or 0)>0 and "Warband" or (b.bankCount or 0)>0 and "Bank" or (b.bagCount or 0)>0 and "Inventory" or "Alts") end
                    return (a.value or 0) > (b.value or 0)
                end)
                return out
            end

            local function GetAcquisitionSource(e)
                local itemID = tonumber(e and e.itemID)
                if not itemID then return "Where to get it: Source information unavailable." end

                -- Use GoldMint's real farming database first when this material has
                -- a known gathering route. This gives a useful zone/profession answer
                -- instead of pretending Blizzard exposes a universal source API.
                if GoldMint.Market and GoldMint.Market.GetGatheringRoute then
                    local ok, route = pcall(GoldMint.Market.GetGatheringRoute, GoldMint.Market, itemID)
                    if ok and type(route) == "table" then
                        local parts = {}
                        if route.profession and route.profession ~= "" then parts[#parts+1] = route.profession end
                        if route.zone and route.zone ~= "" then parts[#parts+1] = route.zone end
                        if route.start and route.start ~= "" then parts[#parts+1] = route.start end
                        if #parts > 0 then return "Where to get it: "..table.concat(parts, " • ") end
                    end
                end

                -- If GoldMint has a recipe producing this item, show the known
                -- profession/recipe source.
                local recipes = GoldMintDB and GoldMintDB.recipes or {}
                local recipeName, profession
                for _, recipe in pairs(recipes) do
                    if type(recipe) == "table" and tonumber(recipe.outputItemID) == itemID then
                        recipeName = recipe.name
                        profession = recipe.professionName or recipe.profession
                        break
                    end
                end
                if recipeName then
                    if profession and profession ~= "" then
                        return "Where to get it: Crafting • "..tostring(profession).." • "..tostring(recipeName)
                    end
                    return "Where to get it: Crafting • "..tostring(recipeName)
                end

                local t = string.lower(tostring(e.itemType or ""))
                if string.find(t, "trade goods", 1, true) or string.find(t, "profession", 1, true) then
                    return "Where to get it: Gathering, crafting, or loot • exact source not exposed by Blizzard."
                elseif string.find(t, "consumable", 1, true) then
                    return "Where to get it: Vendor, crafting, quest, or loot • exact source not exposed by Blizzard."
                elseif string.find(t, "armor", 1, true) or string.find(t, "weapon", 1, true) then
                    return "Where to get it: Quest, dungeon/raid, world drop, or vendor • exact source not exposed by Blizzard."
                end
                return "Where to get it: Exact acquisition source is not exposed by Blizzard for this item."
            end

            local function ShowItemDetails(e)
                selectedItem = e
                detailEmpty:SetText("")
                detailIcon:SetTexture(e.icon or 134400)
                detailIcon:Show()
                detailName:SetText(e.name or ("Item "..tostring(e.itemID)))
                detailQty:SetText("Qty: "..tostring(e.count or 0))
                local locs = {}
                if (e.bagCount or 0) > 0 then locs[#locs+1] = "Inventory" end
                if (e.bankCount or 0) > 0 then locs[#locs+1] = "Bank" end
                if (e.guildBankCount or 0) > 0 then locs[#locs+1] = "Guild Bank" end
                if (e.warbandCount or 0) > 0 then locs[#locs+1] = "Warband" end
                if (e.altCount or 0) > 0 then locs[#locs+1] = "Alts" end
                detailLocation:SetText("Location: "..table.concat(locs, ", "))
                detailSource:SetText(GetAcquisitionSource(e))
                detailValue:SetText("AH Value: "..FormatGold(e.value or 0))
                detailVendor:SetText("Vendor Value: "..FormatGold((e.vendorPrice or 0) * (e.count or 0)))
                local ahEligible = e.unitValue and e.unitValue > 0
                detailStatus:SetText(ahEligible and "✓ AH Eligible" or "• AH value not tracked")
                detailTracked:SetText(ahEligible and "✓ Tracked" or "• Not tracked")
            end

            RefreshList = function(forceScan)
                if forceScan ~= false or not inventoryData then inventoryData=CollectInventory() end
                local data=inventoryData
                local rawQuery=search:GetText() or ""
                local query=(rawQuery == "Search Inventory..." and "" or string.lower(rawQuery))
                local filtered={}
                local total=0
                local bagItems, bankItems, guildBankItems, warbandItems, altItems = 0,0,0,0,0
                for _,e in ipairs(data) do
                    total=total+(tonumber(e.value) or 0)
                    bagItems=bagItems+(e.bagCount or 0)
                    bankItems=bankItems+(e.bankCount or 0)
                    guildBankItems=guildBankItems+(e.guildBankCount or 0)
                    warbandItems=warbandItems+(e.warbandCount or 0)
                    altItems=altItems+(e.altCount or 0)
                    local matchesSearch = query=="" or string.find(string.lower(e.name or ""),query,1,true)
                    local matchesCategory = categoryFilter == "All Categories" or e.category == categoryFilter
                    local matchesLocation = HasLocation(e, locationFilter)
                    if matchesSearch and matchesCategory and matchesLocation then filtered[#filtered+1]=e end
                end

                -- Apply the selected sort to the rows actually being displayed.
                -- Previously sortMode was only applied while rebuilding the raw
                -- inventory cache, so clicking SORT changed the label but did not
                -- reorder an already-cached list.
                table.sort(filtered,function(a,b)
                    if sortMode == "Name" then
                        return string.lower(a.name or "") < string.lower(b.name or "")
                    elseif sortMode == "Quantity" then
                        return (a.count or 0) > (b.count or 0)
                    elseif sortMode == "Location" then
                        local function primaryLocation(e)
                            if (e.guildBankCount or 0)>0 then return "Guild Bank" end
                            if (e.warbandCount or 0)>0 then return "Warband" end
                            if (e.bankCount or 0)>0 then return "Bank" end
                            if (e.bagCount or 0)>0 then return "Inventory" end
                            return "Alts"
                        end
                        return string.lower(primaryLocation(a)) < string.lower(primaryLocation(b))
                    end
                    return (a.value or 0) > (b.value or 0)
                end)

                totalLabel:SetText("Total Inventory Value: "..FormatGold(total))
                local ahValue = 0
                local vendorValue = 0
                for _,e in ipairs(data) do
                    ahValue = ahValue + (tonumber(e.value) or 0)
                    vendorValue = vendorValue + ((tonumber(e.vendorPrice) or 0) * (tonumber(e.count) or 0))
                end
                ahTotalLabel:SetText("AH Value: "..FormatGold(ahValue))
                vendorTotalLabel:SetText("Vendor Value: "..FormatGold(vendorValue))

                for _,r in ipairs(listCard.rowWidgets) do r:Hide() end
                wipe(listCard.rowWidgets)
                local rowHeight=56
                rows:SetHeight(math.max(1,#filtered*rowHeight))
                for i=1,math.min(#filtered,12) do
                    local e=filtered[i]
                    local row=CreateFrame("Button",nil,rows,"BackdropTemplate")
                    row:SetSize(668,50)
                    row:SetPoint("TOPLEFT",0,-((i-1)*rowHeight))
                    row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",tile=true,tileSize=8})
                    -- Keep every inventory row in the same dark-navy style.  The
                    -- previous first-row brown treatment looked like a selection
                    -- overlay and could make the row feel blocked/non-interactive.
                    row:SetBackdropColor(0.018,0.055,0.09,0.72)
                    row:SetBackdropBorderColor(0.08,0.25,0.38,0.82)
                    row:SetHighlightTexture("Interface\\Buttons\\WHITE8X8")
                    row:GetHighlightTexture():SetVertexColor(0.08,0.30,0.46,0.18)
                    row:EnableMouse(true)
                    local icon=row:CreateTexture(nil,"ARTWORK"); icon:SetSize(38,38); icon:SetPoint("LEFT",8,0); icon:SetTexture(e.icon)
                    local displayName = tostring(e.name or "Unknown Item")
                    if #displayName > 28 then displayName = string.sub(displayName, 1, 27) .. "…" end
                    local name=IL(row,displayName,56,-10,205,e.quality>=4 and GOLD or MUTED,"GameFontNormal")
                    name:SetWordWrap(false)
                    name:SetNonSpaceWrap(false)
                    IL(row,"Qty: "..tostring(e.count),56,-31,120,MUTED,"GameFontNormalSmall")
                    -- Keep the value/location columns physically separated from the item name.
                    local valueLabel = IL(row,"Est. Value: "..FormatGold(e.value),270,-10,180,GOLD,"GameFontNormalSmall")
                    valueLabel:SetWordWrap(false)
                    valueLabel:SetNonSpaceWrap(false)
                    local trend=GoldMint.Market and GoldMint.Market.GetUnitValue and e.unitValue>0 and "(Tracked)" or "(No price)"
                    IL(row,trend,500,-10,82,e.unitValue>0 and GREEN or MUTED,"GameFontNormalSmall")
                    local loc="Loc: "
                    if e.bagCount>0 then loc=loc.."Inventory"
                    elseif e.bankCount>0 then loc=loc.."Bank"
                    elseif e.guildBankCount>0 then loc=loc.."Guild Bank"
                    elseif e.warbandCount>0 then loc=loc.."Warband"
                    else loc=loc.."Alts" end
                    IL(row,loc,500,-31,160,MUTED,"GameFontNormalSmall")
                    row:SetScript("OnClick", function(self)
                        ShowItemDetails(e)
                        if IsShiftKeyDown and IsShiftKeyDown() and e.link and ChatEdit_InsertLink then
                            ChatEdit_InsertLink(e.link)
                        end
                    end)
                    row:SetScript("OnEnter", function(self)
                        if GameTooltip and e.link then
                            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                            GameTooltip:SetHyperlink(e.link)
                            GameTooltip:Show()
                        end
                    end)
                    row:SetScript("OnLeave", function()
                        if GameTooltip then GameTooltip:Hide() end
                    end)

                    listCard.rowWidgets[#listCard.rowWidgets+1]=row
                end

                local maxItems=math.max(bagItems+bankItems+guildBankItems+warbandItems+altItems,1)
                local itemPercents={Bag=bagItems/maxItems,Bank=bankItems/maxItems,["Guild Bank"]=guildBankItems/maxItems,Warband=warbandItems/maxItems,Alts=altItems/maxItems,["Auction House"]=0}
                for name,pct in pairs(itemPercents) do
                    distribution[name].item:SetText(string.format("%d%%",math.floor(pct*100+0.5)))
                    distribution[name].itemBar:SetWidth(math.max(2,120*pct))
                end

                local wallet=GoldMint.Ledger and GoldMint.Ledger:GetAccountWallet() or {}
                local characterGold=GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney() or 0
                local warbankGold=tonumber(wallet.warbandGold) or 0
                local guildBankGold=0
                if selectedGuild and GoldMint.Valuation and GoldMint.Valuation.GetGoldMakingGuildBankValue then
                    local guildData = GoldMint.Valuation:GetGoldMakingGuildBankValue()
                    if guildData and guildData.tracked == true then guildBankGold=tonumber(guildData.gold) or 0 end
                end
                local totalCurrency=math.max(tonumber(characterGold) or 0,0)+math.max(warbankGold,0)+math.max(guildBankGold,0)
                local goldRows={Bag=characterGold,Bank=0,["Guild Bank"]=guildBankGold,Warband=warbankGold,Alts=0,["Auction House"]=0}
                for name,v in pairs(goldRows) do
                    local pct=totalCurrency>0 and math.max(v,0)/totalCurrency or 0
                    distribution[name].gold:SetText(string.format("%d%%",math.floor(pct*100+0.5)))
                    distribution[name].goldBar:SetWidth(math.max(2,120*pct))
                end

            end

            -- Refresh is provided by the Inventory Filters bar above; keep the
            -- Inventory Overview header free of a duplicate refresh button.
            refreshFilter:SetScript("OnClick", function()
                if openFilterMenu then openFilterMenu:Hide(); openFilterMenu=nil end
                inventoryData = nil
                selectedItem = nil
                detailEmpty:SetText("Select an item to view its details.")
                detailIcon:Hide()
                detailName:SetText("")
                detailQty:SetText("")
                detailLocation:SetText("")
                detailSource:SetText("")
                detailValue:SetText("")
                detailVendor:SetText("")
                detailStatus:SetText("")
                detailTracked:SetText("")
                -- Force a fresh collection rather than merely reusing the cached
                -- list. This also picks up newly opened/updated guild-bank data.
                RefreshList(true)
                if restock and restock.Refresh then restock.Refresh() end
            end)
            for _, name in ipairs({"Bag", "Bank", "Guild Bank", "Warband", "Alts", "Auction House"}) do
                local d = distribution[name]
                if d then
                    local hit = CreateFrame("Button", nil, storageCard)
                    hit:SetPoint("TOPLEFT", 10, ({Bag=-52, Bank=-80, Warband=-108, Alts=-136, ["Auction House"]=-164, ["Guild Bank"]=-192})[name])
                    hit:SetSize(285, 22)
                    hit:SetScript("OnClick", function()
                        locationFilter = name == "Bag" and "Inventory" or name
                        locationButton:SetText(locationFilter:upper())
                        if listCard.Refresh then listCard.Refresh(false) end
                    end)
                    hit:SetScript("OnEnter", function() d.label:SetTextColor(unpack(CYAN)) end)
                    hit:SetScript("OnLeave", function() d.label:SetTextColor(unpack(MUTED)) end)
                end
            end

            -- Guild Bank scanning is automatic. When a Gold-making guild is
            -- selected, the normal guild-bank events trigger the incremental
            -- scanner whenever that guild bank is opened or updated. There is
            -- intentionally no manual scan button on the Inventory page.
            listCard.Refresh=RefreshList
            restock.Refresh=function() BuildRestockRows() end

            -- Item display data can arrive asynchronously after the inventory scan.
            -- Refresh the visible rows when Blizzard finishes loading an item so
            -- real item icons replace the fallback question-mark texture.
            page:RegisterEvent("ITEM_DATA_LOAD_RESULT")
            page:SetScript("OnEvent", function(self, event, itemID)
                if event == "ITEM_DATA_LOAD_RESULT" and itemID and listCard:IsShown() then
                    if C_Timer and C_Timer.After then
                        C_Timer.After(0, function()
                            if listCard.Refresh then listCard.Refresh(false) end
                        end)
                    elseif listCard.Refresh then
                        listCard.Refresh(false)
                    end
                end
            end)

            RefreshList(true)
            restock.Refresh()

            -- Inventory page intentionally ends after the main inventory/restock content.
            -- The four utility cards that previously occupied the bottom rail have been removed.
        end

        local function recipes()
            -- Crafting workspace.  This replaces the old recipe-management page
            -- visually, but deliberately keeps GoldMint.Recipes and
            -- GoldMint.RecipeStatus untouched. Recipe-known/unknown information
            -- continues to live in the database and in item tooltips.
            for _, b in pairs(tabButtons) do b:Hide() end
            title:SetText("")
            sub:SetText("")
            content:ClearAllPoints()
            content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, -8)
            content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)

            local page = CreateFrame("Frame", nil, content)
            page:SetAllPoints(content)
            -- Crafting page stays transparent; each card supplies its own surface.
            -- This lets the dashboard artwork remain visible around the panels.

            local function CL(parent, text, x, y, w, color, font, justify)
                local l = MakeLabel(parent, font or "GameFontNormal", text, w)
                l:SetPoint("TOPLEFT", x, y)
                l:SetTextColor(unpack(color or MUTED))
                if justify then l:SetJustifyH(justify) end
                return l
            end

            local function CCard(parent, w, h, x, y, border)
                return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
            end

            local function VRule(parent, x, y, height, alpha)
                local rule = parent:CreateTexture(nil, "ARTWORK")
                rule:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], alpha or 0.48)
                rule:SetSize(1, height)
                rule:SetPoint("TOPLEFT", x, y)
                return rule
            end

            local function HRule(parent, x, y, width, alpha)
                local rule = parent:CreateTexture(nil, "ARTWORK")
                rule:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], alpha or 0.48)
                rule:SetSize(width, 1)
                rule:SetPoint("TOPLEFT", x, y)
                return rule
            end

            local function CButton(parent, text, w, h, x, y)
                local b = MakeButton(parent, text, w, h or 28, "secondary")
                b:SetPoint("TOPLEFT", x, y)
                return b
            end

            local function GetRecipeIcon(record)
                local itemID = record and tonumber(record.outputItemID)
                if itemID and C_Item then
                    if C_Item.GetItemIconByID then
                        local okIcon, icon = pcall(C_Item.GetItemIconByID, itemID)
                        if not okIcon then icon = nil end
                        if icon then return icon end
                    end
                    if C_Item.GetItemInfo then
                        local okInfo, _, _, _, _, _, _, _, _, _, icon = pcall(C_Item.GetItemInfo, itemID)
                        if not okInfo then icon = nil end
                        if icon then return icon end
                    end
                end
                return 134400
            end

            local function IsKnown(record)
                for _, state in pairs(record.characters or {}) do
                    if state.learned == true then return true end
                end
                return false
            end

            local function GetProfit(record)
                local p = record and record.profit
                if type(p) == "table" then
                    return tonumber(p.profit) or 0
                end
                return tonumber(record and record.profit) or 0
            end

            local function GetSaleValue(record)
                local p = record and record.profit
                if type(p) == "table" then
                    return tonumber(p.outputValue) or 0
                end
                return 0
            end

            local function GetMaterialCost(record)
                local p = record and record.profit
                if type(p) == "table" then
                    return tonumber(p.reagentCost) or 0
                end
                return 0
            end

            local function GetROI(record)
                local cost = GetMaterialCost(record)
                local profit = GetProfit(record)
                if cost > 0 then return (profit / cost) * 100 end
                return profit > 0 and 999 or 0
            end

            -- Concentration is optional because not every saved recipe has
            -- concentration metadata yet.  Accept the common persisted field
            -- names without inventing a value when the backend has none.
            local function GetConcentration(record)
                local p = record and record.profit
                local candidates = {
                    record and record.concentrationCost,
                    record and record.concentration,
                    record and record.concentrationRequired,
                    type(p) == "table" and p.concentrationCost or nil,
                    type(p) == "table" and p.concentration or nil,
                    type(p) == "table" and p.concentrationRequired or nil,
                }
                for _, value in ipairs(candidates) do
                    value = tonumber(value)
                    if value and value > 0 then return value end
                end
                return nil
            end

            local function GetGoldPerConcentration(record, profit)
                local concentration = GetConcentration(record)
                if concentration and concentration > 0 then
                    return math.max(tonumber(profit) or 0, 0) / concentration
                end
                return nil
            end

            local function GetCraftTime(record)
                local p = record and record.profit
                local candidates = {
                    record and record.craftTime,
                    record and record.craftingTime,
                    type(p) == "table" and p.craftTime or nil,
                    type(p) == "table" and p.craftingTime or nil,
                }
                for _, value in ipairs(candidates) do
                    value = tonumber(value)
                    if value and value > 0 then return value end
                end
                return nil
            end

            local function GetFutureProfitPerMinute(record, profit)
                local craftTime = GetCraftTime(record)
                if craftTime and craftTime > 0 then
                    return (tonumber(profit) or 0) * 60 / craftTime
                end
                return nil
            end

            local function GetMarketData(record)
                local itemID = tonumber(record and record.outputItemID)
                if itemID and GoldMint.Market and GoldMint.Market.GetMultiverseData then
                    return GoldMint.Market:GetMultiverseData(itemID)
                end
                return nil
            end

            local function GetOwnedCount(itemID)
                if not itemID or not C_Item or not C_Item.GetItemCount then return 0 end
                local ok, count = pcall(C_Item.GetItemCount, itemID, true, true, true, true)
                return ok and (tonumber(count) or 0) or 0
            end

            local function GetItemName(itemID)
                if not itemID or not C_Item or not C_Item.GetItemInfo then return nil end
                local ok, name = pcall(C_Item.GetItemInfo, itemID)
                return ok and name or nil
            end

            local function MaterialsReady(record)
                local reagents = record and record.reagents
                if type(reagents) ~= "table" or #reagents == 0 then
                    -- A recipe with no recorded reagents is safe to treat as ready.
                    return true
                end
                for _, reagent in ipairs(reagents) do
                    local needed = tonumber(reagent.quantity) or 0
                    if needed > 0 then
                        local slotReady = false
                        for _, option in ipairs(reagent.options or {}) do
                            if GetOwnedCount(tonumber(option.itemID)) >= needed then
                                slotReady = true
                                break
                            end
                        end
                        if not slotReady then return false end
                    end
                end
                return true
            end

            local function HasObservedSales(record)
                local market = GetMarketData(record)
                if market and ((tonumber(market.regionSoldPerDay) or 0) > 0 or (tonumber(market.regionSaleRate) or 0) > 0) then
                    return true
                end
                local itemID = tonumber(record and record.outputItemID)
                local sales = GoldMintDB and GoldMintDB.market and GoldMintDB.market.salesByItem
                local saleRecord = itemID and sales and sales[itemID]
                return type(saleRecord) == "table" and (tonumber(saleRecord.sales) or 0) > 0
            end

            local function IsHighDemand(record)
                local market = GetMarketData(record)
                if not market then return false end
                return (tonumber(market.regionSoldPerDay) or 0) > 0
                    or (tonumber(market.regionSaleRate) or 0) >= 0.05
            end

            local function GetCraftingOrderCounts()
                local counts = {}
                if not C_CraftingOrders or not C_CraftingOrders.GetCrafterBuckets then
                    return counts
                end
                local ok, buckets = pcall(C_CraftingOrders.GetCrafterBuckets)
                if not ok or type(buckets) ~= "table" then
                    return counts
                end
                for _, bucket in ipairs(buckets) do
                    local spellID = tonumber(bucket.spellID)
                    local itemID = tonumber(bucket.itemID)
                    local count = tonumber(bucket.numAvailable) or 0
                    if count > 0 then
                        if spellID then counts[spellID] = (counts[spellID] or 0) + count end
                        if itemID then counts["item:" .. itemID] = (counts["item:" .. itemID] or 0) + count end
                    end
                end
                return counts
            end

            local function HasCraftingOrders(record, orderCounts)
                if record.craftingOrder == true
                    or record.craftingOrders == true
                    or record.orderEligible == true
                    or record.craftingOrderEligible == true then
                    return true
                end
                orderCounts = orderCounts or {}
                local recipeID = tonumber(record and record.recipeID)
                local itemID = tonumber(record and record.outputItemID)
                return (recipeID and (orderCounts[recipeID] or 0) > 0)
                    or (itemID and (orderCounts["item:" .. itemID] or 0) > 0)
                    or false
            end

            -- The old TOP GOLD OPPORTUNITIES rail has been removed from the
            -- Crafting page. Crafting Opportunities is now the primary top card.
            local opp = CCard(page, 490, 270, 0, 10, {0.08,0.38,0.58,0.95})
            AddSectionTitle(opp, "craftingOpportunitiesTitle", "CRAFTING OPPORTUNITIES", CYAN, 18, -14)
            CL(opp, "Recipe", 48, -48, 150, MUTED, "GameFontNormalSmall")
            CL(opp, "Profit", 220, -48, 72, MUTED, "GameFontNormalSmall", "RIGHT")
            CL(opp, "ROI", 310, -48, 42, MUTED, "GameFontNormalSmall", "RIGHT")
            CL(opp, "Status", 375, -48, 62, MUTED, "GameFontNormalSmall")
            -- Use horizontal separators between opportunity rows instead of
            -- vertical column rules, keeping the table visually clean while
            -- preserving the existing column alignment.

            local filter = CCard(page, 410, 245, 502, 10, {0.08,0.38,0.58,0.95})
            AddSectionTitle(filter, "goldmakingFiltersTitle", "GOLDMAKING FILTERS", CYAN, 18, -14)

            local current = CCard(page, 311, 300, 845, -280, {0.36,0.28,0.08,0.95})
            AddSectionTitle(current, "currentOpportunityTitle", "CURRENT OPPORTUNITY", CYAN, 18, -14)

            local function GetProfessionRows()
                if GoldMint.Professions and GoldMint.Professions.GetRoadmap then
                    local rows = GoldMint.Professions:GetRoadmap()
                    if type(rows) == "table" then
                        return rows
                    end
                end
                return {}
            end

            local profCard = CCard(page, 450, 360, 0, -280, {0.08,0.38,0.58,0.95})
            AddSectionTitle(profCard, "professionLevelingTitle", "PROFESSION LEVELING", CYAN, 16, -18)
            CL(profCard, "Only professions with an unfinished tier are shown", 16, -43, 418, MUTED, "GameFontNormalSmall")
            HRule(profCard, 16, -59, 418, 0.48)
            local profs = GetProfessionRows()
            local profStatus = "unscanned"
            if GoldMint.Professions and GoldMint.Professions.GetRoadmapStatus then
                profStatus = GoldMint.Professions:GetRoadmapStatus()
            end
            if #profs == 0 then
                if profStatus == "maxed" then
                    CL(profCard, "All tracked professions are maxed.", 16, -78, 428, MUTED, "GameFontNormal")
                    CL(profCard, "GoldMint has scanned the available profession tiers.", 16, -105, 428, MUTED, "GameFontNormalSmall")
                elseif profStatus == "unavailable" then
                    CL(profCard, "Profession data needs another scan.", 16, -78, 428, MUTED, "GameFontNormal")
                    CL(profCard, "Open the profession again to refresh its progression data.", 16, -105, 428, MUTED, "GameFontNormalSmall")
                else
                    CL(profCard, "No profession tiers scanned yet.", 16, -78, 428, MUTED, "GameFontNormal")
                    CL(profCard, "Open a profession window to scan progression data.", 16, -105, 428, MUTED, "GameFontNormalSmall")
                end
            else
                -- Keep profession details and the progress indicator visually
                -- separated into two readable columns.
                VRule(profCard, 244, -59, 216, 0.42)
                for i = 1, math.min(6, #profs) do
                    local prof = profs[i]
                    local yy = -72 - ((i-1)*34)
                    -- Profession rows are informational; do not render an
                    -- empty checkbox/status square beside them.
                    CL(profCard, prof.character .. " • " .. prof.name, 16, yy, 250, MUTED, "GameFontNormalSmall")
                    CL(profCard, prof.expansion or "Unfinished profession tier", 16, yy+12, 250, CYAN, "GameFontNormalSmall")
                    local pct = nil
                    if prof.rank and prof.maxRank and prof.maxRank > 0 then pct = math.max(0, math.min(1, prof.rank/prof.maxRank)) end
                    if pct then
                        -- Use a real status bar so profession progress has a
                        -- visible fill instead of looking like an empty line.
                        -- A small marker also makes very low progress (for
                        -- example 1/100) visibly distinct from 0.
                        local bar = CreateFrame("StatusBar", nil, profCard)
                        bar:SetSize(110, 8)
                        bar:SetPoint("TOPLEFT", 250, yy-6)
                        bar:SetMinMaxValues(0, 1)
                        bar:SetValue(pct)
                        bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
                        bar:SetStatusBarColor(CYAN[1], CYAN[2], CYAN[3], 0.82)

                        local bg = bar:CreateTexture(nil, "BACKGROUND")
                        bg:SetAllPoints()
                        bg:SetColorTexture(0.025, 0.07, 0.10, 0.95)

                        local marker = bar:CreateTexture(nil, "OVERLAY")
                        marker:SetColorTexture(1, 0.82, 0.12, 0.95)
                        marker:SetSize(2, 12)
                        marker:SetPoint("CENTER", bar, "LEFT", math.max(1, math.min(109, 110*pct)), 0)

                        CL(profCard, string.format("%d/%d  •  %d%%", prof.rank, prof.maxRank, math.floor(pct*100 + 0.5)), 250, yy+2, 110, MUTED, "GameFontNormalSmall", "CENTER")
                    else
                        CL(profCard, "scan", 250, yy+2, 110, MUTED, "GameFontNormalSmall", "CENTER")
                    end
                end
            end
            local scan = CButton(profCard, "OPEN RECIPES", 116, 26, 16, -320)
            scan:SetScript("OnClick", function()
                -- Open Blizzard's built-in Professions book.  GoldMint is
                -- temporarily lowered while Blizzard's window is open so the
                -- profession UI is always visually above GoldMint.
                if ToggleProfessionsBook then
                    ToggleProfessionsBook()
                elseif ProfessionMicroButton and ProfessionMicroButton.Click then
                    ProfessionMicroButton:Click()
                else
                    GoldMint.Print("Unable to open the Blizzard Professions window right now.")
                    return
                end

                if frame then
                    frame:SetFrameStrata("LOW")
                end
            end)

            -- Keep the Blizzard Professions book/window above GoldMint while
            -- it is open, then restore GoldMint's normal DIALOG strata when
            -- Blizzard closes it.
            if not frame._professionOverlayWatcher then
                local watcher = CreateFrame("Frame")
                watcher.elapsed = 0
                watcher.professionWasOpen = false
                watcher:SetScript("OnUpdate", function(self, elapsed)
                    self.elapsed = self.elapsed + elapsed
                    if self.elapsed < 0.10 then return end
                    self.elapsed = 0

                    local professionsOpen = false
                    if ProfessionsFrame and ProfessionsFrame:IsShown() then
                        professionsOpen = true
                    elseif ProfessionsBookFrame and ProfessionsBookFrame:IsShown() then
                        professionsOpen = true
                    end

                    if professionsOpen then
                        if frame:GetFrameStrata() ~= "LOW" then
                            frame:SetFrameStrata("LOW")
                        end
                        self.professionWasOpen = true
                    elseif self.professionWasOpen then
                        frame:SetFrameStrata("DIALOG")
                        self.professionWasOpen = false
                    end
                end)
                frame._professionOverlayWatcher = watcher
            end

            local filterState = {
                profitable = true,
                materials = false,
                demand = false,
                orders = false,
                sales = false,
            }
            local sortMode = "profit"
            local minimumProfit = 100
            local selected = nil
            local rows = {}
            local filterSummary
            local filterButtons = {}
            local emptyMessage
            local buildRows

            local function MakeCheck(text, key, y)
                local b = CreateFrame("Button", nil, filter, "BackdropTemplate")
                b:SetSize(462, 24)
                b:SetPoint("TOPLEFT", 14, y)
                b:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8})
                b:SetBackdropColor(0,0,0,0)

                local box = CreateFrame("CheckButton", nil, b, "UICheckButtonTemplate")
                box:SetSize(24, 24)
                box:SetPoint("LEFT", 0, 0)
                box:SetChecked(filterState[key] == true)
                local checkTexture = box:GetCheckedTexture()
                if checkTexture then
                    checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                end
                b.checkBox = box

                local hoverGlow = b:CreateTexture(nil, "ARTWORK")
                hoverGlow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
                hoverGlow:SetBlendMode("ADD")
                hoverGlow:SetSize(30, 30)
                hoverGlow:SetPoint("CENTER", box, "CENTER", 0, 0)
                hoverGlow:SetVertexColor(0.15, 0.95, 0.25, 0.85)
                hoverGlow:Hide()
                b.hoverGlow = hoverGlow

                local label = MakeLabel(b, "GameFontNormalSmall", text, 420)
                label:SetPoint("LEFT", 28, 0)
                label:SetWordWrap(false)
                label:SetJustifyH("LEFT")
                label:SetTextColor(unpack(MUTED))
                filterButtons[key] = b

                local function ApplyState()
                    local checked = filterState[key] == true
                    box:SetChecked(checked)
                    if checkTexture then
                        checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                    end
                end

                b:SetScript("OnEnter", function()
                    hoverGlow:Show()
                end)
                b:SetScript("OnLeave", function()
                    hoverGlow:Hide()
                end)
                box:SetScript("OnEnter", function()
                    hoverGlow:Show()
                end)
                box:SetScript("OnLeave", function()
                    hoverGlow:Hide()
                end)
                b:SetScript("OnClick", function()
                    filterState[key] = not filterState[key]
                    ApplyState()
                    if buildRows then buildRows() end
                end)
                box:SetScript("OnClick", function(self)
                    filterState[key] = self:GetChecked() == true
                    ApplyState()
                    if buildRows then buildRows() end
                end)
                b.ApplyState = ApplyState
                return b
            end

            MakeCheck("Profitable Only", "profitable", -43)
            MakeCheck("Materials Available", "materials", -67)
            MakeCheck("High Demand", "demand", -91)
            MakeCheck("Crafting Orders", "orders", -115)
            MakeCheck("AH Sales", "sales", -139)
            -- Separate the checkbox/status gutter from the filter text.
            VRule(filter, 38, -39, 118, 0.42)

            -- Keep the sort controls on one clean row with enough width for both labels.
            local roiButton = CButton(filter, "BEST ROI", 124, 25, 14, -166)
            local goldButton = CButton(filter, "BEST GOLD / CONC.", 159, 25, 144, -166)
            local minLabel = CL(filter, "Minimum Profit:", 14, -197, 82, MUTED, "GameFontNormalSmall")
            local minBox = CreateFrame("EditBox", nil, filter, "InputBoxTemplate")
            minBox:SetSize(78, 24)
            minBox:SetPoint("TOPLEFT", 98, -193)
            minBox:SetAutoFocus(false)
            minBox:SetNumeric(true)
            minBox:SetText(tostring(minimumProfit))
            minBox:SetTextInsets(6, 6, 0, 0)
            local clear = CButton(filter, "CLEAR", 82, 25, 313, -166)

            local currentIcon = current:CreateTexture(nil, "ARTWORK")
            currentIcon:SetSize(42,42)
            currentIcon:SetPoint("TOPLEFT", 18, -47)
            currentIcon:SetTexture(134400)
            local currentName = CL(current, "No opportunity selected", 70, -48, 240, MUTED, "GameFontNormal")
            currentName:SetWordWrap(false)
            local currentProfession = CL(current, "", 70, -70, 240, MUTED, "GameFontNormalSmall")
            currentProfession:SetWordWrap(false)
            local currentStatus = CL(current, "", 70, -90, 240, GREEN, "GameFontNormalSmall")
            currentStatus:SetWordWrap(false)

            local function DetailLine(label, value, y, color)
                CL(current, label, 18, y, 130, MUTED, "GameFontNormalSmall")
                local v = CL(current, value, 130, y, 165, color or MUTED, "GameFontNormalSmall", "RIGHT")
                return v
            end
            local saleValue = DetailLine("SALE VALUE", "—", -122, GOLD)
            local materialValue = DetailLine("MATERIAL COST", "—", -141, MUTED)
            local profitValue = DetailLine("PROFIT", "—", -160, GREEN)
            local roiValue = DetailLine("ROI", "—", -179, GREEN)
            local concentrationValue = DetailLine("GOLD / CONCENTRATION", "—", -198, CYAN)
            local materialState = DetailLine("MATERIALS", "—", -217, MUTED)
            local action = CButton(current, "CRAFT", 82, 24, 18, -260)
            local buy = CButton(current, "BUY MATERIALS", 140, 28, 158, -257)

            -- Profession recipes are scanned automatically when the WoW profession
            -- window opens or the selected profession changes.  Keep this area as
            -- passive status text rather than requiring a manual Scan click.

            -- ================================================================
            -- DEDICATED CRAFTING BOTTOM BOXES
            -- ================================================================
            -- These cards intentionally use live recipe/opportunity data rather
            -- than generic dashboard metrics.  The queue is persisted in the
            -- account SavedVariable and is populated explicitly by the player.
            -- Arrange the four detail boxes in a 2x2 grid in the open space
            -- between Profession Leveling and Current Opportunity so their text
            -- has room to breathe without overlapping neighboring cards.
            local bottomY = -530
            local bottomRowY = -405
            -- Center the three detail cards as a clean row in the open middle area.
            -- The queue remains in the left column; these three are evenly spaced
            -- between the Profession Leveling and Current Opportunity columns.
            local bottomCards = {
                CCard(page, 245, 115, 445, bottomY, {0.08,0.30,0.46,0.92}),
                CCard(page, 200, 245, 915, 10, {0.08,0.30,0.46,0.92}),
                CCard(page, 245, 115, 311, bottomRowY, {0.08,0.30,0.46,0.92}),
                CCard(page, 245, 115, 311, -530, {0.08,0.30,0.46,0.92}),
            }
            local queueCard, materialsCard, concentrationCard, profitCard = unpack(bottomCards)
            -- Stack the three detail panels vertically, centered in the open
            -- space between Profession Leveling and Current Opportunity.
            local middleX = 465
            materialsCard:ClearAllPoints()
            materialsCard:SetSize(200, 245)
            materialsCard:SetPoint("TOPLEFT", page, "TOPLEFT", 930, 10)
            concentrationCard:ClearAllPoints()
            concentrationCard:SetSize(360, 115)
            concentrationCard:SetPoint("TOPLEFT", page, "TOPLEFT", middleX, -405)
            profitCard:ClearAllPoints()
            profitCard:SetSize(360, 115)
            profitCard:SetPoint("TOPLEFT", page, "TOPLEFT", middleX, -280)
            queueCard:ClearAllPoints()
            queueCard:SetSize(360, 115)
            queueCard:SetPoint("TOPLEFT", page, "TOPLEFT", middleX, -530)
            CL(queueCard, "CRAFTING QUEUE", 14, -12, 330, CYAN, "GameFontNormalSmall")
            CL(materialsCard, "CRAFTING MATERIALS", 14, -12, 172, CYAN, "GameFontNormalSmall")
            CL(concentrationCard, "CONCENTRATION", 14, -12, 330, CYAN, "GameFontNormalSmall")
            CL(profitCard, "CRAFTING PROFIT", 14, -12, 330, CYAN, "GameFontNormalSmall")

            local queueLines, materialLines = {}, {}
            for i = 1, 3 do
                queueLines[i] = CL(queueCard, "", 14, -30 - ((i-1) * 18), 335, MUTED, "GameFontNormalSmall")
                queueLines[i]:SetWordWrap(false)
                materialLines[i] = CL(materialsCard, "", 14, -30 - ((i-1) * 18), 172, MUTED, "GameFontNormalSmall")
                materialLines[i]:SetWordWrap(false)
            end
            local concentrationText = CL(concentrationCard, "No opportunity selected", 14, -33, 330, MUTED, "GameFontNormalSmall")
            concentrationText:SetWordWrap(false)
            local concentrationDetail = CL(concentrationCard, "", 14, -55, 330, MUTED, "GameFontNormalSmall")
            concentrationDetail:SetWordWrap(false)
            local concentrationGold = CL(concentrationCard, "", 14, -77, 330, GREEN, "GameFontNormalSmall")
            concentrationGold:SetWordWrap(false)

            local profitMain = CL(profitCard, "No opportunity selected", 14, -33, 335, MUTED, "GameFontNormalSmall")
            profitMain:SetWordWrap(false)
            local profitDetail = CL(profitCard, "", 14, -55, 335, MUTED, "GameFontNormalSmall")
            profitDetail:SetWordWrap(false)
            local profitROI = CL(profitCard, "", 14, -77, 335, GREEN, "GameFontNormalSmall")
            profitROI:SetWordWrap(false)

            local queueCurrent = CButton(queueCard, "QUEUE CURRENT", 122, 22, 80, -78)
            local queueClear = CButton(queueCard, "CLEAR", 58, 22, 14, -78)

            local RefreshCraftingBottomBoxes

            -- Gathering professions produce materials rather than crafted items.
            -- Keep them out of Crafting Opportunities so this panel remains focused
            -- on things the player can actually craft. Skill-line IDs are used when
            -- available, with profession-name fallbacks for older saved records.
            local GATHERING_SKILL_LINES = {
                [182] = true, -- Herbalism
                [186] = true, -- Mining
                [356] = true, -- Fishing
                [393] = true, -- Skinning
            }

            local GATHERING_PROFESSIONS = {
                herbalism = true,
                mining = true,
                fishing = true,
                skinning = true,
            }

            local function IsGatheringProfession(record)
                if type(record) ~= "table" then return false end

                local skillLineID = tonumber(record.skillLineID)
                if skillLineID and GATHERING_SKILL_LINES[skillLineID] then
                    return true
                end

                local name = tostring(record.professionName or record.profession or ""):lower()
                name = name:gsub("[^%a]", "")
                return GATHERING_PROFESSIONS[name] == true
            end

            -- Crafting Opportunities are character-specific.  The recipe
            -- database is shared across characters, so looking only at the
            -- global recipe profession can leak Alchemy/Enchanting/etc. into
            -- a Leatherworking character's dashboard. Build the set of
            -- professions actually registered for this character and require
            -- each opportunity to belong to one of them.
            local function NormalizeProfessionName(name)
                return tostring(name or ""):lower():gsub("[^%a]", "")
            end

            local function GetCurrentCharacterProfessionSet()
                local ids, names = {}, {}
                local hasLiveProfessions = false

                local function AddProfessionIdentity(skillLineID, professionName)
                    local id = tonumber(skillLineID)
                    if id then ids[id] = true end
                    local name = NormalizeProfessionName(professionName)
                    if name ~= "" then names[name] = true end
                end

                -- The live character profession slots are the authoritative
                -- source for this page.  Do not let shared/stale recipe scan
                -- data decide which professions the current character owns.
                -- GetProfessions() returns the professions actually learned by
                -- the player, while GetProfessionSkillLineID() gives us the
                -- base SkillLineID for the modern profession enum.
                if GetProfessions and GetProfessionInfo then
                    local prof1, prof2, archaeology, fishing, cooking = GetProfessions()
                    local slots = { prof1, prof2, archaeology, fishing, cooking }
                    for _, slot in ipairs(slots) do
                        if slot then
                            local ok, name, _, _, _, _, skillLineID = pcall(GetProfessionInfo, slot)
                            if ok and (name or skillLineID) then
                                hasLiveProfessions = true
                                AddProfessionIdentity(skillLineID, name)

                                local enumByName = {
                                    blacksmithing = Enum and Enum.Profession and Enum.Profession.Blacksmithing,
                                    leatherworking = Enum and Enum.Profession and Enum.Profession.Leatherworking,
                                    alchemy = Enum and Enum.Profession and Enum.Profession.Alchemy,
                                    herbalism = Enum and Enum.Profession and Enum.Profession.Herbalism,
                                    cooking = Enum and Enum.Profession and Enum.Profession.Cooking,
                                    mining = Enum and Enum.Profession and Enum.Profession.Mining,
                                    tailoring = Enum and Enum.Profession and Enum.Profession.Tailoring,
                                    engineering = Enum and Enum.Profession and Enum.Profession.Engineering,
                                    enchanting = Enum and Enum.Profession and Enum.Profession.Enchanting,
                                    fishing = Enum and Enum.Profession and Enum.Profession.Fishing,
                                    skinning = Enum and Enum.Profession and Enum.Profession.Skinning,
                                    jewelcrafting = Enum and Enum.Profession and Enum.Profession.Jewelcrafting,
                                    inscription = Enum and Enum.Profession and Enum.Profession.Inscription,
                                    firstaid = Enum and Enum.Profession and Enum.Profession.FirstAid,
                                }
                                local enum = enumByName[NormalizeProfessionName(name)]
                                if enum ~= nil and C_TradeSkillUI and C_TradeSkillUI.GetProfessionSkillLineID then
                                    local okID, baseID = pcall(C_TradeSkillUI.GetProfessionSkillLineID, enum)
                                    if okID then
                                        AddProfessionIdentity(baseID, name)
                                    end
                                end
                            end
                        end
                    end
                end

                -- If the live profession API is unavailable, retain the saved
                -- data fallback for older clients. It is deliberately never
                -- merged with live data, because old scans can contain stale
                -- professions from earlier versions of GoldMint.
                if not hasLiveProfessions then
                    local characterKey = GoldMint.characterKey
                    local character = GoldMintDB and GoldMintDB.characters and GoldMintDB.characters[characterKey]
                    if type(character) == "table" then
                        local function AddProfession(profession)
                            if type(profession) ~= "table" then return end
                            AddProfessionIdentity(
                                profession.baseSkillLineID or profession.parentSkillLineID or profession.skillLineID,
                                profession.name or profession.parentProfessionName or profession.professionName or profession.displayName
                            )
                            AddProfessionIdentity(profession.skillLineID, profession.name or profession.displayName)

                            if type(profession.variants) == "table" then
                                for _, variant in pairs(profession.variants) do
                                    if type(variant) == "table" then
                                        AddProfessionIdentity(variant.skillLineID, variant.name or variant.displayName)
                                    end
                                end
                            end
                        end

                        if type(character.professions) == "table" then
                            for _, profession in pairs(character.professions) do
                                AddProfession(profession)
                            end
                        end
                        if type(character.professionScans) == "table" then
                            for _, scan in pairs(character.professionScans) do
                                AddProfession(scan)
                            end
                        end
                    end
                end

                return ids, names
            end

            local function IsCurrentCharacterProfessionRecipe(record, professionIDs, professionNames)
                if type(record) ~= "table" then return false end

                -- Ask Blizzard which profession owns this exact recipe.  This
                -- avoids relying on shared GoldMint recipe records, which may
                -- have been scanned by another character/profession in the
                -- past.  The API returns both the expansion skill line and its
                -- parent profession skill line.
                local recipeID = tonumber(record.recipeID)
                if recipeID and C_TradeSkillUI then
                    if C_TradeSkillUI.GetTradeSkillLineForRecipe then
                        local ok, tradeSkillID, skillLineName, parentTradeSkillID = pcall(
                            C_TradeSkillUI.GetTradeSkillLineForRecipe, recipeID
                        )
                        if ok then
                            if tonumber(tradeSkillID) and professionIDs[tonumber(tradeSkillID)] then
                                return true
                            end
                            if tonumber(parentTradeSkillID) and professionIDs[tonumber(parentTradeSkillID)] then
                                return true
                            end
                            local apiName = NormalizeProfessionName(skillLineName)
                            if apiName ~= "" and professionNames[apiName] then
                                return true
                            end
                            -- If Blizzard positively identifies the recipe as
                            -- another profession, do not fall through to stale
                            -- character/record fields and accidentally accept it.
                            if tonumber(tradeSkillID) or tonumber(parentTradeSkillID) or apiName ~= "" then
                                return false
                            end
                        end
                    end

                    if C_TradeSkillUI.GetProfessionInfoByRecipeID then
                        local ok, info = pcall(C_TradeSkillUI.GetProfessionInfoByRecipeID, recipeID)
                        if ok and type(info) == "table" then
                            local parentID = tonumber(info.parentProfessionID)
                            local professionID = tonumber(info.professionID)
                            if parentID and professionIDs[parentID] then return true end
                            if professionID and professionIDs[professionID] then return true end
                            local apiName = NormalizeProfessionName(info.parentProfessionName or info.professionName)
                            if apiName ~= "" then
                                return professionNames[apiName] == true
                            end
                            return false
                        end
                    end
                end

                -- Last-resort fallback for old saved recipe records when the
                -- live recipe-profession API is unavailable.
                local characterKey = GoldMint.characterKey
                local characterRecord = record.characters and record.characters[characterKey]
                if type(characterRecord) == "table" then
                    local characterSkillLine = tonumber(characterRecord.skillLineID)
                    if characterSkillLine and professionIDs[characterSkillLine] then return true end
                    local characterProfession = NormalizeProfessionName(characterRecord.skillLineName)
                    if characterProfession ~= "" and professionNames[characterProfession] then return true end
                end

                local recordSkillLine = tonumber(record.skillLineID)
                if recordSkillLine and professionIDs[recordSkillLine] then return true end
                local recordProfessionID = tonumber(record.professionID)
                if recordProfessionID and professionIDs[recordProfessionID] then return true end

                local recordProfession = NormalizeProfessionName(record.professionName or record.profession)
                return recordProfession ~= "" and professionNames[recordProfession] == true
            end

            local function GetRecords()
                local professionIDs, professionNames = GetCurrentCharacterProfessionSet()
                local data = {}
                local orderCounts = GetCraftingOrderCounts()
                for recipeID, record in pairs((GoldMintDB and GoldMintDB.recipes) or {}) do
                    if type(record) == "table" and record.name
                        and not IsGatheringProfession(record)
                        and IsCurrentCharacterProfessionRecipe(record, professionIDs, professionNames) then
                        record.recipeID = record.recipeID or recipeID
                        local profit = GetProfit(record)
                        local roi = GetROI(record)
                        local goldPerConcentration = GetGoldPerConcentration(record, profit)
                        local profitPerMinute = GetFutureProfitPerMinute(record, profit)
                        local ready = MaterialsReady(record)
                        local known = IsKnown(record)
                        local demand = IsHighDemand(record)
                        local sales = HasObservedSales(record)
                        local orders = HasCraftingOrders(record, orderCounts)
                        local passes = true
                        if filterState.profitable and profit <= 0 then passes = false end
                        if profit < (tonumber(minimumProfit) or 0) * 10000 then passes = false end
                        if filterState.materials and not ready then passes = false end
                        if filterState.demand and not demand then passes = false end
                        if filterState.orders and not orders then passes = false end
                        if filterState.sales and not sales then passes = false end
                        if passes then
                            data[#data+1] = {
                                record = record,
                                profit = profit,
                                roi = roi,
                                goldPerConcentration = goldPerConcentration,
                                profitPerMinute = profitPerMinute,
                                ready = ready,
                                known = known,
                                demand = demand,
                                sales = sales,
                                orders = orders,
                            }
                        end
                    end
                end
                table.sort(data, function(a,b)
                    if sortMode == "roi" then
                        if a.roi ~= b.roi then return a.roi > b.roi end
                    elseif sortMode == "goldConcentration" then
                        local ag = a.goldPerConcentration
                        local bg = b.goldPerConcentration
                        if ag and bg and ag ~= bg then return ag > bg end
                        if ag and not bg then return true end
                        if bg and not ag then return false end
                    end
                    if a.profit ~= b.profit then return a.profit > b.profit end
                    return tostring(a.record.name) < tostring(b.record.name)
                end)
                return data
            end

            local function OpportunityReason(entry)
                if not entry.known then return "RECIPE UNKNOWN" end
                if entry.profit <= 0 then return "LOSS" end
                if entry.ready and entry.roi >= 100 then return "CONCENTRATION PROFIT" end
                if entry.demand then return "HIGH DEMAND" end
                if entry.ready then return "MATERIALS READY" end
                return "MATERIALS NEEDED"
            end

            local function OpportunityStatus(entry)
                if not entry.known then return "LEARN", GOLD end
                if entry.profit <= 0 then return "SKIP", RED end
                if entry.ready then return "CRAFT", GREEN end
                return "BUY", CYAN
            end

            RefreshCraftingBottomBoxes = function()
                local queue = GoldMintDB and GoldMintDB.craftingQueue or {}
                for i = 1, 3 do
                    local q = queue[i]
                    if q then
                        local quantity = math.max(tonumber(q.quantity) or 1, 1)
                        local status = tostring(q.status or "QUEUED")
                        queueLines[i]:SetText(string.format("%d. %s x%d  •  %s", i, tostring(q.name or "Queued craft"), quantity, status))
                        queueLines[i]:SetTextColor(unpack(status == "READY" and GREEN or MUTED))
                    else
                        queueLines[i]:SetText(i == 1 and "Queue is empty" or "")
                        queueLines[i]:SetTextColor(unpack(MUTED))
                    end
                end

                for i = 1, 3 do
                    materialLines[i]:SetText("")
                end

                if not selected or not selected.record then
                    concentrationText:SetText("No opportunity selected")
                    concentrationDetail:SetText("Select a craft above")
                    concentrationGold:SetText("")
                    profitMain:SetText("No opportunity selected")
                    profitDetail:SetText("")
                    profitROI:SetText("")
                    return
                end

                local r = selected.record
                local reagents = r.reagents or {}
                if #reagents == 0 then
                    materialLines[1]:SetText("No reagent data recorded")
                else
                    for i = 1, math.min(#reagents, 3) do
                        local reagent = reagents[i]
                        local needed = tonumber(reagent.quantity) or 0
                        local bestItem, owned = nil, 0
                        for _, option in ipairs(reagent.options or {}) do
                            local itemID = tonumber(option.itemID)
                            local count = GetOwnedCount(itemID)
                            if count >= needed then
                                bestItem, owned = itemID, count
                                break
                            elseif not bestItem or count > owned then
                                bestItem, owned = itemID, count
                            end
                        end
                        local reagentName = bestItem and GetItemName(bestItem) or "Unknown material"
                        reagentName = reagentName or ("Item " .. tostring(bestItem or "?"))
                        materialLines[i]:SetText(string.format("%s  %d/%d", reagentName, owned, needed))
                        materialLines[i]:SetTextColor(unpack(owned >= needed and GREEN or GOLD))
                    end
                    if #reagents > 3 then
                        materialLines[3]:SetText(string.format("%s (+%d more)", materialLines[3]:GetText() or "", #reagents - 3))
                    end
                end

                local concentration = GetConcentration(r)
                local gpc = selected.goldPerConcentration
                concentrationText:SetText(tostring(r.name or "Selected craft"))
                concentrationDetail:SetText(concentration and ("Cost: " .. string.format("%.0f", concentration) .. " concentration") or "Cost: not tracked")
                concentrationGold:SetText(gpc and (FormatGold(gpc) .. " / concentration") or "Gold / concentration: —")

                profitMain:SetText("Profit  " .. ((selected.profit >= 0 and "+" or "") .. FormatGold(math.abs(selected.profit))))
                profitMain:SetTextColor(unpack(selected.profit >= 0 and GREEN or RED))
                profitDetail:SetText("Sale " .. (GetSaleValue(r) > 0 and FormatGold(GetSaleValue(r)) or "—") .. "  •  Cost " .. (GetMaterialCost(r) > 0 and FormatGold(GetMaterialCost(r)) or "—"))
                local futurePPM = selected.profitPerMinute
                if futurePPM then
                    profitROI:SetText("ROI  " .. (selected.roi > 0 and string.format("%.0f%%", math.min(selected.roi, 9999)) or "—") .. "  •  FUTURE " .. FormatGold(futurePPM) .. "/min")
                else
                    profitROI:SetText("ROI  " .. (selected.roi > 0 and string.format("%.0f%%", math.min(selected.roi, 9999)) or "—") .. "  •  FUTURE /min  —")
                end
            end

            local function SelectOpportunity(entry)
                selected = entry
                local r = entry.record
                currentIcon:SetTexture(GetRecipeIcon(r))
                currentName:SetText(r.name or "Unknown Recipe")
                currentProfession:SetText(r.professionName or r.profession or "Profession unknown")
                local status, statusColor = OpportunityStatus(entry)
                currentStatus:SetText(status .. "  •  " .. OpportunityReason(entry))
                currentStatus:SetTextColor(unpack(statusColor))
                saleValue:SetText(GetSaleValue(r) > 0 and FormatGold(GetSaleValue(r)) or "—")
                materialValue:SetText(GetMaterialCost(r) > 0 and FormatGold(GetMaterialCost(r)) or "—")
                profitValue:SetText((entry.profit >= 0 and "+" or "") .. FormatGold(math.abs(entry.profit)))
                profitValue:SetTextColor(unpack(entry.profit >= 0 and GREEN or RED))
                roiValue:SetText(entry.roi > 0 and string.format("%.0f%%", math.min(entry.roi, 9999)) or "—")
                roiValue:SetTextColor(unpack(entry.roi >= 100 and GREEN or MUTED))
                local gpc = entry.goldPerConcentration
                concentrationValue:SetText(gpc and FormatGold(gpc) .. " / concentration" or "Not tracked")
                materialState:SetText(entry.ready and "READY" or "NEEDED")
                materialState:SetTextColor(unpack(entry.ready and GREEN or GOLD))
                action:SetText(entry.ready and "CRAFT" or "BUY MATERIALS")
                action:Show()
                buy:Show()
                if RefreshCraftingBottomBoxes then RefreshCraftingBottomBoxes() end
            end

            local function ClearRows()
                for _, row in ipairs(rows) do row:Hide() end
                wipe(rows)
            end

            buildRows = function()
                ClearRows()
                minimumProfit = tonumber(minBox:GetText()) or 0
                local data = GetRecords()
                local y = 0
                for i, entry in ipairs(data) do
                    if i <= 5 then
                        local row = CreateFrame("Button", nil, opp, "BackdropTemplate")
                        row:SetSize(460, 33)
                        row:SetPoint("TOPLEFT", 14, -78 - (i-1)*34)
                        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8})
                        row:SetBackdropColor(i % 2 == 0 and 0.012 or 0.018, 0.035, 0.055, 0.94)
                        row:SetBackdropBorderColor(0.07,0.20,0.31,0.70)

                        local icon = row:CreateTexture(nil, "ARTWORK")
                        icon:SetSize(24,24)
                        icon:SetPoint("LEFT", 6, 0)
                        icon:SetTexture(GetRecipeIcon(entry.record))
                        local name = CL(row, entry.record.name, 38, -6, 175, entry.known and MUTED or GOLD, "GameFontNormalSmall")
                        name:SetWordWrap(false)
                        local profitText = CL(row, (entry.profit >= 0 and "+" or "") .. ShortGold(entry.profit) .. "g", 220, -6, 82, entry.profit > 0 and GREEN or RED, "GameFontNormalSmall", "RIGHT")
                        local roiText = CL(row, entry.roi > 0 and string.format("%.0f%%", math.min(entry.roi,9999)) or "—", 310, -6, 52, entry.roi >= 100 and GREEN or MUTED, "GameFontNormalSmall", "RIGHT")
                        local status, statusColor = OpportunityStatus(entry)
                        CL(row, status, 375, -6, 72, statusColor, "GameFontNormalSmall")

                        -- Thin horizontal separator between each opportunity.
                        -- Keep it inside the row so the final row has no extra
                        -- line hanging below the table.
                        if i < math.min(5, #data) then
                            local separator = row:CreateTexture(nil, "ARTWORK")
                            separator:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 0.28)
                            separator:SetSize(448, 1)
                            separator:SetPoint("BOTTOMLEFT", 6, -1)
                        end

                        row:SetScript("OnClick", function() SelectOpportunity(entry) end)
                        row:SetScript("OnEnter", function(self) self:SetBackdropColor(0.055,0.11,0.16,0.98) end)
                        row:SetScript("OnLeave", function(self) self:SetBackdropColor(i % 2 == 0 and 0.012 or 0.018,0.035,0.055,0.94) end)
                        rows[#rows+1] = row
                    end
                end

                if emptyMessage then emptyMessage:Hide() end
                if #data == 0 then
                    emptyMessage = emptyMessage or CL(opp, "No crafting opportunities match the current filters.", 18, -84, 450, MUTED, "GameFontNormal")
                    emptyMessage:Show()
                    selected = nil
                    if RefreshCraftingBottomBoxes then RefreshCraftingBottomBoxes() end
                else
                    local selectedEntry = data[1]
                    if selected and selected.record then
                        local selectedID = tonumber(selected.record.recipeID)
                        for _, candidate in ipairs(data) do
                            if selectedID and tonumber(candidate.record.recipeID) == selectedID then
                                selectedEntry = candidate
                                break
                            end
                        end
                    end
                    SelectOpportunity(selectedEntry)
                end

                filterSummary = filterSummary or CL(filter, "", 14, -222, 280, MUTED, "GameFontNormalSmall")
                filterSummary:SetText(string.format("%d opportunities • %d ready", #data, (function()
                    local n=0; for _, e in ipairs(data) do if e.ready then n=n+1 end end; return n
                end)()))
                -- The old top-opportunity rail was removed from this page, so
                -- there is no separate top-card scan-status label to update.
            end

            roiButton:SetScript("OnClick", function()
                sortMode = "roi"
                buildRows()
            end)
            goldButton:SetScript("OnClick", function()
                sortMode = "goldConcentration"
                buildRows()
            end)
            clear:SetScript("OnClick", function()
                filterState.profitable = false
                filterState.materials = false
                filterState.demand = false
                filterState.orders = false
                filterState.sales = false
                for key, b in pairs(filterButtons) do
                    local checked = filterState[key] == true
                    if b.ApplyState then
                        b.ApplyState()
                    elseif b.checkBox then
                        b.checkBox:SetChecked(checked)
                        local checkTexture = b.checkBox:GetCheckedTexture()
                        if checkTexture then
                            checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                        end
                    end
                end
                minimumProfit = 0
                minBox:SetText("0")
                sortMode = "profit"
                buildRows()
            end)
            minBox:SetScript("OnEnterPressed", function(self)
                minimumProfit = tonumber(self:GetText()) or 0
                self:ClearFocus()
                buildRows()
            end)
            minBox:SetScript("OnTextChanged", function() end)

            action:SetScript("OnClick", function()
                if selected and selected.record and selected.record.recipeID and C_TradeSkillUI and C_TradeSkillUI.OpenRecipe then
                    pcall(C_TradeSkillUI.OpenRecipe, selected.record.recipeID)
                end
            end)
            buy:SetScript("OnClick", function()
                if selected and selected.record then
                    GoldMint.Print("Material shopping list requested for " .. tostring(selected.record.name or "this craft") .. ".")
                end
            end)

            queueCurrent:SetScript("OnClick", function()
                if not selected or not selected.record then
                    GoldMint.Print("Select a crafting opportunity first.")
                    return
                end
                GoldMintDB.craftingQueue = type(GoldMintDB.craftingQueue) == "table" and GoldMintDB.craftingQueue or {}
                local recipeID = tonumber(selected.record.recipeID)
                for _, q in ipairs(GoldMintDB.craftingQueue) do
                    if recipeID and tonumber(q.recipeID) == recipeID then
                        GoldMint.Print("That recipe is already in the crafting queue.")
                        RefreshCraftingBottomBoxes()
                        return
                    end
                end
                GoldMintDB.craftingQueue[#GoldMintDB.craftingQueue + 1] = {
                    recipeID = recipeID,
                    name = selected.record.name or "Craft",
                    quantity = 1,
                    status = selected.ready and "READY" or "MATERIALS NEEDED",
                    profit = selected.profit,
                    roi = selected.roi,
                    concentrationCost = selected.record.concentrationCost,
                    queuedAt = time(),
                }
                GoldMint.Print("Queued " .. tostring(selected.record.name or "craft") .. ".")
                RefreshCraftingBottomBoxes()
            end)

            queueClear:SetScript("OnClick", function()
                GoldMintDB.craftingQueue = {}
                RefreshCraftingBottomBoxes()
            end)

            buildRows()
        end
        local function market()
            for _, b in pairs(tabButtons) do b:Hide() end
            title:SetText("")
            sub:SetText("")
            content:ClearAllPoints()
            content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, -8)
            content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)

            -- Build the Market page only once.  Previously every navigation back to
            -- Market created another complete set of scroll rows, buttons, labels,
            -- tooltips, and history widgets, then hid the old page.  After several
            -- visits that left hundreds/thousands of live frames behind and made the
            -- Market page increasingly laggy even when the Auction House was closed.
            if panels.marketPage then
                local existing = panels.marketPage
                existing:SetParent(content)
                existing:ClearAllPoints()
                existing:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
                existing:SetPoint("BOTTOMRIGHT", content, "BOTTOMRIGHT", 0, 0)
                existing:Show()
                return
            end

            local page = CreateFrame("Frame", nil, content)
            panels.marketPage = page
            -- Market uses the same full-width page surface as the other dashboard pages so
            -- the header and primary panels share the same left/right edges.
            page:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
            page:SetPoint("BOTTOMRIGHT", content, "BOTTOMRIGHT", 0, 0)

            local function ML(parent, text, x, y, w, color, font, justify)
                local l = MakeLabel(parent, font or "GameFontNormal", text, w)
                l:SetPoint("TOPLEFT", x, y)
                l:SetTextColor(unpack(color or MUTED))
                l:SetWordWrap(false)
                l:SetNonSpaceWrap(false)
                if justify then l:SetJustifyH(justify) end
                return l
            end
            local function MCard(parent, w, h, x, y, border)
                return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
            end
            local function MButton(parent, text, w, h, x, y, kind)
                local b = MakeButton(parent, text, w, h or 28, kind or "secondary")
                b:SetPoint("TOPLEFT", x, y)
                return b
            end
            local function UnitGold(value)
                value = tonumber(value) or 0
                if value <= 0 then return "—" end
                return FormatGold(value)
            end
            local function ShortGold(value)
                value = tonumber(value) or 0
                if value <= 0 then return "0g" end
                if value >= 10000000 then return string.format("%.1fm", value / 10000000) end
                if value >= 100000 then return string.format("%.1fk", value / 10000) end
                return tostring(math.floor(value / 10000)) .. "g"
            end
            local function ItemInfo(itemID)
                itemID = tonumber(itemID)
                if itemID then
                    -- Retail can have a valid item ID in the Market database before
                    -- Blizzard has loaded that item's display data. Prefer the direct
                    -- name/icon APIs so a cold cache does not render "Item 12345" and
                    -- a question-mark icon. Request the data once; the Market event
                    -- path refreshes the rows when ITEM_DATA_LOAD_RESULT arrives.
                    local name, link, quality, icon
                    if C_Item and C_Item.GetItemNameByID then
                        local ok, value = pcall(C_Item.GetItemNameByID, itemID)
                        if ok and value then name = value end
                    end
                    if C_Item and C_Item.GetItemIconByID then
                        local ok, value = pcall(C_Item.GetItemIconByID, itemID)
                        if ok and value then icon = value end
                    end
                    if C_Item and C_Item.GetItemInfo then
                        local ok, n, l, q, _, _, _, _, _, _, tex = pcall(C_Item.GetItemInfo, itemID)
                        if ok then
                            name = name or n
                            link = l
                            quality = q
                            icon = icon or tex
                        end
                    end
                    if (not name or not icon) and C_Item and C_Item.RequestLoadItemDataByID then
                        pcall(C_Item.RequestLoadItemDataByID, itemID)
                    end
                    if name then return name, link, icon or 134400, quality or 1 end
                end
                local record = GoldMint.Market and GoldMint.Market.GetRecord and GoldMint.Market:GetRecord(itemID)
                return (record and record.name) or ("Item "..tostring(itemID or "?")), nil, 134400, 1
            end

            -- ================================================================
            -- MARKET INTELLIGENCE HEADER
            -- ================================================================
            local header = MCard(page, 1136, 64, 0, 8, {0.08,0.38,0.58,0.95})
            local marketIcon = header:CreateTexture(nil, "ARTWORK")
            marketIcon:SetSize(30,30); marketIcon:SetPoint("TOPLEFT",14,-16)
            marketIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintMarket")
            ML(header, "MARKET OVERVIEW", 54, -12, 330, CYAN, "GameFontNormalLarge")
            local scanStatus = ML(header, "Ready for a live market database scan", 54, -37, 520, MUTED, "GameFontNormalSmall")

            local statsTracked = ML(header, "0 TRACKED", 398, -14, 92, GOLD, "GameFontNormalSmall", "CENTER")
            local statsMarket = ML(header, "MARKET: —", 492, -14, 126, CYAN, "GameFontNormalSmall", "CENTER")
            local statsProfit = ML(header, "PROFIT: —", 620, -14, 126, GREEN, "GameFontNormalSmall", "CENTER")
            local statsChanges = ML(header, "0 CHANGES", 748, -14, 128, GOLD, "GameFontNormalSmall", "CENTER")
            local sync = MButton(header, "SCAN MARKET", 104, 28, 884, -18, "secondary")

            -- ================================================================
            -- DATABASE / SMART VALUATION
            -- ================================================================
            local database = MCard(page, 570, 474, 0, -80, {0.08,0.38,0.58,0.95})
            local marketWatchHeader = ML(database, "MARKET WATCH", 16, -14, 270, CYAN, "GameFontNormalLarge")
            marketWatchHeader:SetShadowOffset(1, -1)
            local marketWatchAccent = Accent(database, "TOPLEFT", 16, -32, 38, CYAN)
            C_Timer.After(0, function()
                if marketWatchHeader and marketWatchAccent then
                    local font, size, flags = marketWatchHeader:GetFont()
                    if font and size then
                        local measure = database:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("MAR")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        marketWatchAccent:SetWidth(width)
                    end
                end
            end)
            ML(database, "Current price, regional value, demand, and price trend", 16, -37, 390, MUTED, "GameFontNormalSmall")

            local search = CreateFrame("EditBox", nil, database, "BackdropTemplate")
            search:SetSize(190,28); search:SetPoint("TOPRIGHT", -78, -12)
            search:SetAutoFocus(false); search:SetFontObject("GameFontNormalSmall"); search:SetTextColor(1,1,1)
            search:SetTextInsets(9,9,0,0)
            search:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8})
            search:SetBackdropColor(0.012,0.035,0.055,0.95); search:SetBackdropBorderColor(0.07,0.25,0.38,0.85)
            local searchHint = search:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            searchHint:SetPoint("LEFT", 9, 0)
            searchHint:SetText("Search materials")
            searchHint:SetTextColor(unpack(MUTED))
            searchHint:SetAlpha(0.70)
            search:SetScript("OnTextChanged", function(self) searchHint:SetShown(self:GetText()=="") end)
            local clear = MButton(database, "CLEAR", 62, 28, 495, -12, "secondary")

            -- Market filter buttons: keep the displayed labels explicitly tied to
            -- their filter modes so later refreshes can never visually swap them.
            local modeMaterials = MButton(database, "MATERIALS", 92, 24, 16, -58, "primary")
            local modeAll = MButton(database, "ALL TRACKED", 92, 24, 114, -58, "secondary")
            local modeHighDemand = MButton(database, "HIGH DEMAND", 102, 24, 212, -58, "secondary")
            local modeOpportunity = MButton(database, "OPPORTUNITIES", 108, 24, 320, -58, "secondary")
            modeMaterials.text:SetText("MATERIALS")
            modeAll.text:SetText("ALL TRACKED")
            modeHighDemand.text:SetText("HIGH DEMAND")
            modeOpportunity.text:SetText("OPPORTUNITIES")
            local activeMode = "materials"
            local modeLabel = ML(database, "All tracked market materials. Gear, costumes, and collectibles remain excluded.", 16, -84, 530, MUTED, "GameFontNormalSmall")

            -- Clickable market-data headers. First click sorts high-to-low for
            -- numeric columns; clicking the same header again reverses the order.
            local sortKey = nil
            local sortDesc = true
            local sortButtons = {}
            local RefreshRows, RefreshSelected
            local headerDefs = {
                {key="name",   text="ITEM",     x=16,  w=170, justify="LEFT",  numeric=false},
                {key="market", text="MARKET",   x=190, w=82,  justify="RIGHT", numeric=true},
                {key="region", text="REGION",   x=278, w=82,  justify="RIGHT", numeric=true},
                {key="sold",   text="SOLD/DAY", x=366, w=74,  justify="RIGHT", numeric=true},
                {key="demand", text="DEMAND",   x=444, w=64,  justify="RIGHT", numeric=true},
                {key="trend",  text="TREND",    x=512, w=44,  justify="RIGHT", numeric=false},
            }
            local function UpdateSortHeaderText()
                for _, h in ipairs(headerDefs) do
                    local b = sortButtons[h.key]
                    if b then
                        local suffix = (sortKey == h.key) and (sortDesc and " ▼" or " ▲") or ""
                        b.text:SetText(h.text .. suffix)
                    end
                end
            end
            for _, h in ipairs(headerDefs) do
                local b = CreateFrame("Button", nil, database)
                b:SetSize(h.w, 24)
                b:SetPoint("TOPLEFT", h.x, -110)
                b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                b.text:SetAllPoints()
                b.text:SetTextColor(unpack(MUTED))
                b.text:SetJustifyH(h.justify)
                b.text:SetWordWrap(false)
                b.text:SetNonSpaceWrap(false)
                b:SetHighlightTexture("Interface\\Buttons\\WHITE8X8")
                b:GetHighlightTexture():SetVertexColor(0.08,0.25,0.38,0.18)
                b:SetScript("OnClick", function()
                    if sortKey == h.key then
                        sortDesc = not sortDesc
                    else
                        sortKey = h.key
                        sortDesc = h.numeric
                    end
                    UpdateSortHeaderText()
                    if RefreshRows then RefreshRows() end
                end)
                sortButtons[h.key] = b
            end
            UpdateSortHeaderText()
            local divider=database:CreateTexture(nil,"ARTWORK")
            divider:SetColorTexture(0.08,0.25,0.38,0.82); divider:SetSize(1,1); divider:SetPoint("TOPLEFT",14,-132); divider:SetPoint("TOPRIGHT",-14,-132)

            local scroll, rows = CreateGoldMintScrollFrame(database, 10, -138, -22, 16, 565)
            local rowWidgets = {}
            local selectedItem = nil

            local function GetDemandInfo(soldPerDay)
                local sold = tonumber(soldPerDay) or 0
                if sold >= 10000 then return "VERY HIGH", GREEN, 5 end
                if sold >= 1000 then return "HIGH", GREEN, 4 end
                if sold >= 100 then return "MEDIUM", CYAN, 3 end
                if sold >= 10 then return "LOW", MUTED, 2 end
                return "VERY LOW", MUTED, 1
            end

            local trendCache = {}
            local function GetTrendInfo(itemID)
                itemID = tonumber(itemID)
                if itemID and trendCache[itemID] then
                    local c = trendCache[itemID]
                    return c[1], c[2], c[3]
                end
                local history = GoldMint.Market and GoldMint.Market.GetHistory and GoldMint.Market:GetHistory(itemID,30) or {}
                local text, color, value
                if #history < 2 then
                    text, color, value = "—", MUTED, 0
                else
                    local first = tonumber(history[1].value) or 0
                    local last = tonumber(history[#history].value) or 0
                    if first <= 0 or last <= 0 then
                        text, color, value = "—", MUTED, 0
                    else
                        local change = (last - first) / first
                        if change >= 0.05 then
                            text, color, value = "↗", GREEN, change
                        elseif change <= -0.05 then
                            text, color, value = "↘", RED, change
                        else
                            text, color, value = "↔", MUTED, change
                        end
                    end
                end
                if itemID then trendCache[itemID] = {text, color, value} end
                return text, color, value
            end


            -- ================================================================
            -- SMART VALUATION PANEL
            -- ================================================================
            local detail = MCard(page, 548, 474, 588, -80, {0.08,0.38,0.58,0.95})

            local priceTrendsHeader = ML(detail, "PRICE TRENDS & SMART VALUATION", 16, -14, 360, CYAN, "GameFontNormalLarge")
            priceTrendsHeader:SetShadowOffset(1, -1)
            local priceTrendsAccent = Accent(detail, "TOPLEFT", 16, -32, 38, CYAN)
            C_Timer.After(0, function()
                if priceTrendsHeader and priceTrendsAccent then
                    local font, size, flags = priceTrendsHeader:GetFont()
                    if font and size then
                        local measure = detail:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("PRI")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        priceTrendsAccent:SetWidth(width)
                    end
                end
            end)
            local selectedNameLabel = ML(detail, "Select a material", 16, -43, 378, MUTED, "GameFontHighlightLarge")
            detail._selectedNameLabel = selectedNameLabel

            local currentCard=MCard(detail,378,64,105,-70,{0.08,0.30,0.46,0.92})
            ML(currentCard,"CURRENT MARKET",12,-10,140,CYAN,"GameFontNormalSmall")
            local currentMarketValue=ML(currentCard,"—",12,-29,190,CYAN,"GameFontHighlightLarge")
            local marketPosition=ML(currentCard,"Region Avg: —",204,-18,162,MUTED,"GameFontNormalSmall","RIGHT")
            local marketPositionSub=ML(currentCard,"",204,-39,162,MUTED,"GameFontNormalSmall","RIGHT")

            local rawBox = MCard(detail, 116, 70, 106, -140, {0.08,0.30,0.46,0.92})
            local processedBox = MCard(detail, 116, 70, 236, -140, {0.08,0.30,0.46,0.92})
            local shatterBox = MCard(detail, 116, 70, 366, -140, {0.08,0.30,0.46,0.92})
            ML(rawBox,"RAW",12,-10,104,CYAN,"GameFontNormalSmall")
            ML(processedBox,"PROCESSED",12,-10,104,GOLD,"GameFontNormalSmall")
            ML(shatterBox,"SHATTER / DUST",12,-10,104,GREEN,"GameFontNormalSmall")
            local rawValue=ML(rawBox,"—",12,-34,104,CYAN,"GameFontNormal")
            local processedValue=ML(processedBox,"—",12,-34,104,GOLD,"GameFontNormal")
            local shatterValue=ML(shatterBox,"—",12,-34,104,GREEN,"GameFontNormal")

            local regionCard=MCard(detail,378,72,105,-216,{0.08,0.30,0.46,0.92})
            ML(regionCard,"REGION INTELLIGENCE",12,-10,210,CYAN,"GameFontNormalSmall")
            local regionAvg=ML(regionCard,"Region Avg: —",12,-32,178,MUTED,"GameFontNormalSmall")
            local regionHistorical=ML(regionCard,"Historical: —",12,-50,178,MUTED,"GameFontNormalSmall")
            local regionSale=ML(regionCard,"Sale Avg: —",196,-32,170,MUTED,"GameFontNormalSmall","RIGHT")
            local regionVol=ML(regionCard,"Sold / Day: —",196,-50,170,MUTED,"GameFontNormalSmall","RIGHT")

            local signalsCard=MCard(detail,378,72,105,-292,{0.08,0.30,0.46,0.92})
            ML(signalsCard,"MARKET SIGNALS",12,-10,150,CYAN,"GameFontNormalSmall")
            local signalDemand=ML(signalsCard,"DEMAND: —",12,-31,174,MUTED,"GameFontNormalSmall")
            local signalPosition=ML(signalsCard,"POSITION: —",192,-31,174,MUTED,"GameFontNormalSmall","RIGHT")
            local signalOpportunity=ML(signalsCard,"OPPORTUNITY: —",12,-50,174,MUTED,"GameFontNormalSmall")
            local signalTrend=ML(signalsCard,"TREND:",192,-50,154,MUTED,"GameFontNormalSmall","RIGHT")
            local signalTrendIcon=signalsCard:CreateTexture(nil,"ARTWORK")
            signalTrendIcon:SetSize(16,16)
            signalTrendIcon:SetPoint("RIGHT",-12,-50)
            signalTrendIcon:Hide()

            local chart=MCard(detail,378,92,105,-368,{0.08,0.30,0.46,0.92})
            ML(chart,"PRICE HISTORY • 30 DAYS",12,-10,240,MUTED,"GameFontNormalSmall")
            local chartMax=ML(chart,"—",12,-31,92,MUTED,"GameFontNormalSmall")
            local chartMin=ML(chart,"—",12,-72,92,MUTED,"GameFontNormalSmall")
            local chartLines={}
            local chartEmpty
            local function DrawHistory(itemID)
                for _,line in ipairs(chartLines) do line:Hide() end; wipe(chartLines)
                if chartEmpty then chartEmpty:Hide() end
                local history=GoldMint.Market and GoldMint.Market.GetHistory and GoldMint.Market:GetHistory(itemID,30) or {}
                if #history < 2 then
                    chartMax:SetText("—"); chartMin:SetText("—")
                    chartEmpty=ML(chart,"Awaiting more observations",82,-56,280,MUTED,"GameFontNormalSmall","CENTER")
                    return
                end
                local minV,maxV=math.huge,0
                for _,point in ipairs(history) do minV=math.min(minV,point.value); maxV=math.max(maxV,point.value) end
                if maxV<=minV then maxV=minV+1 end
                chartMax:SetText(UnitGold(maxV)); chartMin:SetText(UnitGold(minV))
                local left,right,top,bottom=82,370,34,78
                for i=1,#history-1 do
                    local a,b=history[i],history[i+1]
                    local x1=left+((i-1)/math.max(1,#history-1))*(right-left); local x2=left+(i/math.max(1,#history-1))*(right-left)
                    local y1=bottom-((a.value-minV)/(maxV-minV))*(bottom-top); local y2=bottom-((b.value-minV)/(maxV-minV))*(bottom-top)
                    local dx,dy=x2-x1,y2-y1; local len=math.sqrt(dx*dx+dy*dy)
                    local line=chart:CreateTexture(nil,"ARTWORK")
                    line:SetColorTexture(1.0,0.82,0.25,0.88); line:SetSize(math.max(1,len),2)
                    line:SetPoint("CENTER",chart,"TOPLEFT",(x1+x2)/2,-((y1+y2)/2)); line:SetRotation(math.atan2(-dy,dx)); chartLines[#chartLines+1]=line
                end
            end

            -- ================================================================
            -- BEST OPPORTUNITY / FARM DETAILS
            -- ================================================================
            -- Anchor the route panel to the fixed data-panel row instead of the page bottom.
            -- This prevents the action buttons from jumping to the top-left when the
            -- operations content surface is resized or its bottom anchor changes.
            -- Compact route card: keep the Market page's farming recommendation
            -- visually close to the reference layout instead of consuming a large
            -- block of vertical space.  The detailed route data remains in the
            -- underlying route record; this card only surfaces the information that
            -- matters at a glance: best route type/value, zone/area, and instructions.
            local farmPanel = Panel(page, 1136, 104, "TOPLEFT", 0, -575, {0.08,0.30,0.46,0.92})
            local farmTitle = ML(farmPanel, "TOP OPPORTUNITY: —", 16, -12, 790, CYAN, "GameFontNormalLarge")
            farmTitle:SetShadowOffset(1, -1)
            local farmAccent = Accent(farmPanel, "TOPLEFT", 16, -30, 38, CYAN)
            C_Timer.After(0, function()
                if farmTitle and farmAccent then
                    local font, size, flags = farmTitle:GetFont()
                    if font and size then
                        local measure = farmPanel:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("BES")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        farmAccent:SetWidth(width)
                    end
                end
            end)
            local farmItem = ML(farmPanel, "Select a material to see where to farm it.", 16, -37, 790, MUTED, "GameFontNormalSmall")
            local farmZone = ML(farmPanel, "ZONE: —", 16, -57, 790, MUTED, "GameFontNormalSmall")
            local farmArea = ML(farmPanel, "AREA: —", 16, -57, 790, MUTED, "GameFontNormalSmall")
            local farmTargets = ML(farmPanel, "WHAT TO FARM: —", 16, -76, 900, MUTED, "GameFontNormalSmall")
            farmTargets:SetWordWrap(false); farmTargets:SetNonSpaceWrap(false)
            local farmNotes = ML(farmPanel, "", 16, -57, 790, MUTED, "GameFontNormalSmall")
            farmNotes:SetWordWrap(false); farmNotes:SetNonSpaceWrap(false)
            local farmButton = MButton(farmPanel, "SET WAYPOINT", 126, 26, 858, -14, "secondary")
            farmButton:Hide()
            local farmCompareButton = MButton(farmPanel, "ROUTE DATA", 126, 26, 720, -14, "secondary")
            farmCompareButton:Hide()
            local selectedGatherRoute = nil
            local routeCompareFrame

            local function HideRouteComparison()
                if routeCompareFrame then routeCompareFrame:Hide() end
            end

            local function ShowRouteComparison(itemID, itemName)
                if not itemID then return end
                if not routeCompareFrame then
                    routeCompareFrame = CreateFrame("Frame", "GoldMintRoutePerformanceFrame", UIParent, "BackdropTemplate")
                    routeCompareFrame:SetSize(720, 390)
                    routeCompareFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
                    routeCompareFrame:SetFrameStrata("DIALOG")
                    routeCompareFrame:SetClampedToScreen(true)
                    routeCompareFrame:SetBackdrop({
                        bgFile = "Interface\\Buttons\\WHITE8X8",
                        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                        edgeSize = 14,
                        insets = {left=4,right=4,top=4,bottom=4},
                    })
                    routeCompareFrame:SetBackdropColor(DARK[1], DARK[2], DARK[3], 0.98)
                    routeCompareFrame:SetBackdropBorderColor(0.08, 0.30, 0.46, 0.95)

                    local title = routeCompareFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
                    title:SetPoint("TOPLEFT", 20, -18)
                    title:SetTextColor(unpack(GOLD))
                    routeCompareFrame.title = title

                    local subtitle = routeCompareFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
                    subtitle:SetTextColor(unpack(MUTED))
                    routeCompareFrame.subtitle = subtitle

                    local close = MButton(routeCompareFrame, "CLOSE", 82, 24, 618, -16, "secondary")
                    close:SetScript("OnClick", HideRouteComparison)

                    local header = routeCompareFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    header:SetPoint("TOPLEFT", 20, -68)
                    header:SetTextColor(unpack(CYAN))
                    header:SetText("ROUTE  •  GOLD / HOUR  •  MATERIALS / HOUR  •  EVIDENCE / GEOMETRY")

                    routeCompareFrame.rows = {}
                    for i = 1, 7 do
                        local row = CreateFrame("Frame", nil, routeCompareFrame, "BackdropTemplate")
                        row:SetSize(680, 44)
                        row:SetPoint("TOPLEFT", 20, -84 - ((i - 1) * 46))
                        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
                        row:SetBackdropColor(0.015, 0.045, 0.075, 0.82)

                        local route = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                        route:SetPoint("LEFT", 10, 5)
                        route:SetWidth(280)
                        route:SetJustifyH("LEFT")
                        route:SetTextColor(unpack(MUTED))

                        local rate = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                        rate:SetPoint("LEFT", 300, 5)
                        rate:SetWidth(110)
                        rate:SetJustifyH("LEFT")
                        rate:SetTextColor(unpack(GREEN))

                        local items = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                        items:SetPoint("LEFT", 420, 5)
                        items:SetWidth(130)
                        items:SetJustifyH("LEFT")
                        items:SetTextColor(unpack(CYAN))

                        local sessions = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                        sessions:SetPoint("LEFT", 555, 13)
                        sessions:SetWidth(110)
                        sessions:SetJustifyH("LEFT")
                        sessions:SetTextColor(unpack(MUTED))

                        local evidence = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                        evidence:SetPoint("LEFT", 555, -8)
                        evidence:SetWidth(110)
                        evidence:SetJustifyH("LEFT")
                        evidence:SetTextColor(unpack(CYAN))

                        row.route, row.rate, row.items, row.sessions, row.evidence = route, rate, items, sessions, evidence
                        routeCompareFrame.rows[i] = row
                    end
                end

                local tracker = GoldMint.FarmTracker
                local rows = tracker and tracker.GetRoutePerformances and tracker:GetRoutePerformances(itemID) or {}
                routeCompareFrame.title:SetText("ROUTE PERFORMANCE: " .. tostring(itemName or "Material"))
                routeCompareFrame.subtitle:SetText("Measured from GoldMint farming sessions. No external or invented GPH estimates are used.")

                local currentKey = tracker and (tracker.routeKey or (tracker.session and tracker.session.routeKey)) or nil
                for i, row in ipairs(routeCompareFrame.rows) do
                    local data = rows[i]
                    if data then
                        local label = tostring(data.zone or "Unknown zone") .. " • " .. tostring(data.area or "Recorded route")
                        if currentKey and tostring(data.routeKey or "") == tostring(currentKey) then
                            label = "CURRENT • " .. label
                            row.route:SetTextColor(unpack(GREEN))
                        else
                            row.route:SetTextColor(unpack(MUTED))
                        end
                        row.route:SetText(label)
                        row.rate:SetText(FormatGold(data.valuePerHour) .. "/hr")
                        row.items:SetText(string.format("%.1f /hr", data.itemsPerHour or 0))
                        local viz = tracker and tracker.GetRouteVisualization and tracker:GetRouteVisualization(selectedItem, data.routeKey) or nil
                        local coverage = viz and viz.metrics and tonumber(viz.metrics.coverage) or 0
                        local loopTag = viz and viz.metrics and viz.metrics.loop and " • LOOP" or ""
                        row.sessions:SetText(string.format("%d session%s • %d%% path%s", data.sessions or 0, (data.sessions or 0) == 1 and "" or "s", math.floor(coverage + 0.5), loopTag))

                        local confidence = tonumber(data.recommendationConfidence) or tonumber(data.averageConfidence) or 0
                        local geomSessions = tonumber(data.geometrySessions) or 0
                        local consistency = tonumber(data.geometryConsistency) or 0
                        local loops = tonumber(data.loopRate) or 0
                        local pending = data.pendingBaselineRevision
                        local pendingTag = type(pending) == "table" and " • BASELINE VALIDATING" or ""
                        local diagnostics = data.baselineRevisionDiagnostics
                        if type(diagnostics) == "table" and diagnostics.status == "REJECTED" then pendingTag = " • BASELINE REJECTED" end
                        if geomSessions >= 2 then
                            row.evidence:SetText(string.format("%.0f%% conf • %.0f%% geo • %.0f%% loop%s", confidence, consistency, loops, pendingTag))
                        else
                            row.evidence:SetText(string.format("%.0f%% conf • geometry limited%s", confidence, pendingTag))
                        end
                        row:Show()
                    else
                        row.evidence:SetText("")
                        row:Hide()
                    end
                end

                if #rows == 0 then
                    routeCompareFrame.subtitle:SetText("No completed route sessions yet. Finish a farming session to build measured route data.")
                end
                routeCompareFrame:Show()
            end

            farmCompareButton:SetScript("OnClick", function()
                ShowRouteComparison(selectedItem, ItemInfo(selectedItem))
            end)

            farmButton:SetScript("OnClick", function()
                local route = selectedGatherRoute
                if not route then return end
                local tracker = GoldMint.FarmTracker
                local path, pathMap = tracker and tracker.GetRoutePath and tracker:GetRoutePath(selectedItem, route.routeID) or {}, nil
                local mapID = tonumber(pathMap) or tonumber(route.mapID)
                local pointData = path and path[#path] or nil
                local px = pointData and pointData.x or ((tonumber(route.x) or 0) / 100)
                local py = pointData and pointData.y or ((tonumber(route.y) or 0) / 100)
                if not mapID or not px or not py or px <= 0 or py <= 0 then return end
                if C_Map and C_Map.SetUserWaypoint and UiMapPoint and C_SuperTrack then
                    local ok, point = pcall(UiMapPoint.CreateFromCoordinates, mapID, px, py)
                    if ok and point then
                        pcall(C_Map.SetUserWaypoint, point)
                        if C_SuperTrack.SetSuperTrackedUserWaypoint then pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true) end
                    end
                end
            end)
            local function SelectItem(itemID)
                selectedItem=tonumber(itemID)
                RefreshSelected()
            end

            RefreshSelected = function()
                if not selectedItem then return end
                local name=ItemInfo(selectedItem)
                local label = detail._selectedNameLabel
                if label then label:SetText(name) end
                -- Keep the Market page itself lightweight. The full Smart Valuation
                -- graph walks the entire known recipe network recursively and can be
                -- extremely expensive on large databases. It must never run merely
                -- because the Market tab was opened or an item was selected. The
                -- detail surface uses the already-cached/raw market values here.
                local smart = nil
                local data=GoldMint.Market and GoldMint.Market.GetMultiverseData and GoldMint.Market:GetMultiverseData(selectedItem) or {}
                local current = tonumber(data.marketValue) or 0
                local region = tonumber(data.regionMarketAvg) or 0
                currentMarketValue:SetText(UnitGold(current))
                marketPosition:SetText("Region Avg: " .. UnitGold(region))
                local positionChange = (region > 0 and current > 0) and ((current-region)/region) or nil
                if positionChange then
                    local pct = math.abs(positionChange)*100
                    local direction = positionChange < 0 and "BELOW" or (positionChange > 0 and "ABOVE" or "AT")
                    marketPositionSub:SetText(string.format("%.1f%% %s REGION",pct,direction))
                    marketPositionSub:SetTextColor(unpack(positionChange < 0 and GREEN or (positionChange > 0 and GOLD or MUTED)))
                else
                    marketPositionSub:SetText("Regional comparison unavailable")
                    marketPositionSub:SetTextColor(unpack(MUTED))
                end
                rawValue:SetText(UnitGold(current))
                processedValue:SetText("—")
                shatterValue:SetText(UnitGold(data.destroyValue))

                local demandText,demandColor = GetDemandInfo(data.regionSoldPerDay)
                local trendText,trendColor,trendChange = GetTrendInfo(selectedItem)
                signalDemand:SetText("DEMAND: " .. demandText)
                signalDemand:SetTextColor(unpack(demandColor))
                if positionChange then
                    signalPosition:SetText(string.format("POSITION: %+.1f%%",positionChange*100))
                    signalPosition:SetTextColor(unpack(positionChange < 0 and GREEN or GOLD))
                else
                    signalPosition:SetText("POSITION: —")
                    signalPosition:SetTextColor(unpack(MUTED))
                end
                local bestValue = math.max(current, tonumber(data.destroyValue) or 0)
                local opportunity = current > 0 and ((bestValue-current)/current) or 0
                if opportunity > 0.001 then
                    signalOpportunity:SetText(string.format("OPPORTUNITY: +%.1f%%",opportunity*100))
                    signalOpportunity:SetTextColor(unpack(GREEN))
                else
                    signalOpportunity:SetText("OPPORTUNITY: RAW")
                    signalOpportunity:SetTextColor(unpack(MUTED))
                end
                signalTrend:SetText("TREND:")
                signalTrend:SetTextColor(unpack(trendColor))
                signalTrendIcon:Hide()
                signalTrendIcon:SetVertexColor(unpack(trendColor))
                if trendText == "↗" then
                    signalTrendIcon:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up")
                    signalTrendIcon:Show()
                elseif trendText == "↘" then
                    signalTrendIcon:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
                    signalTrendIcon:Show()
                end

                local gatheringRoutes = GoldMint.Market and GoldMint.Market.GetGatheringRoutes and GoldMint.Market:GetGatheringRoutes(selectedItem) or {}
                selectedGatherRoute = gatheringRoutes[1] or (GoldMint.Market and GoldMint.Market.GetGatheringRoute and GoldMint.Market:GetGatheringRoute(selectedItem) or nil)
                if GoldMint.FarmTracker and GoldMint.FarmTracker.GetRecommendedRoute and #gatheringRoutes > 0 then
                    local recommendedRoute, recommendationSource = GoldMint.FarmTracker:GetRecommendedRoute(selectedItem, gatheringRoutes)
                    if recommendedRoute then
                        selectedGatherRoute = recommendedRoute
                        selectedGatherRoute.recommendationSource = recommendationSource
                    end
                end
                if selectedGatherRoute and GoldMint.FarmTracker and GoldMint.FarmTracker.SetRoute then
                    local trackerRoute = {}
                    for k, v in pairs(selectedGatherRoute) do trackerRoute[k] = v end
                    trackerRoute.itemID = selectedItem
                    trackerRoute.itemName = name
                    trackerRoute.routeID = trackerRoute.routeID or ((trackerRoute.zone or "") .. "|" .. (trackerRoute.start or "") .. "|" .. tostring(trackerRoute.mapID or ""))
                    GoldMint.FarmTracker:SetRoute(trackerRoute)
                end
                if selectedGatherRoute then
                    local bestType = tostring(smart and smart.best or "RAW")
                    local bestValue = tonumber(smart and smart.bestValue) or 0
                    -- Distinguish the static market/gathering suggestion from GoldMint's
                    -- evidence-backed route recommendation.
                    if intelligence and intelligence.recommendationReady and intelligence.recommended then
                        local recRate = tonumber(intelligence.recommended.valuePerHour) or 0
                        farmTitle:SetText("BEST ROUTE: GOLDMINT • " .. FormatGold(recRate) .. "/hr")
                        farmTitle:SetTextColor(unpack(CYAN))
                    else
                        farmTitle:SetText("MARKET ROUTE: " .. bestType .. " • " .. FormatGold(bestValue))
                        farmTitle:SetTextColor(unpack(CYAN))
                    end

                    -- Compact second line: zone + recommended farming area.
                    local zone = tostring(selectedGatherRoute.zone or "—")
                    local area = tostring(selectedGatherRoute.start or "Recommended route")
                    local source = tostring(selectedGatherRoute.recommendationSource or "")
                    local suffix = source == "MEASURED" and " • MEASURED" or (source == "FALLBACK" and " • FALLBACK" or "")
                    farmItem:SetText("FARM: " .. zone .. " • " .. area .. suffix)

                    -- Keep the reference card to two information lines below the
                    -- header. Prefer the route's human-readable instructions, while
                    -- still mentioning the actual targets when no notes are available.
                    local notes = tostring(selectedGatherRoute.notes or "")
                    local targets = tostring(selectedGatherRoute.targets or selectedGatherRoute.profession or "")
                    local tracker = GoldMint.FarmTracker
                    local performance = tracker and tracker.GetRoutePerformance and tracker:GetRoutePerformance() or nil
                    local intelligence = tracker and tracker.GetRouteIntelligence and tracker:GetRouteIntelligence(selectedItem) or nil
                    local trend = tracker and tracker.GetRouteTrend and tracker:GetRouteTrend(selectedItem) or nil
                    if intelligence and intelligence.recommendationReady and intelligence.recommended then
                        local rec = intelligence.recommended
                        local recRate = tonumber(rec.valuePerHour) or 0
                        local recSessions = tonumber(rec.qualitySessions) or tonumber(rec.sessions) or 0
                        local recConfidence = tonumber(rec.averageConfidence) or 0
                        local geom = tonumber(rec.geometryConsistency) or 0
                        local loops = tonumber(rec.loopRate) or 0
                        local geomSessions = tonumber(rec.geometrySessions) or 0
                        farmTargets:SetText(string.format("GOLDMINT DATA: %s/hr  •  %d quality sessions  •  %.0f%% confidence", FormatGold(recRate), recSessions, recConfidence))
                        farmTargets:SetTextColor(unpack(GREEN))
                        if rec.recommendationConfidence then
                            local confidenceText = string.format("RECOMMENDATION CONFIDENCE: %.0f%%", tonumber(rec.recommendationConfidence) or 0)
                            if geomSessions >= 2 then
                                confidenceText = confidenceText .. string.format("  •  ROUTE CONSISTENCY: %.0f%%  •  LOOPS: %.0f%%", geom, loops)
                            else
                                confidenceText = confidenceText .. "  •  LIMITED ROUTE GEOMETRY"
                            end
                            farmNotes:SetText(confidenceText)
                            farmNotes:SetTextColor(unpack(CYAN))
                        end
                    elseif performance and performance.sessions > 0 then
                        farmTargets:SetText(string.format("YOUR DATA: %s/hr  •  %.1f %s/hr  •  %d sessions", FormatGold(performance.valuePerHour), performance.itemsPerHour, tostring(name or "items"), performance.sessions))
                        farmTargets:SetTextColor(unpack(GREEN))
                    else
                        farmTargets:SetText("YOUR DATA: No completed farming sessions yet.")
                        farmTargets:SetTextColor(unpack(MUTED))
                    end
                    if intelligence and intelligence.recommendationReady and intelligence.recommended then
                        local rec = intelligence.recommended
                        local routeLabel = tostring(rec.zone or rec.area or rec.routeKey or "measured route")
                        local recSessions = tonumber(rec.qualitySessions) or tonumber(rec.sessions) or 0
                        local recConfidence = tonumber(rec.recommendationConfidence) or 0
                        local reasons = rec.recommendationReasons or {}
                        local reasonText = ""
                        if type(reasons) == "table" and #reasons > 0 then
                            reasonText = "  •  " .. table.concat(reasons, ", ")
                        end
                        local geom = tonumber(rec.geometryConsistency) or 0
                        local loops = tonumber(rec.loopRate) or 0
                        local geomSessions = tonumber(rec.geometrySessions) or 0
                        local geometryText = geomSessions >= 2 and string.format("  •  geometry %.0f%%  •  loops %.0f%%", geom, loops) or "  •  geometry history limited"
                        local timeline = intelligence and intelligence.routeStateTimeline or nil
                        local pending = intelligence and intelligence.pendingBaselineRevision or (rec and rec.pendingBaselineRevision) or nil
                        local baselineText = ""
                        if type(pending) == "table" then
                            local streak = tonumber(pending.validationStreak) or tonumber(pending.streak) or 0
                            local required = tonumber(pending.validationRequired) or 3
                            if streak > 0 then
                                baselineText = string.format("  •  baseline validation %d/%d", streak, required)
                            else
                                baselineText = "  •  new baseline candidate validating"
                            end
                        elseif tonumber(rec and rec.baselineRevision) and tonumber(rec.baselineRevision) > 0 then
                            baselineText = string.format("  •  baseline revision %d established", tonumber(rec.baselineRevision))
                        end
                        local baselineAgeState = tostring(intelligence and intelligence.baselineAgeState or (rec and rec.baselineAgeState) or "NONE")
                        local baselineAgeDays = tonumber(intelligence and intelligence.baselineAgeDays or (rec and rec.baselineAgeDays) or 0) or 0
                        if baselineAgeState == "AGING" then
                            baselineText = baselineText .. string.format("  •  baseline aging (%.1fd)", baselineAgeDays)
                        elseif baselineAgeState == "STALE" then
                            baselineText = baselineText .. string.format("  •  baseline stale (%.1fd)", baselineAgeDays)
                        elseif baselineAgeState == "REVALIDATE" then
                            baselineText = baselineText .. string.format("  •  baseline revalidation needed (%.1fd)", baselineAgeDays)
                        end
                        local diagnostics = intelligence and intelligence.baselineRevisionDiagnostics or (rec and rec.baselineRevisionDiagnostics) or nil
                        if type(diagnostics) == "table" and diagnostics.status == "REJECTED" then
                            local failed = type(diagnostics.failedSignals) == "table" and #diagnostics.failedSignals > 0 and table.concat(diagnostics.failedSignals, ", ") or "stability"
                            baselineText = "  •  baseline candidate rejected: " .. failed
                        end
                        local timelineText = ""
                        if type(timeline) == "table" and #timeline >= 2 then
                            local changes = 0
                            for i = 2, #timeline do
                                if tostring(timeline[i].state) ~= tostring(timeline[i - 1].state) then changes = changes + 1 end
                            end
                            if changes > 0 then
                                timelineText = string.format("  •  %d recent state transition%s", changes, changes == 1 and "" or "s")
                            end
                        end
                        -- Keep the live HUD line intentionally short.  The detailed
                        -- evidence remains available on hover so the dashboard does not
                        -- become a wall of diagnostic text at narrow UI scales.
                        local compactState = recConfidence >= 70 and "HIGH" or (recConfidence >= 40 and "BUILDING" or "LIMITED")
                        farmNotes:SetText(string.format("GOLDMINT RECOMMENDATION: %s  •  %d quality sessions  •  %.0f%% confidence  •  %s", routeLabel, recSessions, recConfidence, compactState))
                        farmNotes:SetTextColor(recConfidence >= 70 and unpack(GREEN) or unpack(CYAN))
                        farmNotes:EnableMouse(true)
                        farmNotes:SetScript("OnEnter", function(self)
                            GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
                            GameTooltip:SetText("GoldMint Route Recommendation", 1.0, 0.82, 0.25)
                            GameTooltip:AddLine(string.format("%s • %d quality sessions • %.0f%% recommendation confidence", routeLabel, recSessions, recConfidence), 0.85, 0.92, 1.0, true)
                            if geometryText ~= "" then GameTooltip:AddLine(string.gsub(geometryText, "^  •  ", ""), 0.55, 0.78, 0.92, true) end
                            if reasonText ~= "" then GameTooltip:AddLine("Factors: " .. string.gsub(reasonText, "^  •  ", ""), 0.55, 0.78, 0.92, true) end
                            if baselineText ~= "" then GameTooltip:AddLine("Baseline: " .. string.gsub(baselineText, "^  •  ", ""), 0.55, 0.78, 0.92, true) end
                            if timelineText ~= "" then GameTooltip:AddLine("State: " .. string.gsub(timelineText, "^  •  ", ""), 0.55, 0.78, 0.92, true) end
                            GameTooltip:Show()
                        end)
                        farmNotes:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    elseif trend and trend.status == "RISING" then
                        farmNotes:SetText(string.format("FARMING INTELLIGENCE: TREND RISING  •  recent runs +%.1f%% vs earlier data", trend.changePct or 0))
                        farmNotes:SetTextColor(unpack(GREEN))
                    elseif trend and trend.status == "FALLING" then
                        farmNotes:SetText(string.format("FARMING INTELLIGENCE: TREND FALLING  •  recent runs %.1f%% vs earlier data", trend.changePct or 0))
                        farmNotes:SetTextColor(unpack(MUTED))
                    elseif trend and trend.status == "STABLE" then
                        farmNotes:SetText(string.format("FARMING INTELLIGENCE: STABLE  •  recent runs %.1f%% vs earlier data", trend.changePct or 0))
                        farmNotes:SetTextColor(unpack(CYAN))
                    elseif intelligence and intelligence.status == "ESTABLISHED" then
                        farmNotes:SetText(string.format("FARMING INTELLIGENCE: ESTABLISHED  •  %d sessions  •  %.1f hours measured", intelligence.sessions, (intelligence.seconds or 0) / 3600))
                        farmNotes:SetTextColor(unpack(GREEN))
                    elseif intelligence and intelligence.status == "VERIFIED" then
                        farmNotes:SetText(string.format("FARMING INTELLIGENCE: VERIFIED  •  %d sessions  •  %.1f minutes measured", intelligence.sessions, (intelligence.seconds or 0) / 60))
                        farmNotes:SetTextColor(unpack(CYAN))
                    elseif intelligence and intelligence.sessions > 0 then
                        farmNotes:SetText(string.format("FARMING INTELLIGENCE: BUILDING DATA  •  %d session%s recorded", intelligence.sessions, intelligence.sessions == 1 and "" or "s"))
                        farmNotes:SetTextColor(unpack(MUTED))
                    elseif notes ~= "" then
                        farmNotes:SetText(notes)
                        farmNotes:SetTextColor(unpack(MUTED))
                    elseif targets ~= "" then
                        farmNotes:SetText("Farm " .. targets .. ".")
                        farmNotes:SetTextColor(unpack(MUTED))
                    else
                        farmNotes:SetText("Follow the recommended route and prioritize the listed material sources.")
                        farmNotes:SetTextColor(unpack(MUTED))
                    end

                    farmZone:Hide()
                    farmArea:Hide()
                    farmTargets:Show()
                    farmNotes:Show()
                    if selectedGatherRoute.mapID and selectedGatherRoute.x and selectedGatherRoute.y then
                        farmButton:Show()
                    else
                        farmButton:Hide()
                    end
                    farmCompareButton:Show()
                else
                    farmTitle:SetText("BEST ROUTE: —")
                    farmItem:SetText("FARM: No verified route available for " .. tostring(name or "this material"))
                    farmTargets:SetText("YOUR DATA: No verified route performance yet.")
                    farmTargets:SetTextColor(unpack(MUTED))
                    farmNotes:SetText("GoldMint will show a route here when verified farming data is available.")
                    farmZone:Hide()
                    farmArea:Hide()
                    farmTargets:Show()
                    farmNotes:Show()
                    farmButton:Hide()
                    farmCompareButton:Hide()
                    HideRouteComparison()
                    if GoldMint.FarmTracker and GoldMint.FarmTracker.SetRoute then
                        GoldMint.FarmTracker:SetRoute(nil)
                    end
                end

                regionAvg:SetText("Region Avg: "..UnitGold(data.regionMarketAvg))
                regionHistorical:SetText("Historical: "..UnitGold(data.regionHistorical))
                regionSale:SetText("Sale Avg: "..UnitGold(data.regionSaleAvg))
                regionVol:SetText("Sold / Day: "..(data.regionSoldPerDay and string.format("%.1f",data.regionSoldPerDay) or "—"))
                DrawHistory(selectedItem)
            end

            function RefreshRows()
                wipe(trendCache)
                for _,row in ipairs(rowWidgets) do row:Hide() end; wipe(rowWidgets)
                -- Pull the correct source pool for the active view. MATERIALS, HIGH DEMAND,
                -- and OPPORTUNITIES use the current-character gathering pool;
                -- ALL TRACKED uses the profession-independent tracked-material pool.
                local sourceMode = (activeMode == "all") and "all" or "materials"
                local rowsData=GoldMint.Market and GoldMint.Market.GetTrackedItems and GoldMint.Market:GetTrackedItems(100,search:GetText(),sourceMode) or {}

                if activeMode == "materials" or activeMode == "all" or activeMode == "highdemand" or activeMode == "opportunity" then
                    local filtered={}
                    for _,d in ipairs(rowsData) do
                        local record = GoldMint.Market and GoldMint.Market.GetRecord and GoldMint.Market:GetRecord(d.itemID) or nil
                        local isMaterial = GoldMint.Market and GoldMint.Market.IsMaterial and GoldMint.Market:IsMaterial(d.itemID)
                        local isGathering = GoldMint.Market and GoldMint.Market.IsGatheringMaterialForCurrentCharacter and GoldMint.Market:IsGatheringMaterialForCurrentCharacter(d.itemID, record)

                        -- MATERIALS is the current character's profession-specific pool; All Tailoring-produced cloth materials (including every Bolt of ... item and Mooncloth) are included for Tailors; raw legacy cloth belongs in ALL TRACKED.
                        -- ALL TRACKED is profession-independent: Dragonflight-and-older cloth
                        -- plus valid market materials that do not require a gathering profession.
                        -- HIGH DEMAND / OPPORTUNITIES use the current-character gatherable pool.
                        local isAllTracked = GoldMint.Market and GoldMint.Market.IsAllTrackedMaterial and GoldMint.Market:IsAllTrackedMaterial(d.itemID, record)
                        if activeMode == "materials" and isGathering then
                            filtered[#filtered+1]=d
                        elseif activeMode == "all" and isAllTracked then
                            filtered[#filtered+1]=d
                        elseif activeMode == "highdemand" and isGathering then
                            -- HIGH DEMAND must contain only materials whose demand tier
                            -- is actually HIGH or VERY HIGH. Do not let LOW/MEDIUM
                            -- materials into this view merely because they have sales.
                            local soldPerDay = tonumber(d.regionSoldPerDay) or 0
                            if soldPerDay >= 1000 then
                                filtered[#filtered+1]=d
                            end
                        elseif activeMode == "opportunity" and isGathering then
                            -- Opportunity mode must also remain frame-safe. Do not
                            -- recursively value every candidate while building the
                            -- list; that can walk a very large recipe graph. Use the
                            -- already-recorded destroy/shatter value as the cheap
                            -- opportunity signal. Full Smart Valuation remains an
                            -- explicit backend calculation, never an implicit page
                            -- refresh operation.
                            local raw=tonumber(d.marketValue) or 0
                            local record=GoldMint.Market and GoldMint.Market.GetRecord and GoldMint.Market:GetRecord(d.itemID) or nil
                            local best=math.max(raw, tonumber(record and record.region and record.region.destroyValue) or 0)
                            if raw > 0 and best > raw * 1.001 then filtered[#filtered+1]=d end
                        end
                    end
                    rowsData=filtered

                    -- High Demand contains only HIGH / VERY HIGH demand materials,
                    -- then ranks those materials by regional sales per day.
                    if activeMode == "highdemand" then
                        table.sort(rowsData, function(a,b)
                            local av = tonumber(a.regionSoldPerDay) or 0
                            local bv = tonumber(b.regionSoldPerDay) or 0
                            if av == bv then
                                return string.lower(tostring(ItemInfo(a.itemID) or "")) < string.lower(tostring(ItemInfo(b.itemID) or ""))
                            end
                            return av > bv
                        end)
                    end
                end

                if sortKey then
                    local function sortValue(d)
                        if sortKey == "name" then return string.lower(tostring(ItemInfo(d.itemID) or ""))
                        elseif sortKey == "market" then return tonumber(d.marketValue) or 0
                        elseif sortKey == "region" then return tonumber(d.regionMarketAvg) or 0
                        elseif sortKey == "sold" then return tonumber(d.regionSoldPerDay) or 0
                        elseif sortKey == "demand" then return tonumber(d.regionSoldPerDay) or 0
                        elseif sortKey == "trend" then local _,_,v=GetTrendInfo(d.itemID); return tonumber(v) or 0 end
                        return 0
                    end
                    table.sort(rowsData,function(a,b)
                        local av,bv=sortValue(a),sortValue(b)
                        if av==bv then return tostring(a.itemID or "") < tostring(b.itemID or "") end
                        if sortDesc then return av>bv else return av<bv end
                    end)
                end

                statsTracked:SetText(#rowsData .. " TRACKED")
                local marketTotal, profitTotal, significantChanges = 0, 0, 0
                for _,d in ipairs(rowsData) do
                    local raw = tonumber(d.marketValue) or 0
                    marketTotal = marketTotal + raw

                    -- Never run the recursive Smart Valuation graph for every
                    -- visible row just to populate the summary counters. That
                    -- turned a simple Market refresh into dozens of recursive
                    -- recipe walks. Smart Valuation is still calculated for
                    -- the selected material/detail view and for the explicit
                    -- OPPORTUNITIES filter.
                    local record = GoldMint.Market and GoldMint.Market.GetRecord and GoldMint.Market:GetRecord(d.itemID) or nil
                    local destroy = record and record.region and tonumber(record.region.destroyValue) or 0
                    if destroy > raw then profitTotal = profitTotal + (destroy - raw) end

                    local _, _, trendValue = GetTrendInfo(d.itemID)
                    if math.abs(tonumber(trendValue) or 0) >= 0.05 then significantChanges = significantChanges + 1 end
                end
                statsMarket:SetText("MARKET: " .. (marketTotal > 0 and ShortGold(marketTotal) or "—"))
                statsProfit:SetText("PROFIT: " .. (profitTotal > 0 and ShortGold(profitTotal) or "—"))
                statsChanges:SetText(significantChanges .. " PRICE CHANGES")

                local rowHeight=38
                local child=scroll._goldMintContent
                if child then child:SetHeight(math.max(1,#rowsData*rowHeight)) end
                for i,d in ipairs(rowsData) do
                    local row=CreateFrame("Button",nil,child or scroll)
                    row:SetSize(565,rowHeight-4); row:SetPoint("TOPLEFT",0,-((i-1)*rowHeight))
                    row:SetHighlightTexture("Interface\\Buttons\\WHITE8X8"); row:GetHighlightTexture():SetVertexColor(0.08,0.25,0.38,0.25)
                    local icon=row:CreateTexture(nil,"ARTWORK"); icon:SetSize(22,22); icon:SetPoint("LEFT",4,0)
                    local name,_,tex=ItemInfo(d.itemID); icon:SetTexture(tex or 134400)
                    local label=ML(row,name,32,-5,150,MUTED,"GameFontNormalSmall"); label:SetMaxLines(1)
                    ML(row,UnitGold(d.marketValue),190,-5,82,GOLD,"GameFontNormalSmall","RIGHT")
                    ML(row,UnitGold(d.regionMarketAvg),278,-5,82,MUTED,"GameFontNormalSmall","RIGHT")
                    ML(row,d.regionSoldPerDay and string.format("%.1f",d.regionSoldPerDay) or "—",366,-5,74,GREEN,"GameFontNormalSmall","RIGHT")
                    local demandText,demandColor=GetDemandInfo(d.regionSoldPerDay)
                    local demandShort = demandText == "VERY HIGH" and "V.HIGH" or demandText
                    local dl=ML(row,demandShort,444,-5,64,demandColor,"GameFontNormalSmall","RIGHT")
                    local trendText,trendColor=GetTrendInfo(d.itemID)
                    local tl=ML(row,trendText,512,-5,44,trendColor,"GameFontNormal","RIGHT")
                    row:SetScript("OnClick",function() SelectItem(d.itemID) end)
                    rowWidgets[#rowWidgets+1]=row
                end
                scroll:SetVerticalScroll(0)
                if scroll.UpdateGoldMintScrollBar then C_Timer.After(0,scroll.UpdateGoldMintScrollBar) end
                if Dashboard._marketFocusItemID then
                    local focusID = tonumber(Dashboard._marketFocusItemID)
                    Dashboard._marketFocusItemID = nil
                    if focusID then selectedItem = focusID end
                end
                if not selectedItem and rowsData[1] then selectedItem=rowsData[1].itemID end
                -- Expose the lightweight row refresh so the Market data-load event
                -- can repaint names/icons after Blizzard asynchronously resolves cold
                -- item data. This does not perform any scan or valuation work.
                page.RefreshMarketRows = RefreshRows

                if selectedItem then
                    GoldMint:ScheduleGuardedCallback(GoldMint, "market initial detail", 0.05, function()
                        if RefreshSelected then RefreshSelected() end
                    end)
                end
            end

            local function SetMode(mode)
                activeMode=mode
                if mode=="materials" then
                    modeMaterials:SetBackdropBorderColor(1.0,0.78,0.20,1); modeAll:SetBackdropBorderColor(unpack(CYAN)); modeHighDemand:SetBackdropBorderColor(unpack(CYAN)); modeOpportunity:SetBackdropBorderColor(unpack(CYAN))
                    modeLabel:SetText("Materials your current character can personally gather with their gathering professions.")
                elseif mode=="highdemand" then
                    modeMaterials:SetBackdropBorderColor(unpack(CYAN)); modeAll:SetBackdropBorderColor(unpack(CYAN)); modeHighDemand:SetBackdropBorderColor(1.0,0.78,0.20,1); modeOpportunity:SetBackdropBorderColor(unpack(CYAN))
                    modeLabel:SetText("Highest-demand materials your current gathering professions can collect, ranked by regional sales per day.")
                elseif mode=="opportunity" then
                    modeMaterials:SetBackdropBorderColor(unpack(CYAN)); modeAll:SetBackdropBorderColor(unpack(CYAN)); modeHighDemand:SetBackdropBorderColor(unpack(CYAN)); modeOpportunity:SetBackdropBorderColor(1.0,0.78,0.20,1)
                    modeLabel:SetText("Materials where current processing or shatter value exceeds the raw market value.")
                else
                    modeMaterials:SetBackdropBorderColor(unpack(CYAN)); modeAll:SetBackdropBorderColor(1.0,0.78,0.20,1); modeHighDemand:SetBackdropBorderColor(unpack(CYAN)); modeOpportunity:SetBackdropBorderColor(unpack(CYAN))
                    modeLabel:SetText("Cloth from Dragonflight through Classic plus other useful market materials that do not require a gathering profession.")
                end
                RefreshRows()
            end
            modeMaterials:SetScript("OnClick",function() SetMode("materials") end)
            modeAll:SetScript("OnClick",function() SetMode("all") end)
            modeHighDemand:SetScript("OnClick",function() SetMode("highdemand") end)
            modeOpportunity:SetScript("OnClick",function() SetMode("opportunity") end)
            sync:SetScript("OnClick",function()
                if not GoldMint.Market then return end
                if GoldMint.Market:IsFullMarketScanRunning() then
                    GoldMint.Market:CancelFullMarketScan(); sync:SetText("SCAN MARKET"); scanStatus:SetText("Live market scan cancelled."); scanStatus:SetTextColor(unpack(MUTED)); RefreshRows(); return
                end
                local started, reason = GoldMint.Market:StartFullMarketScan(activeMode == "all" and "all" or "materials", function(done,total,captured)
                    sync:SetText("CANCEL SCAN")
                    local pct=total>0 and math.floor((done/total)*100) or 100
                    scanStatus:SetText(string.format("Scanning live market data • %d / %d (%d%%) • %d updated",done,total,pct,captured)); scanStatus:SetTextColor(unpack(CYAN))
                end,function(captured,total,duration,cancelled)
                    sync:SetText("SCAN MARKET")
                    if cancelled then scanStatus:SetText(string.format("Live scan cancelled • %d / %d items processed",captured,total)); scanStatus:SetTextColor(unpack(MUTED))
                    else scanStatus:SetText(string.format("Live scan complete • %d / %d items updated in %ds",captured,total,duration)); scanStatus:SetTextColor(unpack(GREEN)) end
                    RefreshRows()
                    if GoldMint.Print then
                        if cancelled then GoldMint.Print(string.format("Live market scan cancelled after %d of %d items.",captured,total))
                        else GoldMint.Print(string.format("Live market database scan complete: %d of %d items updated.",captured,total)) end
                    end
                end,true)
                if not started then
                    if reason=="tsm-unavailable" then scanStatus:SetText("TSM market data is unavailable. Install/enable TSM to scan live prices.")
                    elseif reason=="already-running" then scanStatus:SetText("A live market scan is already running.")
                    else scanStatus:SetText("Unable to start the live market scan.") end
                    scanStatus:SetTextColor(unpack(RED)); return
                end
                if reason=="empty" then sync:SetText("SCAN MARKET"); scanStatus:SetText("No known market materials to scan. Scan professions or discover materials first."); scanStatus:SetTextColor(unpack(MUTED)) end
            end)
            search:SetScript("OnEnterPressed",function(edit) RefreshRows(); edit:ClearFocus() end)
            clear:SetScript("OnClick",function() search:SetText(""); RefreshRows() end)

            RefreshRows()
        end
        local function wealth()
            -- Wealth is intentionally self-contained. Build its frame tree only
            -- once. Rebuilding it on every visit would stack duplicate
            -- FontStrings/textures and cause the gold values to visually overlap.
            for _, b in pairs(tabButtons) do b:Hide() end
            title:SetText("")
            sub:SetText("")
            content:ClearAllPoints()
            content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, 0)
            content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)

            if not panels.wealthPage then
                panels.wealthPage = CreateFrame("Frame", nil, content)
            end
            local page = panels.wealthPage
            page:SetParent(content)
            page:ClearAllPoints()
            page:SetAllPoints(content)
            page:Show()
            if page._wealthBuilt then
                return
            end
            wipe(wealthLiveLabels)

            local function WL(parent, text, x, y, w, color, font, justify)
                local l = MakeLabel(parent, font or "GameFontNormalSmall", text, w)
                l:SetPoint("TOPLEFT", x, y)
                l:SetTextColor(unpack(color or MUTED))
                l:SetWordWrap(false)
                if justify then l:SetJustifyH(justify) end
                return l
            end

            -- Wealth-only panel skin.  The texture is a small TGA tile so the
            -- page gets the mockup's richer panel treatment without baking any
            -- text, values, or screenshots into the artwork.
            local function WealthPanel(parent, width, height, point, x, y)
                local p = CreateFrame("Frame", nil, parent, "BackdropTemplate")
                p:SetSize(width, height)
                p:SetPoint(point, parent, point, x or 0, y or 0)
                p:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                    tile = true, tileSize = 16, edgeSize = 12,
                    insets = {left=5,right=5,top=5,bottom=5},
                })
                p:SetBackdropColor(0.006,0.018,0.032,0.985)
                p:SetBackdropBorderColor(0.10,0.34,0.52,0.90)
                return p
            end

            local function MakeLine(parent, x1, y1, x2, y2, color, thickness)
                local line = parent:CreateTexture(nil, "ARTWORK")
                line:SetColorTexture(color[1], color[2], color[3], color[4] or 1)
                local dx, dy = x2-x1, y2-y1
                local len = math.sqrt(dx*dx + dy*dy)
                line:SetSize(math.max(1,len), thickness or 1)
                line:SetPoint("CENTER", parent, "TOPLEFT", (x1+x2)*0.5, -((y1+y2)*0.5))
                line:SetRotation(math.atan2(-dy,dx))
                return line
            end

            local pw = math.floor(page:GetWidth() or 0)
            if pw < 900 then pw = 1080 end
            local gap = 12
            local rightW = 340
            local leftW = pw - rightW - gap
            if leftW < 650 then
                rightW = math.max(280, math.floor(pw * 0.30))
                leftW = pw - rightW - gap
            end
            local topH = 390
            local txY = -(topH + gap)
            local txH = 250

            local overview = WealthPanel(page, leftW, topH, "TOPLEFT", 0, 0)
            local breakdown = WealthPanel(page, rightW, topH, "TOPRIGHT", 0, 0)
            local transactions = WealthPanel(page, pw, txH, "TOPLEFT", 0, txY)

            WL(overview, "WEALTH OVERVIEW", 16, -14, 300, CYAN, "GameFontNormalLarge")
            Accent(overview, "TOPLEFT", 16, -32, 38, CYAN)
            WL(breakdown, "WEALTH BREAKDOWN", 16, -14, 300, CYAN, "GameFontNormalLarge")
            Accent(breakdown, "TOPLEFT", 16, -32, 38, CYAN)
            WL(transactions, "RECENT TRANSACTIONS", 16, -14, 360, CYAN, "GameFontNormalLarge")
            Accent(transactions, "TOPLEFT", 16, -32, 38, CYAN)

            -- Summary cards: keep these visually clean and close to the mockup.
            -- They are intentionally simple WoW UI frames rather than artwork-heavy
            -- panels, so the live values remain the focus and never get clipped.
            local innerW = leftW - 24
            local cardGap = 12
            local cardW = math.floor((innerW - cardGap*3) / 4)
            local cardH = 92
            local cardTitles = {"TOTAL GOLD","AUCTION HOUSE VALUE","VENDOR VALUE","7 DAY TREND"}
            local cardAccent = {GOLD, CYAN, GOLD, GREEN}
            local cardIcons = {
                "Interface\\AddOns\\GoldMint\\Assets\\GoldMintGoldCoin",
                "Interface\\AddOns\\GoldMint\\Assets\\GoldMintAuctionHouse",
                "Interface\\AddOns\\GoldMint\\Assets\\GoldMintBag", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintProfitVelocity",
            }
            local overviewCards = {}
            for i, name in ipairs(cardTitles) do
                local x = 12 + (i-1)*(cardW+cardGap)
                local c = CreateFrame("Frame", nil, overview, "BackdropTemplate")
                c:SetSize(cardW, cardH)
                c:SetPoint("TOPLEFT", overview, "TOPLEFT", x, -43)
                c:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                    tile = true, tileSize = 16, edgeSize = 10,
                    insets = {left=3,right=3,top=3,bottom=3},
                })
                c:SetBackdropColor(0.008,0.020,0.032,0.96)
                c:SetBackdropBorderColor(0.08,0.30,0.46,0.95)

                local accent = c:CreateTexture(nil,"ARTWORK")
                accent:SetColorTexture(unpack(cardAccent[i]))
                accent:SetSize(cardW-18,1)
                accent:SetPoint("TOPLEFT", c, "TOPLEFT", 9, -7)
                accent:SetAlpha(0.70)

                local titleX = 8
                local titleW = cardW-16
                if cardIcons[i] then
                    local icon = c:CreateTexture(nil,"ARTWORK")
                    icon:SetTexture(cardIcons[i])
                    if i == 2 then
                        icon:SetSize(28,34)
                        icon:SetPoint("TOPLEFT", c, "TOPLEFT", 8, -10)
                    else
                        icon:SetSize(22,22)
                        icon:SetPoint("TOPLEFT", c, "TOPLEFT", 10, -13)
                    end
                    icon:SetTexCoord(0,1,0,1)
                    icon:SetAlpha(i == 4 and 0.70 or 0.95)
                    titleX = (i == 2) and 42 or 38
                    titleW = cardW - titleX - 8
                end
                local title = WL(c, name, titleX, -13, titleW, MUTED, "GameFontNormalSmall", "CENTER")
                title:SetWordWrap(false)

                local valueFont = (i == 1) and "GameFontNormal" or "GameFontHighlightLarge"
                local value = WL(c, "—", 8, -43, cardW-16, cardAccent[i], valueFont, "CENTER")
                value:SetWordWrap(false)
                if i == 1 then
                    value:SetFont("Fonts\\FRIZQT__.TTF", 13, "")
                    value:SetWidth(cardW-14)
                    value:SetJustifyH("CENTER")
                end
                overviewCards[i] = value

                local divider = c:CreateTexture(nil,"ARTWORK")
                divider:SetColorTexture(0.08,0.25,0.38,0.55)
                divider:SetSize(cardW-18,1)
                divider:SetPoint("BOTTOMLEFT", c, "BOTTOMLEFT", 9, 16)
            end
            wealthLiveLabels.netWorth = overviewCards[1]
            wealthLiveLabels.ahValue = overviewCards[2]
            wealthLiveLabels.vendorValue = overviewCards[3]
            wealthLiveLabels.trendValue = overviewCards[4]

            -- Trend chart.
            local trendPanel = WealthPanel(overview, innerW, 244, "TOPLEFT", 12, -134)
            WL(trendPanel, "TOTAL WEALTH TREND", 12, -10, 260, CYAN, "GameFontNormalLarge")
            Accent(trendPanel, "TOPLEFT", 12, -28, 38, CYAN)
            local rangeButtons = {}
            local ranges = {{"7D",7},{"14D",14},{"30D",30},{"90D",90}}
            local selectedRange = 7
            for i, range in ipairs(ranges) do
                local b = MakeButton(trendPanel, range[1], 58, 30, "secondary")
                b:SetPoint("TOPRIGHT", -10 - (4-i)*66, -8)
                b:SetScript("OnClick", function()
                    selectedRange = range[2]
                    for _, rb in ipairs(rangeButtons) do rb._selected = false end
                    b._selected = true
                    if page.RefreshWealth then page:RefreshWealth() end
                end)
                b._selected = (i == 1)
                rangeButtons[i] = b
            end
            local chart = CreateFrame("Frame", nil, trendPanel)
            chart:SetPoint("TOPLEFT", 48, -50)
            chart:SetPoint("BOTTOMRIGHT", -18, 28)
            local chartGrid = {}
            for i=0,4 do
                local g = chart:CreateTexture(nil,"BACKGROUND")
                g:SetColorTexture(0.08,0.25,0.38,0.42)
                g:SetSize(1,1)
                g:SetPoint("TOPLEFT",0,-i*30)
                g:SetPoint("TOPRIGHT",0,-i*30)
                chartGrid[#chartGrid+1]=g
            end
            local chartLines, chartDots = {}, {}
            local minLabel = WL(trendPanel,"—",4,-62,40,MUTED,"GameFontNormalSmall","RIGHT")
            local maxLabel = WL(trendPanel,"—",4,-14,40,MUTED,"GameFontNormalSmall","RIGHT")
            wealthLiveLabels.trend = {chart=chart,lines=chartLines,dots=chartDots,minLabel=minLabel,maxLabel=maxLabel,lastTrendCount=-1}

            -- Wealth breakdown uses the same proven donut-slice TGA already used
            -- elsewhere in GoldMint, so the ring is a real WoW texture rather than
            -- a generated screenshot.
            local ring = CreateFrame("Frame",nil,breakdown)
            ring:SetSize(178,178)
            ring:SetPoint("TOPLEFT",10,-195)
            local ringSegments = {}
            local sliceTexture = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWealthSlice"
            local breakdownRows = {
                {key="Liquid Gold", color=GOLD},
                {key="Auction House", color=CYAN},
                {key="Inventory & Bank", color=GREEN},
                {key="Guild Bank", color={0.65,0.40,1.0}},
            }
            local breakdownLabels = {}
            for i, part in ipairs(breakdownRows) do
                local y = -68 - (i-1)*66
                local dot = breakdown:CreateTexture(nil,"ARTWORK")
                dot:SetColorTexture(unpack(part.color)); dot:SetSize(12,12)
                dot:SetPoint("TOPLEFT",196,y-2)
                local name = WL(breakdown,part.key,216,y,112,CYAN,"GameFontNormalSmall")
                local value = WL(breakdown,"—",216,y-22,112,GOLD,"GameFontNormalSmall")
                local pct = WL(breakdown,"0%",rightW-54,y,42,CYAN,"GameFontNormalSmall","RIGHT")
                breakdownLabels[part.key]={value=value,pct=pct}
            end
            -- Subtle horizontal separators keep the breakdown rows visually
            -- organized like the polished reference layout.
            for i=1,3 do
                local divider = breakdown:CreateTexture(nil,"ARTWORK")
                divider:SetColorTexture(0.10,0.28,0.40,0.55)
                divider:SetSize(math.max(1,rightW-220),1)
                divider:SetPoint("TOPLEFT",196,-112-(i-1)*66)
            end
            local center = ring:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            center:SetPoint("CENTER",0,16); center:SetText("TOTAL WEALTH"); center:SetTextColor(unpack(MUTED))
            local centerValue = ring:CreateFontString(nil,"OVERLAY","GameFontHighlightLarge")
            centerValue:SetPoint("CENTER",0,-7); centerValue:SetText("—"); centerValue:SetTextColor(unpack(GOLD))
            centerValue:SetFont("Fonts\\FRIZQT__.TTF", 15, "OUTLINE")
            centerValue:SetJustifyH("CENTER")
            centerValue:SetWidth(120)
            wealthLiveLabels.allocationCenter=centerValue
            wealthLiveLabels["Liquid GoldValue"] = breakdownLabels["Liquid Gold"].value
            wealthLiveLabels["Liquid GoldPct"] = breakdownLabels["Liquid Gold"].pct
            wealthLiveLabels["AH Value"] = breakdownLabels["Auction House"].value
            wealthLiveLabels["AH Pct"] = breakdownLabels["Auction House"].pct
            wealthLiveLabels["AssetsValue"] = breakdownLabels["Inventory & Bank"].value
            wealthLiveLabels["AssetsPct"] = breakdownLabels["Inventory & Bank"].pct
            wealthLiveLabels.bankValue = breakdownLabels["Guild Bank"].value
            wealthLiveLabels.bankPct = breakdownLabels["Guild Bank"].pct

            wealthLiveLabels.allocation = {apply=function(parts)
                local total=0
                for _,p in ipairs(parts) do total=total+math.max(0,tonumber(p.value) or 0) end
                total=math.max(total,1)
                local map={ ["Liquid Gold"]="Liquid Gold", ["AH Value"]="Auction House", ["Assets"]="Inventory & Bank", ["Guild Bank"]="Guild Bank" }
                local colors={GOLD,CYAN,GREEN,{0.65,0.40,1.0}}
                local counts={}
                local assigned=0
                for i,p in ipairs(parts) do
                    local row=breakdownLabels[map[p.key] or p.key]
                    if row then
                        local pct=math.max(0,tonumber(p.value) or 0)/total
                        row.value:SetText(FormatWealthAmount(p.value))
                        row.pct:SetText(math.floor(pct*100+0.5).."%")
                        counts[i]=math.floor(pct*36+0.5)
                        assigned=assigned+counts[i]
                    end
                end
                while assigned>36 do
                    local idx=1; for i=2,#counts do if counts[i]>counts[idx] then idx=i end end
                    if counts[idx]>0 then counts[idx]=counts[idx]-1; assigned=assigned-1 else break end
                end
                while assigned<36 do
                    local best=1; for i=2,#counts do if (tonumber(parts[i] and parts[i].value) or 0)>(tonumber(parts[best] and parts[best].value) or 0) then best=i end end
                    counts[best]=(counts[best] or 0)+1; assigned=assigned+1
                end
                for _,seg in ipairs(ringSegments) do seg:Hide() end
                wipe(ringSegments)
                local cursor=0
                for i=1,4 do
                    for _=1,(counts[i] or 0) do
                        cursor=cursor+1
                        local tex=ring:CreateTexture(nil,"ARTWORK")
                        tex:SetTexture(sliceTexture)
                        tex:SetSize(178,178)
                        tex:SetPoint("CENTER")
                        tex:SetRotation((cursor-1)*(2*math.pi/36))
                        tex:SetVertexColor(unpack(colors[i]))
                        ringSegments[#ringSegments+1]=tex
                    end
                end
            end}

            -- Recent transactions: a compact, Blizzard-style ledger table.
            -- Keep this focused on the transaction data itself; the old
            -- "significant movements" footer was not part of the Wealth UI.
            local txHeaderY=-44
            WL(transactions,"DATE & TIME",16,txHeaderY,180,MUTED,"GameFontNormalSmall")
            WL(transactions,"TYPE",206,txHeaderY,92,MUTED,"GameFontNormalSmall")
            WL(transactions,"ITEM",305,txHeaderY,410,MUTED,"GameFontNormalSmall")
            WL(transactions,"AMOUNT",735,txHeaderY,180,MUTED,"GameFontNormalSmall","RIGHT")
            WL(transactions,"SOURCE",930,txHeaderY,150,MUTED,"GameFontNormalSmall")
            local txLine=transactions:CreateTexture(nil,"ARTWORK")
            txLine:SetColorTexture(0.08,0.25,0.38,0.82)
            txLine:SetSize(math.max(1,pw-32),1)
            txLine:SetPoint("TOPLEFT",16,-67)

            wealthLiveLabels.activityRows={}
            for i=1,5 do
                local y=-78-(i-1)*31
                local row={}
                row.bg=transactions:CreateTexture(nil,"BACKGROUND")
                row.bg:SetColorTexture(0.01,0.025,0.04,(i%2==0) and 0.45 or 0.22)
                row.bg:SetSize(math.max(1,pw-32),29)
                row.bg:SetPoint("TOPLEFT",16,y+5)

                row.source=WL(transactions,"",16,y,180,MUTED,"GameFontNormalSmall")
                row.type=WL(transactions,"",206,y,92,CYAN,"GameFontNormalSmall")

                row.icon=transactions:CreateTexture(nil,"ARTWORK")
                row.icon:SetSize(22,22)
                row.icon:SetPoint("TOPLEFT",305,y-1)
                row.icon:Hide()

                row.detail=WL(transactions,"",334,y,376,MUTED,"GameFontNormalSmall")
                row.amount=WL(transactions,"",735,y,180,GREEN,"GameFontNormalSmall","RIGHT")
                row.origin=WL(transactions,"",930,y,150,MUTED,"GameFontNormalSmall")

                row.divider=transactions:CreateTexture(nil,"ARTWORK")
                row.divider:SetColorTexture(0.08,0.25,0.38,0.34)
                row.divider:SetSize(math.max(1,pw-32),1)
                row.divider:SetPoint("TOPLEFT",16,y-24)
                wealthLiveLabels.activityRows[i]=row
            end

            local viewAll=MakeButton(transactions,"VIEW ALL",94,30,"secondary")
            viewAll:SetPoint("TOPRIGHT",-12,-10)
            viewAll:SetScript("OnClick",function()
                if GoldMint.Print and GoldMint.Ledger and GoldMint.Ledger.GetSession then
                    local session=GoldMint.Ledger:GetSession()
                    local txs=session and session.transactions or {}
                    GoldMint.Print("Wealth transactions: "..tostring(#txs))
                end
            end)

            local function GetWealthData()
                local wallet=GoldMint.Ledger and GoldMint.Ledger:GetAccountWallet() or {}
                local personal=GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney() or 0
                local warband=tonumber(wallet.warbandGold) or 0
                local guildGold,guildValue=0,0
                local selectedGuild=GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
                if selectedGuild and GoldMint.Valuation and GoldMint.Valuation.GetGoldMakingGuildBankValue then
                    local gd=GoldMint.Valuation:GetGoldMakingGuildBankValue()
                    if gd and gd.tracked then guildGold=tonumber(gd.gold) or 0; guildValue=tonumber(gd.itemValue) or 0 end
                end
                local hoard=GoldMint.Valuation and GoldMint.Valuation:GetKnownHoardValue() or {total=0}
                local auction=GoldMint.Market and GoldMint.Market.GetOwnedAuctionValue and GoldMint.Market:GetOwnedAuctionValue() or 0
                local vendor=0
                local valuationStore=GoldMintDB and GoldMintDB.valuation or nil
                local function BucketVendorValue(bucket)
                    local sum=0
                    if type(bucket)~="table" then return 0 end
                    for itemID,count in pairs(bucket) do
                        local sell=0
                        if C_Item and C_Item.GetItemInfo then
                            local ok,_,_,_,_,_,_,_,_,_,_,sellPrice=pcall(C_Item.GetItemInfo,tonumber(itemID))
                            if ok then sell=tonumber(sellPrice) or 0 end
                        end
                        sum=sum+sell*(tonumber(count) or 0)
                    end
                    return sum
                end
                if valuationStore then
                    for _,character in pairs(valuationStore.characters or {}) do
                        if type(character)=="table" then vendor=vendor+BucketVendorValue(character.inventory)+BucketVendorValue(character.bank) end
                    end
                    vendor=vendor+BucketVendorValue(valuationStore.accountBank)
                    local selectedKey=selectedGuild and tostring(selectedGuild) or nil
                    if selectedKey and type(valuationStore.guildBanks)=="table" then
                        local guildRecord=valuationStore.guildBanks[selectedKey]
                        if type(guildRecord)=="table" then vendor=vendor+BucketVendorValue(guildRecord.items) end
                    end
                end
                local liquid=math.max(tonumber(personal) or 0,0)+math.max(warband,0)+math.max(guildGold,0)
                local assets=math.max((tonumber(hoard.total) or 0)-math.max(tonumber(auction) or 0,0),0)
                local total=liquid+math.max(tonumber(auction) or 0,0)+assets
                return {personal=personal,warband=warband,guildGold=guildGold,guildValue=guildValue,hoard=tonumber(hoard.total) or 0,auction=tonumber(auction) or 0,vendor=vendor,liquid=liquid,assets=assets,total=total}
            end

            local function DrawTrend()
                local points=GoldMintDB and GoldMintDB.milestones and GoldMintDB.milestones.snapshots or {}
                local cutoff=time()-(selectedRange*86400)
                local filtered={}
                for _,p in ipairs(points) do
                    if type(p)=="table" and (tonumber(p.time) or 0)>=cutoff then
                        local t=tonumber(p.time) or 0; local v=tonumber(p.value or p.gold) or 0
                        if t>0 and v>=0 then filtered[#filtered+1]={time=t,value=v} end
                    end
                end
                if #filtered<2 and GoldMint.Ledger and GoldMint.Ledger.GetTrendPoints then
                    filtered={}
                    for _,p in ipairs(GoldMint.Ledger:GetTrendPoints() or {}) do
                        if type(p)=="table" then local t=tonumber(p.time) or 0; local v=tonumber(p.gold or p.value) or 0; if t>0 and v>=0 and t>=cutoff then filtered[#filtered+1]={time=t,value=v} end end
                    end
                end
                table.sort(filtered,function(a,b) return a.time<b.time end)
                local dedup={}
                for _,p in ipairs(filtered) do
                    local last=dedup[#dedup]
                    if last and last.time==p.time then last.value=p.value else dedup[#dedup+1]=p end
                end
                filtered=dedup
                for _,l in ipairs(chartLines) do l:Hide() end
                for _,d in ipairs(chartDots) do d:Hide() end
                wipe(chartLines); wipe(chartDots)
                if #filtered<2 then maxLabel:SetText("—"); minLabel:SetText("—"); return end
                local minV,maxV=math.huge,-math.huge
                for _,p in ipairs(filtered) do local v=tonumber(p.value or p.gold) or 0; minV=math.min(minV,v); maxV=math.max(maxV,v) end
                if maxV<=minV then maxV=minV+1 end
                maxLabel:SetText(FormatWealthAmount(maxV)); minLabel:SetText(FormatWealthAmount(minV))
                local cw,ch=chart:GetWidth(),chart:GetHeight(); local left,right,top,bottom=0,math.max(1,cw),8,math.max(10,ch-8)
                for i=1,#filtered-1 do
                    local a,b=filtered[i],filtered[i+1]
                    local av=tonumber(a.value or a.gold) or 0; local bv=tonumber(b.value or b.gold) or 0
                    local x1=left+((i-1)/math.max(1,#filtered-1))*(right-left); local x2=left+(i/math.max(1,#filtered-1))*(right-left)
                    local y1=bottom-((av-minV)/(maxV-minV))*(bottom-top); local y2=bottom-((bv-minV)/(maxV-minV))*(bottom-top)
                    chartLines[#chartLines+1]=MakeLine(chart,x1,y1,x2,y2,CYAN,2)
                end
                for i,p in ipairs(filtered) do
                    local v=tonumber(p.value or p.gold) or 0; local x=left+((i-1)/math.max(1,#filtered-1))*(right-left); local y=bottom-((v-minV)/(maxV-minV))*(bottom-top)
                    local dot=chart:CreateTexture(nil,"ARTWORK"); dot:SetColorTexture(unpack(CYAN)); dot:SetSize(6,6); dot:SetPoint("CENTER",chart,"TOPLEFT",x,-y); chartDots[#chartDots+1]=dot
                end
            end
            wealthLiveLabels.trend.draw=DrawTrend

            function page:RefreshWealth()
                local d=GetWealthData()
                wealthLiveLabels.netWorth:SetText(FormatWealthAmount(d.total))
                wealthLiveLabels.ahValue:SetText(FormatWealthAmount(d.auction))
                wealthLiveLabels.vendorValue:SetText(FormatWealthAmount(d.vendor))
                local trendDelta=0
                local snapshots=GoldMintDB and GoldMintDB.milestones and GoldMintDB.milestones.snapshots or {}
                local cutoff=time()-(7*86400); local currentSnapshot,priorSnapshot
                for i=#snapshots,1,-1 do
                    local sp=snapshots[i]
                    if type(sp)=="table" and not currentSnapshot then currentSnapshot=sp end
                    if type(sp)=="table" and (tonumber(sp.time) or 0)<=cutoff then priorSnapshot=sp; break end
                end
                if currentSnapshot and priorSnapshot then trendDelta=(tonumber(currentSnapshot.value) or tonumber(currentSnapshot.gold) or 0)-(tonumber(priorSnapshot.value) or tonumber(priorSnapshot.gold) or 0) end
                if trendDelta==0 and d.total>0 then local session=GoldMint.Ledger and GoldMint.Ledger:GetSession() or nil; trendDelta=session and tonumber(session.netGold) or 0 end
                wealthLiveLabels.trendValue:SetText((trendDelta>=0 and "+" or "")..FormatWealthAmount(math.abs(trendDelta)))
                wealthLiveLabels.trendValue:SetTextColor(unpack(trendDelta>=0 and GREEN or RED))
                wealthLiveLabels.allocationCenter:SetText(FormatWholeGold(d.total))
                local parts={{key="Liquid Gold",value=d.liquid},{key="AH Value",value=d.auction},{key="Assets",value=d.assets},{key="Guild Bank",value=d.guildValue}}
                wealthLiveLabels.allocation.apply(parts)
                -- Rebuild the ring as 36 real annular slices.  The slice texture is
                -- transparent outside the wedge, so the result is a clean donut rather
                -- than the old radial-line/sunburst effect.
                local total=0; for _,part in ipairs(parts) do total=total+math.max(0,tonumber(part.value) or 0) end; total=math.max(total,1)
                for _,seg in ipairs(ringSegments) do seg:Hide() end; wipe(ringSegments)
                local segmentCount=36; local cursor=0; local assigned={}
                for idx,part in ipairs(parts) do
                    local count=math.floor((math.max(0,tonumber(part.value) or 0)/total)*segmentCount+0.5)
                    if (tonumber(part.value) or 0)>0 and count<1 then count=1 end
                    assigned[idx]=count; cursor=cursor+count
                end
                while cursor>segmentCount do
                    local largest=1; for i=2,#assigned do if (assigned[i] or 0)>(assigned[largest] or 0) then largest=i end end
                    if (assigned[largest] or 0)>0 then assigned[largest]=assigned[largest]-1; cursor=cursor-1 else break end
                end
                while cursor<segmentCount do
                    local largest=1; for i=2,#assigned do if (tonumber(parts[i] and parts[i].value) or 0)>(tonumber(parts[largest] and parts[largest].value) or 0) then largest=i end end
                    assigned[largest]=(assigned[largest] or 0)+1; cursor=cursor+1
                end
                local colors={GOLD,CYAN,GREEN,{0.65,0.40,1.0}}
                local sliceIndex=0
                for idx=1,#parts do
                    for _=1,(assigned[idx] or 0) do
                        sliceIndex=sliceIndex+1
                        local tex=ring:CreateTexture(nil,"ARTWORK"); tex:SetTexture(sliceTexture); tex:SetSize(190,190); tex:SetPoint("CENTER"); tex:SetRotation((sliceIndex-1)*(2*math.pi/segmentCount)); tex:SetVertexColor(unpack(colors[idx] or GOLD)); ringSegments[#ringSegments+1]=tex
                    end
                end
                local tx=GoldMint.Ledger and GoldMint.Ledger:GetSession() or nil; local list=tx and tx.transactions or {}; local rows={}
                for i=#list,1,-1 do
                    local t=list[i]
                    if type(t)=="table" and t.type~="transfer" then
                        rows[#rows+1]=t
                        if #rows>=#wealthLiveLabels.activityRows then break end
                    end
                end
                local function TransactionType(t, amount)
                    local source=t and tostring(t.source or "") or ""
                    if string.find(source,"Auction House Sale",1,true) or string.find(source,"Vendor Sale",1,true) then return "Sale", GREEN end
                    if string.find(source,"Purchase",1,true) or (t and t.type=="spending") then return "Purchase", RED end
                    if amount>0 and (string.find(source,"Deposit",1,true) or string.find(source,"Bank",1,true)) then return "Deposit", CYAN end
                    return amount>=0 and "Income" or "Change", amount>=0 and GREEN or RED
                end
                for i,row in ipairs(wealthLiveLabels.activityRows) do
                    local t=rows[i]
                    if t then
                        local amount=tonumber(t.amount) or 0
                        local txTime=tonumber(t.time)
                        row.source:SetText(txTime and date("%b %d, %Y %I:%M %p",txTime) or "")
                        local typeText,typeColor=TransactionType(t,amount)
                        row.type:SetText(typeText); row.type:SetTextColor(unpack(typeColor))
                        local itemName=""; local icon=nil
                        if t.itemID and C_Item then
                            if C_Item.GetItemNameByID then local ok,n=pcall(C_Item.GetItemNameByID,t.itemID); if ok then itemName=n or "" end end
                            if C_Item.GetItemIconByID then local ok,v=pcall(C_Item.GetItemIconByID,t.itemID); if ok then icon=v end end
                            if (not itemName or itemName=="") and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID,t.itemID) end
                        end
                        row.detail:SetText(itemName~="" and itemName or tostring(t.source or "Gold movement"))
                        if icon then row.icon:SetTexture(icon); row.icon:Show() else row.icon:Hide() end
                        row.amount:SetText((amount>=0 and "+" or "-")..FormatGold(math.abs(amount))); row.amount:SetTextColor(unpack(amount>=0 and GREEN or RED))
                        row.origin:SetText(tostring(t.source or "Wallet"))
                    else
                        row.source:SetText(""); row.type:SetText(""); row.detail:SetText(""); row.amount:SetText(""); row.origin:SetText(""); row.icon:Hide()
                    end
                end
                DrawTrend()
            end

            wealthLiveLabels._built=true
            page._wealthBuilt=true
            page.RefreshSessionSummary=function() end
            page:RefreshWealth()
        end
        local function cooldowns()
            -- Cooldowns is intentionally a dedicated dashboard-style page.
            -- Do not use the older Operations/table treatment here: the page
            -- mirrors the GoldMint cooldown reference with compact status chips,
            -- one clean list, character/profession/item context, and a single
            -- action column.
            if panels.cooldownsPage then
                -- The header is part of the cooldown page so it follows the page
                -- visibility and cannot be left behind or hidden by another view.
                if panels.cooldownsPage.header then
                    panels.cooldownsPage.header:Show()
                    panels.cooldownsPage.header:SetFrameLevel(panels.cooldownsPage:GetFrameLevel() + 10)
                end
                panels.cooldownsPage:Show()
            else
                local page = CreateFrame("Frame", nil, content)
                page:SetAllPoints(content)
                panels.cooldownsPage = page

                -- Put the entire cooldown header into a single framed panel so
                -- the title, description, status chips, refresh control, timestamp,
                -- and filter read as one cohesive dashboard header.
                local header = Panel(page, 0, 72, "TOPLEFT", 228, -126, {0.08, 0.34, 0.52, 0.90})
                header:ClearAllPoints()
                header:SetPoint("TOPLEFT", frame, "TOPLEFT", 228, -126)
                header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -126)
                header:SetHeight(72)
                header:SetFrameLevel(page:GetFrameLevel() + 2)
                page.header = header

                local heading = MakeLabel(header, "GameFontNormalLarge", "ACTIVE COOLDOWNS")
                local cooldownIcon = AddActiveCooldownIcon(header, 18, -13, 32)
                cooldownIcon:ClearAllPoints()
                cooldownIcon:SetPoint("LEFT", header, "LEFT", 8, 15)
                heading:SetPoint("TOPLEFT", 50, -10)
                heading:SetTextColor(unpack(CYAN))
                heading:SetShadowOffset(1, -1)
                page.heading = heading

                -- Match the Home page title treatment: same font, color, shadow,
                -- and short cyan accent beneath the first three letters.
                local headingUnderline = Accent(header, "TOPLEFT", 50, -28, 38, CYAN)
                page.headingUnderline = headingUnderline

                local subtitle = MakeLabel(header, "GameFontNormalSmall", "Tracked profession cooldowns across your characters. Ready items are shown first.", 255)
                subtitle:SetPoint("TOPLEFT", 18, -40)
                subtitle:SetTextColor(unpack(MUTED))
                page.subtitle = subtitle

                local function StatusChip(text, width, x, color)
                    local b = MakeButton(header, text, width, 38, "secondary")
                    b:SetPoint("TOPLEFT", x, -17)
                    local function ApplyChipStyle()
                        -- Keep the status color visible even while hovering.
                        -- Only the brightness changes; the status color remains intact.
                        b:SetBackdropColor(color[1] * 0.12, color[2] * 0.12, color[3] * 0.12, 0.98)
                        b:SetBackdropBorderColor(color[1], color[2], color[3], 0.72)
                        b.text:SetTextColor(unpack(color))
                    end

                    ApplyChipStyle()
                    b:SetScript("OnEnter", ApplyChipStyle)
                    b:SetScript("OnLeave", ApplyChipStyle)
                    b._chipColor = color
                    return b
                end

                page.readyChip = StatusChip("[0] READY NOW", 142, 300, GREEN)
                page.activeChip = StatusChip("[0] IN PROGRESS", 150, 455, GOLD)
                page.overdueChip = StatusChip("[0] OVERDUE", 132, 618, RED)

                -- A real refresh control keeps the page useful after opening a
                -- profession, changing characters, or returning from the AH.
                local refreshButton = MakeButton(header, "REFRESH", 94, 38, "secondary")
                refreshButton:SetPoint("TOPRIGHT", -145, -17)
                page.refreshButton = refreshButton

                local updated = MakeLabel(header, "GameFontNormalSmall", "UPDATED --", 150)
                updated:SetPoint("TOPRIGHT", -275, -50)
                updated:SetJustifyH("RIGHT")
                updated:SetTextColor(unpack(MUTED))
                page.updated = updated

                -- Filter is intentionally not a button. It is a simple text control
                -- with the supplied GoldMint arrow, matching the reference UI.
                local filter = CreateFrame("Frame", nil, header)
                filter:SetSize(125, 38)
                filter:SetPoint("TOPRIGHT", -8, -17)
                filter:EnableMouse(true)
                local filterText = MakeLabel(filter, "GameFontNormal", "FILTER")
                filterText:SetPoint("LEFT", 0, 0)
                filterText:SetTextColor(unpack(MUTED))
                local filterArrow = filter:CreateTexture(nil, "ARTWORK")
                filterArrow:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintFilterArrow")
                filterArrow:SetSize(22, 14)
                filterArrow:SetPoint("RIGHT", 0, 0)
                page.filterButton = filter
                page.filterText = filterText
                page.filter = "ALL"

                -- The list/table now flows from the header instead of using a
                -- hard-coded Y offset.  This keeps the content below the header
                -- automatically if the header height/padding changes later.
                local listPanel = Panel(page, 0, 0, "TOPLEFT", 0, 0, {0.08, 0.34, 0.52, 0.90})
                listPanel:ClearAllPoints()
                listPanel:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -10)
                listPanel:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", 0, -10)
                listPanel:SetHeight(400)
                page.listPanel = listPanel

                local function Header(text, x, width)
                    local h = MakeLabel(listPanel, "GameFontNormalSmall", text, width)
                    h:SetPoint("TOPLEFT", x, -16)
                    h:SetTextColor(unpack(MUTED))
                    return h
                end
                Header("CHARACTER NAME", 22, 235)
                Header("PROFESSION", 275, 350)
                Header("ITEM / COOLDOWN", 520, 250)
                Header("STATUS", 790, 135)

                local divider = listPanel:CreateTexture(nil, "ARTWORK")
                divider:SetColorTexture(0.08, 0.25, 0.38, 0.82)
                divider:SetSize(1, 1)
                divider:SetPoint("TOPLEFT", 18, -43)
                divider:SetPoint("TOPRIGHT", listPanel, "TOPRIGHT", -18, -43)

                local scroll, rowsFrame = CreateGoldMintScrollFrame(listPanel, 12, -50, -30, 12, 1080)
                page.scroll = scroll
                page.rowsFrame = rowsFrame
                page.rows = {}

                local empty = MakeLabel(rowsFrame, "GameFontNormal", "No tracked cooldowns have been discovered yet.", 900)
                empty:SetPoint("TOPLEFT", 22, -26)
                empty:SetTextColor(unpack(MUTED))
                page.empty = empty

                -- Secondary cooldown workspace.  These panels deliberately sit
                -- below the main table so they never overlap it.
                local restockPanel = Panel(page, 525, 175, "TOPLEFT", 0, -500, {0.08, 0.34, 0.52, 0.90})
                page.restockPanel = restockPanel
                local restockTitle = MakeLabel(restockPanel, "GameFontNormalLarge", "RESTOCKING MATERIALS")
                restockTitle:SetPoint("TOPLEFT", 16, -12)
                restockTitle:SetTextColor(unpack(CYAN))
                restockTitle:SetShadowOffset(1, -1)
                local restockUnderline = Accent(restockPanel, "TOPLEFT", 16, -30, 38, CYAN)
                page.restockUnderline = restockUnderline
                local restockSub = MakeLabel(restockPanel, "GameFontNormalSmall", "Materials needed across your tracked cooldowns.", 470)
                restockSub:SetPoint("TOPLEFT", 16, -34)
                restockSub:SetTextColor(unpack(MUTED))
                local rh1 = MakeLabel(restockPanel, "GameFontNormalSmall", "MATERIAL", 220)
                rh1:SetPoint("TOPLEFT", 16, -58)
                rh1:SetTextColor(unpack(MUTED))
                local rh2 = MakeLabel(restockPanel, "GameFontNormalSmall", "NEED", 65)
                rh2:SetPoint("TOPLEFT", 275, -58); rh2:SetJustifyH("RIGHT"); rh2:SetTextColor(unpack(MUTED))
                local rh3 = MakeLabel(restockPanel, "GameFontNormalSmall", "HAVE", 65)
                rh3:SetPoint("TOPLEFT", 350, -58); rh3:SetJustifyH("RIGHT"); rh3:SetTextColor(unpack(MUTED))
                local rh4 = MakeLabel(restockPanel, "GameFontNormalSmall", "MISSING", 80)
                rh4:SetPoint("TOPLEFT", 425, -58); rh4:SetJustifyH("RIGHT"); rh4:SetTextColor(unpack(MUTED))

                -- Column guides are placed in the gaps between the row values.
                local restockHeaderLine = restockPanel:CreateTexture(nil, "OVERLAY")
                restockHeaderLine:SetColorTexture(0.08, 0.25, 0.38, 0.55)
                restockHeaderLine:SetSize(493, 1)
                restockHeaderLine:SetPoint("TOPLEFT", 16, -76)
                for _, x in ipairs({340, 415, 509}) do
                    local line = restockPanel:CreateTexture(nil, "OVERLAY")
                    line:SetColorTexture(0.08, 0.25, 0.38, 0.40)
                    line:SetSize(1, 92)
                    line:SetPoint("TOPLEFT", x, -76)
                end

                -- Scrollable material list. The panel keeps its compact height while
                -- the material rows can grow beyond the visible area without spilling
                -- over the panel border or the UI beneath it.
                local restockScroll, restockRowsFrame = CreateGoldMintScrollFrame(
                    restockPanel,
                    8, -78,
                    -24, 8,
                    495
                )
                page.restockScroll = restockScroll
                page.restockRowsFrame = restockRowsFrame
                page.restockRows = {}
                page.restockEmpty = MakeLabel(
                    restockRowsFrame,
                    "GameFontNormalSmall",
                    "No tracked cooldown materials are currently recorded.",
                    455
                )
                page.restockEmpty:SetPoint("TOPLEFT", 16, -4)
                page.restockEmpty:SetTextColor(unpack(MUTED))

                local itemPanel = Panel(page, 525, 175, "TOPRIGHT", 0, -500, {0.08, 0.34, 0.52, 0.90})
                page.itemPanel = itemPanel
                local itemTitle = MakeLabel(itemPanel, "GameFontNormalLarge", "ITEM COOLDOWNS")
                itemTitle:SetPoint("TOPLEFT", 16, -12)
                itemTitle:SetTextColor(unpack(CYAN))
                itemTitle:SetShadowOffset(1, -1)
                local itemUnderline = Accent(itemPanel, "TOPLEFT", 16, -30, 38, CYAN)
                page.itemUnderline = itemUnderline
                local itemSub = MakeLabel(itemPanel, "GameFontNormalSmall", "Items with a Duration in bags, bank, or warbank.", 470)
                itemSub:SetPoint("TOPLEFT", 16, -34)
                itemSub:SetTextColor(unpack(MUTED))
                local ih1 = MakeLabel(itemPanel, "GameFontNormalSmall", "ITEM", 235)
                ih1:SetPoint("TOPLEFT", 16, -58); ih1:SetTextColor(unpack(MUTED))
                local ih2 = MakeLabel(itemPanel, "GameFontNormalSmall", "LOCATION", 90)
                ih2:SetPoint("TOPLEFT", 275, -58); ih2:SetTextColor(unpack(MUTED))
                local ih3 = MakeLabel(itemPanel, "GameFontNormalSmall", "DURATION", 110)
                ih3:SetPoint("TOPLEFT", 385, -58); ih3:SetJustifyH("RIGHT"); ih3:SetTextColor(unpack(MUTED))

                -- Column guides are placed in the gaps between the row values.
                local itemHeaderLine = itemPanel:CreateTexture(nil, "OVERLAY")
                itemHeaderLine:SetColorTexture(0.08, 0.25, 0.38, 0.55)
                itemHeaderLine:SetSize(493, 1)
                itemHeaderLine:SetPoint("TOPLEFT", 16, -76)
                for _, x in ipairs({265, 375}) do
                    local line = itemPanel:CreateTexture(nil, "OVERLAY")
                    line:SetColorTexture(0.08, 0.25, 0.38, 0.40)
                    line:SetSize(1, 92)
                    line:SetPoint("TOPLEFT", x, -76)
                end

                page.itemRows = {}
                page.itemEmpty = MakeLabel(itemPanel, "GameFontNormalSmall", "No item cooldowns have been discovered yet.", 480)
                page.itemEmpty:SetPoint("TOPLEFT", 16, -82)
                page.itemEmpty:SetTextColor(unpack(MUTED))

                local function FormatAuxCooldown(seconds)
                    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
                    local days = math.floor(seconds / 86400)
                    local hours = math.floor((seconds % 86400) / 3600)
                    local minutes = math.floor((seconds % 3600) / 60)
                    if days > 0 then return string.format("%dd %dh", days, hours) end
                    if hours > 0 then return string.format("%dh %dm", hours, minutes) end
                    return string.format("%dm", minutes)
                end

                function page:RefreshAuxiliaryPanels()
                    local materials = GoldMint.Cooldowns and GoldMint.Cooldowns.GetRestockingMaterials and GoldMint.Cooldowns:GetRestockingMaterials() or {}
                    for _, row in ipairs(self.restockRows) do row:Hide() end
                    if #materials == 0 then
                        self.restockEmpty:Show()
                    else
                        self.restockEmpty:Hide()
                        for i, material in ipairs(materials) do
                            local row = self.restockRows[i]
                            if not row then
                                row = CreateFrame("Button", nil, self.restockRowsFrame)
                                row:SetSize(self.restockRowsFrame:GetWidth() - 20, 28)

                                local bg = row:CreateTexture(nil, "BACKGROUND")
                                bg:SetAllPoints(row)
                                row.bg = bg

                                row.icon = row:CreateTexture(nil, "ARTWORK")
                                row.icon:SetSize(20, 20)
                                row.icon:SetPoint("LEFT", row, "LEFT", 8, 0)

                                row.material = row:CreateFontString(nil, "ARTWORK", "GameFontNormal")
                                row.material:SetPoint("LEFT", row.icon, "RIGHT", 8, 0)
                                row.material:SetWidth(190)
                                row.material:SetJustifyH("LEFT")
                                row.material:SetTextColor(0.88, 0.92, 0.98)
                                -- Keep the existing name reference for compatibility.
                                row.name = row.material

                                row.need = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
                                row.need:SetPoint("LEFT", row, "LEFT", 260, 0)
                                row.need:SetWidth(55)
                                row.need:SetJustifyH("RIGHT")

                                row.have = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
                                row.have:SetPoint("LEFT", row, "LEFT", 335, 0)
                                row.have:SetWidth(55)
                                row.have:SetJustifyH("RIGHT")
                                row.have:SetTextColor(unpack(MUTED))

                                row.missing = row:CreateFontString(nil, "ARTWORK", "GameFontRed")
                                row.missing:SetPoint("LEFT", row, "LEFT", 420, 0)
                                row.missing:SetWidth(65)
                                row.missing:SetJustifyH("RIGHT")

                                self.restockRows[i] = row
                            end

                            -- First row sits just below the header; every following
                            -- row sits 2px below the previous row.
                            row:ClearAllPoints()
                            if i == 1 then
                                row:SetPoint("TOPLEFT", self.restockRowsFrame, "TOPLEFT", 10, -4)
                            else
                                row:SetPoint("TOPLEFT", self.restockRows[i - 1], "BOTTOMLEFT", 0, -2)
                            end

                            row.bg:SetColorTexture(
                                i % 2 == 0 and 1 or 0,
                                i % 2 == 0 and 1 or 0,
                                i % 2 == 0 and 1 or 0,
                                i % 2 == 0 and 0.03 or 0.15
                            )
                            row.icon:SetTexture(material.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                            row.material:SetText(material.name or "Material")
                            row.need:SetText(tostring(material.needed or 0)); row.need:SetTextColor(unpack(GOLD))
                            row.have:SetText(tostring(material.have or 0))
                            local missing = tonumber(material.missing) or 0
                            row.missing:SetText(tostring(missing)); row.missing:SetTextColor(unpack(missing > 0 and RED or GREEN)); row:Show()
                        end

                        -- Give the scroll child enough height for every material row.
                        -- The visible portion stays fixed to the panel, so excess rows
                        -- are clipped and reached with the mouse wheel or scrollbar.
                        self.restockRowsFrame:SetHeight(math.max(1, (#materials * 30) + 8))
                    end

                    self.restockScroll:SetVerticalScroll(0)
                    if self.restockScroll.UpdateGoldMintScrollBar then
                        self.restockScroll:UpdateGoldMintScrollBar()
                    end

                    local items = GoldMint.Cooldowns and GoldMint.Cooldowns.GetItemCooldowns and GoldMint.Cooldowns:GetItemCooldowns() or {}
                    for _, row in ipairs(self.itemRows) do row:Hide() end
                    if #items == 0 then
                        self.itemEmpty:Show()
                    else
                        self.itemEmpty:Hide()
                        local rowHeight = 28
                        for i, item in ipairs(items) do
                            local row = self.itemRows[i]
                            if not row then
                                row = CreateFrame("Button", nil, self.itemPanel)
                                row:SetSize(self.itemPanel:GetWidth() - 20, rowHeight)

                                local bg = row:CreateTexture(nil, "BACKGROUND")
                                bg:SetAllPoints(row)
                                row.bg = bg

                                row.icon = row:CreateTexture(nil, "ARTWORK")
                                row.icon:SetSize(20, 20)
                                row.icon:SetPoint("LEFT", row, "LEFT", 8, 0)

                                row.name = row:CreateFontString(nil, "ARTWORK", "GameFontNormal")
                                row.name:SetPoint("LEFT", row.icon, "RIGHT", 8, 0)
                                row.name:SetWidth(215)
                                row.name:SetJustifyH("LEFT")
                                row.name:SetTextColor(0.88, 0.92, 0.98)

                                row.location = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
                                row.location:SetPoint("LEFT", row, "LEFT", 260, 0)
                                row.location:SetWidth(90)
                                row.location:SetJustifyH("LEFT")
                                row.location:SetTextColor(unpack(MUTED))

                                row.cooldown = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
                                row.cooldown:SetPoint("RIGHT", row, "RIGHT", -16, 0)
                                row.cooldown:SetWidth(110)
                                row.cooldown:SetJustifyH("RIGHT")

                                self.itemRows[i] = row
                            end

                            row:ClearAllPoints()
                            if i == 1 then
                                row:SetPoint("TOPLEFT", self.itemPanel, "TOPLEFT", 16, -82)
                            else
                                row:SetPoint("TOPLEFT", self.itemRows[i - 1], "BOTTOMLEFT", 0, -2)
                            end

                            row.bg:SetColorTexture(
                                i % 2 == 0 and 1 or 0,
                                i % 2 == 0 and 1 or 0,
                                i % 2 == 0 and 1 or 0,
                                i % 2 == 0 and 0.02 or 0.12
                            )
                            row.icon:SetTexture(item.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                            row.name:SetText(item.name or "Item")
                            row.location:SetText(item.location or "Bags")
                            row.cooldown:SetText(item.durationText or "--")
                            row.cooldown:SetTextColor(unpack(GOLD))
                            row:Show()
                        end
                    end
                end

                local function HideFilterMenu()
                    if cooldownFilterMenu then cooldownFilterMenu:Hide() end
                end
                page.HideFilterMenu = HideFilterMenu
                local function ShowFilterMenu()
                    if not cooldownFilterMenu then
                        cooldownFilterMenu = CreateFrame("Frame", nil, page, "BackdropTemplate")
                        cooldownFilterMenu:SetSize(150, 104)
                        cooldownFilterMenu:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", -8, -4)
                        cooldownFilterMenu:SetFrameLevel(page:GetFrameLevel() + 20)
                        cooldownFilterMenu:SetBackdrop({
                            bgFile = "Interface\\Buttons\\WHITE8X8",
                            tile = true, tileSize = 8,
                        })
                        cooldownFilterMenu:SetBackdropColor(0.006, 0.025, 0.045, 0.99)
                        for i, key in ipairs({"ALL", "READY", "COOLDOWN"}) do
                            local b = CreateFrame("Button", nil, cooldownFilterMenu)
                            b:SetSize(134, 30)
                            b:SetPoint("TOPLEFT", 8, -4 - (i - 1) * 32)
                            local t = MakeLabel(b, "GameFontNormalSmall", key, 134)
                            t:SetPoint("CENTER")
                            t:SetJustifyH("CENTER")
                            t:SetTextColor(unpack(MUTED))
                            b.text = t
                            b:SetScript("OnEnter", function() t:SetTextColor(unpack(GOLD)) end)
                            b:SetScript("OnLeave", function() t:SetTextColor(unpack(MUTED)) end)
                            b:SetScript("OnClick", function()
                                page.filter = key
                                HideFilterMenu()
                                page:Refresh()
                            end)
                        end
                    end
                    cooldownFilterMenu:Show()
                end
                refreshButton:SetScript("OnEnter", function(self) self.text:SetTextColor(unpack(GOLD)) end)
                refreshButton:SetScript("OnLeave", function(self) self.text:SetTextColor(unpack(MUTED)) end)

                filter:SetScript("OnEnter", function() filterText:SetTextColor(unpack(GOLD)) end)
                filter:SetScript("OnLeave", function() filterText:SetTextColor(unpack(MUTED)) end)
                filter:SetScript("OnMouseDown", ShowFilterMenu)
                page:SetScript("OnMouseDown", HideFilterMenu)

                refreshButton:SetScript("OnClick", function()
                    page:Refresh()
                end)

                function page:Refresh()
                    local data = {}
                    if GoldMint.Cooldowns and GoldMint.Cooldowns.GetTrackedCooldowns then
                        data = GoldMint.Cooldowns:GetTrackedCooldowns() or {}
                    end
                    self.updated:SetText("UPDATED " .. date("%H:%M:%S"))
                    self:RefreshAuxiliaryPanels()

                    local readyCount, activeCount, overdueCount = 0, 0, 0
                    for _, entry in ipairs(data) do
                        if entry.overdue then
                            overdueCount = overdueCount + 1
                        elseif entry.ready then
                            readyCount = readyCount + 1
                        else
                            activeCount = activeCount + 1
                        end
                    end

                    self.readyChip.text:SetText("[" .. readyCount .. "] READY NOW")
                    self.activeChip.text:SetText("[" .. activeCount .. "] IN PROGRESS")
                    self.overdueChip.text:SetText("[" .. overdueCount .. "] OVERDUE")

                    local visible = {}
                    for _, entry in ipairs(data) do
                        local show = self.filter == "ALL"
                        if self.filter == "READY" then show = entry.ready == true end
                        if self.filter == "COOLDOWN" then show = entry.ready ~= true end
                        if show then visible[#visible + 1] = entry end
                    end

                    for _, row in ipairs(self.rows) do row:Hide() end

                    if #visible == 0 then
                        self.empty:SetText(#data == 0 and "No tracked cooldowns have been discovered yet. Open a profession and use the cooldown tracker to choose what GoldMint should watch." or "No cooldowns match this filter.")
                        self.empty:Show()
                        self.rowsFrame:SetHeight(70)
                        return
                    end
                    self.empty:Hide()

                    local rowHeight = 78
                    for i, entry in ipairs(visible) do
                        local row = self.rows[i]
                        if not row then
                            row = CreateFrame("Frame", nil, self.rowsFrame, "BackdropTemplate")
                            row:SetSize(1080, 72)
                            row:SetBackdrop({
                                bgFile = "Interface\\Buttons\\WHITE8X8",
                                edgeFile = "Interface\\Buttons\\WHITE8X8",
                                tile = true, tileSize = 8, edgeSize = 1,
                                insets = {left = 1, right = 1, top = 1, bottom = 1},
                            })
                            row:SetBackdropColor(0.006, 0.025, 0.045, 0.72)
                            row:SetBackdropBorderColor(0.06, 0.22, 0.34, 0.72)

                            local classIcon = row:CreateTexture(nil, "ARTWORK")
                            classIcon:SetSize(40, 40)
                            classIcon:SetPoint("LEFT", 10, 0)
                            row.classIcon = classIcon

                            local character = MakeLabel(row, "GameFontNormal", "", 195)
                            character:SetPoint("LEFT", 62, 10)
                            character:SetTextColor(0.88, 0.92, 0.98)
                            row.character = character

                            local characterStatus = MakeLabel(row, "GameFontNormalSmall", "", 195)
                            characterStatus:SetPoint("LEFT", 62, -12)
                            characterStatus:SetTextColor(0.45, 0.66, 0.80)
                            row.characterStatus = characterStatus

                            local professionIcon = row:CreateTexture(nil, "ARTWORK")
                            professionIcon:SetSize(38, 38)
                            professionIcon:SetPoint("LEFT", 275, 0)
                            row.professionIcon = professionIcon

                            local profession = MakeLabel(row, "GameFontNormal", "", 150)
                            profession:SetPoint("LEFT", 323, 10)
                            profession:SetTextColor(0.76, 0.84, 0.94)
                            row.profession = profession

                            local item = MakeLabel(row, "GameFontNormal", "", 250)
                            item:SetPoint("LEFT", 520, 10)
                            item:SetTextColor(0.92, 0.94, 0.98)
                            row.item = item

                            local charges = MakeLabel(row, "GameFontNormalSmall", "", 250)
                            charges:SetPoint("LEFT", 520, -12)
                            charges:SetTextColor(0.48, 0.66, 0.78)
                            row.charges = charges

                            local status = MakeLabel(row, "GameFontNormal", "", 135)
                            status:SetPoint("LEFT", 790, 7)
                            row.status = status

                            local action = MakeButton(row, "LOGOUT", 118, 32, "secondary")
                            action:SetPoint("RIGHT", -10, 0)
                            row.action = action

                            local rowLine = row:CreateTexture(nil, "ARTWORK")
                            rowLine:SetColorTexture(0.08, 0.25, 0.38, 0.55)
                            rowLine:SetSize(1045, 1)
                            rowLine:SetPoint("BOTTOMLEFT", 18, 0)
                            row.rowLine = rowLine

                            self.rows[i] = row
                        end

                        row:ClearAllPoints()
                        row:SetPoint("TOPLEFT", 2, -((i - 1) * rowHeight))
                        row:Show()

                        if page._focusRecipeID and tonumber(entry.recipeID) == tonumber(page._focusRecipeID) then
                            row:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
                            row:SetBackdropColor(0.025, 0.070, 0.100, 0.98)
                            page._focusedRow = row
                        else
                            row:SetBackdropBorderColor(0.06, 0.22, 0.34, 0.72)
                            row:SetBackdropColor(0.006, 0.025, 0.045, 0.72)
                        end

                        local characterData = GoldMintDB and GoldMintDB.characters and GoldMintDB.characters[entry.characterKey]
                        local class = characterData and characterData.class
                        local classCoords = class and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]
                        if classCoords then
                            row.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes")
                            row.classIcon:SetTexCoord(unpack(classCoords))
                        else
                            row.classIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
                            row.classIcon:SetTexCoord(0, 1, 0, 1)
                        end

                        local charName = entry.characterName or entry.characterKey or "Unknown"
                        local dash = string.find(charName, "-", 1, true)
                        if dash then charName = string.sub(charName, 1, dash - 1) end
                        row.character:SetText(charName)
                        row.characterStatus:SetText(entry.characterKey == (GoldMint.characterKey or "") and "Current character" or "Tracked character")

                        local professionName = entry.professionName or "Profession"
                        row.profession:SetText(professionName)
                        local professionIcons = {
                            Alchemy = "Interface\\Icons\\Trade_Alchemy",
                            Blacksmithing = "Interface\\Icons\\Trade_BlackSmithing",
                            Enchanting = "Interface\\Icons\\Trade_Enchanting",
                            Engineering = "Interface\\Icons\\Trade_Engineering",
                            Herbalism = "Interface\\Icons\\Trade_Herbalism",
                            Inscription = "Interface\\Icons\\INV_Inscription_majorglyph01",
                            Jewelcrafting = "Interface\\Icons\\INV_Jewelry_Talisman_06",
                            Leatherworking = "Interface\\Icons\\Trade_LeatherWorking",
                            Mining = "Interface\\Icons\\Trade_Mining",
                            Skinning = "Interface\\Icons\\INV_Misc_Pelt_Wolf",
                            Tailoring = "Interface\\Icons\\Trade_Tailoring",
                            Cooking = "Interface\\Icons\\INV_Misc_Food_15",
                        }
                        row.professionIcon:SetTexture(professionIcons[professionName] or entry.icon or "Interface\\Icons\\Trade_Alchemy")

                        row.item:SetText(entry.name or "Cooldown")
                        row.item:SetWidth(250)
                        row.charges:SetWidth(250)
                        if entry.charges and entry.maxCharges then
                            row.charges:SetText(string.format("%d/%d Charges", entry.charges, entry.maxCharges))
                        elseif entry.ready then
                            row.charges:SetText("Daily cooldown")
                        else
                            row.charges:SetText("Cooldown in progress")
                        end

                        local isCurrentCharacter = entry.characterKey == (GoldMint.characterKey or "")
                        local canCraftNow = entry.ready and entry.canCraft == true and isCurrentCharacter
                        -- There is no reason to offer LOGOUT for the character
                        -- the player is already on.  Keep CRAFT NOW available
                        -- when the current character is ready and can open the
                        -- recipe; otherwise hide the action control entirely.
                        row.action:Hide()
                        row.action:SetScript("OnClick", nil)

                        if entry.overdue then
                            row.status:SetText("⚠ OVERDUE")
                            row.status:SetTextColor(unpack(RED))
                        elseif entry.ready then
                            row.status:SetText("READY")
                            row.status:SetTextColor(unpack(GREEN))
                            if canCraftNow then
                                row.action.text:SetText("CRAFT NOW")
                                row.action.text:SetTextColor(unpack(GOLD))
                                row.action:SetScript("OnClick", function()
                                    if C_TradeSkillUI and C_TradeSkillUI.OpenRecipe and entry.recipeID then
                                        pcall(C_TradeSkillUI.OpenRecipe, entry.recipeID)
                                    end
                                end)
                                row.action:Show()
                            elseif not isCurrentCharacter then
                                row.action.text:SetText("LOGOUT")
                                row.action.text:SetTextColor(unpack(MUTED))
                                row.action:Show()
                            end
                        else
                            local remaining = math.max(0, tonumber(entry.remaining) or 0)
                            local days = math.floor(remaining / 86400)
                            local hours = math.floor((remaining % 86400) / 3600)
                            local minutes = math.floor((remaining % 3600) / 60)
                            local timerText
                            if days > 0 then
                                timerText = string.format("%dd %dh", days, hours)
                            elseif hours > 0 then
                                timerText = string.format("%dh %dm", hours, minutes)
                            else
                                timerText = string.format("%dm", minutes)
                            end
                            row.status:SetText("TIME " .. timerText)
                            row.status:SetTextColor(unpack(GOLD))
                        end
                    end

                    self.rowsFrame:SetHeight(math.max(70, (#visible * rowHeight) + 8))
                end

                -- Refresh the cooldown page only while it is visible.  Use a
                -- timer instead of a frame OnUpdate so hidden pages perform no
                -- per-frame work.
                page._refreshTicker = nil
                page:SetScript("OnShow", function(self)
                    self:Refresh()
                    if C_Timer and C_Timer.NewTicker and not self._refreshTicker then
                        self._refreshTicker = C_Timer.NewTicker(1, function()
                            if not self:IsShown() then return end
                            self:Refresh()
                        end)
                    end
                end)
                page:SetScript("OnHide", function(self)
                    if self._refreshTicker then
                        self._refreshTicker:Cancel()
                        self._refreshTicker = nil
                    end
                end)

            end
            panels.cooldownsPage:Refresh()
        end

        local function routines()
            -- Routines page: Daily Focus / Daily Task List / Weekly Overview
            -- on top, then Manual World Quests / World Boss Timers / Rare Recipe
            -- Spawn Timers below.
            for _, b in pairs(tabButtons) do b:Hide() end
            title:SetText("")
            sub:SetText("")
            content:ClearAllPoints()
            content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, -8)
            content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)

            local page = CreateFrame("Frame", nil, content)
            page:SetAllPoints(content)
            -- Keep the Routines page surface transparent. The individual
            -- routine cards provide their own dark panels while the supplied
            -- dashboard artwork remains visible between them.

            local function RL(parent, text, x, y, w, color, font, justify)
                local l = MakeLabel(parent, font or "GameFontNormal", text or "", w)
                l:SetPoint("TOPLEFT", x, y)
                l:SetTextColor(unpack(color or MUTED))
                l:SetWordWrap(false)
                l:SetNonSpaceWrap(false)
                if justify then l:SetJustifyH(justify) end
                return l
            end

            local function RCard(parent, w, h, x, y, border)
                return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
            end

            local function RButton(parent, text, w, h, x, y, kind)
                local b = MakeButton(parent, text, w, h or 28, kind or "secondary")
                b:SetPoint("TOPLEFT", x, y)
                return b
            end

            local function Checkbox(parent, x, y, checked, onclick)
                local box = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
                box:SetSize(22, 22)
                box:SetPoint("TOPLEFT", x, y)
                box:SetChecked(checked == true)
                local checkTexture = box:GetCheckedTexture()
                if checkTexture then
                    checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                end
                box:SetScript("OnClick", function(self)
                    if checkTexture then
                        checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                    end
                    if onclick then onclick(self) end
                end)
                return box
            end

            local dailyDetailFrame

            local function GetBountifulDelves()
                local result = {}
                -- Blizzard exposes the current Midnight bountiful rotation as
                -- Delve Area POIs on the Midnight continent map (2537).
                -- IMPORTANT: do not require isCurrentEvent here. The bountiful
                -- POIs are identified by the dedicated Blizzard atlas marker.
                local continentMapID = 2537
                if not (C_AreaPoiInfo and C_AreaPoiInfo.GetDelvesForMap and C_AreaPoiInfo.GetAreaPOIInfo) then
                    return result
                end

                local ok, poiIDs = pcall(C_AreaPoiInfo.GetDelvesForMap, continentMapID)
                if not ok or type(poiIDs) ~= "table" then
                    return result
                end

                for _, poiID in ipairs(poiIDs) do
                    local okInfo, info = pcall(C_AreaPoiInfo.GetAreaPOIInfo, continentMapID, poiID)
                    local atlas = okInfo and info and tostring(info.atlasName or "") or ""
                    if okInfo and info and info.name and atlas:lower() == "delves-bountiful" then
                        local zoneName = "Midnight"
                        local mapID = tonumber(info.linkedUiMapID)
                        if mapID and C_Map and C_Map.GetMapInfo then
                            local okMap, mapInfo = pcall(C_Map.GetMapInfo, mapID)
                            if okMap and mapInfo and mapInfo.name then
                                zoneName = mapInfo.name
                            end
                        end
                        result[#result + 1] = {
                            areaPoiID = poiID,
                            name = tostring(info.name),
                            zone = zoneName,
                            atlas = info.atlasName,
                            mapID = mapID,
                        }
                    end
                end

                table.sort(result, function(a,b) return a.name < b.name end)
                return result
            end

            local function ShowRoutineDetail(activity)
                if not dailyDetailFrame then
                    local detail = CreateFrame("Frame", "GoldMintRoutineDetail", UIParent, "BackdropTemplate")
                    detail:SetSize(430, 330)
                    detail:SetPoint("CENTER")
                    detail:SetFrameStrata("DIALOG")
                    detail:SetFrameLevel(500)
                    detail:SetBackdrop({
                        bgFile = "Interface\\Buttons\\WHITE8X8",
                        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                        tile = true, tileSize = 8, edgeSize = 14,
                        insets = {left=3,right=3,top=3,bottom=3},
                    })
                    detail:SetBackdropColor(0.006,0.018,0.030,0.98)
                    detail:SetBackdropBorderColor(0.08,0.38,0.58,0.98)
                    detail:EnableMouse(true)
                    detail:Hide()

                    local title = MakeLabel(detail, "GameFontNormalLarge", "ROUTINE DETAILS", 330)
                    title:SetPoint("TOPLEFT", 18, -16)
                    title:SetTextColor(unpack(GOLD))
                    detail.title = title

                    local close = MakeButton(detail, "CLOSE", 70, 26, "secondary")
                    close:SetPoint("TOPRIGHT", -16, -14)
                    close:SetScript("OnClick", function() detail:Hide() end)

                    local subtitle = MakeLabel(detail, "GameFontNormalSmall", "", 390)
                    subtitle:SetPoint("TOPLEFT", 18, -48)
                    subtitle:SetTextColor(unpack(MUTED))
                    detail.subtitle = subtitle

                    detail.body = CreateFrame("Frame", nil, detail)
                    detail.body:SetPoint("TOPLEFT", 18, -76)
                    detail.body:SetPoint("BOTTOMRIGHT", -18, 18)
                    dailyDetailFrame = detail
                end

                local detail = dailyDetailFrame
                detail.activity = activity
                for _, child in ipairs({detail.body:GetChildren()}) do child:Hide() end
                detail.title:SetText(tostring(activity and activity.title or "ROUTINE DETAILS"))

                if activity and tostring(activity.title or ""):lower():find("bountiful delve", 1, true) then
                    -- Always perform a live query when the detail window opens.
                    -- Opening the world map is no longer required as the trigger.
                    local delves = GetBountifulDelves()
                    detail.subtitle:SetText(#delves > 0 and (#delves .. " active bountiful delves today") or "No active bountiful delves were returned by Blizzard yet.")
                    if #delves == 0 then
                        local note = MakeLabel(detail.body, "GameFontNormal", "No active bountiful delves were returned by Blizzard yet. GoldMint will refresh automatically when Blizzard updates the Delve POIs.", 385)
                        note:SetPoint("TOPLEFT", 0, 0)
                        note:SetTextColor(unpack(MUTED))
                    else
                        for i, delve in ipairs(delves) do
                            local row = CreateFrame("Frame", nil, detail.body, "BackdropTemplate")
                            row:SetSize(390, 42)
                            row:SetPoint("TOPLEFT", 0, -((i-1)*46))
                            row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
                            row:SetBackdropColor(0.015,0.055,0.085,0.78)
                            row:SetBackdropBorderColor(0.06,0.28,0.42,0.9)

                            if delve.atlas and row.CreateTexture then
                                local icon = row:CreateTexture(nil, "ARTWORK")
                                local okAtlas = pcall(icon.SetAtlas, icon, delve.atlas)
                                if okAtlas then
                                    icon:SetSize(26,26)
                                    icon:SetPoint("LEFT", 8, 0)
                                end
                            end
                            RL(row, delve.name, 44, -8, 230, {0.88,0.92,0.98}, "GameFontNormal")
                            RL(row, delve.zone, 44, -24, 230, MUTED, "GameFontNormalSmall")
                            RL(row, "BOUNTIFUL", 300, -13, 78, GREEN, "GameFontNormalSmall", "RIGHT")
                        end
                    end
                else
                    detail.subtitle:SetText("Current routine information")
                    local name = tostring(activity and activity.title or "Routine")
                    local info = MakeLabel(detail.body, "GameFontNormal", name .. " is currently " .. tostring(activity and activity.status or "tracked") .. ".", 385)
                    info:SetPoint("TOPLEFT", 0, 0)
                    info:SetTextColor(unpack(MUTED))
                end
                detail:Show()
                detail:Raise()
            end

            -- AREA_POIS_UPDATED is a secondary refresh trigger, not the only
            -- way GoldMint learns the daily bountiful rotation. The detail
            -- window already performs an immediate live query; this event keeps
            -- an open window synchronized when Blizzard refreshes the POI data.
            do
                local refreshFrame = GoldMint.BountifulDelvesRefreshFrame
                if not refreshFrame then
                    refreshFrame = CreateFrame("Frame")
                    GoldMint.BountifulDelvesRefreshFrame = refreshFrame
                    refreshFrame:RegisterEvent("AREA_POIS_UPDATED")
                    refreshFrame:SetScript("OnEvent", function()
                        local detail = dailyDetailFrame
                        local activity = detail and detail:IsShown() and detail.activity
                        if activity and tostring(activity.title or ""):lower():find("bountiful delve", 1, true) then
                            if C_Timer and C_Timer.After then
                                C_Timer.After(0, function()
                                    if dailyDetailFrame and dailyDetailFrame:IsShown() and dailyDetailFrame.activity == activity then
                                        ShowRoutineDetail(activity)
                                    end
                                end)
                            else
                                ShowRoutineDetail(activity)
                            end
                        end
                    end)
                end
            end

            local function FrequencyIs(activity, wanted)
                return tostring(activity and activity.frequency or "") == wanted
            end

            local function GetActivities()
                local state = GoldMint.RoutineState
                if not state or not state.GetRelevantActivities then return {} end
                return state:GetRelevantActivities(GoldMint.characterKey, { currentOnly = true, season = 2 }) or {}
            end

            local function GetLegacyActivities()
                local state = GoldMint.RoutineState
                if not state or not state.GetRelevantActivities then return {} end
                local all = state:GetRelevantActivities(GoldMint.characterKey, {}) or {}
                local result = {}
                for _, activity in ipairs(all) do
                    if tonumber(activity.expansionID) ~= 11 then
                        result[#result + 1] = activity
                    end
                end
                return result
            end

            local function SortFocus(a,b)
                -- Always surface the currently rotating Midnight outdoor World
                -- Boss in Weekly Task Overview.  It is a catalog activity rather
                -- than a normal quest-backed routine, so alphabetical sorting can
                -- otherwise push it past the eight-row display limit.
                local aWorldBoss = a and a.id == "midnight_s2_world_boss"
                local bWorldBoss = b and b.id == "midnight_s2_world_boss"
                if aWorldBoss ~= bWorldBoss then
                    return aWorldBoss
                end

                local rank = { ready=1, unknown=2, completed=3, scheduled=4 }
                local ar = rank[a.status] or 5
                local br = rank[b.status] or 5
                if ar ~= br then return ar < br end
                return tostring(a.title or "") < tostring(b.title or "")
            end

            local activities = GetActivities()
            local daily, weekly = {}, {}
            for _, activity in ipairs(activities) do
                if FrequencyIs(activity, "Daily") then
                    daily[#daily + 1] = activity
                elseif FrequencyIs(activity, "Weekly") then
                    weekly[#weekly + 1] = activity
                end
            end
            table.sort(daily, SortFocus)
            table.sort(weekly, SortFocus)

            -- ================================================================
            -- TOP LEFT: DAILY FOCUS
            -- ================================================================
            local dailyFocus = RCard(page, 252, 238, 275, -4, {0.38,0.30,0.08,0.95})
            RL(dailyFocus, "DAILY FOCUS", 14, -14, 150, GOLD, "GameFontNormalLarge")
            RL(dailyFocus, "(" .. tostring(math.min(3, #daily)) .. " tasks)", 160, -16, 75, MUTED, "GameFontNormal")
            RL(dailyFocus, "Only the routines that matter today.", 14, -39, 232, MUTED, "GameFontNormalSmall")
            RL(dailyFocus, "Only the ones worth your attention.", 14, -55, 232, MUTED, "GameFontNormalSmall")

            local focusRows = {}
            local function BuildDailyFocus()
                for _, row in ipairs(focusRows) do row:Hide() end
                focusRows = {}
                if #daily == 0 then
                    RL(dailyFocus, "No daily routines observed yet.", 14, -88, 230, MUTED, "GameFontNormal")
                    RL(dailyFocus, "GoldMint will learn repeatable activities as you play.", 14, -116, 230, MUTED, "GameFontNormalSmall")
                    return
                end
                for i = 1, math.min(3, #daily) do
                    local activity = daily[i]
                    local row = CreateFrame("Frame", nil, dailyFocus, "BackdropTemplate")
                    row:SetSize(220, 46)
                    row:SetPoint("TOPLEFT", 14, -78 - ((i-1)*49))
                    row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
                    row:SetBackdropColor(i == 1 and 0.18 or 0.035, i == 1 and 0.15 or 0.075, i == 1 and 0.045 or 0.11, i == 1 and 0.72 or 0.55)
                    row:SetBackdropBorderColor(i == 1 and 0.42 or 0.12, i == 1 and 0.35 or 0.30, i == 1 and 0.10 or 0.46, 0.9)
                    Checkbox(row, 8, -14, activity.status == "completed", function()
                        GoldMint.Print("Routine completion is learned from Blizzard quest state; GoldMint updates it automatically.")
                    end)
                    local titleText = tostring(activity.title or "Routine")
                    if #titleText > 24 then titleText = titleText:sub(1,21) .. "..." end
                    RL(row, titleText, 34, -8, 120, i == 1 and {1,0.88,0.52} or MUTED, i == 1 and "GameFontNormal" or "GameFontNormalSmall")
                    local action = RButton(row, activity.status == "ready" and "VIEW" or "VIEW", 52, 24, 154, -11, "secondary")
                    action:SetScript("OnClick", function()
                        ShowRoutineDetail(activity)
                    end)
                    focusRows[#focusRows + 1] = row
                end
            end
            BuildDailyFocus()

            -- ================================================================
            -- TOP RIGHT: WEEKLY OVERVIEW
            -- ================================================================
            local weeklyCard = RCard(page, 586, 238, 550, -4, {0.08,0.38,0.58,0.95})
            RL(weeklyCard, "WEEKLY TASK OVERVIEW", 14, -14, 250, CYAN, "GameFontNormalLarge")
            RL(weeklyCard, "ROUTINE ERA", 14, -39, 100, MUTED, "GameFontNormalSmall")
            local routineEra = "current"
            -- Keep the era tabs fully inside the card.  The previous layout
            -- pushed the long CURRENT EXPANSION label too close to the card
            -- edge, which made the control look like it was overlapping the
            -- surrounding frame at smaller UI scales.
            local currentTab = RButton(weeklyCard, "CURRENT EXPANSION", 132, 24, 106, -31, "primary")
            local legacyTab = RButton(weeklyCard, "LEGACY", 72, 24, 244, -31, "secondary")
            currentTab.text:SetFontObject("GameFontNormalSmall")
            currentTab.text:SetWidth(124)
            currentTab.text:SetWordWrap(false)
            currentTab.text:SetNonSpaceWrap(false)
            legacyTab.text:SetFontObject("GameFontNormalSmall")

            -- Keep the refresh action beside the routine-era controls so it is
            -- part of the Weekly Task Overview header instead of floating at
            -- the bottom of the Routines page.
            local refresh = RButton(weeklyCard, "REFRESH", 82, 26, 324, -30, "secondary")
            refresh:SetScript("OnClick", function()
                if GoldMint.Routines and GoldMint.Routines.SyncCurrentCharacter then GoldMint.Routines:SyncCurrentCharacter() end
                if GoldMint.RoutineState and GoldMint.RoutineState.SyncCharacter then GoldMint.RoutineState:SyncCharacter() end
                if panels.operationsShow then panels.operationsShow("routines") end
            end)

            local weeklyScroll, weeklyRows = CreateGoldMintScrollFrame(weeklyCard, 10, -63, -10, 10, 399)

            -- Manual weekly checklist state.  The checkbox in the Weekly Task
            -- Overview is an actionable checklist control, not just a visual
            -- reflection of Blizzard quest completion.  Keep the player's
            -- dismissals for the current weekly reset so checking a row removes
            -- it immediately and it stays out of the list when the panel is
            -- rebuilt.  A new weekly reset starts a fresh checklist.
            local function GetWeeklyChecklistReset()
                local now = time()
                if C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset then
                    local remaining = tonumber(C_DateAndTime.GetSecondsUntilWeeklyReset())
                    if remaining and remaining >= 0 then
                        return now - (7 * 24 * 60 * 60 - remaining)
                    end
                end
                return math.floor(now / (7 * 24 * 60 * 60)) * (7 * 24 * 60 * 60)
            end

            local function EnsureWeeklyChecklist()
                GoldMintDB.routineWeeklyChecklist = type(GoldMintDB.routineWeeklyChecklist) == "table" and GoldMintDB.routineWeeklyChecklist or {}
                local store = GoldMintDB.routineWeeklyChecklist
                local reset = GetWeeklyChecklistReset()
                if tonumber(store.reset) ~= tonumber(reset) then
                    store.reset = reset
                    store.dismissed = {}
                end
                store.dismissed = type(store.dismissed) == "table" and store.dismissed or {}
                return store
            end

            local function WeeklyChecklistKey(activity)
                if activity and activity.questID then
                    return "quest:" .. tostring(activity.questID)
                end
                return "activity:" .. tostring(activity and activity.category or "routine") .. "|" .. tostring(activity and activity.title or "")
            end

            local function IsWeeklyDismissed(activity)
                return EnsureWeeklyChecklist().dismissed[WeeklyChecklistKey(activity)] == true
            end

            local function DismissWeeklyActivity(activity)
                local store = EnsureWeeklyChecklist()
                store.dismissed[WeeklyChecklistKey(activity)] = true
            end

            local function SetRoutineEra(era)
                routineEra = era
                currentTab:SetBackdropBorderColor(unpack(era == "current" and GOLD or {0.08,0.30,0.46,0.95}))
                legacyTab:SetBackdropBorderColor(unpack(era == "legacy" and GOLD or {0.08,0.30,0.46,0.95}))
                for _, child in ipairs({weeklyRows:GetChildren()}) do child:Hide() end
                local sourceList = era == "current" and weekly or GetLegacyActivities()
                local list = {}
                for _, activity in ipairs(sourceList) do
                    if not IsWeeklyDismissed(activity) then
                        list[#list + 1] = activity
                    end
                end
                table.sort(list, SortFocus)
                if #list == 0 then
                    RL(weeklyRows, era == "current" and "No current-expansion weekly routines are observed." or "No legacy routines are observed.", 8, -8, 385, MUTED, "GameFontNormal")
                    weeklyRows:SetHeight(52)
                    return
                end
                local rowH = 31
                for i, activity in ipairs(list) do
                    if i > 8 then break end
                    local row = CreateFrame("Frame", nil, weeklyRows)
                    row:SetSize(390, rowH)
                    row:SetPoint("TOPLEFT", 4, -((i-1)*rowH))
                    Checkbox(row, 0, -6, false, function()
                        DismissWeeklyActivity(activity)
                        SetRoutineEra(routineEra)
                    end)
                    local prefix = activity.category and string.upper(tostring(activity.category)) or "ROUTINE"
                    local text = prefix .. ": " .. tostring(activity.title or "")
                    if #text > 48 then text = text:sub(1,45) .. "..." end
                    RL(row, text, 26, -4, 300, activity.status == "completed" and MUTED or {0.78,0.72,0.58}, "GameFontNormalSmall")
                    local statusText = activity.status == "completed" and "DONE" or (activity.status == "ready" and "READY" or "TRACK")
                    RL(row, statusText, 330, -4, 52, activity.status == "ready" and GREEN or (activity.status == "completed" and MUTED or GOLD), "GameFontNormalSmall", "RIGHT")
                end
                weeklyRows:SetHeight(math.max(52, math.min(8,#list)*rowH + 10))
            end
            currentTab:SetScript("OnClick", function() SetRoutineEra("current") end)
            legacyTab:SetScript("OnClick", function() SetRoutineEra("legacy") end)
            SetRoutineEra("current")

            -- ================================================================
            -- BOTTOM LEFT: WORLD QUEST OPPORTUNITIES
            -- ================================================================
            -- GoldMint scans Blizzard's live World Quest data and only shows
            -- quests with a gold, mount, or achievement-related reward.
            local questCard = RCard(page, 252, 538, 0, -4, {0.08,0.38,0.58,0.95})
            RL(questCard, "World Quests", 14, -14, 224, CYAN, "GameFontNormalLarge")
            RL(questCard, "GOLD • MOUNTS • ACHIEVEMENTS", 14, -37, 224, MUTED, "GameFontNormalSmall")

            local questRows = {}
            local questStatus = RL(questCard, "SCANNING WORLD QUESTS...", 14, -64, 224, GOLD, "GameFontNormalSmall")
            local questEmpty1 = RL(questCard, "", 14, -94, 224, MUTED, "GameFontNormalSmall")
            local questEmpty2 = RL(questCard, "", 14, -112, 224, MUTED, "GameFontNormalSmall")
            local questEmpty3 = RL(questCard, "", 14, -130, 224, MUTED, "GameFontNormalSmall")
            local questMore = RL(questCard, "", 14, -510, 224, MUTED, "GameFontNormalSmall")

            local function ClearWorldQuestRows()
                for _, row in ipairs(questRows) do
                    if row and row.Hide then row:Hide() end
                end
                questRows = {}
            end

            local function RewardColor(row)
                if row.mount then return GOLD end
                if row.achievement then return CYAN end
                return GREEN
            end

            local function BuildWorldQuestRows()
                ClearWorldQuestRows()
                local tracker = GoldMint.WorldQuestTracker
                local list = tracker and tracker.GetRows and tracker:GetRows() or {}

                questEmpty1:SetText("")
                questEmpty2:SetText("")
                questEmpty3:SetText("")
                questMore:SetText("")

                if #list == 0 then
                    questStatus:SetText("No matching World Quests found.")
                    questStatus:SetTextColor(unpack(MUTED))
                    questEmpty1:SetText("GoldMint checks the live World Quest")
                    questEmpty2:SetText("reward data for gold, mounts, and")
                    questEmpty3:SetText("achievement-related rewards.")
                    return
                end

                questStatus:SetText(string.format("%d matching World Quest%s", #list, #list == 1 and "" or "s"))
                questStatus:SetTextColor(unpack(GREEN))

                local maxRows = math.min(12, #list)
                for i = 1, maxRows do
                    local data = list[i]
                    local row = CreateFrame("Button", nil, questCard)
                    row:SetSize(224, 34)
                    row:SetPoint("TOPLEFT", 14, -82 - ((i-1) * 34))
                    row:EnableMouse(true)
                    row:RegisterForClicks("LeftButtonUp")

                    if i > 1 then
                        local line = row:CreateTexture(nil, "ARTWORK")
                        line:SetTexture("Interface\\Buttons\\WHITE8X8")
                        line:SetVertexColor(0.08,0.30,0.46,0.65)
                        line:SetSize(224, 1)
                        line:SetPoint("TOPLEFT", 0, 1)
                    end

                    local title = tostring(data.title or "World Quest")
                    if #title > 27 then title = title:sub(1,24) .. "..." end
                    RL(row, title, 0, -4, 156, RewardColor(data), "GameFontNormalSmall")

                    local reward = tostring(data.rewardText or "")
                    if data.gold then
                        reward = "GOLD " .. (tracker and tracker.FormatMoney and tracker:FormatMoney(data.gold) or "")
                    elseif data.mount then
                        reward = "MOUNT"
                    elseif data.achievement then
                        reward = "ACHIEVEMENT"
                    end
                    RL(row, reward, 158, -4, 66, RewardColor(data), "GameFontNormalSmall", "RIGHT")

                    local zone = tostring(data.zone or "")
                    if #zone > 22 then zone = zone:sub(1,19) .. "..." end
                    local timeText = tracker and tracker.FormatTime and tracker:FormatTime(data.timeLeft) or "TIME UNKNOWN"
                    RL(row, zone .. " • " .. timeText, 0, -20, 224, MUTED, "GameFontNormalSmall")

                    row:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:AddLine(data.title or "World Quest", 0.2, 0.9, 1)
                        GameTooltip:AddLine(data.zone or "", 0.72, 0.84, 0.96)
                        if data.gold then GameTooltip:AddLine("Gold: " .. (tracker:FormatMoney(data.gold)), 0.2, 1, 0.2) end
                        if data.mount then GameTooltip:AddLine("Mount reward", 1, 0.82, 0.2) end
                        if data.achievement then GameTooltip:AddLine("Achievement-related reward", 0.2, 0.9, 1) end
                        if data.timeLeft then GameTooltip:AddLine("Expires in: " .. tracker:FormatTime(data.timeLeft), 0.72, 0.84, 0.96) end
                        GameTooltip:AddLine("Click to view this World Quest on the map.", 0.65, 0.65, 0.65)
                        GameTooltip:Show()
                    end)
                    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    row:SetScript("OnClick", function()
                        if C_QuestLog and C_QuestLog.SetMapForQuestPOIs and data.mapID then
                            pcall(C_QuestLog.SetMapForQuestPOIs, data.mapID)
                        end
                        if C_QuestLog and C_QuestLog.SetSelectedQuest and data.questID then
                            pcall(C_QuestLog.SetSelectedQuest, data.questID)
                        end
                        if C_Map and C_Map.OpenWorldMap then
                            pcall(C_Map.OpenWorldMap, data.mapID)
                        end
                    end)

                    questRows[#questRows + 1] = row
                end

                if #list > maxRows then
                    questMore:SetText("+ " .. tostring(#list - maxRows) .. " more matching quests")
                end
            end

            -- Build once for the initial state, then let the tracker notify
            -- this card only when the matching World Quest result set changes.
            BuildWorldQuestRows()

            -- WorldQuestTracker continues scanning in the background, but it
            -- notifies the UI only when the matching World Quest result set
            -- actually changes. This prevents the card from rebuilding every
            -- few seconds while still allowing newly-appearing quests (and
            -- quests that disappear/expire) to show immediately.
            local tracker = GoldMint.WorldQuestTracker
            if tracker and tracker.SetOnChanged then
                tracker:SetOnChanged(function()
                    if questCard:IsShown() then
                        BuildWorldQuestRows()
                    end
                end)
            end

            -- ================================================================
            -- BOTTOM CENTER: WORLD BOSS TIMERS
            -- ================================================================
            -- Standalone GoldMint world-boss timer engine.
            local bossCard = RCard(page, 252, 290, 275, -252, {0.08,0.38,0.58,0.95})
            RL(bossCard, "WORLD BOSS TIMERS", 14, -14, 220, CYAN, "GameFontNormalLarge")
            RL(bossCard, "RESPAWN WINDOWS", 14, -37, 180, MUTED, "GameFontNormalSmall")

            local bossRows = {}
            local bossUpdateFrame = CreateFrame("Frame", nil, bossCard)
            bossUpdateFrame:SetAllPoints()
            bossUpdateFrame:SetScript("OnHide", function(self)
                self:SetScript("OnUpdate", nil)
            end)

            local function FormatClock(seconds)
                seconds = math.max(0, math.floor(tonumber(seconds) or 0))
                local mins = math.floor(seconds / 60)
                local secs = seconds % 60
                return string.format("%02d:%02d", mins, secs)
            end

            local function FormatBossTimer(seconds)
                seconds = tonumber(seconds)
                if not seconds then return "--:--" end
                if seconds <= 0 then return "READY" end
                local s = math.floor(seconds)
                local mins = math.floor(s / 60)
                local secs = s % 60
                return string.format("%02d:%02d", mins, secs)
            end

            local function GetWorldBossRows()
                if not GoldMint.WorldBossTimers or not GoldMint.WorldBossTimers.GetRows then
                    return nil, "World Boss Timers are unavailable."
                end
                return GoldMint.WorldBossTimers:GetRows()
            end

            local function ClearBossRows()
                for _, row in ipairs(bossRows) do row:Hide() end
                bossRows = {}
            end

            local function BuildBossRows()
                ClearBossRows()
                local list, unavailable = GetWorldBossRows()
                if not list then
                    RL(bossCard, unavailable or "World Boss Timers unavailable.", 14, -70, 220, GOLD, "GameFontNormalSmall")
                    RL(bossCard, "GoldMint tracks boss deaths", 14, -94, 220, MUTED, "GameFontNormalSmall")
                    RL(bossCard, "and respawn windows automatically.", 14, -112, 220, MUTED, "GameFontNormalSmall")
                    return
                end

                if #list == 0 then
                    RL(bossCard, "No world bosses are configured.", 14, -70, 220, MUTED, "GameFontNormal")
                    return
                end

                local shown = math.min(6, #list)
                for i = 1, shown do
                    local data = list[i]
                    local row = CreateFrame("Frame", nil, bossCard)
                    row:SetSize(224, 29)
                    row:SetPoint("TOPLEFT", 14, -63 - ((i-1) * 30))

                    if i > 1 then
                        local line = row:CreateTexture(nil, "ARTWORK")
                        line:SetTexture("Interface\\Buttons\\WHITE8X8")
                        line:SetVertexColor(0.08,0.30,0.46,0.70)
                        line:SetSize(224, 1)
                        line:SetPoint("TOPLEFT", 0, 1)
                    end

                    local bossName = data.name
                    if #bossName > 23 then bossName = bossName:sub(1,20) .. "..." end
                    local nameColor = data.highlight and GOLD or (data.hasTimer and CYAN or MUTED)
                    RL(row, bossName, 0, -5, 142, nameColor, "GameFontNormalSmall")

                    local timerText
                    local timerColor
                    if data.midnightActive then
                        timerText = "ACTIVE"
                        timerColor = GREEN
                    elseif data.midnightLair then
                        timerText = "WEEKLY"
                        timerColor = GOLD
                    elseif not data.hasTimer then
                        timerText = "NO TIMER"
                        timerColor = MUTED
                    elseif data.max and data.max <= 0 then
                        timerText = "READY"
                        timerColor = GREEN
                    elseif data.random then
                        local lower = tonumber(data.min) or 0
                        local upper = tonumber(data.max) or lower
                        timerText = (lower <= 0 and "READY" or FormatClock(lower)) .. " - " .. FormatClock(upper)
                        timerColor = GOLD
                    else
                        timerText = FormatBossTimer(data.min or data.max or 0)
                        timerColor = GOLD
                    end
                    RL(row, timerText, 146, -5, 78, timerColor, "GameFontNormalSmall", "RIGHT")

                    local zone = data.zone
                    if data.saved then zone = (zone ~= "" and zone .. " • SAVED" or "SAVED") end
                    if data.realm and data.realm ~= "" then zone = (zone ~= "" and zone .. " • " or "") .. tostring(data.realm) end
                    if zone and zone ~= "" then
                        if #zone > 31 then zone = zone:sub(1,28) .. "..." end
                        RL(row, zone, 0, -20, 142, data.saved and GOLD or MUTED, "GameFontNormalSmall")
                    end

                    bossRows[#bossRows + 1] = row
                end

            end

            BuildBossRows()

            local requestBossTimers = RButton(bossCard, "REQUEST TIMERS", 112, 24, 126, -250, "secondary")
            requestBossTimers:SetScript("OnClick", function()
                if GoldMint.WorldBossTimers and GoldMint.WorldBossTimers.RequestTimers then
                    GoldMint.WorldBossTimers:RequestTimers()
                    GoldMint.Print("Requested World Boss timer data from nearby players.")
                else
                    GoldMint.Print("World Boss Timers are unavailable.")
                end
                BuildBossRows()
            end)

            bossUpdateFrame:SetScript("OnUpdate", function(self, elapsed)
                self._elapsed = (self._elapsed or 0) + elapsed
                if self._elapsed < 1 then return end
                self._elapsed = 0
                if bossCard:IsShown() then
                    BuildBossRows()
                end
            end)

            -- ================================================================
            -- BOTTOM RIGHT: RARE RECIPE SPAWN TIMERS
            -- ================================================================
            local rareCard = RCard(page, 586, 290, 550, -252, {0.08,0.38,0.58,0.95})
            RL(rareCard, "RARE RECIPE SPAWN TIMERS", 14, -14, 520, CYAN, "GameFontNormalLarge")
            local clock = rareCard:CreateTexture(nil, "ARTWORK")
            clock:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintRoutineStopwatch.tga")
            clock:SetSize(78,78)
            clock:SetPoint("TOPLEFT", 18, -54)

            local realmTime = RL(rareCard, "", 112, -60, 450, MUTED, "GameFontNormalSmall")
            local rareStatus = RL(rareCard, "", 112, -80, 450, MUTED, "GameFontNormal")
            local rareHint = RL(rareCard, "", 112, -104, 450, MUTED, "GameFontNormalSmall")
            local rareRows = {}

            for i = 1, 4 do
                local row = CreateFrame("Frame", nil, rareCard)
                row:SetSize(510, 24)
                row:SetPoint("TOPLEFT", 18, -132 - ((i-1) * 25))
                local label = RL(row, "", 26, 0, 330, MUTED, "GameFontNormalSmall")
                local timer = RL(row, "", 370, 0, 125, CYAN, "GameFontNormalSmall")
                rareRows[i] = {frame=row, label=label, timer=timer}
            end

            local setAlerts = RButton(rareCard, "SET ALERTS", 125, 26, 290, -250, "secondary")
            setAlerts:SetScript("OnClick", function()
                if GoldMint.OpenOptions then
                    GoldMint:OpenOptions("rarerecipealerts")
                end
            end)

            local function RefreshRareRecipeCard()
                local rare = GoldMint.RareRecipeAlerts
                local watches = rare and rare.GetWatches and rare:GetWatches() or {}
                realmTime:SetText("Realm Time: " .. date("%H:%M"))

                for _, row in ipairs(rareRows) do row.frame:Hide() end

                if not rare then
                    rareStatus:SetText("Rare recipe spawn alerts are unavailable.")
                    rareHint:SetText("Reload the interface after installing the current GoldMint build.")
                    return
                end

                if #watches == 0 then
                    rareStatus:SetText("No rare recipe sources are configured.")
                    rareHint:SetText("Use SET ALERTS to add the NPC and respawn interval.")
                    return
                end

                local shown = math.min(4, #watches)
                rareStatus:SetText(rare:GetSettings().enabled and "Spawn alerts are enabled." or "Spawn alerts are disabled.")
                rareHint:SetText("Timers begin after GoldMint detects a configured source.")

                for i = 1, shown do
                    local watch = watches[i]
                    local row = rareRows[i]
                    row.frame:Show()
                    row.label:SetText(tostring(watch.name or "Rare Recipe Source"))
                    if watch.nextSpawn and tonumber(watch.nextSpawn) > time() then
                        row.timer:SetText(rare:FormatRemaining(watch.nextSpawn))
                    else
                        row.timer:SetText("WAITING")
                    end
                end
            end

            RefreshRareRecipeCard()
            local rareUpdateFrame = CreateFrame("Frame", nil, rareCard)
            rareUpdateFrame:SetScript("OnUpdate", function(self, elapsed)
                self._elapsed = (self._elapsed or 0) + elapsed
                if self._elapsed < 1 then return end
                self._elapsed = 0
                if rareCard:IsShown() then RefreshRareRecipeCard() end
            end)

        end
        local builders={inventory=inventory,recipes=recipes,market=market,routines=routines,wealth=wealth,cooldowns=cooldowns}
        show = function(name)
            section=name or section or "inventory"
            SetNavigationActive(section)
            wipeContent()
            local isWealth = section == "wealth"
            local isCooldowns = section == "cooldowns"
            for k,b in pairs(tabButtons) do
                if isWealth or isCooldowns then
                    b:Hide()
                else
                    b:Show()
                    b:SetBackdropBorderColor(k==section and 1.0 or 0.10,k==section and 0.78 or 0.34,k==section and 0.20 or 0.52,1)
                end
            end
            if isWealth or isCooldowns then
                title:SetText("")
                sub:SetText("")
                content:ClearAllPoints()
                content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, -8)
                content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)
            else
                title:SetText("GOLDMINT OPERATIONS")
                sub:SetText("Inventory, mail, crafting, market, routines, and gentle maintenance tools.")
                content:ClearAllPoints()
                content:SetPoint("TOPLEFT",22,-130)
                content:SetPoint("BOTTOMRIGHT",-22,22)
            end
            -- Cooldowns' header is part of the cooldown page, but we still
            -- explicitly show/hide the page here so navigation remains deterministic.
            if panels.cooldownsPage and panels.cooldownsPage.header then
                if isCooldowns then
                    panels.cooldownsPage.header:Show()
                    panels.cooldownsPage:Show()
                else
                    panels.cooldownsPage.header:Hide()
                    panels.cooldownsPage:Hide()
                end
            end

            local builder=builders[section]
            if builder then builder() else L("SECTION UNAVAILABLE",18,-16,500,RED,"GameFontHighlight"); L("GoldMint could not build this section.",18,-42,820,MUTED,"GameFontNormal") end

            -- Prime the live wallet immediately when navigating into Wealth.
            -- The character wallet can receive its final client-side value one
            -- frame/event after navigation; retrying on the next few frames
            -- prevents the header from briefly showing an older cached amount.
            if section == "wealth" then
                if GoldMint.Ledger and GoldMint.Ledger.UpdateCharacterGold then
                    GoldMint.Ledger:UpdateCharacterGold()
                end
                if GoldMint.Economy and GoldMint.Economy.ScheduleRefresh then
                    GoldMint.Economy:ScheduleRefresh("wealth_navigation", 0.05)
                end
                Refresh()
                local wealthGeneration = (frame._wealthRefreshGeneration or 0) + 1
                frame._wealthRefreshGeneration = wealthGeneration
                local function queueWealthRefresh(delay)
                    C_Timer.After(delay, function()
                        if frame and frame:IsShown() and activeNavKey == "wealth" and frame._wealthRefreshGeneration == wealthGeneration then
                            GoldMint:SafeCall("dashboard wealth repaint", Refresh)
                        end
                    end)
                end
                queueWealthRefresh(0)
                queueWealthRefresh(0.10)
                queueWealthRefresh(0.35)
            end
        end
        for i,name in ipairs(tabs) do local tabLabel = (name == "recipes") and "CRAFTING" or name:upper(); local b=MakeButton(view,tabLabel,130,30,"secondary"); b:SetPoint("TOPLEFT",22+(i-1)*142,-84); b:SetScript("OnClick",function() show(name) end); tabButtons[name]=b end
        panels.operationsShow = show
        view:SetScript("OnShow",function() show(section or "inventory") end); panels.operationsView=view
    end
    SetHomePanelsShown(false)
    if panels.projectsView then panels.projectsView:Hide() end
    panels.operationsView:Show(); panels.operationsView:Raise()
    if panels.operationsShow then
        panels.operationsShow(section or "inventory")
    end
    SetNavigationActive(section or "inventory")
end

function Dashboard:OpenSettings()
    -- Settings is a separate GoldMint window. Opening it closes the dashboard
    -- so the two large interfaces never overlap.
    if GoldMint.OpenOptions then
        GoldMint:OpenOptions()
    end
end

function Dashboard:OpenCooldownRecipe(recipeID)
    recipeID = tonumber(recipeID)
    if not recipeID then return end

    if OpenOperations then
        OpenOperations("cooldowns")
    end

    local page = panels.cooldownsPage
    if not page then return end

    page._focusRecipeID = recipeID
    page.filter = "READY"
    if page.filterText then
        page.filterText:SetText("READY")
    end
    if page.Refresh then
        page:Refresh()
    end

    -- Bring the focused recipe into view after the rows have been rebuilt.
    if page.rows and page.scroll then
        for i, row in ipairs(page.rows) do
            if row:IsShown() and tonumber(row.recipeID) == recipeID then
                local target = math.max(0, (i - 1) * 78 - 20)
                page.scroll:SetVerticalScroll(target)
                if page.scroll.UpdateGoldMintScrollBar then
                    page.scroll:UpdateGoldMintScrollBar()
                end
                break
            end
        end
    end
end

function Dashboard:ShowHome()
    if cooldownFilterMenu then cooldownFilterMenu:Hide() end
    if panels.operationsView then panels.operationsView:Hide() end
    if panels.projectsView then panels.projectsView:Hide() end
    SetHomePanelsShown(true)
    SetNavigationActive("dashboard")
    Refresh()
end

local function BuildNavigation()
    local nav = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    nav:SetPoint("TOPLEFT", 20, -126)
    nav:SetSize(190, 570)
    nav:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true,
        tileSize = 16,
        edgeSize = 1,
    })
    nav:SetBackdropColor(0.004, 0.020, 0.040, 1.0)
    nav:SetBackdropBorderColor(0.10, 0.42, 0.66, 0.85)
    panels.nav = nav

    local items = {
        {"Home", "dashboard", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavHome"},
        {"Wealth", "wealth", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavWealth"},
        {"Cooldowns", "cooldowns", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavCooldowns"},
        {"Inventory", "inventory", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavInventory"},
        {"Crafting", "recipes", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavCrafting"},
        {"Market", "market", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavMarket"},
        {"Routines", "routines", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavRoutines"},
        {"Projects", "projects", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavProjects"},
    }

    for i, item in ipairs(items) do
        local b = CreateFrame("Button", nil, nav, "BackdropTemplate")
        b:SetSize(188, 48)
        b:SetPoint("TOPLEFT", 0, -((i - 1) * 51))
        b:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            tile = true, tileSize = 16,
        })
        b:SetBackdropColor(0, 0, 0, 0)
        if item[3] then
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetTexture(item[3])
            b.icon:SetSize(34, 34)
            b.icon:SetPoint("CENTER", -44, 0)

            -- Keep the navigation labels beside their icons.  Use a bold
            -- outlined font so the cyan lettering stays crisp over the dark UI.
            b.text = MakeLabel(b, "GameFontNormal", item[1], 108)
            b.text:SetPoint("LEFT", 76, 0)
            b.text:SetJustifyH("LEFT")
            local font, _, _ = b.text:GetFont()
            if font then
                b.text:SetFont(font, 13, "OUTLINE")
            end
            b.text:SetShadowOffset(1, -1)
            b.text:SetTextColor(unpack(CYAN))
            b.text:SetWordWrap(false)
        else
            b.text = MakeLabel(b, "GameFontNormal", item[1])
            b.text:SetPoint("LEFT", 22, 0)
            b.text:SetShadowOffset(1, -1)
            b.text:SetTextColor(unpack(MUTED))
        end
        -- Horizontal cyan accent under every navigation icon.
        local navLine = b:CreateTexture(nil, "ARTWORK")
        navLine:SetColorTexture(0.30, 0.90, 1.0, 1.0)
        navLine:SetSize(150, 2)
        navLine:SetPoint("TOPLEFT", 20, -43)

        local navLineGlow = b:CreateTexture(nil, "BACKGROUND")
        navLineGlow:SetColorTexture(0.20, 0.78, 1.0, 0.32)
        navLineGlow:SetSize(154, 6)
        navLineGlow:SetPoint("CENTER", navLine, "CENTER", 0, 0)

        local accent = b:CreateTexture(nil, "ARTWORK")
        accent:SetColorTexture(0.08, 0.78, 1.0, 0.95)
        accent:SetSize(3, 48)
        accent:SetPoint("TOPLEFT", 0, 0)
        accent:Hide()
        b.accent = accent

        b:SetScript("OnEnter", function(self)
            if activeNavKey ~= item[2] then
                ApplyNavState(self, false, true)
            end
        end)
        b:SetScript("OnLeave", function(self)
            if activeNavKey == item[2] then
                ApplyNavState(self, true, false)
            else
                ApplyNavState(self, false, false)
            end
        end)
        navButtons[item[2]] = b

        if item[2] == "dashboard" then
            b:SetScript("OnClick", function()
                if cooldownFilterMenu then cooldownFilterMenu:Hide() end
                if panels.operationsView then panels.operationsView:Hide() end
                if panels.projectsView then panels.projectsView:Hide() end
                            SetHomePanelsShown(true)
                SetNavigationActive("dashboard")
                Refresh()
            end)
        elseif item[2] == "projects" then
            b:SetScript("OnClick", function()
                if cooldownFilterMenu then cooldownFilterMenu:Hide() end
                            SetNavigationActive("projects")
                OpenProjects()
            end)
        elseif item[2] == "cooldowns" or item[2] == "routines" or item[2] == "inventory" or item[2] == "recipes" or item[2] == "market" or item[2] == "wealth" then
            b:SetScript("OnClick", function() OpenOperations(item[2]) end)
        end
    end

    SetNavigationActive("dashboard")

    -- Footer brand artwork uses the newly supplied horizontal GoldMint mark.
    local footerLogo = nav:CreateTexture(nil, "ARTWORK")
    footerLogo:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintFooter")
    footerLogo:SetSize(165, 79)
    footerLogo:SetPoint("BOTTOMLEFT", 18, -105)
    footerLogo:SetTexCoord(0, 1, 0, 1)
    panels.footerLogo = footerLogo
end

local function GetMinimapSettings()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    local settings = GoldMintDB.settings
    if settings.minimapButtonShown == nil then settings.minimapButtonShown = true end
    if settings.minimapButtonAngle == nil then settings.minimapButtonAngle = 45 end
    return settings
end

local function PositionMinimapButton()
    if not minimapButton or not Minimap then return end
    local settings = GetMinimapSettings()
    local angle = math.rad(tonumber(settings.minimapButtonAngle) or 45)
    -- Keep the 60px button completely outside the minimap's circular edge.
    -- Calculate from the live minimap size so UI scaling/custom minimap sizes
    -- cannot pull the button back inside the map.
    local mapSize = tonumber(Minimap:GetWidth()) or 176
    local radius = (mapSize * 0.5) + 36
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

function Dashboard:BuildMinimapButton()
    if minimapButton or not Minimap then
        return
    end

    GetMinimapSettings()

    minimapButton = CreateFrame("Button", "GoldMintMinimapButton", UIParent)
    minimapButton:SetSize(60, 60)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel(20)
    minimapButton:SetClampedToScreen(true)
    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    minimapButton:RegisterForDrag("LeftButton")

    local icon = minimapButton:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintMinimap")
    icon:SetSize(54, 54)
    icon:SetPoint("CENTER")
    icon:SetTexCoord(0, 1, 0, 1)

    -- No external tracking ring: the GoldMint logo is the complete button artwork.
    -- Keeping the button clean prevents a detached green/cyan ring from
    -- appearing around the icon.

    minimapButton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    PositionMinimapButton()

    minimapButton._dragging = false
    minimapButton._moved = false
    minimapButton._startX = 0
    minimapButton._startY = 0

    minimapButton:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        local x, y = GetCursorPosition()
        self._startX, self._startY = x, y
        self._moved = false
        self._dragging = true
    end)

    minimapButton:SetScript("OnUpdate", function(self)
        if not self._dragging or not IsMouseButtonDown("LeftButton") or not Minimap then
            return
        end

        local x, y = GetCursorPosition()
        local scale = UIParent:GetEffectiveScale()
        x, y = x / scale, y / scale
        local centerX, centerY = Minimap:GetCenter()
        if not centerX or not centerY then return end

        local dx, dy = x - centerX, y - centerY
        if (dx * dx + dy * dy) < 1 then return end

        if math.abs(x - self._startX / scale) > 4 or math.abs(y - self._startY / scale) > 4 then
            self._moved = true
        end

        if self._moved then
            local angle = math.deg(math.atan2(dy, dx))
            GetMinimapSettings().minimapButtonAngle = angle
            PositionMinimapButton()
        end
    end)

    minimapButton:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" then
            self._dragging = false
        end
    end)

    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("GoldMint")
        GameTooltip:AddLine("Left-click: Open Dashboard", 0.72, 0.84, 0.96)
        GameTooltip:AddLine("Right-click: Gold Per Hour", 0.72, 0.84, 0.96)
        GameTooltip:AddLine("Middle-click: World Quests List", 0.72, 0.84, 0.96)
        GameTooltip:AddLine("Drag: Move around the minimap", 0.72, 0.84, 0.96)
        GameTooltip:Show()
    end)
    minimapButton:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    minimapButton:SetScript("OnClick", function(self, button)
        if self._moved then
            self._moved = false
            return
        end

        if button == "LeftButton" then
            -- Left-click opens the full GoldMint dashboard.
            Dashboard:Toggle()
        elseif button == "RightButton" then
            -- Right-click opens the floating Gold Per Hour farming tracker.
            if GoldMint.FarmTracker then
                if GoldMint.FarmTracker.EnsureFrame then
                    GoldMint.FarmTracker:EnsureFrame()
                end
                if GoldMint.FarmTracker.OnMinimapClick then
                    GoldMint.FarmTracker:OnMinimapClick()
                elseif GoldMint.FarmTracker.Toggle then
                    GoldMint.FarmTracker:Toggle()
                end
            end
        elseif button == "MiddleButton" then
            -- Middle-click opens the standalone manual World Quests popout.
            if GoldMint.ToDoPopout and GoldMint.ToDoPopout.Toggle then
                GoldMint.ToDoPopout:Toggle()
            end
        end

        self._moved = false
    end)

    minimapButton:SetShown(GetMinimapSettings().minimapButtonShown ~= false)
    panels.minimapButton = minimapButton
end

local function RefreshGoal(status)
    local widget = panels.goalWidget
    if not widget then return end

    if not status then
        widget.Title:SetText("YOUR GOAL: No active goal")
        widget.ProgressArc.Text:SetText("0%")
        widget.PacingText:SetText("Current Pacing: —")
        widget.EstText:SetText("Goal Est: —")
        if widget.ProgressArc.Fill then widget.ProgressArc.Fill:Hide() end
        if widget.ProgressLine then
            widget.ProgressLine:SetValue(0)
        end
        for _, seg in ipairs(widget.ProgressArc._fallbackSegments or {}) do seg:Hide() end
        return
    end

    local progress = math.max(0, math.min(1, tonumber(status.progress) or 0))
    local current = tonumber(status.currentValue) or 0
    local target = tonumber(status.target) or 0
    local weekly = status.weekly or {}

    widget.Title:SetText("YOUR GOAL: " .. tostring(status.name or "Savings Goal"))
    widget.ProgressArc.Text:SetText(string.format("%d%%", math.floor(progress * 100 + 0.5)))

    if weekly.status == "ahead" then
        widget.PacingText:SetText("Current Pacing: Ahead by " .. FormatGold(math.abs(tonumber(weekly.aheadBehind) or 0)))
        widget.PacingText:SetTextColor(unpack(GREEN))
    elseif weekly.status == "behind" then
        widget.PacingText:SetText("Current Pacing: Behind by " .. FormatGold(math.abs(tonumber(weekly.aheadBehind) or 0)))
        widget.PacingText:SetTextColor(unpack(RED))
    elseif weekly.status == "complete" then
        widget.PacingText:SetText("Current Pacing: Goal complete")
        widget.PacingText:SetTextColor(unpack(GREEN))
    elseif weekly.status == "baseline" then
        widget.PacingText:SetText("Current Pacing: " .. FormatGold(math.max(0, tonumber(weekly.actual) or 0)) .. " / 7 days")
        widget.PacingText:SetTextColor(unpack(MUTED))
    else
        widget.PacingText:SetText("Current Pacing: Building baseline")
        widget.PacingText:SetTextColor(unpack(MUTED))
    end

    local dailyRate = math.max(0, (tonumber(weekly.actual) or 0) / 7)
    local remaining = math.max(target - current, 0)
    local estimateDays
    if remaining <= 0 then
        estimateDays = 0
    elseif dailyRate > 0 then
        estimateDays = math.ceil(remaining / dailyRate)
    end

    if estimateDays then
        widget.EstText:SetText(estimateDays > 0 and ("Goal Est: " .. tostring(estimateDays) .. " days") or "Goal Est: Reached")
    else
        widget.EstText:SetText("Goal Est: —")
    end
    widget.EstText:SetTextColor(unpack(MUTED))

    UpdateGoldProgress(widget, current, target)
end

local function GetDailyProfit()
    if GoldMint.Ledger and GoldMint.Ledger.GetDailyEconomics then
        local daily = GoldMint.Ledger:GetDailyEconomics() or {}
        return tonumber(daily.net) or 0
    end
    return 0
end

local function GetWeeklyProfitSeries()
    local now = time()
    local today = GoldMint.Ledger and GoldMint.Ledger.GetDailyEconomics and GoldMint.Ledger:GetDailyEconomics() or {}
    local todayReset = tonumber(today.resetAt) or now
    local history = GoldMint.Ledger and GoldMint.Ledger.GetDailyHistory and GoldMint.Ledger:GetDailyHistory() or {}

    local byReset = {}
    for _, entry in ipairs(history) do
        byReset[tonumber(entry.resetAt) or 0] = tonumber(entry.net) or 0
    end
    byReset[todayReset] = tonumber(today.net) or 0

    local series = {}
    local total = 0
    local runningTotal = 0
    local daySeconds = 86400
    for i = 6, 0, -1 do
        local startOfDay = todayReset - (i * daySeconds)
        local value = byReset[startOfDay] or 0
        runningTotal = runningTotal + value
        series[#series + 1] = {startOfDay, runningTotal}
        total = total + value
    end

    return series, total
end

local function GetHeaderIntention()
    -- Mirror the first/highlighted task shown in Daily Focus.  Daily Focus
    -- orders ready work first, so the header always reflects the task currently
    -- receiving the player's attention there.
    local state = GoldMint.RoutineState
    if state and state.GetRelevantActivities then
        local activities = state:GetRelevantActivities(GoldMint.characterKey, { currentOnly = true, season = 2 }) or {}
        local daily = {}
        for _, activity in ipairs(activities) do
            if tostring(activity and activity.frequency or "") == "Daily" then
                daily[#daily + 1] = activity
            end
        end

        local rank = { ready = 1, unknown = 2, completed = 3, scheduled = 4 }
        table.sort(daily, function(a, b)
            local ar = rank[a.status] or 5
            local br = rank[b.status] or 5
            if ar ~= br then return ar < br end
            return tostring(a.title or "") < tostring(b.title or "")
        end)

        if daily[1] and daily[1].title and tostring(daily[1].title) ~= "" then
            return tostring(daily[1].title)
        end
    end

    -- If Daily Focus has no observed task, fall back to the player's explicit
    -- workflow task rather than leaving the header misleadingly taskless.
    local workflow = GoldMint.WorkflowState
    if workflow and workflow.GetCurrentTask then
        local task = workflow:GetCurrentTask()
        if task and task.title and tostring(task.title) ~= "" then
            return tostring(task.title)
        end
    end

    return "—"
end

function Refresh()
    -- Keep the dashboard focused on a single clear next step when enabled.
    -- The panel can be hidden from Options without changing workflow state.
    if panels.next then
        local settings = GoldMintDB and GoldMintDB.settings
        -- YOUR NEXT STEP belongs to the Home dashboard only. Refresh() also
        -- runs while Wealth/Operations pages are visible, so never let a
        -- dashboard refresh re-show this panel over another page.
        local onHome = activeNavKey == "dashboard"
        panels.next:SetShown(onHome and not (settings and settings.oneClearNextStep == false))
    end
    if not frame then return end
    if GoldMint:IsMerchantOpen() then
        -- Do not synchronously force Economy while a vendor is visible. The core
        -- post-merchant refresh will update the dashboard once the inventory settles.
        return
    end

    local status = GoldMint.Economy and GoldMint.Economy:GetStatus() or nil
    local session = status and status.session or nil
    -- Normalize session metrics before the dashboard compares or formats them.
    -- Older/partial Economy status payloads may omit these fields during login.
    local net = session and tonumber(session.netGold) or 0
    local rate = session and tonumber(session.goldPerHour) or 0
    local totalGold = 0
    local wallet = status and status.wallet or nil
    local valuation = status and status.valuation or nil
    local market = status and status.market or nil
    local mail = status and status.mail or nil
    local crafting = status and status.crafting or nil
    local milestoneSummary = status and status.milestones or nil

    -- Gold Total is the actual currency total: current character gold +
    -- Warbank gold, plus the selected Guild Bank's gold when a guild is
    -- explicitly selected. Guild Bank item value is not counted here because
    -- this header is a gold/currency total, not net worth.
    local displayGold = GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney() or 0
    displayGold = tonumber(displayGold) or 0
    local displayWarbankGold = wallet and tonumber(wallet.warbandGold) or 0
    local displayGuildGold = 0
    local selectedHeaderGuild = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
    if selectedHeaderGuild and GoldMint.Valuation and GoldMint.Valuation.GetGoldMakingGuildBankValue then
        local headerGuildData = GoldMint.Valuation:GetGoldMakingGuildBankValue()
        if headerGuildData and headerGuildData.tracked == true then
            displayGuildGold = tonumber(headerGuildData.gold) or 0
        end
    end
    local goldTotal = displayGold + displayWarbankGold + displayGuildGold
    SetText("headerGold", FormatGold(goldTotal))
    SetText("headerValue", "Gold Total")

    -- The old weekly metric is now the live Daily Focus intention.
    SetText("headerWeek", GetHeaderIntention())
    SetText("headerWeekLabel", "Intention")

    -- Session Velocity has been removed from the header.

    -- Mail indicator replaces the duplicated Daily Profit header metric.
    -- MailTracking only reports what has actually been observed for the current
    -- character; if the mailbox has never been scanned, do not guess.
    local mailSummary = GoldMint.MailTracking and GoldMint.MailTracking.GetSummary and GoldMint.MailTracking:GetSummary() or nil
    if mailSummary then
        local scanned = tonumber(mailSummary.lastScanAt) or 0
        local mailCount = tonumber(mailSummary.mailCount) or 0
        local attachmentCount = tonumber(mailSummary.attachmentCount) or 0
        local unreadCount = tonumber(mailSummary.unreadCount) or 0
        if scanned <= 0 then
            if labels.mailIcon then labels.mailIcon:Hide() end
            labels.mailStatus:SetPoint("TOPLEFT", 10, -27)
            labels.mailStatus:SetWidth(146)
            SetText("mailStatus", "NOT SCANNED")
            SetStatus(labels.mailStatus, "muted")
            SetText("mailDetail", "Open mailbox to check")
        elseif mailCount > 0 or attachmentCount > 0 then
            if labels.mailIcon then labels.mailIcon:Show() end
            SetText("mailStatus", "MAIL WAITING")
            SetStatus(labels.mailStatus, "profit")
            local detail = string.format("%d message%s", mailCount, mailCount == 1 and "" or "s")
            if attachmentCount > 0 then
                detail = detail .. string.format(" • %d attachment%s", attachmentCount, attachmentCount == 1 and "" or "s")
            elseif unreadCount > 0 then
                detail = detail .. string.format(" • %d unread", unreadCount)
            end
            SetText("mailDetail", detail)
        else
            if labels.mailIcon then labels.mailIcon:Hide() end
            labels.mailStatus:SetPoint("TOPLEFT", 10, -27)
            labels.mailStatus:SetWidth(146)
            SetText("mailStatus", "NO MAIL")
            SetStatus(labels.mailStatus, "muted")
            SetText("mailDetail", "Mailbox is clear")
        end
    else
        if labels.mailIcon then labels.mailIcon:Hide() end
        labels.mailStatus:SetPoint("TOPLEFT", 10, -27)
        labels.mailStatus:SetWidth(146)
        SetText("mailStatus", "NOT SCANNED")
        SetStatus(labels.mailStatus, "muted")
        SetText("mailDetail", "Open mailbox to check")
    end

    -- WoW Token card uses the same visual language.  The small graph is fed
    -- by the same 24-hour token history used by the Market backend.
    local tokenHistory = GoldMint.Market and GoldMint.Market.GetTokenHistory and GoldMint.Market:GetTokenHistory(24) or {}
    local tokenCurrent = GoldMint.Market and GoldMint.Market.GetCurrentTokenPrice and GoldMint.Market:GetCurrentTokenPrice() or nil
    for _, line in ipairs(labels.tokenGraphLines or {}) do line:Hide() end
    labels.tokenTrend:Hide()

    if #tokenHistory > 8 then
        local sampled = {}
        local step = (#tokenHistory - 1) / 7
        for i = 0, 7 do
            local index = math.floor(i * step + 1.5)
            sampled[#sampled + 1] = tokenHistory[math.min(index, #tokenHistory)]
        end
        tokenHistory = sampled
    end

    if #tokenHistory >= 2 then
        local minPrice, maxPrice = math.huge, -math.huge
        for _, point in ipairs(tokenHistory) do
            local price = tonumber(point.price) or 0
            minPrice = math.min(minPrice, price); maxPrice = math.max(maxPrice, price)
        end
        local span = math.max(maxPrice - minPrice, math.max(maxPrice * 0.005, 1))
        minPrice = minPrice - span * 0.10; maxPrice = maxPrice + span * 0.10; span = maxPrice - minPrice
        local n = #tokenHistory
        for i = 1, math.min(n - 1, #labels.tokenGraphLines) do
            local p1, p2 = tokenHistory[i], tokenHistory[i + 1]
            local a = tonumber(p1.price) or 0
            local b = tonumber(p2.price) or 0
            local x1 = ((i - 1) / (n - 1)) * 62
            local x2 = (i / (n - 1)) * 62
            local y1 = ((a - minPrice) / span) * 42
            local y2 = ((b - minPrice) / span) * 42
            local dx, dy = x2 - x1, y2 - y1
            local len = math.sqrt(dx * dx + dy * dy)
            local line = labels.tokenGraphLines[i]
            line:ClearAllPoints(); line:SetSize(math.max(len, 1), 2)
            line:SetPoint("CENTER", labels.tokenIconBox, "BOTTOMLEFT", 5 + (x1 + x2) * 0.5, 5 + (y1 + y2) * 0.5)
            line:SetRotation(math.atan2(dy, dx)); line:Show()
        end

        local current = tonumber(tokenHistory[#tokenHistory].price) or tokenCurrent or 0
        local first = tonumber(tokenHistory[1].price) or current
        local delta = current - first
        labels.tokenValue:SetText(current > 0 and FormatTokenPrice(current) or "—")
        if delta > 0 then
            labels.tokenValue:SetTextColor(unpack(GREEN))
            labels.tokenTrend:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintTokenUp")
            labels.tokenTrend:Show()
        elseif delta < 0 then
            labels.tokenValue:SetTextColor(unpack(RED))
            labels.tokenTrend:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintTokenDown")
            labels.tokenTrend:Show()
        else
            labels.tokenValue:SetTextColor(unpack(GOLD))
        end
    elseif tokenCurrent then
        labels.tokenValue:SetText(FormatTokenPrice(tokenCurrent))
        labels.tokenValue:SetTextColor(unpack(GOLD))
    else
        labels.tokenValue:SetText("—")
        labels.tokenValue:SetTextColor(unpack(GOLD))
    end

    -- Keep the embedded Wealth page live without rebuilding its frames.
    if activeNavKey == "wealth" and wealthLiveLabels._built then
        local liveWallet = GoldMint.Ledger and GoldMint.Ledger:GetAccountWallet() or {warbandGold=0}
        local livePersonal = GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney() or 0
        livePersonal = tonumber(livePersonal) or 0
        local liveSelectedGuild = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
        local liveWarband = tonumber(liveWallet.warbandGold) or 0
        local liveHoard = GoldMint.Valuation and GoldMint.Valuation:GetKnownHoardValue() or {total=0,accountBank=0}
        local liveGuildBank = 0
        local liveGuildBankGold = 0
        local liveGuildBankData = nil
        if liveSelectedGuild and GoldMint.Valuation and GoldMint.Valuation.GetGoldMakingGuildBankValue then
            liveGuildBankData = GoldMint.Valuation:GetGoldMakingGuildBankValue()
            if liveGuildBankData and liveGuildBankData.tracked == true then
                liveGuildBank = tonumber(liveGuildBankData.value) or 0
                liveGuildBankGold = tonumber(liveGuildBankData.gold) or 0
            end
        end
        local liveInventory = tonumber(liveHoard.currentCharacter) or 0
        local liveMail = 0
        if GoldMint.MailTracking and GoldMint.MailTracking.GetAccountExternalMoneyTotal then
            liveMail = tonumber(GoldMint.MailTracking:GetAccountExternalMoneyTotal()) or 0
        end
        local liveAuction = GoldMint.Market and GoldMint.Market.GetOwnedAuctionValue and GoldMint.Market:GetOwnedAuctionValue() or 0
        local liveWarbankVault = liveWarband
        -- Use the complete known account-wide item hoard for net worth rather than
        -- only the currently logged-in character's inventory.
        local liveAccountItemValue = tonumber(liveHoard.total) or 0
        local liveNetWorth = livePersonal + liveWarbankVault + liveAccountItemValue + liveMail + liveAuction + liveGuildBank
        local liveGoldTotal = livePersonal + liveWarbankVault + liveGuildBankGold
        if labels.headerGold then labels.headerGold:SetText(FormatGold(liveGoldTotal)) end
        if labels.headerValue then labels.headerValue:SetText("Gold Total") end
        local liveAccountItemValue = tonumber(liveHoard.total) or 0
        local liveGuildAssetValue = liveSelectedGuild and math.max(liveGuildBank - liveGuildBankGold, 0) or 0
        local liveParts = {
            {key="Liquid Gold", value=livePersonal + liveWarband + liveGuildBankGold, color=GOLD},
            {key="AH Value", value=liveAuction, color={0.92,0.30,0.28}},
            {key="Assets", value=math.max(liveAccountItemValue + liveMail + liveGuildAssetValue, 0), color=GREEN},
        }
        local liveKnown = 0
        for _, part in ipairs(liveParts) do liveKnown = liveKnown + math.max(tonumber(part.value) or 0, 0) end
        liveKnown = math.max(liveKnown, 1)
        if wealthLiveLabels.netWorth then wealthLiveLabels.netWorth:SetText(FormatWealthAmount(liveNetWorth)) end
        if wealthLiveLabels.allocationCenter then wealthLiveLabels.allocationCenter:SetText(FormatWholeGold(liveNetWorth)) end
        if wealthLiveLabels.bankValue then
            if liveSelectedGuild and liveGuildBankData and liveGuildBankData.tracked == true then
                wealthLiveLabels.bankValue:SetText(FormatWealthAmount(liveGuildBank))
            elseif liveSelectedGuild then
                wealthLiveLabels.bankValue:SetText("Scan guild bank")
            end
        end
        for _, part in ipairs(liveParts) do
            local valueLabel = wealthLiveLabels[part.key .. "Value"]
            local pctLabel = wealthLiveLabels[part.key .. "Pct"]
            if valueLabel then valueLabel:SetText(FormatWealthAmount(part.value)) end
            if pctLabel then pctLabel:SetText(math.floor(((tonumber(part.value) or 0) / liveKnown) * 100 + 0.5) .. "%") end
        end
        local allocationLive = wealthLiveLabels.allocation
        if allocationLive and allocationLive.apply then
            allocationLive.apply(liveParts)
        end
        -- Keep the pacing tower live as milestone progress changes.
        if wealthLiveLabels.goalRail and wealthLiveLabels.goalRail.fill and GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal then
            local liveGoal = GoldMint.Milestones:GetActiveGoal()
            local liveGoalPct = liveGoal and math.max(0, math.min(1, tonumber(liveGoal.progress) or 0)) or 0
            wealthLiveLabels.goalRail.fill:SetWidth(math.max(2, 305 * liveGoalPct))
            if wealthLiveLabels.goalPercent then
                wealthLiveLabels.goalPercent:SetText(string.format("%d%%", math.floor(liveGoalPct * 100 + 0.5)))
            end
        end
        -- Refresh the activity feed without rebuilding the Wealth page.
        if wealthLiveLabels.activityRows then
            local liveSession = GoldMint.Ledger and GoldMint.Ledger:GetSession() or nil
            local liveTx = liveSession and liveSession.transactions or {}
            local liveRows = {}
            for i=#liveTx,1,-1 do
                local t=liveTx[i]
                if type(t)=="table" and t.type~="transfer" then
                    liveRows[#liveRows+1]=t
                    if #liveRows>=#wealthLiveLabels.activityRows then break end
                end
            end
            for i,row in ipairs(wealthLiveLabels.activityRows) do
                local t=liveRows[i]
                if t then
                    local amount=tonumber(t.amount) or 0
                    local txTime=tonumber(t.time)
                    row.source:SetText(txTime and date("%b %d, %Y %I:%M %p",txTime) or "")
                    local source=tostring(t.source or "")
                    local typeText,typeColor
                    if string.find(source,"Auction House Sale",1,true) or string.find(source,"Vendor Sale",1,true) then typeText,typeColor="Sale",GREEN
                    elseif string.find(source,"Purchase",1,true) or t.type=="spending" then typeText,typeColor="Purchase",RED
                    elseif amount>0 and string.find(source,"Deposit",1,true) then typeText,typeColor="Deposit",CYAN
                    else typeText,typeColor=amount>=0 and "Income" or "Change",amount>=0 and GREEN or RED end
                    row.type:SetText(typeText); row.type:SetTextColor(unpack(typeColor))
                    local itemName=""; local icon=nil
                    if t.itemID and C_Item then
                        if C_Item.GetItemNameByID then local ok,n=pcall(C_Item.GetItemNameByID,t.itemID); if ok then itemName=n or "" end end
                        if C_Item.GetItemIconByID then local ok,v=pcall(C_Item.GetItemIconByID,t.itemID); if ok then icon=v end end
                    end
                    row.detail:SetText(itemName~="" and itemName or source)
                    if icon then row.icon:SetTexture(icon); row.icon:Show() else row.icon:Hide() end
                    row.amount:SetText((amount>=0 and "+" or "-")..FormatGold(math.abs(amount))); row.amount:SetTextColor(unpack(amount>=0 and GREEN or RED))
                    row.origin:SetText(source~="" and source or "Wallet")
                else
                    row.source:SetText(""); row.type:SetText(""); row.detail:SetText(""); row.amount:SetText(""); row.origin:SetText(""); row.icon:Hide()
                end
            end
        end
        -- Value Trend is event-driven: it only redraws after Ledger records
        -- a qualifying sale or looted-gold event. Ordinary PLAYER_MONEY changes
        -- and Warbank transfers are deliberately ignored.
        if wealthLiveLabels.sessionStart and panels.wealthPage and panels.wealthPage.RefreshSessionSummary then
            panels.wealthPage:RefreshSessionSummary()
        end

        local trendLive = wealthLiveLabels.trend
        if trendLive and trendLive.chart and GoldMint.Ledger and GoldMint.Ledger.GetTrendPoints then
            local points = GoldMint.Ledger:GetTrendPoints() or {}
            local count = #points
            if trendLive.lastTrendCount ~= count then
                trendLive.lastTrendCount = count
                local minV, maxV, pointCount = trendLive.draw(points)
                trendLive.lastRenderedCount = pointCount or 0
                if trendLive.maxLabel then trendLive.maxLabel:SetText(maxV and FormatWealthAmount(maxV) or "") end
                if trendLive.minLabel then trendLive.minLabel:SetText(minV and FormatWealthAmount(minV) or "") end
            end
        end
    end

    local goal = nil
    if GoldMint.Milestones and GoldMint.Milestones.GetGoals then
        local goals = GoldMint.Milestones:GetGoals() or {}
        for _, candidate in ipairs(goals) do
            if not candidate.completeAt and tonumber(candidate.progress or 0) < 1 then
                goal = candidate
                break
            end
        end
        if not goal and goals[1] and tonumber(goals[1].progress or 0) < 1 then
            goal = goals[1]
        end
    end
    RefreshGoal(goal)

    local dailyEconomics = GoldMint.Ledger and GoldMint.Ledger.GetDailyEconomics and GoldMint.Ledger:GetDailyEconomics() or {}
    local dailyVelocity = tonumber(dailyEconomics.velocityGoldPerHour) or 0
    local dailyProfitRate = tonumber(dailyEconomics.profitPerHour) or 0

    local weekSeries, weekTotal = GetWeeklyProfitSeries()
    -- Always normalize weekly dashboard values before numeric comparisons.
    -- This protects the refresh path if an older/partial data source returns nil.
    weekSeries = type(weekSeries) == "table" and weekSeries or {}
    weekTotal = tonumber(weekTotal) or 0
    SetText("momentumStatus", "This Week")
    SetText("momentumEarnedValue", (weekTotal >= 0 and "+" or "") .. FormatProfitGold(weekTotal))
    SetStatus(labels.momentumEarnedValue, weekTotal >= 0 and "profit" or "warning")
    SetText("momentumSpentValue", "Velocity: " .. ((dailyVelocity >= 0 and "+" or "") .. FormatRate(dailyVelocity) .. "/hr"))
    SetStatus(labels.momentumSpentValue, dailyProfitRate >= 0 and "profit" or "warning")
    SetText("momentumHint", "Today • since daily reset")
    SetText("momentumWeekTotal", "Total Week: " .. ((weekTotal >= 0 and "+" or "") .. FormatProfitGold(weekTotal)))

    local lines = labels.momentumGraphLines or {}
    local graphPoints = labels.momentumGraphPoints or {}
    local graphFill = labels.momentumGraphFill or {}
    local area = labels.momentumGraphArea
    if area and #weekSeries >= 2 then
        local minV, maxV = math.huge, -math.huge
        for _, point in ipairs(weekSeries) do
            minV = math.min(minV, tonumber(point[2]) or 0)
            maxV = math.max(maxV, tonumber(point[2]) or 0)
        end

        local span = maxV - minV
        if span < 1 then span = 1 end
        local points = {}
        for i, point in ipairs(weekSeries) do
            local value = tonumber(point[2]) or 0
            local normalized = (value - minV) / span
            -- In the WoW frame coordinate system, smaller Y is higher on
            -- screen. This keeps rising profit visually rising on the graph.
            local x = area.x + ((i - 1) / (#weekSeries - 1)) * area.w
            local y = area.y + ((1 - normalized) * area.h)
            points[#points + 1] = {x, y}
        end

        -- Draw the translucent filled area beneath the line. The strips are
        -- narrow enough to read as a continuous polygon at normal UI scale.
        local stripCount = #graphFill
        for i = 1, stripCount do
            local stripX = (i - 1) * 2
            local fraction = stripCount > 1 and ((i - 1) / (stripCount - 1)) or 0
            local pointPosition = fraction * (#points - 1) + 1
            local leftIndex = math.floor(pointPosition)
            local rightIndex = math.min(#points, leftIndex + 1)
            local localFraction = pointPosition - leftIndex
            local y = points[leftIndex][2]
            if points[rightIndex] and rightIndex ~= leftIndex then
                y = y + (points[rightIndex][2] - y) * localFraction
            end
            local fill = graphFill[i]
            fill:ClearAllPoints()
            fill:SetPoint("TOPLEFT", panels.momentum, "TOPLEFT", area.x + stripX, -(y))
            fill:SetHeight(math.max(1, area.y + area.h - y))
            fill:Show()
        end

        for i = 1, #lines do
            local line = lines[i]
            if points[i] and points[i + 1] then
                local x1, y1 = points[i][1], points[i][2]
                local x2, y2 = points[i + 1][1], points[i + 1][2]
                local dx, dy = x2 - x1, y2 - y1
                local length = math.sqrt(dx * dx + dy * dy)
                line:ClearAllPoints()
                line:SetSize(math.max(2, length), 2)
                line:SetPoint("CENTER", panels.momentum, "TOPLEFT", (x1 + x2) * 0.5, -((y1 + y2) * 0.5))
                line:SetRotation(math.atan2(-dy, dx))
                line:Show()
            else
                line:Hide()
            end
        end

        for i = 1, #graphPoints do
            local marker = graphPoints[i]
            local point = points[i]
            if point then
                marker.glow:ClearAllPoints()
                marker.glow:SetPoint("CENTER", panels.momentum, "TOPLEFT", point[1], -point[2])
                marker.glow:Show()
                marker.dot:ClearAllPoints()
                marker.dot:SetPoint("CENTER", panels.momentum, "TOPLEFT", point[1], -point[2])
                if i == #points then
                    marker.dot:SetColorTexture(0.25, 0.85, 0.95, 1.0)
                    marker.glow:SetColorTexture(0.25, 0.85, 0.95, 0.22)
                else
                    marker.dot:SetColorTexture(0.78, 0.90, 0.91, 0.98)
                    marker.glow:SetColorTexture(0.18, 0.72, 0.82, 0.16)
                end
                marker.dot:Show()
            else
                marker.glow:Hide()
                marker.dot:Hide()
            end
        end
    else
        for _, line in ipairs(lines) do line:Hide() end
        for _, marker in ipairs(graphPoints) do
            marker.glow:Hide()
            marker.dot:Hide()
        end
        for _, fill in ipairs(graphFill) do fill:Hide() end
    end

    local ready, active, overdue = 0, 0, 0
    if GoldMint.Cooldowns and GoldMint.Cooldowns.GetSummary then
        local readyCount, activeCount = GoldMint.Cooldowns:GetSummary()
        ready = tonumber(readyCount) or 0
        active = tonumber(activeCount) or 0
        -- Cooldowns:GetSummary() currently exposes ready/active only.
        -- Keep the dashboard field stable until an overdue count is added to that API.
        overdue = 0
    end
    RefreshHomeWatchlist()

    SetText("cooldownsReady", string.format("%d Ready", ready))
    SetText("cooldownsActive", string.format("%d On Cooldown", active))
    SetText("cooldownsDetail", "Cross-character profession status")

    if labels.cooldownsCraftNow and GoldMint.Cooldowns and GoldMint.Cooldowns.GetBestReadyProfitableCooldown then
        local bestCooldown = GoldMint.Cooldowns:GetBestReadyProfitableCooldown()
        if bestCooldown then
            labels.cooldownsCraftNow._recipeID = tonumber(bestCooldown.recipeID)
            labels.cooldownsCraftNow._recipeName = bestCooldown.name
            labels.cooldownsCraftNow._characterName = bestCooldown.characterName
            labels.cooldownsCraftNow._profit = bestCooldown.profit
            labels.cooldownsCraftNow.text:SetText("CRAFT NOW")
            labels.cooldownsCraftNow:Show()
        else
            labels.cooldownsCraftNow._recipeID = nil
            labels.cooldownsCraftNow._recipeName = nil
            labels.cooldownsCraftNow._characterName = nil
            labels.cooldownsCraftNow._profit = nil
            labels.cooldownsCraftNow:Hide()
        end
    end

    local mailCount = mail and tonumber(mail.attachmentCount) or 0
    if labels.homeQuickMail then
        labels.homeQuickMail:SetText("Mail")
    end
    if labels.homeQuickMailValue then
        labels.homeQuickMailValue:SetText(tostring(mailCount))
    end

    local profitable = crafting and tonumber(crafting.profitableRecipes) or 0
    if labels.homeQuickRecipes then
        labels.homeQuickRecipes:SetText("Recipes")
    end
    if labels.homeQuickRecipesValue then
        labels.homeQuickRecipesValue:SetText(tostring(profitable))
    end

    local routineAttention = 0
    if GoldMint.RoutineState and GoldMint.RoutineState.GetSummary then
        local rs = GoldMint.RoutineState:GetSummary() or {}
        routineAttention = tonumber(rs.ready or rs.incomplete or rs.attention) or 0
    end
    if labels.homeQuickRoutines then
        labels.homeQuickRoutines:SetText("Routines")
    end
    if labels.homeQuickRoutinesValue then
        labels.homeQuickRoutinesValue:SetText(tostring(routineAttention))
    end

    SetText("sessionStart", FormatGold(session and session.startingGold or 0))
    SetText("sessionEnd", FormatGold(session and session.endingGold or totalGold))
    SetText("sessionNet", (net >= 0 and "+" or "") .. FormatProfitGold(net))
    SetStatus(labels.sessionNet, net >= 0 and "profit" or "warning")
    SetText("sessionRate", (rate >= 0 and "+" or "") .. FormatRate(rate) .. "/hr")
    SetText("sessionStartName", "SESSION PROFIT")
    SetText("sessionEndName", "Current Hourly Rate")

    local top = {}
    if crafting and profitable > 0 then top[#top + 1] = "Crafting " .. tostring(profitable) end
    if market and tonumber(market.trackedItems) then top[#top + 1] = "Market " .. tostring(market.trackedItems) end
    if mailCount > 0 then top[#top + 1] = "Mail " .. tostring(mailCount) end
    SetText("sessionTopSources", #top > 0 and ("Sources: " .. table.concat(top, "  •  ")) or "Sources: —")
    SetText("sessionNetDetail", net >= 0 and "Current session is profitable" or "Current session is in investment")

    -- First-run flow: establish the data sources GoldMint relies on before
    -- asking the player to set a goal. Each setup action advances automatically
    -- once its corresponding data has actually been observed.
    local onboarding = GetOnboardingState()
    local setupStep = GetNextOnboardingStep()
    if setupStep then
        SetText("nextTitle", "GETTING STARTED")
        SetText("nextText", setupStep.title)
        local setupDone = 0
        local setupSteps = GetOnboardingSteps()
        for _, step in ipairs(setupSteps) do
            if step.done or onboarding.skipped[step.id] then setupDone = setupDone + 1 end
        end
        SetText("nextDetail", setupStep.detail .. "\n\nSetup: " .. tostring(setupDone) .. "/" .. tostring(#setupSteps) .. " complete")
        buttons.next:SetEnabled(true)
    elseif not goal then
        SetText("nextTitle", "YOUR NEXT STEP")
        SetText("nextText", "Create your first savings goal")
        SetText("nextDetail", "Set a target and optional checkpoint. After that, GoldMint will use your goal and routine activity to keep the next action current.")
        buttons.next:SetEnabled(true)
    else
        SetText("nextTitle", "YOUR NEXT STEP")
        local routineSummary = GoldMint.RoutineState and GoldMint.RoutineState.GetSummary and GoldMint.RoutineState:GetSummary() or nil
        local routineReady = routineSummary and tonumber(routineSummary.ready or 0) or 0
        if routineReady > 0 then
            SetText("nextText", "Review ready routines")
            SetText("nextDetail", string.format("%d routine item%s are ready. GoldMint will keep watching routine state after your goal is set.", routineReady, routineReady == 1 and " is" or "s are"))
        elseif (tonumber(goal.remaining) or 0) > 0 then
            SetText("nextText", "Watch your routines")
            local checkpointRemaining = goal.nextCheckpoint and (tonumber(goal.nextCheckpoint.remaining) or 0) or nil
            SetText("nextDetail", checkpointRemaining and (FormatGold(checkpointRemaining) .. " until the next checkpoint. GoldMint will keep watching Routines and surface ready work here.") or "Your active savings goal is set. GoldMint will keep watching Routines and surface the next actionable activity here.")
        else
            SetText("nextText", "Goal reached")
            SetText("nextDetail", "Your goal is complete. GoldMint will continue monitoring routines and new activity.")
        end
        buttons.next:SetEnabled(true)
    end

    local milestoneTarget = goal and (tonumber(goal.target) or 0) or 0
    if goal and goal.nextCheckpoint then
        SetText("milestone", FormatGold(goal.nextCheckpoint.amount))
        SetText("milestoneDetail", FormatGold(goal.nextCheckpoint.remaining) .. " to go")
    else
        SetText("milestone", goal and FormatGold(milestoneTarget) or "—")
        SetText("milestoneDetail", goal and "Current goal target" or "No active goal")
    end

    -- Only display the progress track when there is an actual target.
    -- A blank/no-goal milestone card must remain clean.
    if labels.milestoneTrack and labels.milestoneFill then
        if goal and milestoneTarget > 0 then
            local current = tonumber(goal.currentValue) or tonumber(goal.current) or 0
            local progress = math.max(0, math.min(1, current / milestoneTarget))
            labels.milestoneTrack:Show()
            labels.milestoneFill:SetSize(math.max(1, 228 * progress), 6)
            labels.milestoneFill:Show()
        else
            labels.milestoneTrack:Hide()
            labels.milestoneFill:Hide()
        end
    end

    local shield = goal and goal.weekly or nil
    if shield and shield.status == "ahead" then
        SetText("shield", "You're ahead")
        SetText("shieldDetail", "Based on your rolling 7-day pace.")
        SetStatus(labels.shield, "ahead")
    elseif shield and shield.status == "behind" then
        SetText("shield", "You're behind")
        SetText("shieldDetail", "Your 7-day pace is below target.")
        SetStatus(labels.shield, "behind")
    elseif shield and shield.status == "complete" then
        SetText("shield", "Goal complete")
        SetText("shieldDetail", "Time pressure is cleared.")
        SetStatus(labels.shield, "ahead")
    elseif shield and shield.status == "baseline" then
        SetText("shield", "7-day baseline")
        SetText("shieldDetail", "Tracking your actual weekly pace.")
        SetStatus(labels.shield, "normal")
    else
        SetText("shield", "Building baseline")
        SetText("shieldDetail", "More 7-day history is needed.")
        SetStatus(labels.shield, "normal")
    end

    -- Keep the header focused on liquid value; goal information belongs in the goal panel.
end

local function CreateFrameOnce()
    if initialized then return end
    initialized = true

    frame = CreateFrame("Frame", "GoldMintDashboard", UIParent, "BackdropTemplate")
    frame:SetSize(DASHBOARD_BASE_WIDTH, DASHBOARD_BASE_HEIGHT)
    -- Scale the complete dashboard canvas to the available UI space.  Because
    -- every page is a child of this frame, the same responsive treatment
    -- automatically applies to Home, Projects, Wealth, Inventory, Market,
    -- Recipes, Cooldowns, and Routines without individually redesigning each
    -- page around a particular monitor size or UI scale.
    UpdateResponsiveScale()
    -- Preserve the established default position, while allowing the new settings
    -- panel to remember a user-moved position.
    local savedX = GoldMintDB and GoldMintDB.settings and tonumber(GoldMintDB.settings.dashboardX)
    local savedY = GoldMintDB and GoldMintDB.settings and tonumber(GoldMintDB.settings.dashboardY)
    if savedX and savedY and savedX == savedX and savedY == savedY then
        -- Saved dashboard coordinates are CENTER offsets. Clamp them before
        -- restoring so an old/corrupt position can never put the window away.
        local uiW, uiH = UIParent:GetWidth(), UIParent:GetHeight()
        local responsiveScale = frame:GetScale() or 1
        local halfW = (frame:GetWidth() * responsiveScale) / 2
        local halfH = (frame:GetHeight() * responsiveScale) / 2
        local maxX = math.max(0, uiW / 2 - halfW - 24)
        local maxY = math.max(0, uiH / 2 - halfH - 22)
        savedX = math.max(-maxX, math.min(maxX, savedX))
        savedY = math.max(-maxY, math.min(maxY, savedY))
        frame:SetPoint("CENTER", UIParent, "CENTER", savedX, savedY)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", -150, 0)
    end
    -- Keep the GoldMint dashboard above unit frames and other game HUD elements.
    -- DIALOG is intentionally used instead of MEDIUM so stance/action/unit frames
    -- cannot visually bleed over the dashboard.
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(100)
    -- Treat Escape as the dashboard close key, matching normal Blizzard window behavior.
    if UISpecialFrames then
        tinsert(UISpecialFrames, "GoldMintDashboard")
    end
    -- Only the dedicated title-bar drag handle moves the dashboard.  The old
    -- implementation made the entire 1400x840 frame draggable, which allowed
    -- clicks/releases over child controls to interfere with the dashboard
    -- lifecycle and made the window appear to close after being moved.
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)

    local dragHandle = CreateFrame("Frame", "GoldMintDashboardDragHandle", frame)
    dragHandle:SetSize(1320, 82)
    dragHandle:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 18)
    dragHandle:SetFrameLevel(frame:GetFrameLevel() + 1)
    dragHandle:EnableMouse(true)
    dragHandle:RegisterForDrag("LeftButton")
    dragHandle:SetScript("OnDragStart", function()
        local locked = GoldMintDB and GoldMintDB.settings and GoldMintDB.settings.dashboardLocked
        if not locked then
            frame._goldMintDragging = true
            frame:StartMoving()
        end
    end)
    dragHandle:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        frame._goldMintDragging = false

        local centerX, centerY = frame:GetCenter()
        local uiCenterX, uiCenterY = UIParent:GetWidth() / 2, UIParent:GetHeight() / 2
        if GoldMintDB and GoldMintDB.settings and centerX and centerY then
            local x = centerX - uiCenterX
            local y = centerY - uiCenterY
            -- Never save invalid coordinates.
            if x == x and y == y then
                GoldMintDB.settings.dashboardX = x
                GoldMintDB.settings.dashboardY = y
            end
        end
    end)

    -- Keep the drag handle visually inert. It exists only to provide a safe,
    -- predictable place to move the dashboard without intercepting buttons.
    dragHandle:SetAlpha(0.001)
    panels.dashboardDragHandle = dragHandle

    -- Recalculate the canvas scale whenever WoW changes resolution or UI
    -- scale.  This makes the same addon layout adapt without requiring the
    -- user to manually resize the main window.
    frame:RegisterEvent("DISPLAY_SIZE_CHANGED")
    frame:RegisterEvent("UI_SCALE_CHANGED")
    frame:SetScript("OnEvent", function(self)
        UpdateResponsiveScale()
    end)

    frame:SetScript("OnHide", function(self)
        -- The lifecycle OnHide handler below is installed later in this
        -- function; this placeholder is intentionally replaced there.
    end)

    frame:SetBackdrop({
        -- Use the supplied Darkfiber artwork as the main dashboard background.
        -- The current Darkfiber.tga asset is the latest supplied background artwork.
        -- It is displayed behind all dashboard panels.
        bgFile = "Interface\\AddOns\\GoldMint\\Assets\\Darkfiber",
        tile = false,
    })
    frame:SetBackdropColor(1.0, 1.0, 1.0, 1.0)

    -- Custom metallic/cyan border supplied for the GoldMint main window.
    -- This replaces the old plain blue edge.
    local function AddWindowBorderTexture(name, width, height, point, x, y, texturePath)
        local t = frame:CreateTexture(name, "BORDER")
        t:SetTexture(texturePath or "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowBorder")
        t:SetSize(width, height)
        t:SetPoint(point, frame, point, x or 0, y or 0)
        t:SetTexCoord(0, 1, 0, 1)
        return t
    end
    -- Keep the main window edge at exactly 4 pixels.  The supplied horizontal
    -- artwork is used on the top/bottom, while the supplied vertical artwork
    -- is used on the left/right without rotating it.
    panels.windowBorderTop = AddWindowBorderTexture("GoldMintWindowBorderTop", DASHBOARD_BASE_WIDTH, 4, "TOPLEFT", 0, 0)
    panels.windowBorderBottom = AddWindowBorderTexture("GoldMintWindowBorderBottom", DASHBOARD_BASE_WIDTH, 4, "BOTTOMLEFT", 0, 0)
    panels.windowBorderLeft = AddWindowBorderTexture("GoldMintWindowBorderLeft", 4, DASHBOARD_BASE_HEIGHT, "TOPLEFT", 0, 0, "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowBorderVertical")
    panels.windowBorderRight = AddWindowBorderTexture("GoldMintWindowBorderRight", 4, DASHBOARD_BASE_HEIGHT, "TOPRIGHT", 0, 0, "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowBorderVertical")

    -- Bottom-right decorative corner. Keep the same size and mirrored placement
    -- as the bottom-left corner artwork. This only replaces the artwork itself.
    local cornerRight = frame:CreateTexture("GoldMintWindowCornerRight", "OVERLAY")
    cornerRight:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowCornerRight")
    cornerRight:SetSize(90, 105)
    cornerRight:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", 11, 95)
    cornerRight:SetTexCoord(0, 1, 0, 1)
    panels.windowCornerRight = cornerRight

    -- Bottom-left decorative corner.  The bend of the supplied artwork is
    -- centered directly over the 4px main-window corner, so the artwork
    -- overlaps the border without changing the header or logo.
    local cornerLeft = frame:CreateTexture("GoldMintWindowCornerLeft", "OVERLAY")
    cornerLeft:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowCornerLeft")
    cornerLeft:SetSize(90, 105)
    -- Source bend is approximately (305, 478) in the 521x606 artwork.
    -- Scale the decorative corner down while keeping its bend centered on the 4px frame corner.
    cornerLeft:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", -11, 95)
    cornerLeft:SetTexCoord(0, 1, 0, 1)
    panels.windowCornerLeft = cornerLeft

    BuildHeader()
    Dashboard:BuildMinimapButton()
    if GoldMint.FarmTracker and GoldMint.FarmTracker.Reanchor then
        GoldMint.FarmTracker:EnsureFrame()
        GoldMint.FarmTracker:Reanchor()
    end
    BuildNavigation()
    BuildGoalPanel()
    BuildMomentumPanel()
    BuildNextStepPanel()
    BuildLiveInventoryPanel()
    BuildSessionPanel()
    BuildBottomPanels()

    buttons.next:SetScript("OnClick", function()
        local setupStep = GetNextOnboardingStep()
        if setupStep then
            if setupStep.open then setupStep.open() end
            return
        end

        local activeGoal = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil
        if not activeGoal then
            OpenGoalEditor()
            return
        end

        local routineSummary = GoldMint.RoutineState and GoldMint.RoutineState.GetSummary and GoldMint.RoutineState:GetSummary() or nil
        if routineSummary and tonumber(routineSummary.ready or 0) > 0 then
            OpenOperations("routines")
            return
        end

        OpenOperations("routines")
    end)

    buttons.nextLater:SetScript("OnClick", function()
        local setupStep = GetNextOnboardingStep()
        if setupStep then
            local state = GetOnboardingState()
            state.skipped[setupStep.id] = true
            GoldMint.Print("Skipped setup step: " .. tostring(setupStep.title) .. ". GoldMint will continue to the next setup step.")
            Refresh()
            return
        end

        GoldMint.Print("Recommendation deferred. GoldMint will continue monitoring your goal and routines.")
        Refresh()
    end)

    -- Refresh state must be declared before the OnShow/OnHide handlers so
    -- those closures capture these locals rather than creating globals.
    local refreshPending = false
    local refreshGeneration = 0
    local refreshTicker
    local fallbackRefreshElapsed = 0

    frame:SetScript("OnShow", function(self)
        self._uiLifecycle = (self._uiLifecycle or 0) + 1
        self._refreshElapsed = 0
        fallbackRefreshElapsed = 0
        refreshPending = false
        refreshGeneration = refreshGeneration + 1
        Refresh()

        if not refreshTicker and C_Timer and C_Timer.NewTicker then
            refreshTicker = C_Timer.NewTicker(5, function()
                if not frame:IsShown() then return end
                -- The Routines page contains the World Quest card. Do not run
                -- the dashboard-wide five-second repaint while that page is
                -- visible; the World Quest tracker has its own change-driven
                -- notification and must not be rebuilt by this fallback.
                if activeNavKey == "routines" then return end
                Refresh()
            end)
        end
    end)
    frame:SetScript("OnHide", function(self)
        self._uiLifecycle = (self._uiLifecycle or 0) + 1
        refreshPending = false
        refreshGeneration = refreshGeneration + 1
        self._refreshElapsed = 0
        fallbackRefreshElapsed = 0
        if refreshTicker then
            refreshTicker:Cancel()
            refreshTicker = nil
        end
    end)

    -- Keep the dashboard data fresh when the game changes the underlying
    -- economy state. The five-second ticker remains as a quiet fallback,
    -- while these events make visible changes appear immediately.
    local refreshEvents = CreateFrame("Frame", nil, frame)
    refreshEvents:RegisterEvent("PLAYER_MONEY")
    refreshEvents:RegisterEvent("BANKFRAME_OPENED")
    refreshEvents:RegisterEvent("GUILDBANKFRAME_OPENED")
    refreshEvents:RegisterEvent("GUILDBANK_UPDATE_MONEY")
    refreshEvents:RegisterEvent("GUILDBANK_UPDATE_TABS")
    refreshEvents:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED")
    refreshEvents:RegisterEvent("PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED")
    refreshEvents:RegisterEvent("MAIL_INBOX_UPDATE")
    refreshEvents:RegisterEvent("AUCTION_HOUSE_SHOW")
    refreshEvents:RegisterEvent("TRADE_SKILL_SHOW")
    refreshEvents:RegisterEvent("TRADE_SKILL_CLOSE")
    refreshEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
    refreshEvents:SetScript("OnEvent", function(_, event)
        if not frame or not frame:IsShown() then return end
        if GoldMint:IsMerchantOpen() and event == "PLAYER_MONEY" then
            refreshPending = true
            refreshGeneration = refreshGeneration + 1
            return
        end
        -- Immediate events supersede any delayed bag repaint already queued.
        -- This keeps the visible UI converged on the newest Economy state.
        refreshGeneration = refreshGeneration + 1
        refreshPending = false
        Refresh()
    end)
    panels.refreshEvents = refreshEvents

    -- Create the frame hidden. Initialization should never consume the first
    -- /gm dashboard toggle by hiding a newly-created, automatically shown frame.
    frame:Hide()
end

function Dashboard:Initialize()
    CreateFrameOnce()
end

function Dashboard:IsShown()
    return frame ~= nil and frame.IsShown and frame:IsShown() == true
end

function Dashboard:Refresh()
    if not initialized then
        return
    end
    Refresh()
end

function Dashboard:RefreshWealthView()
    if not initialized then
        return
    end
    if panels.operationsShow then
        panels.operationsShow("wealth")
    else
        Refresh()
    end
end

function Dashboard:Show()
    CreateFrameOnce()
    frame:Show()
    if activeNavKey == "projects" and OpenProjects then
        OpenProjects()
    elseif activeNavKey == "wealth" or activeNavKey == "cooldowns" or activeNavKey == "inventory" or activeNavKey == "recipes" or activeNavKey == "market" or activeNavKey == "routines" then
        if OpenOperations then OpenOperations(activeNavKey) end
    else
        Dashboard:ShowHome()
    end
    Refresh()
end

function Dashboard:Hide()
    if frame then frame:Hide() end
end

function Dashboard:Toggle()
    CreateFrameOnce()
    if frame:IsShown() then self:Hide() else self:Show() end
end
