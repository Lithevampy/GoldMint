local ADDON_NAME, GoldMint = ...

GoldMint.LootAlerts = {}
local LootAlerts = GoldMint.LootAlerts

local STORE_VERSION = 2
local DEFAULT_THRESHOLD = 100000
local MAX_HISTORY = 100
local MAX_PENDING = 25
local RECENT_SIGNATURE_WINDOW = 3
local MARKET_CACHE_WINDOW = 30
local marketValueCache = {}

local function EnsureStore()
    GoldMintDB.lootAlerts = type(GoldMintDB.lootAlerts) == "table" and GoldMintDB.lootAlerts or {}
    GoldMintDB.lootAlerts.version = math.max(tonumber(GoldMintDB.lootAlerts.version) or 0, STORE_VERSION)
    GoldMintDB.lootAlerts.threshold = tonumber(GoldMintDB.lootAlerts.threshold) or DEFAULT_THRESHOLD
    GoldMintDB.lootAlerts.history = type(GoldMintDB.lootAlerts.history) == "table" and GoldMintDB.lootAlerts.history or {}
    GoldMintDB.lootAlerts.pending = type(GoldMintDB.lootAlerts.pending) == "table" and GoldMintDB.lootAlerts.pending or {}
    GoldMintDB.lootAlerts.settings = type(GoldMintDB.lootAlerts.settings) == "table" and GoldMintDB.lootAlerts.settings or {}
    local settings = GoldMintDB.lootAlerts.settings
    if settings.alertHighValue == nil then settings.alertHighValue = true end
    if settings.alertUncollected == nil then settings.alertUncollected = true end
    if settings.soundEnabled == nil then settings.soundEnabled = false end
    return GoldMintDB.lootAlerts
end

local function GetItemID(itemLink)
    if not itemLink or not C_Item or not C_Item.GetItemIDForItemInfo then return nil end
    local ok, id = pcall(C_Item.GetItemIDForItemInfo, itemLink)
    return ok and tonumber(id) or nil
end

local function IsTransmogItem(itemLink)
    if not itemLink then return false end

    if C_Item and C_Item.GetItemInfoInstant then
        local ok, _, _, _, _, classID = pcall(C_Item.GetItemInfoInstant, itemLink)
        if ok and (tonumber(classID) == 2 or tonumber(classID) == 4) then
            return true
        end
    end

    if C_TransmogCollection and C_TransmogCollection.GetItemInfo then
        local ok, appearanceID = pcall(C_TransmogCollection.GetItemInfo, itemLink)
        if ok and appearanceID then
            return true
        end
    end

    return false
end

local function GetItemQuality(itemLink)
    if not C_Item or not C_Item.GetItemInfo then return nil end
    local ok, _, quality = pcall(C_Item.GetItemInfo, itemLink)
    return ok and tonumber(quality) or nil
end

local function GetItemName(itemLink)
    if not C_Item or not C_Item.GetItemInfo then return nil end
    local ok, name = pcall(C_Item.GetItemInfo, itemLink)
    if ok and name then return tostring(name) end
    return nil
end

local function PlayLootAlertSound()
    local settings = EnsureStore().settings
    if not settings.soundEnabled then return end
    if GoldMint.Sounds and GoldMint.Sounds.Play then
        GoldMint.Sounds:Play("alert")
    end
end

local function PublishAlert(record)
    if not record then return end

    local name = GetItemName(record.itemLink) or (record.itemLink and tostring(record.itemLink)) or "Loot item"
    local quantity = tonumber(record.quantity) or 1
    local valueText = record.unitValue and GoldMint.Ledger and GoldMint.Ledger.FormatGoldFull
        and GoldMint.Ledger:FormatGoldFull(record.unitValue) or "Unknown"
    local totalText = record.totalValue and GoldMint.Ledger and GoldMint.Ledger.FormatGoldFull
        and GoldMint.Ledger:FormatGoldFull(record.totalValue) or valueText

    local title
    local reason
    if record.alertReason == "high-value-loot" then
        title = "VALUABLE LOOT"
        reason = "Above your value threshold"
    elseif record.alertReason == "uncollected-transmog" then
        title = "NEW TRANSMOG"
        reason = "Appearance not collected"
    end

    local body = string.format("%s x%d\n%s unit • %s total\n%s", name, quantity, valueText, totalText, reason)
    if GoldMint.Alerts and GoldMint.Alerts.Push then
        GoldMint.Alerts:Push(title, body, {
        id = "transmog-" .. tostring(record.time) .. "-" .. tostring(record.itemID),
        dedupeKey = "transmog-" .. tostring(record.itemID),
        priority = record.alertReason == "high-value-loot" and 100 or 90,
        ttl = 12,
        category = record.alertReason == "high-value-loot" and "loot" or "transmog",
        sound = true,
    })
    end
end

local function GetTransmogState(itemLink)
    if not C_TransmogCollection or not C_TransmogCollection.GetItemInfo then
        return nil, nil, nil, nil
    end

    local ok, appearanceID, sourceID = pcall(C_TransmogCollection.GetItemInfo, itemLink)
    if not ok or not appearanceID then
        return nil, nil, nil, nil
    end

    local isCollected
    local sourceType

    if sourceID and C_TransmogCollection.GetAppearanceSourceInfo then
        local okSource, info = pcall(C_TransmogCollection.GetAppearanceSourceInfo, sourceID)
        if okSource and type(info) == "table" then
            isCollected = info.isCollected
            sourceType = info.sourceType
        end
    end

    if isCollected == nil and C_TransmogCollection.PlayerHasTransmogByItemInfo then
        local okCollected, collected = pcall(C_TransmogCollection.PlayerHasTransmogByItemInfo, itemLink)
        if okCollected then
            isCollected = collected == true
        end
    end

    return tonumber(appearanceID), tonumber(sourceID), isCollected, sourceType
end

function LootAlerts:GetThreshold()
    return tonumber(EnsureStore().threshold) or DEFAULT_THRESHOLD
end

function LootAlerts:SetThreshold(copper)
    copper = tonumber(copper)
    if not copper or copper < 0 then return false end
    EnsureStore().threshold = math.floor(copper)
    return true
end

function LootAlerts:GetPendingAlerts()
    return EnsureStore().pending
end

function LootAlerts:AcknowledgeAlert(index)
    local store = EnsureStore()
    index = tonumber(index)
    if not index or not store.pending[index] then return false end
    table.remove(store.pending, index)
    return true
end

function LootAlerts:ClearPendingAlerts()
    EnsureStore().pending = {}
end

function LootAlerts:GetSettings()
    return EnsureStore().settings
end

function LootAlerts:SetSetting(name, value)
    local settings = EnsureStore().settings
    if name ~= "alertHighValue" and name ~= "alertUncollected" and name ~= "soundEnabled" then
        return false
    end
    settings[name] = value == true
    return true
end

local function QueueAlert(record)
    local store = EnsureStore()
    local pending = store.pending
    pending[#pending + 1] = record
    while #pending > MAX_PENDING do
        table.remove(pending, 1)
    end
end

-- Alert policy:
--   * Transmog alerts are only for appearances the player does NOT know.
--   * Valuable-loot alerts are only for Bind on Equip items.
--   * Valuable-loot market value comes from TSM DBMarket only.
--   * Bind on Pickup and Bind on Account items are ignored by the valuable-loot rule.
local function GetBindType(itemLink)
    if not itemLink or not C_Item or not C_Item.GetItemInfo then return nil end
    local ok, _, _, _, _, _, _, _, _, _, _, _, _, bindType = pcall(C_Item.GetItemInfo, itemLink)
    if ok then return tonumber(bindType) end
    return nil
end

local function IsBindOnEquip(itemLink)
    return GetBindType(itemLink) == 2
end

function LootAlerts:IsValuableLoot(itemLink)
    if not itemLink then
        return false, "no-item-link"
    end

    local itemID = GetItemID(itemLink)
    if not itemID then
        return false, "no-item-id"
    end

    local transmog = IsTransmogItem(itemLink)
    local appearanceID, sourceID, isCollected, sourceType
    if transmog then
        appearanceID, sourceID, isCollected, sourceType = GetTransmogState(itemLink)
    end

    local settings = EnsureStore().settings

    -- Transmog alerts are strictly for appearances the player does not know.
    -- A known appearance must never trigger a transmog-only alert.

    -- An uncollected appearance by itself is not enough to interrupt gameplay.
    -- The player asked for loot to be quiet unless the item is actually
    -- worthwhile, so uncollected transmog must also have a known market value
    -- at or above the normal loot threshold.
    if settings.alertUncollected and transmog and isCollected == false then
        local threshold = self:GetThreshold()
        local value
        local source
        if GoldMint.Market then
            GoldMint.Market:RecordItem(itemID)
            local cached = marketValueCache[itemID]
            local now = time()
            if cached and now - (tonumber(cached.at) or 0) <= MARKET_CACHE_WINDOW then
                value = tonumber(cached.value)
                source = value and "tsm" or nil
            else
                GoldMint.Market:CaptureTSM(itemID)
                local status = GoldMint.Market:GetStatus(itemID)
                if status then
                    value = tonumber(status.tsmMarketValue)
                    source = value and "tsm" or nil
                end
                marketValueCache[itemID] = { value = value, at = now }
            end
        end
        if value and value >= threshold then
            return true, {
                itemID = itemID,
                unitValue = value,
                valueSource = source,
                appearanceID = appearanceID,
                sourceID = sourceID,
                isCollected = false,
                sourceType = sourceType,
                isTransmog = true,
                alertReason = "uncollected-transmog",
            }
        end
    end

    -- Valuable-loot alerts are restricted to Bind on Equip items. TSM is the
    -- sole market-value source for this alert; vendor/AH fallback values are
    -- deliberately not used here.
    if settings.alertHighValue and IsBindOnEquip(itemLink) then
        local value
        local source
        if GoldMint.Market then
            GoldMint.Market:RecordItem(itemID)

            -- TSM price lookup is comparatively expensive and loot can arrive in
            -- bursts. Cache the result briefly so the same item does not trigger
            -- an external API lookup every time it is looted.
            local cached = marketValueCache[itemID]
            local now = time()
            if cached and now - (tonumber(cached.at) or 0) <= MARKET_CACHE_WINDOW then
                value = tonumber(cached.value)
                source = value and "tsm" or nil
            else
                GoldMint.Market:CaptureTSM(itemID)
                local status = GoldMint.Market:GetStatus(itemID)
                if status then
                    value = tonumber(status.tsmMarketValue)
                    source = value and "tsm" or nil
                end
                marketValueCache[itemID] = { value = value, at = now }
            end
        end

        local threshold = self:GetThreshold()
        if value and value >= threshold then
            return true, {
                itemID = itemID,
                unitValue = value,
                valueSource = source,
                appearanceID = appearanceID,
                sourceID = sourceID,
                isCollected = isCollected,
                sourceType = sourceType,
                isTransmog = transmog,
                alertReason = "high-value-loot",
            }
        end
    end

    return false, "below-threshold-or-not-boe"
end

local function BuildSignature(itemLink, quantity)
    return tostring(GetItemID(itemLink) or itemLink or "") .. ":" .. tostring(tonumber(quantity) or 1)
end

function LootAlerts:ProcessLoot(itemLink, quantity, source)
    if not itemLink then return false, "no-link" end

    -- Gold Per Hour farming tracker observes every looted item, not only items
    -- that qualify for a valuable-loot alert. This keeps the farming session
    -- independent from the player's alert filters.
    if GoldMint.FarmTracker and GoldMint.FarmTracker.RecordLoot then
        GoldMint.FarmTracker:RecordLoot(itemLink, quantity or 1)
    end

    local store = EnsureStore()
    local now = time()
    local signature = BuildSignature(itemLink, quantity)
    if store.recentSignature == signature and now - (tonumber(store.recentSignatureAt) or 0) <= RECENT_SIGNATURE_WINDOW then
        return false, "duplicate"
    end
    store.recentSignature = signature
    store.recentSignatureAt = now

    local qualifies, data = self:IsValuableLoot(itemLink)
    if not qualifies then return false, data end
    quantity = math.max(tonumber(quantity) or 1, 1)
    data.source = source

    local history = store.history
    history[#history + 1] = {
        time = now, itemID = data.itemID, itemLink = itemLink, quantity = quantity,
        unitValue = data.unitValue, totalValue = data.unitValue and data.unitValue * quantity or nil,
        valueSource = data.valueSource, quality = GetItemQuality(itemLink), character = GoldMint.characterKey,
        appearanceID = data.appearanceID, sourceID = data.sourceID, isTransmogCollected = data.isCollected,
        transmogSourceType = data.sourceType, alertReason = data.alertReason, source = source,
    }
    while #history > MAX_HISTORY do table.remove(history, 1) end

    local recorded = history[#history]
    QueueAlert({
        time = recorded.time, itemID = recorded.itemID, itemLink = recorded.itemLink, quantity = recorded.quantity,
        unitValue = recorded.unitValue, totalValue = recorded.totalValue, valueSource = recorded.valueSource,
        quality = recorded.quality, character = recorded.character, appearanceID = recorded.appearanceID,
        sourceID = recorded.sourceID, isTransmogCollected = recorded.isTransmogCollected,
        transmogSourceType = recorded.transmogSourceType, alertReason = recorded.alertReason, source = recorded.source,
    })

    -- The saved history above is the persistent record. The contextual Alerts
    -- layer is the immediate, sensory-friendly presentation for the player.
    PublishAlert(recorded)
    return true, recorded
end

local function IsFarmingWindowOpen()
    local tracker = GoldMint and GoldMint.FarmTracker
    return tracker and tracker.frame and tracker.frame.IsShown and tracker.frame:IsShown()
end

function LootAlerts:RecordLoot(itemLink, quantity)
    if not IsFarmingWindowOpen() then return false end
    return self:ProcessLoot(itemLink, quantity, "loot")
end

function LootAlerts:GetHistory()
    return EnsureStore().history
end

function LootAlerts:Initialize()
    if self._initialized then return end
    self._initialized = true
    EnsureStore()

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("SHOW_LOOT_TOAST")
    frame:RegisterEvent("LOOT_OPENED")
    frame:RegisterEvent("ENCOUNTER_LOOT_RECEIVED")

    frame:SetScript("OnEvent", function(_, event, ...)
        if event == "SHOW_LOOT_TOAST" then
            if not IsFarmingWindowOpen() then return end
            local typeIdentifier, itemLink, quantity = ...
            -- SHOW_LOOT_TOAST also reports money/currency. GoldMint's item
            -- alert pipeline should only consume actual item links.
            if typeIdentifier == "item" and type(itemLink) == "string" and itemLink ~= "" then
                self:ProcessLoot(itemLink, tonumber(quantity) or 1, "loot_toast")
            end
        elseif event == "ENCOUNTER_LOOT_RECEIVED" then
            if not IsFarmingWindowOpen() then return end
            local _, _, itemLink, quantity = ...
            if type(itemLink) == "string" and itemLink ~= "" then
                self:ProcessLoot(itemLink, tonumber(quantity) or 1, "encounter")
            end
        elseif event == "LOOT_OPENED" then
            if IsFarmingWindowOpen() then
                self:ScanOpenLoot()
            end
        end
    end)
end

function LootAlerts:ScanOpenLoot()
    if not GetNumLootItems or not GetLootSlotLink then return 0 end
    local count = 0
    local slots = tonumber(GetNumLootItems()) or 0
    for slot = 1, slots do
        local link = GetLootSlotLink(slot)
        if link then
            local quantity = 1
            if GetLootSlotInfo then
                local _, _, lootQuantity = GetLootSlotInfo(slot)
                quantity = tonumber(lootQuantity) or 1
            end
            local accepted = self:ProcessLoot(link, quantity, "loot_window")
            if accepted then count = count + 1 end
        end
    end
    return count
end
