local ADDON_NAME, addon = ...
local GoldMint = addon or _G[ADDON_NAME]

local Options = {}
GoldMint.Options = Options

-- Centralized settings schema.  Keep defaults in one place so new settings do
-- not have to be initialized independently by Core.lua, the UI, or individual
-- feature modules.  Unknown settings are intentionally preserved for
-- forward/backward compatibility.
local SETTINGS_SCHEMA_VERSION = 9

local SETTINGS_DEFAULTS = {
    dashboardLocked = false,
    minimapButtonShown = true,
    minimapButtonAngle = 45,
    dashboardX = nil,
    dashboardY = nil,
    showWealthBankValue = false,
    notificationIntensity = "NORMAL",
    alertEnabled = true,
    alertMuted = false,
    cooldownReadyAlert = true,
    oneClearNextStep = true,
    taskPopoutEnabled = false,
    nextSuggestionAlert = true,
    taskPopoutX = nil,
    taskPopoutY = nil,
    taskPopoutPoint = nil,
    alertUnlocked = false,
    alertX = nil,
    alertY = nil,
    alertPoint = nil,
    goldMakingGuild = nil,
    alertSound = "RAID_WARNING",
    stretchSound = "READY_CHECK",
    dashboardScale = 1.0,
    showGoalPanel = true,
    showMomentumPanel = true,
    showNextStepPanel = true,
    showSessionPanel = true,
    showCooldownPanel = true,
    showProfitPanel = true,
    showMilestonePanel = true,
    showShieldPanel = true,
    showInventoryPanel = true,
}

local SETTINGS_TYPES = {
    dashboardLocked = "boolean",
    minimapButtonShown = "boolean",
    minimapButtonAngle = "number",
    dashboardX = "number_or_nil",
    dashboardY = "number_or_nil",
    showWealthBankValue = "boolean",
    notificationIntensity = "string",
    alertEnabled = "boolean",
    alertMuted = "boolean",
    cooldownReadyAlert = "boolean",
    oneClearNextStep = "boolean",
    taskPopoutEnabled = "boolean",
    nextSuggestionAlert = "boolean",
    taskPopoutX = "number_or_nil",
    taskPopoutY = "number_or_nil",
    taskPopoutPoint = "string_or_nil",
    alertUnlocked = "boolean",
    alertX = "number_or_nil",
    alertY = "number_or_nil",
    alertPoint = "string_or_nil",
    goldMakingGuild = "table_or_nil",
    alertSound = "string",
    stretchSound = "string",
    dashboardScale = "number",
    showGoalPanel = "boolean",
    showMomentumPanel = "boolean",
    showNextStepPanel = "boolean",
    showSessionPanel = "boolean",
    showCooldownPanel = "boolean",
    showProfitPanel = "boolean",
    showMilestonePanel = "boolean",
    showShieldPanel = "boolean",
    showInventoryPanel = "boolean",
}

local VALID_NOTIFICATION_INTENSITIES = {
    SILENT = true,
    MINIMAL = true,
    NORMAL = true,
    DETAILED = true,
}

local function IsValidSettingValue(name, value)
    local expected = SETTINGS_TYPES[name]
    if not expected then return true end
    if expected == "boolean" then return type(value) == "boolean" end
    if expected == "string" then
        if name == "notificationIntensity" then
            return type(value) == "string" and VALID_NOTIFICATION_INTENSITIES[value] == true
        end
        if name == "alertSound" or name == "stretchSound" then
            if type(value) ~= "string" then return false end
            if value == "NONE" then return true end
            if GoldMint.Sounds and GoldMint.Sounds.GetChoices then
                for _, choice in ipairs(GoldMint.Sounds:GetChoices()) do
                    if choice.key == value then return true end
                end
            end
            return false
        end
        return type(value) == "string"
    end
    if expected == "table_or_nil" then
        return value == nil or type(value) == "table"
    end
    if expected == "number" then
        return type(value) == "number"
    end
    if expected == "number_or_nil" then
        return value == nil or type(value) == "number"
    end
    if expected == "string_or_nil" then
        return value == nil or type(value) == "string"
    end
    return true
end

local function EnsureSettings()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    local settings = GoldMintDB.settings

    -- Settings migrations are deliberately narrow and data-preserving.  Unknown
    -- keys are retained so newer/older builds can coexist without destructive
    -- resets.  Known keys are repaired only when their stored value is invalid.
    for key, defaultValue in pairs(SETTINGS_DEFAULTS) do
        if settings[key] == nil or not IsValidSettingValue(key, settings[key]) then
            settings[key] = defaultValue
        end
    end

    settings.schemaVersion = SETTINGS_SCHEMA_VERSION
    settings.lastValidatedAt = tonumber(settings.lastValidatedAt) or time()
    return settings
end

function Options:GetSettings()
    return EnsureSettings()
end

function Options:GetSetting(name, defaultValue)
    local settings = EnsureSettings()
    if settings[name] ~= nil then return settings[name] end
    return defaultValue
end

function Options:SetSetting(name, value)
    local settings = EnsureSettings()
    if not IsValidSettingValue(name, value) then
        value = SETTINGS_DEFAULTS[name]
    end
    settings[name] = value
    settings.lastChangedAt = time()
    settings.lastChangedKey = name
    settings.schemaVersion = SETTINGS_SCHEMA_VERSION
    return value
end

function Options:ResetSettings()
    local settings = EnsureSettings()
    for key, defaultValue in pairs(SETTINGS_DEFAULTS) do
        settings[key] = defaultValue
    end
    settings.schemaVersion = SETTINGS_SCHEMA_VERSION
    settings.lastChangedAt = time()
    settings.lastChangedKey = "__RESET__"
    return settings
end

function Options:GetPersistenceStatus()
    local settings = EnsureSettings()
    return {
        schemaVersion = tonumber(settings.schemaVersion) or SETTINGS_SCHEMA_VERSION,
        lastValidatedAt = tonumber(settings.lastValidatedAt) or 0,
        lastChangedAt = tonumber(settings.lastChangedAt) or 0,
        lastChangedKey = settings.lastChangedKey,
    }
end

local function MakeText(parent, text, size, color, template)
    local fs = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormal")
    fs:SetText(text or "")
    fs:SetFont(fs:GetFont(), size or 14, "")
    if color then fs:SetTextColor(unpack(color)) end
    return fs
end

-- GoldMint Options uses the same dark/cyan/gold visual language as the
-- dashboard, but is intentionally a separate window.  The left rail keeps
-- settings easy to scan as the number of options grows.
local WHITE = {1.0, 1.0, 1.0}
local MUTED = {0.60, 0.74, 0.88}
local CYAN = {0.20, 0.78, 1.0}
local GOLD = {1.0, 0.82, 0.25}
local DARK = {0.006, 0.018, 0.032, 0.985}
local PANEL = {0.012, 0.035, 0.055, 0.98}

local function SnapRegion(region)
    if not region then return end
    if region.SetSnapToPixelGrid then
        region:SetSnapToPixelGrid(true)
    end
    if region.SetTexelSnappingBias then
        region:SetTexelSnappingBias(0)
    end
end

local function SnapButtonBackdrop(button)
    SnapRegion(button)
    if button.GetBackdropTexture then
        SnapRegion(button:GetBackdropTexture("bg"))
        SnapRegion(button:GetBackdropTexture("edge"))
    end
end

local function MakeGoldMintButton(parent, text, width, height)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height)
    b:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    SnapButtonBackdrop(b)

    local label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    label:SetPoint("CENTER")
    label:SetText(text)
    label:SetTextColor(unpack(MUTED))
    b.label = label

    local function Normal()
        b:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        b:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
        label:SetTextColor(unpack(MUTED))
    end
    local function Hover()
        b:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
        b:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
        label:SetTextColor(unpack(GOLD))
    end
    Normal()
    b:SetScript("OnEnter", Hover)
    b:SetScript("OnLeave", Normal)
    return b
end

local function MakeCheckbox(parent, y, text, description, getter, setter, x, descWidth)
    -- Use Blizzard's native checkbox artwork so the checked state is rendered
    -- by WoW instead of a text glyph or custom square.
    local row = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    row:SetSize(26, 26)
    row:SetPoint("TOPLEFT", x or 18, y - 1)

    local checkTexture = row:GetCheckedTexture()
    if checkTexture then
        checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
    end

    local title = MakeText(row, text, 14, WHITE, "GameFontHighlight")
    title:SetPoint("TOPLEFT", 32, 1)
    title:SetWordWrap(false)
    row.title = title

    local desc = MakeText(row, description, 11, MUTED)
    desc:SetPoint("TOPLEFT", 32, -21)
    desc:SetWidth(descWidth or 540)
    desc:SetWordWrap(true)
    row.description = desc

    local function Refresh()
        local checked = getter() == true
        row:SetChecked(checked)
        if checkTexture then
            checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
        end
    end

    row:SetScript("OnClick", function(self)
        setter(self:GetChecked() == true)
        Refresh()
    end)
    row:SetScript("OnEnter", function()
        title:SetTextColor(unpack(GOLD))
    end)
    row:SetScript("OnLeave", function()
        title:SetTextColor(unpack(WHITE))
    end)
    row.Refresh = Refresh
    Refresh()
    return row
end

function Options:Create()
    if self.frame then
        return self.frame
    end

    local f = CreateFrame("Frame", "GoldMintOptionsFrame", UIParent, "BackdropTemplate")
    self.frame = f
    f:SetSize(980, 820)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(300)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    SnapRegion(f)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()

        -- Keep the window and its child button backdrops on the physical pixel
        -- grid.  This lets the options window remain freely movable without
        -- the 1px button borders becoming split or blurry at fractional offsets.
        local scale = UIParent:GetEffectiveScale() or 1
        local left = self:GetLeft()
        local top = self:GetTop()
        if left and top and scale > 0 then
            left = math.floor((left * scale) + 0.5) / scale
            top = math.floor((top * scale) + 0.5) / scale
            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
        end
    end)
    f:SetClampedToScreen(true)
    f:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    f:SetBackdropColor(unpack(DARK))
    f:SetBackdropBorderColor(0.10, 0.42, 0.66, 0.95)

    if UISpecialFrames then
        tinsert(UISpecialFrames, "GoldMintOptionsFrame")
    end

    -- Header
    local header = CreateFrame("Frame", nil, f, "BackdropTemplate")
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(88)
    header:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8"})
    header:SetBackdropColor(0.012, 0.030, 0.045, 1.0)

    local logo = header:CreateTexture(nil, "ARTWORK")
    logo:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeaderBrand")
    logo:SetSize(190, 62)
    logo:SetPoint("LEFT", 22, 0)
    logo:SetTexCoord(0, 1, 0, 1)

    local headerTitle = MakeText(header, "Options", 26, WHITE, "GameFontHighlightLarge")
    headerTitle:SetPoint("LEFT", logo, "RIGHT", 18, 8)
    local headerSub = MakeText(header, "GoldMint preferences and feature controls", 12, MUTED)
    headerSub:SetPoint("LEFT", headerTitle, "BOTTOMLEFT", 0, -7)

    local status = MakeText(header, "Changes apply immediately", 11, MUTED)
    status:SetPoint("RIGHT", -58, 16)
    f.settingsStatus = status

    local close = CreateFrame("Button", nil, header, "BackdropTemplate")
    close:SetSize(34, 34)
    close:SetPoint("TOPRIGHT", -16, -15)
    close:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
    close:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
    close:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
    close.label = MakeText(close, "×", 20, WHITE, "GameFontHighlight")
    close.label:SetPoint("CENTER", 0, 1)
    close:SetScript("OnEnter", function() close:SetBackdropBorderColor(1, .78, .20, 1); close.label:SetTextColor(unpack(GOLD)) end)
    close:SetScript("OnLeave", function() close:SetBackdropBorderColor(.10, .34, .52, 1); close.label:SetTextColor(unpack(WHITE)) end)
    close:SetScript("OnClick", function() f:Hide() end)
    f.close = close

    local headerLine = header:CreateTexture(nil, "ARTWORK")
    headerLine:SetColorTexture(0.08, 0.78, 1.0, 0.80)
    headerLine:SetHeight(2)
    headerLine:SetPoint("BOTTOMLEFT", 0, 0)
    headerLine:SetPoint("BOTTOMRIGHT", 0, 0)

    -- Left navigation rail, inspired by the supplied reference but with only
    -- categories that correspond to settings GoldMint currently exposes.
    local rail = CreateFrame("Frame", nil, f, "BackdropTemplate")
    rail:SetPoint("TOPLEFT", 1, -89)
    rail:SetPoint("BOTTOMLEFT", 1, 1)
    rail:SetWidth(225)
    rail:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
    rail:SetBackdropColor(0.006, 0.020, 0.034, 1.0)
    f.rail = rail

    local railTitle = MakeText(rail, "GOLDMINT", 12, CYAN, "GameFontHighlight")
    railTitle:SetPoint("TOPLEFT", 20, -20)
    local railSub = MakeText(rail, "SETTINGS", 10, MUTED)
    railSub:SetPoint("TOPLEFT", 20, -38)

    local railLine = rail:CreateTexture(nil, "ARTWORK")
    railLine:SetColorTexture(0.10, 0.42, 0.66, 0.55)
    railLine:SetSize(185, 1)
    railLine:SetPoint("TOPLEFT", 20, -55)

    local content = CreateFrame("Frame", nil, f, "BackdropTemplate")
    content:SetPoint("TOPLEFT", rail, "TOPRIGHT", 0, 0)
    content:SetPoint("BOTTOMRIGHT", -1, 1)
    content:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
    content:SetBackdropColor(0.010, 0.027, 0.042, 1.0)
    f.content = content

    local contentTitle = MakeText(content, "", 22, WHITE, "GameFontHighlightLarge")
    contentTitle:SetPoint("TOPLEFT", 26, -24)
    f.contentTitle = contentTitle
    local contentDesc = MakeText(content, "", 11, MUTED)
    contentDesc:SetPoint("TOPLEFT", 26, -53)
    contentDesc:SetWidth(650)
    f.contentDesc = contentDesc

    local contentLine = content:CreateTexture(nil, "ARTWORK")
    contentLine:SetColorTexture(0.10, 0.42, 0.66, 0.45)
    contentLine:SetHeight(1)
    contentLine:SetPoint("TOPLEFT", 26, -76)
    contentLine:SetPoint("TOPRIGHT", -26, -76)

    local sections = {}
    local navButtons = {}
    local currentSection = "general"

    local function ClearSection()
        for _, object in ipairs(sections) do object:Hide() end
        wipe(sections)
    end

    local function AddSectionObject(object)
        sections[#sections + 1] = object
        return object
    end

    local function SectionHeader(parent, text, y, x, rightInset)
        local label = MakeText(parent, text, 11, CYAN, "GameFontHighlight")
        label:SetPoint("TOPLEFT", x or 26, y)
        local line = parent:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(0.10, 0.42, 0.66, 0.30)
        line:SetHeight(1)
        line:SetPoint("LEFT", label, "RIGHT", 12, 0)
        line:SetPoint("RIGHT", -(rightInset or 26), 0)
        AddSectionObject(label); AddSectionObject(line)
        return label
    end

    local function GuildInfo(character)
        if type(character) ~= "table" then return nil end
        if character.guildName and character.guildName ~= "" then
            return character.guildName, character.guildRealm or character.realm or "Unknown"
        end
    end

    local function KnownGuilds()
        local guilds, seen = {}, {}
        local store = type(GoldMintDB) == "table" and type(GoldMintDB.characters) == "table" and GoldMintDB.characters or {}
        for _, character in pairs(store) do
            local name, realm = GuildInfo(character)
            if name then
                local key = string.lower((realm or "Unknown") .. "|" .. name)
                if not seen[key] then
                    seen[key] = true
                    guilds[#guilds + 1] = {name=name, realm=realm or "Unknown", key=key}
                end
            end
        end
        table.sort(guilds, function(a,b)
            local an, bn = string.lower(a.name or ""), string.lower(b.name or "")
            if an == bn then return string.lower(a.realm or "") < string.lower(b.realm or "") end
            return an < bn
        end)
        return guilds
    end

    local function GuildLabel()
        local selected = EnsureSettings().goldMakingGuild
        if type(selected) == "table" and selected.name and selected.name ~= "" then
            if selected.realm and selected.realm ~= "" and selected.realm ~= "Unknown" then
                return selected.name .. " - " .. selected.realm
            end
            return selected.name
        end
        return "Personal / No Guild"
    end

    local guildMenu, guildButton
    local function HideGuildMenu() if guildMenu then guildMenu:Hide() end end

    local function SetGuild(guild)
        if guild then
            Options:SetSetting("goldMakingGuild", {name=guild.name, realm=guild.realm})
            Options:SetSetting("showWealthBankValue", true)
            status:SetText("Gold-making guild updated")
        else
            Options:SetSetting("goldMakingGuild", nil)
            Options:SetSetting("showWealthBankValue", false)
            status:SetText("Gold-making guild cleared")
        end
        if guildButton and guildButton.label then guildButton.label:SetText(GuildLabel()) end
        -- Guild-bank contents are intentionally NOT scanned here. Changing the
        -- selected guild while the bank is open must not trigger a full tab/slot
        -- walk or item valuation pass. Cached guild-bank contents remain available
        -- until a manual scan is explicitly requested by a future action.
        if GoldMint.Dashboard and GoldMint.Dashboard.RefreshWealthView then GoldMint.Dashboard:RefreshWealthView() end
        HideGuildMenu()
    end

    local function BuildGuildMenu()
        HideGuildMenu()
        local guilds = KnownGuilds()
        local rowH = 29
        guildMenu = CreateFrame("Frame", nil, f, "BackdropTemplate")
        guildMenu:SetFrameStrata("TOOLTIP")
        guildMenu:SetFrameLevel(500)
        guildMenu:SetSize(560, (#guilds + 1) * rowH + 8)
        guildMenu:SetPoint("TOPLEFT", guildButton, "BOTTOMLEFT", 0, -4)
        guildMenu:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
        guildMenu:SetBackdropColor(0.008, 0.020, 0.032, 0.995)
        guildMenu:SetBackdropBorderColor(0.10, 0.42, 0.66, 1)
        local function Add(label, y, guild)
            local b = CreateFrame("Button", nil, guildMenu)
            b:SetSize(544, rowH)
            b:SetPoint("TOPLEFT", 8, y)
            local t = MakeText(b, label, 12, WHITE)
            t:SetPoint("LEFT", 10, 0)
            b:SetScript("OnEnter", function() t:SetTextColor(unpack(GOLD)) end)
            b:SetScript("OnLeave", function() t:SetTextColor(unpack(WHITE)) end)
            b:SetScript("OnClick", function() SetGuild(guild) end)
        end
        Add("Personal / No Guild", -4, nil)
        for i,g in ipairs(guilds) do
            local label = g.name
            if g.realm and g.realm ~= "" and g.realm ~= "Unknown" then label = label .. " - " .. g.realm end
            Add(label, -(4 + i * rowH), g)
        end
        guildMenu:Show()
    end

    local function BuildGeneral()
        contentTitle:SetText("General")
        contentDesc:SetText("Core GoldMint preferences and economic context.")
        SectionHeader(content, "GOLD-MAKING GUILD", -100)
        local desc = MakeText(content, "Choose the guild GoldMint should use for guild-related economic tracking.", 11, MUTED)
        desc:SetPoint("TOPLEFT", 26, -124); desc:SetWidth(640); AddSectionObject(desc)
        guildButton = MakeGoldMintButton(content, GuildLabel(), 560, 36)
        guildButton:SetPoint("TOPLEFT", 26, -151)
        guildButton.label:SetJustifyH("LEFT"); guildButton.label:ClearAllPoints(); guildButton.label:SetPoint("LEFT", 12, 0); guildButton.label:SetWidth(500)
        local arrow = guildButton:CreateTexture(nil, "OVERLAY")
        arrow:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintTokenDown"); arrow:SetSize(13,13); arrow:SetPoint("RIGHT", -10, 0)
        guildButton:SetScript("OnClick", function() if guildMenu and guildMenu:IsShown() then HideGuildMenu() else BuildGuildMenu() end end)
        AddSectionObject(guildButton)
        local bank = MakeCheckbox(content, -210, "Include Guild Bank Value", "GoldMint uses the tracked bank value in the Wealth view when enabled.", function() return EnsureSettings().showWealthBankValue end, function(v) Options:SetSetting("showWealthBankValue", v); status:SetText("Wealth display updated") end)
        AddSectionObject(bank)
    end

    local function BuildDashboard()
        contentTitle:SetText("Dashboard")
        contentDesc:SetText("Control how the main GoldMint dashboard behaves while you play.")
        SectionHeader(content, "DASHBOARD BEHAVIOR", -100)
        local lock = MakeCheckbox(content, -126, "Lock Dashboard Position", "Prevents accidental dragging of the main dashboard.", function() return EnsureSettings().dashboardLocked end, function(v) Options:SetSetting("dashboardLocked", v); status:SetText("Dashboard setting updated") end)
        AddSectionObject(lock)
        local reset = MakeGoldMintButton(content, "RESET DASHBOARD POSITION", 230, 34)
        reset:SetPoint("TOPLEFT", 26, -203)
        reset:SetScript("OnClick", function()
            Options:SetSetting("dashboardX", nil); Options:SetSetting("dashboardY", nil)
            if GoldMint.Dashboard and GoldMint.Dashboard.frame then
                local dash = GoldMint.Dashboard.frame
                dash:ClearAllPoints(); dash:SetPoint("CENTER", UIParent, "CENTER", -150, 0)
            end
            status:SetText("Dashboard position reset")
        end)
        AddSectionObject(reset)

        SectionHeader(content, "HOME PANELS", -270)
        local panelSettings = {
            {"showGoalPanel", "Goal Panel", "Show the savings-goal progress panel on the Home dashboard."},
            {"showMomentumPanel", "Momentum Panel", "Show the profit and momentum panel on the Home dashboard."},
            {"showNextStepPanel", "Next Step Panel", "Show the primary next-step recommendation panel."},
            {"showSessionPanel", "Session Panel", "Show the current session gold and activity panel."},
            {"showCooldownPanel", "Cooldown Panel", "Show the compact active-cooldown panel on Home."},
            {"showProfitPanel", "Market Opportunity Panel", "Show the compact market opportunity panel on Home."},
            {"showMilestonePanel", "Milestone Panel", "Show the milestone/checkpoint panel on Home."},
            {"showShieldPanel", "Protection Panel", "Show the protected-items / safety panel on Home."},
            {"showInventoryPanel", "Inventory Watch Panel", "Show the inventory watch panel on Home."},
        }
        for i, info in ipairs(panelSettings) do
            local col = (i - 1) % 2
            local row = math.floor((i - 1) / 2)
            local cb = MakeCheckbox(content, -296 - (row * 64), info[2], info[3], function()
                return EnsureSettings()[info[1]] ~= false
            end, function(v)
                Options:SetSetting(info[1], v == true)
                if GoldMint.Dashboard and GoldMint.Dashboard.RefreshPanelVisibility then
                    GoldMint.Dashboard:RefreshPanelVisibility()
                end
                status:SetText(info[2] .. " updated")
            end, 18 + (col * 340), 285)
            AddSectionObject(cb)
        end
    end

    local function BuildNotifications()
        contentTitle:SetText("Alerts")
        contentDesc:SetText("Control GoldMint alerts and preview each alert style.")

        SectionHeader(content, "ALERTS", -100, 26, 26)

        local alertEnabled = MakeCheckbox(content, -126, "Enable Alert", "Allow GoldMint alert cards to appear during play.", function()
            return EnsureSettings().alertEnabled ~= false
        end, function(v)
            Options:SetSetting("alertEnabled", v == true)
            status:SetText(v and "Alerts enabled" or "Alerts disabled")
        end, 18, 300)
        AddSectionObject(alertEnabled)

        local mute = MakeCheckbox(content, -126, "Mute Alerts", "Silence GoldMint alert cards and alert sounds without changing the individual alert settings.", function()
            return EnsureSettings().alertMuted == true
        end, function(v)
            Options:SetSetting("alertMuted", v == true)
            if v and GoldMint.Alerts and GoldMint.Alerts.Clear then
                GoldMint.Alerts:Clear()
            end
            status:SetText(v and "Alerts muted" or "Alerts unmuted")
        end, 18, 300)
        mute:SetPoint("TOPLEFT", 350, -126)
        AddSectionObject(mute)

        local high = MakeCheckbox(content, -202, "Valuable BoE alert", "Show an alert when a valuable bind-on-equip item is detected.", function()
            return GoldMint.LootAlerts and GoldMint.LootAlerts:GetSettings().alertHighValue
        end, function(v)
            if GoldMint.LootAlerts then GoldMint.LootAlerts:SetSetting("alertHighValue", v == true) end
            status:SetText("BoE alert setting updated")
        end, 18, 300)
        AddSectionObject(high)
        local highPreview = MakeGoldMintButton(content, "PREVIEW", 82, 28)
        highPreview:SetPoint("TOPLEFT", 350, -198)
        highPreview:SetScript("OnClick", function()
            if GoldMint.Alerts and GoldMint.Alerts.Preview then GoldMint.Alerts:Preview("valuable") end
            status:SetText("Valuable BoE alert preview shown")
        end)
        AddSectionObject(highPreview)

        local tmog = MakeCheckbox(content, -278, "Unknown Transmog alert", "Show an alert when uncollected transmog is detected.", function()
            return GoldMint.LootAlerts and GoldMint.LootAlerts:GetSettings().alertUncollected
        end, function(v)
            if GoldMint.LootAlerts then GoldMint.LootAlerts:SetSetting("alertUncollected", v == true) end
            status:SetText("Transmog alert setting updated")
        end, 18, 300)
        AddSectionObject(tmog)
        local tmogPreview = MakeGoldMintButton(content, "PREVIEW", 82, 28)
        tmogPreview:SetPoint("TOPLEFT", 350, -274)
        tmogPreview:SetScript("OnClick", function()
            if GoldMint.Alerts and GoldMint.Alerts.Preview then GoldMint.Alerts:Preview("transmog") end
            status:SetText("Unknown Transmog alert preview shown")
        end)
        AddSectionObject(tmogPreview)

        local cooldownAlert = MakeCheckbox(content, -354, "Cooldown Ready alert", "Show an alert when a tracked profession cooldown becomes ready.", function()
            return EnsureSettings().cooldownReadyAlert ~= false
        end, function(v)
            Options:SetSetting("cooldownReadyAlert", v == true)
            status:SetText("Cooldown alert setting updated")
        end, 18, 300)
        AddSectionObject(cooldownAlert)
        local cooldownPreview = MakeGoldMintButton(content, "PREVIEW", 82, 28)
        cooldownPreview:SetPoint("TOPLEFT", 350, -350)
        cooldownPreview:SetScript("OnClick", function()
            if GoldMint.Alerts and GoldMint.Alerts.Preview then GoldMint.Alerts:Preview("cooldown") end
            status:SetText("Cooldown Ready alert preview shown")
        end)
        AddSectionObject(cooldownPreview)

        local nextSuggestion = MakeCheckbox(content, -430, "Next Suggestion alert", "Show an on-screen alert when GoldMint records a new next workflow suggestion.", function()
            return EnsureSettings().nextSuggestionAlert ~= false
        end, function(v)
            Options:SetSetting("nextSuggestionAlert", v == true)
            status:SetText("Next Suggestion alert setting updated")
        end, 18, 300)
        AddSectionObject(nextSuggestion)
        local nextPreview = MakeGoldMintButton(content, "PREVIEW", 82, 28)
        nextPreview:SetPoint("TOPLEFT", 350, -426)
        nextPreview:SetScript("OnClick", function()
            if GoldMint.Alerts and GoldMint.Alerts.Preview then GoldMint.Alerts:Preview("nextSuggestion") end
            status:SetText("Next Suggestion alert preview shown")
        end)
        AddSectionObject(nextPreview)

        -- Welcome Back uses the same visual row treatment as the other alerts.
        -- It is preview-only here, so the checkbox is intentionally non-interactive.
        local welcomeRow = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
        welcomeRow:SetSize(26, 26)
        welcomeRow:SetPoint("TOPLEFT", 18, -503)
        welcomeRow:SetChecked(true)
        welcomeRow:EnableMouse(false)
        local welcomeCheckTexture = welcomeRow:GetCheckedTexture()
        if welcomeCheckTexture then
            welcomeCheckTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
        end
        local welcomeTitle = MakeText(welcomeRow, "Welcome Back alert", 14, WHITE, "GameFontHighlight")
        welcomeTitle:SetPoint("TOPLEFT", 32, 1)
        welcomeTitle:SetWordWrap(false)
        local welcomeDesc = MakeText(welcomeRow, "Preview the alert shown when returning to GoldMint.", 11, MUTED)
        welcomeDesc:SetPoint("TOPLEFT", 32, -21)
        welcomeDesc:SetWidth(300)
        welcomeDesc:SetWordWrap(true)
        AddSectionObject(welcomeRow)

        local welcomePreview = MakeGoldMintButton(content, "PREVIEW", 82, 28)
        welcomePreview:SetPoint("TOPLEFT", 350, -502)
        welcomePreview:SetScript("OnClick", function()
            if GoldMint.Alerts and GoldMint.Alerts.Preview then GoldMint.Alerts:Preview("welcomeBack") end
            status:SetText("Welcome Back alert preview shown")
        end)
        AddSectionObject(welcomePreview)

        local unlock = MakeCheckbox(content, -582, "Unlock Alerts", "Keep the GoldMint alert card visible so you can drag it to the position you want.", function()
            return EnsureSettings().alertUnlocked == true
        end, function(v)
            Options:SetSetting("alertUnlocked", v == true)
            if GoldMint.Alerts and GoldMint.Alerts.SetUnlocked then GoldMint.Alerts:SetUnlocked(v == true) end
            status:SetText(v and "Alerts unlocked — drag the preview into place" or "Alerts locked")
        end, 18, 300)
        AddSectionObject(unlock)

        local resetAlert = MakeGoldMintButton(content, "RESET ALERT POSITION", 190, 30)
        resetAlert:SetPoint("TOPLEFT", 26, -658)
        resetAlert:SetScript("OnClick", function()
            Options:SetSetting("alertX", nil); Options:SetSetting("alertY", nil); Options:SetSetting("alertPoint", nil)
            if GoldMint.Alerts and GoldMint.Alerts.ResetPosition then GoldMint.Alerts:ResetPosition() end
            status:SetText("Alert position reset")
        end)
        AddSectionObject(resetAlert)
    end

    local function BuildDisplay()
        contentTitle:SetText("Display")
        contentDesc:SetText("Resize GoldMint while keeping the dashboard's artwork, spacing, and proportions intact.")

        SectionHeader(content, "DASHBOARD SIZE", -100)
        local sizeDesc = MakeText(content, "GoldMint scales as one complete canvas, so the artwork and panel proportions stay intact. This does not stretch individual panels.", 11, MUTED)
        sizeDesc:SetPoint("TOPLEFT", 26, -124)
        sizeDesc:SetWidth(650)
        sizeDesc:SetWordWrap(true)
        AddSectionObject(sizeDesc)

        local slider = CreateFrame("Slider", nil, content, "OptionsSliderTemplate")
        slider:SetSize(600, 24)
        slider:SetPoint("TOPLEFT", 26, -166)
        slider:SetMinMaxValues(0.75, 1.25)
        slider:SetValueStep(0.05)
        slider:SetObeyStepOnDrag(true)
        slider:SetOrientation("HORIZONTAL")
        slider.Low:SetText("75%")
        slider.High:SetText("125%")
        slider.Text:SetText("")
        local valueText = MakeText(content, "100%", 12, GOLD)
        valueText:SetPoint("TOPLEFT", 26, -198)
        AddSectionObject(slider)
        AddSectionObject(valueText)

        local function RefreshScale()
            local value = math.max(0.75, math.min(1.25, tonumber(EnsureSettings().dashboardScale) or 1.0))
            slider:SetValue(value)
            valueText:SetText(string.format("Dashboard Size: %d%%", math.floor(value * 100 + 0.5)))
        end
        slider:SetScript("OnValueChanged", function(self, value)
            value = math.max(0.75, math.min(1.25, tonumber(value) or 1.0))
            Options:SetSetting("dashboardScale", value)
            valueText:SetText(string.format("Dashboard Size: %d%%", math.floor(value * 100 + 0.5)))
            if GoldMint.Dashboard and GoldMint.Dashboard.ApplyDisplayScale then
                GoldMint.Dashboard:ApplyDisplayScale()
            end
        end)
        RefreshScale()

        SectionHeader(content, "MINIMAP", -245)
        local mini = MakeCheckbox(content, -271, "Show Minimap Button", "Show or hide the GoldMint button around the minimap.", function() return EnsureSettings().minimapButtonShown ~= false end, function(v)
            Options:SetSetting("minimapButtonShown", v == true)
            status:SetText("Minimap setting updated")
            if GoldMint.Dashboard and GoldMint.Dashboard.panels and GoldMint.Dashboard.panels.minimapButton then GoldMint.Dashboard.panels.minimapButton:SetShown(v == true) end
        end)
        AddSectionObject(mini)
    end

    local function BuildWorldBossTimers()
        contentTitle:SetText("World Boss Timers")
        contentDesc:SetText("Control GoldMint's standalone world-boss timer display and alerts.")
        SectionHeader(content, "WORLD BOSS TIMER DISPLAY", -100)

        local wbt = GoldMint.WorldBossTimers
        if not wbt or not wbt.GetSettings then
            local unavailable = MakeText(content, "World Boss Timers are not currently available.", 12, GOLD)
            unavailable:SetPoint("TOPLEFT", 26, -126)
            unavailable:SetWidth(650)
            unavailable:SetWordWrap(true)
            AddSectionObject(unavailable)
            return
        end

        local function AddWBTSetting(y, title, description, key)
            local row = MakeCheckbox(content, y, title, description, function()
                return wbt:GetSettings()[key] == true
            end, function(v)
                wbt:SetSetting(key, v == true)
                status:SetText(title .. " updated")
            end)
            AddSectionObject(row)
        end

        AddWBTSetting(-126, "Show Timers for Other Shards", "Include timers received from other players when their shard information is available.", "showOtherShards")
        AddWBTSetting(-190, "Highlight Current Zone", "Highlight the world boss associated with your current zone.", "highlightCurrentZone")
        AddWBTSetting(-254, "Show Saved Status", "Show whether Blizzard reports that you are saved for a tracked world boss.", "showSavedStatus")
        AddWBTSetting(-318, "Show Realm", "Show the realm associated with a received timer when available.", "showRealm")
        AddWBTSetting(-382, "Cyclic Timers", "Continue displaying a repeating timer after a tracked respawn window expires.", "cyclic")
        AddWBTSetting(-446, "Spawn Sound Alert", "Play a GoldMint alert when a tracked boss reaches its spawn window.", "soundEnabled")
        AddWBTSetting(-510, "Alert When Saved", "Allow spawn alerts even when Blizzard reports that you are saved.", "alertWhenSaved")
    end

    local function BuildRareRecipeAlerts()
        contentTitle:SetText("Rare Recipe Spawn Alerts")
        contentDesc:SetText("Configure rare recipe source spawns and the alerts GoldMint should raise before they return.")

        local rare = GoldMint.RareRecipeAlerts
        if not rare then
            SectionHeader(content, "RARE RECIPE SPAWN ALERTS", -100)
            local unavailable = MakeText(content, "Rare Recipe Spawn Alerts are not currently available.", 12, GOLD)
            unavailable:SetPoint("TOPLEFT", 26, -126)
            unavailable:SetWidth(650)
            AddSectionObject(unavailable)
            return
        end

        SectionHeader(content, "ALERT SETTINGS", -100)
        local enabled = MakeCheckbox(content, -126, "Enable Rare Recipe Spawn Alerts", "Watch configured recipe sources and alert you as their next spawn window approaches.", function()
            return rare:GetSettings().enabled == true
        end, function(v)
            rare:SetSetting("enabled", v == true)
            status:SetText("Rare recipe spawn alerts updated")
        end)
        AddSectionObject(enabled)

        local sound = MakeCheckbox(content, -190, "Spawn Alert Sound", "Play a Blizzard alert sound when a configured recipe source reaches its alert window.", function()
            return rare:GetSettings().soundEnabled == true
        end, function(v)
            rare:SetSetting("soundEnabled", v == true)
            status:SetText("Rare recipe alert sound updated")
        end)
        AddSectionObject(sound)

        local leadLabel = MakeText(content, "Alert Lead Time (minutes)", 11, MUTED)
        leadLabel:SetPoint("TOPLEFT", 26, -252)
        AddSectionObject(leadLabel)
        local leadEdit = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        leadEdit:SetSize(90, 30)
        leadEdit:SetPoint("TOPLEFT", 24, -276)
        leadEdit:SetAutoFocus(false)
        leadEdit:SetNumeric(true)
        leadEdit:SetText(tostring(math.floor(tonumber(rare:GetSettings().leadMinutes) or 5)))
        AddSectionObject(leadEdit)
        local leadSave = MakeGoldMintButton(content, "SAVE", 82, 30)
        leadSave:SetPoint("TOPLEFT", 122, -276)
        leadSave:SetScript("OnClick", function()
            local value = tonumber(leadEdit:GetText()) or 5
            rare:SetSetting("leadMinutes", value)
            leadEdit:SetText(tostring(math.floor(tonumber(rare:GetSettings().leadMinutes) or 5)))
            status:SetText("Rare recipe alert lead time updated")
        end)
        AddSectionObject(leadSave)

        SectionHeader(content, "WATCHED RECIPE SOURCES", -330)
        local desc = MakeText(content, "Add the rare NPC that provides the recipe, then set its expected respawn interval. You can target the NPC in-game and use USE TARGET to fill the name and NPC ID.", 10, MUTED)
        desc:SetPoint("TOPLEFT", 26, -354)
        desc:SetWidth(650)
        desc:SetWordWrap(true)
        AddSectionObject(desc)

        local nameLabel = MakeText(content, "Recipe Source", 10, MUTED)
        nameLabel:SetPoint("TOPLEFT", 26, -384)
        AddSectionObject(nameLabel)
        local nameEdit = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        nameEdit:SetSize(230, 28)
        nameEdit:SetPoint("TOPLEFT", 24, -405)
        nameEdit:SetAutoFocus(false)
        nameEdit:SetTextInsets(7, 7, 0, 0)
        AddSectionObject(nameEdit)

        local npcLabel = MakeText(content, "NPC ID", 10, MUTED)
        npcLabel:SetPoint("TOPLEFT", 270, -384)
        AddSectionObject(npcLabel)
        local npcEdit = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        npcEdit:SetSize(110, 28)
        npcEdit:SetPoint("TOPLEFT", 268, -405)
        npcEdit:SetAutoFocus(false)
        npcEdit:SetNumeric(true)
        AddSectionObject(npcEdit)

        local respawnLabel = MakeText(content, "Respawn (min)", 10, MUTED)
        respawnLabel:SetPoint("TOPLEFT", 392, -384)
        AddSectionObject(respawnLabel)
        local respawnEdit = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        respawnEdit:SetSize(110, 28)
        respawnEdit:SetPoint("TOPLEFT", 390, -405)
        respawnEdit:SetAutoFocus(false)
        respawnEdit:SetNumeric(true)
        AddSectionObject(respawnEdit)

        local add = MakeGoldMintButton(content, "ADD / UPDATE WATCH", 160, 30)
        add:SetPoint("TOPLEFT", 26, -444)
        add:SetScript("OnClick", function()
            local watch, err = rare:AddWatch(nameEdit:GetText(), npcEdit:GetText(), respawnEdit:GetText())
            if not watch then
                status:SetText(err or "Unable to add recipe source")
                return
            end
            nameEdit:SetText("")
            npcEdit:SetText("")
            respawnEdit:SetText("")
            status:SetText("Recipe source watch saved")
            Options:RefreshUI()
        end)
        AddSectionObject(add)

        local target = MakeGoldMintButton(content, "USE TARGET", 110, 30)
        target:SetPoint("TOPLEFT", 194, -444)
        target:SetScript("OnClick", function()
            local data, err = rare:CaptureTarget()
            if not data then
                status:SetText(err or "Unable to read target")
                return
            end
            nameEdit:SetText(data.name or "")
            npcEdit:SetText(tostring(data.npcID or ""))
            status:SetText("Target captured; enter respawn minutes")
        end)
        AddSectionObject(target)

        local clear = MakeGoldMintButton(content, "CLEAR ALL", 100, 30)
        clear:SetPoint("TOPLEFT", 314, -444)
        clear:SetScript("OnClick", function()
            rare:ClearWatches()
            status:SetText("Rare recipe watch list cleared")
            Options:RefreshUI()
        end)
        AddSectionObject(clear)

        local watches = rare:GetWatches()
        if #watches == 0 then
            local empty = MakeText(content, "No rare recipe sources are configured yet.", 10, MUTED)
            empty:SetPoint("TOPLEFT", 26, -486)
            AddSectionObject(empty)
        else
            for i, watch in ipairs(watches) do
                if i > 3 then break end
                local row = CreateFrame("Frame", nil, content, "BackdropTemplate")
                row:SetSize(650, 32)
                row:SetPoint("TOPLEFT", 24, -470 - ((i-1) * 38))
                row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
                row:SetBackdropColor(0.008, 0.024, 0.040, 0.92)
                row:SetBackdropBorderColor(0.08, 0.30, 0.46, 0.8)
                local text = MakeText(row, tostring(watch.name or "Rare Recipe Source") .. "  •  NPC " .. tostring(watch.npcID or "?") .. "  •  " .. tostring(watch.respawnMinutes or "?") .. " min", 10, WHITE)
                text:SetPoint("LEFT", 10, 0)
                text:SetWidth(535)
                text:SetJustifyH("LEFT")
                local remove = MakeGoldMintButton(row, "REMOVE", 72, 24)
                remove:SetPoint("RIGHT", -6, 0)
                remove:SetScript("OnClick", function()
                    rare:RemoveWatch(watch.id)
                    status:SetText("Recipe source watch removed")
                    Options:RefreshUI()
                end)
                AddSectionObject(row)
                AddSectionObject(remove)
            end
            if #watches > 3 then
                local more = MakeText(content, "+ " .. tostring(#watches - 3) .. " more configured source(s)", 10, MUTED)
                more:SetPoint("TOPLEFT", 26, -590)
                AddSectionObject(more)
            end
        end
    end

    local function BuildToDoList()
        contentTitle:SetText("To-Do List")
        contentDesc:SetText("Configure GoldMint's To-Do List presentation and behavior using the same core controls found in Mint's To-Do List.")
        SectionHeader(content, "TO-DO LIST DISPLAY", -100)
        local todo = GoldMint.ToDoList
        if not todo or not todo.GetSettings then
            local unavailable = MakeText(content, "The To-Do List is not currently available.", 12, GOLD)
            unavailable:SetPoint("TOPLEFT", 26, -126); AddSectionObject(unavailable); return
        end
        local s = todo:GetSettings()
        local function ButtonRow(y, label, getText, onClick, width)
            local b = MakeGoldMintButton(content, getText(), width or 180, 30)
            b:SetPoint("TOPLEFT", 26, y)
            b:SetScript("OnClick", function() onClick(); if GoldMint.ToDoPopout and GoldMint.ToDoPopout.ApplyMenuSettings then GoldMint.ToDoPopout:ApplyMenuSettings() end; Options:RefreshUI() end)
            AddSectionObject(b)
            local desc = MakeText(content, label, 10, MUTED)
            desc:SetPoint("LEFT", b, "RIGHT", 12, 0); desc:SetWidth(430); desc:SetWordWrap(true); AddSectionObject(desc)
            return b
        end
        ButtonRow(-126, "Switch between Mint-style dark and clear presentation.", function() return "THEME: " .. string.upper(s.theme or "dark") end, function() s.theme = s.theme == "dark" and "clear" or "dark" end)
        ButtonRow(-170, "Hide completed checklist items from the To-Do List.", function() return s.hideCompleted and "HIDE COMPLETED: ON" or "HIDE COMPLETED: OFF" end, function() s.hideCompleted = not s.hideCompleted end)
        ButtonRow(-214, "Show or hide the small movable on-screen To-Do button.", function() return s.screenButton and "SCREEN BUTTON: ON" or "SCREEN BUTTON: OFF" end, function() s.screenButton = not s.screenButton; if GoldMint.ToDoPopout and GoldMint.ToDoPopout.UpdateScreenButton then GoldMint.ToDoPopout:UpdateScreenButton() end end)
        ButtonRow(-258, "Choose whether newly created tasks are placed at the top or bottom of a category.", function() return s.addToTop and "ADD NEW ITEMS: TOP" or "ADD NEW ITEMS: BOTTOM" end, function() s.addToTop = not s.addToTop end)
        ButtonRow(-302, "Choose whether the To-Do window behaves as a dialog or uses the lower UI strata.", function() return "OPEN BEHAVIOR: " .. (s.openBehavior or "DIALOG") end, function() s.openBehavior = s.openBehavior == "DIALOG" and "LOW" or "DIALOG" end)
        ButtonRow(-346, "Cycle the To-Do window between compact, normal, and large menu sizes.", function() return "MENU SIZE: " .. (s.menuSize or "MEDIUM") end, function() s.menuSize = s.menuSize == "SMALL" and "MEDIUM" or (s.menuSize == "MEDIUM" and "LARGE" or "SMALL") end)
        ButtonRow(-390, "Change the overall To-Do window/font scale.", function() return "FONT SIZE: " .. string.format("%.1f", tonumber(s.fontScale) or 1) end, function() s.fontScale = (tonumber(s.fontScale) or 1) >= 1.4 and .8 or (tonumber(s.fontScale) or 1) + .1 end)
        ButtonRow(-434, "Adjust the To-Do window opacity.", function() return "OPACITY: " .. math.floor((tonumber(s.opacity) or .96) * 100) .. "%" end, function() s.opacity = (tonumber(s.opacity) or .96) - .1; if s.opacity < .4 then s.opacity = .96 end end)
        local note = MakeText(content, "These presentation controls are also available from the To-Do window's gear button.", 10, MUTED)
        note:SetPoint("TOPLEFT", 26, -478); note:SetWidth(650); AddSectionObject(note)
    end

    local function BuildFarming()
        contentTitle:SetText("Farming")
        contentDesc:SetText("Configure the Gold Per Hour popout and its recent-loot display.")
        SectionHeader(content, "RECENT LOOT", -100)
        local tracker = GoldMint.FarmTracker
        if not tracker or not tracker.GetRecentLootSettings then
            local unavailable = MakeText(content, "The farming tracker is not currently available.", 12, GOLD)
            unavailable:SetPoint("TOPLEFT", 26, -126)
            AddSectionObject(unavailable)
            return
        end
        local settings = tracker:GetRecentLootSettings()

        local enabled = MakeCheckbox(content, -126, "Show Recent Loot", "Display a compact list of valuable items collected during the current farming session.", function()
            return tracker:GetRecentLootSettings().enabled
        end, function(v)
            tracker:SetRecentLootEnabled(v)
            status:SetText(v and "Recent loot display enabled" or "Recent loot display disabled")
        end)
        AddSectionObject(enabled)

        local thresholdLabel = MakeText(content, "Minimum item value (gold)", 11, MUTED)
        thresholdLabel:SetPoint("TOPLEFT", 58, -182)
        AddSectionObject(thresholdLabel)
        local threshold = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        threshold:SetSize(120, 28)
        threshold:SetPoint("TOPLEFT", 56, -204)
        threshold:SetAutoFocus(false)
        threshold:SetNumeric(true)
        threshold:SetText(tostring(math.floor((tonumber(settings.minValue) or 0) / 10000)))
        AddSectionObject(threshold)

        local saveThreshold = MakeGoldMintButton(content, "SAVE THRESHOLD", 150, 30)
        saveThreshold:SetPoint("TOPLEFT", 194, -203)
        saveThreshold:SetScript("OnClick", function()
            local gold = math.max(0, tonumber(threshold:GetText()) or 0)
            tracker:SetRecentLootMinValue(gold * 10000)
            status:SetText(string.format("Recent loot threshold set to %dg", gold))
            Options:RefreshUI()
        end)
        AddSectionObject(saveThreshold)

        local currentGold = math.floor((tonumber(settings.minValue) or 0) / 10000)
        local current = MakeText(content, string.format("Only loot worth %dg or more will appear. Vendor or market value is used when available.", currentGold), 10, MUTED)
        current:SetPoint("TOPLEFT", 26, -250)
        current:SetWidth(650)
        current:SetWordWrap(true)
        AddSectionObject(current)

        local example = MakeText(content, "Example: with a 10g threshold, a 5g drop stays hidden while a 25g drop appears in Recent Loot.", 10, CYAN)
        example:SetPoint("TOPLEFT", 26, -284)
        example:SetWidth(650)
        example:SetWordWrap(true)
        AddSectionObject(example)
    end

    local function BuildAccessibility()
        contentTitle:SetText("Accessibility")
        contentDesc:SetText("Control reminders and workflow helpers designed to keep GoldMint focused and low-friction.")

        SectionHeader(content, "BREATHE & STRETCH", -100)
        local stretch = MakeCheckbox(content, -126, "Enable Breathe & Stretch reminders", "Use GoldMint's periodic reminder while you are actively farming or working in-game.", function()
            return GoldMint.Accessibility and GoldMint.Accessibility:GetStretchStatus().enabled == true
        end, function(v)
            if GoldMint.Accessibility then
                GoldMint.Accessibility:SetStretchEnabled(v)
                status:SetText(v and "Breathe & Stretch reminders enabled" or "Breathe & Stretch reminders disabled")
            end
        end)
        AddSectionObject(stretch)

        local intervalLabel = MakeText(content, "Reminder interval (minutes)", 11, MUTED)
        intervalLabel:SetPoint("TOPLEFT", 58, -182)
        AddSectionObject(intervalLabel)
        local interval = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        interval:SetSize(110, 28)
        interval:SetPoint("TOPLEFT", 56, -204)
        interval:SetAutoFocus(false)
        interval:SetNumeric(true)
        local stretchStatus = GoldMint.Accessibility and GoldMint.Accessibility:GetStretchStatus() or {}
        interval:SetText(tostring(math.floor((tonumber(stretchStatus.interval) or 3600) / 60)))
        AddSectionObject(interval)

        local durationLabel = MakeText(content, "Reminder duration (seconds)", 11, MUTED)
        durationLabel:SetPoint("TOPLEFT", 220, -182)
        AddSectionObject(durationLabel)
        local duration = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        duration:SetSize(110, 28)
        duration:SetPoint("TOPLEFT", 218, -204)
        duration:SetAutoFocus(false)
        duration:SetNumeric(true)
        duration:SetText(tostring(tonumber(stretchStatus.duration) or 60))
        AddSectionObject(duration)

        local saveStretch = MakeGoldMintButton(content, "SAVE REMINDER", 140, 30)
        saveStretch:SetPoint("TOPLEFT", 340, -203)
        saveStretch:SetScript("OnClick", function()
            if GoldMint.Accessibility then
                GoldMint.Accessibility:SetStretchSettings((tonumber(interval:GetText()) or 60) * 60, tonumber(duration:GetText()) or 60)
                status:SetText("Breathe & Stretch settings saved")
            end
        end)
        AddSectionObject(saveStretch)

        local startStretch = MakeGoldMintButton(content, "START TIMER", 120, 30)
        startStretch:SetPoint("TOPLEFT", 490, -203)
        startStretch:SetScript("OnClick", function()
            if GoldMint.Accessibility then GoldMint.Accessibility:StartStretchTimer(); status:SetText("Breathe & Stretch timer started") end
        end)
        AddSectionObject(startStretch)

        local stopStretch = MakeGoldMintButton(content, "STOP TIMER", 120, 30)
        stopStretch:SetPoint("TOPLEFT", 620, -203)
        stopStretch:SetScript("OnClick", function()
            if GoldMint.Accessibility then GoldMint.Accessibility:StopStretchTimer(); status:SetText("Breathe & Stretch timer stopped") end
        end)
        AddSectionObject(stopStretch)

        SectionHeader(content, "SMART-DUMP", -245)
        local dumpEnabled = MakeCheckbox(content, -270, "Enable Smart-Dump preparation", "Prepare a review queue from your bags. GoldMint never silently sends mail, moves protected items, or sells items for you.", function()
            return GoldMint.Accessibility and GoldMint.Accessibility:GetMailSettings().enabled == true
        end, function(v)
            if GoldMint.Accessibility then GoldMint.Accessibility:SetSmartDumpEnabled(v); status:SetText(v and "Smart-Dump enabled" or "Smart-Dump disabled") end
        end)
        AddSectionObject(dumpEnabled)

        local onlyUnbound = MakeCheckbox(content, -322, "Only include unbound items", "Exclude items already bound to this character.", function()
            return GoldMint.Accessibility and GoldMint.Accessibility:GetMailSettings().onlyUnbound ~= false
        end, function(v)
            if GoldMint.Accessibility then GoldMint.Accessibility:SetMailSetting("onlyUnbound", v); status:SetText("Smart-Dump filter updated") end
        end)
        AddSectionObject(onlyUnbound)

        local excludeQuest = MakeCheckbox(content, -374, "Exclude quest items", "Keep quest items out of the Smart-Dump queue.", function()
            return GoldMint.Accessibility and GoldMint.Accessibility:GetMailSettings().excludeQuestItems ~= false
        end, function(v)
            if GoldMint.Accessibility then GoldMint.Accessibility:SetMailSetting("excludeQuestItems", v); status:SetText("Smart-Dump filter updated") end
        end)
        AddSectionObject(excludeQuest)

        local excludeCraft = MakeCheckbox(content, -426, "Exclude crafting reagents", "Keep crafting reagents out of the Smart-Dump queue.", function()
            return GoldMint.Accessibility and GoldMint.Accessibility:GetMailSettings().excludeCraftingReagents ~= false
        end, function(v)
            if GoldMint.Accessibility then GoldMint.Accessibility:SetMailSetting("excludeCraftingReagents", v); status:SetText("Smart-Dump filter updated") end
        end)
        AddSectionObject(excludeCraft)

        local minValueLabel = MakeText(content, "Minimum item value (gold)", 11, MUTED)
        minValueLabel:SetPoint("TOPLEFT", 58, -476)
        AddSectionObject(minValueLabel)
        local minValue = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        minValue:SetSize(110, 28); minValue:SetPoint("TOPLEFT", 56, -498); minValue:SetAutoFocus(false); minValue:SetNumeric(true)
        local mailSettings = GoldMint.Accessibility and GoldMint.Accessibility:GetMailSettings() or {}
        minValue:SetText(tostring(math.floor((tonumber(mailSettings.minValue) or 0) / 10000)))
        AddSectionObject(minValue)
        local minQualityLabel = MakeText(content, "Minimum quality (0–4)", 11, MUTED)
        minQualityLabel:SetPoint("TOPLEFT", 196, -476)
        AddSectionObject(minQualityLabel)
        local minQuality = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
        minQuality:SetSize(110, 28); minQuality:SetPoint("TOPLEFT", 194, -498); minQuality:SetAutoFocus(false); minQuality:SetNumeric(true)
        minQuality:SetText(tostring(tonumber(mailSettings.minQuality) or 0))
        AddSectionObject(minQuality)
        local saveDump = MakeGoldMintButton(content, "SAVE SMART-DUMP", 150, 30)
        saveDump:SetPoint("TOPLEFT", 326, -497)
        saveDump:SetScript("OnClick", function()
            if GoldMint.Accessibility then
                GoldMint.Accessibility:SetMailSetting("minValue", math.max(0, math.floor((tonumber(minValue:GetText()) or 0) * 10000)))
                GoldMint.Accessibility:SetMailSetting("minQuality", math.max(0, math.min(4, math.floor(tonumber(minQuality:GetText()) or 0))))
                GoldMint.Accessibility:PrepareSmartDump()
                status:SetText("Smart-Dump settings saved")
            end
        end)
        AddSectionObject(saveDump)

        SectionHeader(content, "ONE CLEAR NEXT STEP", -545)
        local nextStep = MakeCheckbox(content, -570, "Keep the dashboard focused on one clear next step", "Show one primary actionable workflow item instead of adding competing next-step prompts.", function()
            return EnsureSettings().oneClearNextStep ~= false
        end, function(v)
            Options:SetSetting("oneClearNextStep", v)
            status:SetText("Next-step focus updated")
            if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then GoldMint.Dashboard:Refresh() end
        end)
        AddSectionObject(nextStep)

    end

    local function BuildManageProject()
        contentTitle:SetText("Manage Project")
        contentDesc:SetText("Create, update, complete, or clear your active GoldMint project.")
        SectionHeader(content, "PROJECT MANAGEMENT", -100)

        local fields = {}
        local selectedProjectType = "Gold Goal"
        local projectTypeButtons = {}

        local function MakeProjectEdit(labelText, x, y, width, numeric)
            local label = MakeText(content, labelText, 11, MUTED)
            label:SetPoint("TOPLEFT", x, y)
            AddSectionObject(label)
            local edit = CreateFrame("EditBox", nil, content, "InputBoxTemplate")
            edit:SetSize(width, 30)
            edit:SetPoint("TOPLEFT", x - 2, y - 24)
            edit:SetAutoFocus(false)
            edit:SetTextInsets(8, 8, 0, 0)
            if numeric then edit:SetNumeric(true) end
            AddSectionObject(edit)
            return edit
        end

        local function ParseGold(text)
            text = tostring(text or ""):gsub("[, ]", "")
            local n = tonumber(text)
            if not n then return nil end
            return math.floor(n * 10000)
        end

        local function ParseDays(text)
            text = tostring(text or ""):gsub("[, ]", "")
            if text == "" then return nil end
            local n = tonumber(text)
            if not n or n < 1 then return nil end
            return math.floor(n)
        end

        fields.name = MakeProjectEdit("Project Name", 26, -126, 330, false)
        fields.target = MakeProjectEdit("Target Gold", 26, -190, 220, true)
        fields.deadline = MakeProjectEdit("Deadline (days, optional)", 274, -190, 220, true)

        local typeLabel = MakeText(content, "Project Type", 11, MUTED)
        typeLabel:SetPoint("TOPLEFT", 26, -254)
        AddSectionObject(typeLabel)

        local projectTypes = {"Gold Goal", "Stockpile", "Buy & Resell", "Crafting", "Market Investment"}
        local buttonWidth, buttonGap = 128, 8
        local function SelectProjectType(value)
            selectedProjectType = value
            for typeName, button in pairs(projectTypeButtons) do
                if typeName == selectedProjectType then
                    button:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
                    button:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
                    button.label:SetTextColor(unpack(GOLD))
                else
                    button:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
                    button:SetBackdropBorderColor(0.20, 0.78, 1.0, 1.0)
                    button.label:SetTextColor(unpack(MUTED))
                end
            end
        end
        for i, typeName in ipairs(projectTypes) do
            local b = MakeGoldMintButton(content, typeName, buttonWidth, 30)
            b:SetPoint("TOPLEFT", 26 + (i - 1) * (buttonWidth + buttonGap), -274)
            b:SetScript("OnClick", function() SelectProjectType(typeName) end)
            projectTypeButtons[typeName] = b
            AddSectionObject(b)
        end

        fields.budget = MakeProjectEdit("Capital Budget (optional)", 26, -326, 220, true)
        fields.expectedRevenue = MakeProjectEdit("Expected Revenue (optional)", 274, -326, 220, true)
        fields.expectedCost = MakeProjectEdit("Expected Cost (optional)", 26, -390, 220, true)
        fields.nextAction = MakeProjectEdit("Next Action (optional)", 274, -390, 330, false)
        fields.checkpoint = MakeProjectEdit("Checkpoint Gold (optional)", 26, -454, 220, true)
        fields.checkpointName = MakeProjectEdit("Checkpoint Name (optional)", 274, -454, 330, false)

        local function RefreshFields()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                fields.name:SetText(active.name or "")
                fields.target:SetText((tonumber(active.target) or 0) > 0 and tostring(math.floor((tonumber(active.target) or 0) / 10000)) or "")
                local days = active.deadline and math.ceil(math.max(0, (tonumber(active.deadline) - time()) / 86400)) or nil
                fields.deadline:SetText(days and tostring(days) or "")
                selectedProjectType = active.projectType or "Gold Goal"
                SelectProjectType(selectedProjectType)
                fields.budget:SetText((tonumber(active.budget) or 0) > 0 and tostring(math.floor((tonumber(active.budget) or 0) / 10000)) or "")
                fields.expectedRevenue:SetText((tonumber(active.expectedRevenue) or 0) > 0 and tostring(math.floor((tonumber(active.expectedRevenue) or 0) / 10000)) or "")
                fields.expectedCost:SetText((tonumber(active.expectedCost) or 0) > 0 and tostring(math.floor((tonumber(active.expectedCost) or 0) / 10000)) or "")
                fields.nextAction:SetText(active.nextAction or "")
                if active.nextCheckpoint then
                    fields.checkpoint:SetText(tostring(math.floor((tonumber(active.nextCheckpoint.amount) or 0) / 10000)))
                    fields.checkpointName:SetText(active.nextCheckpoint.name or "")
                else
                    fields.checkpoint:SetText("")
                    fields.checkpointName:SetText("")
                end
            else
                fields.name:SetText(""); fields.target:SetText(""); fields.deadline:SetText("")
                selectedProjectType = "Gold Goal"; SelectProjectType(selectedProjectType)
                fields.budget:SetText(""); fields.expectedRevenue:SetText(""); fields.expectedCost:SetText("")
                fields.nextAction:SetText(""); fields.checkpoint:SetText(""); fields.checkpointName:SetText("")
            end
        end

        local save = MakeGoldMintButton(content, "SAVE GOAL", 120, 34)
        save:SetPoint("TOPLEFT", 26, -518)
        save:SetScript("OnClick", function()
            local name = strtrim(fields.name:GetText() or "")
            local target = ParseGold(fields.target:GetText())
            local days = ParseDays(fields.deadline:GetText())
            if name == "" then GoldMint.Print("Goal name is required."); return end
            if not target or target <= 0 then GoldMint.Print("Target gold must be greater than 0."); return end

            local deadline = days and (time() + days * 86400) or nil
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            local result, err
            if active then
                result, err = GoldMint.Milestones:UpdateGoal(active.id, {
                    name=name, target=target, deadline=deadline, type="gold",
                    projectType=selectedProjectType,
                    budget=ParseGold(fields.budget:GetText()) or 0,
                    expectedRevenue=ParseGold(fields.expectedRevenue:GetText()) or 0,
                    expectedCost=ParseGold(fields.expectedCost:GetText()) or 0,
                    nextAction=strtrim(fields.nextAction:GetText() or "") ~= "" and strtrim(fields.nextAction:GetText()) or nil,
                })
            else
                result, err = GoldMint.Milestones:CreateGoal(name, target, {
                    type="gold", deadline=deadline, projectType=selectedProjectType,
                    budget=ParseGold(fields.budget:GetText()) or 0,
                    expectedRevenue=ParseGold(fields.expectedRevenue:GetText()) or 0,
                    expectedCost=ParseGold(fields.expectedCost:GetText()) or 0,
                    nextAction=strtrim(fields.nextAction:GetText() or "") ~= "" and strtrim(fields.nextAction:GetText()) or nil,
                })
            end
            if not result then GoldMint.Print("Unable to save goal: " .. tostring(err)); return end

            local cp = ParseGold(fields.checkpoint:GetText())
            local cpName = strtrim(fields.checkpointName:GetText() or "")
            if cp then
                if cp >= target then GoldMint.Print("Checkpoint must be below the goal target."); return end
                local current = GoldMint.Milestones:GetActiveGoal()
                if current then
                    local cpResult, cpErr = GoldMint.Milestones:SetCheckpoint(current.id, cp, cpName ~= "" and cpName or nil)
                    if not cpResult then GoldMint.Print("Unable to save checkpoint: " .. tostring(cpErr)) end
                end
            end
            if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then GoldMint.Dashboard:Refresh() end
            status:SetText("Project saved: " .. name)
            RefreshFields()
        end)
        AddSectionObject(save)

        local complete = MakeGoldMintButton(content, "MARK COMPLETE", 130, 34)
        complete:SetPoint("TOPLEFT", 154, -518)
        complete:SetScript("OnClick", function()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:CompleteGoal(active.id, "manual")
                if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then GoldMint.Dashboard:Refresh() end
                status:SetText("Project marked complete")
                RefreshFields()
            else
                GoldMint.Print("No active project to complete.")
            end
        end)
        AddSectionObject(complete)

        local clear = MakeGoldMintButton(content, "CLEAR GOAL", 110, 34)
        clear:SetPoint("TOPLEFT", 296, -518)
        clear:SetScript("OnClick", function()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:DeleteGoal(active.id)
                if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then GoldMint.Dashboard:Refresh() end
                status:SetText("Active project cleared")
                RefreshFields()
            else
                GoldMint.Print("No active project to clear.")
            end
        end)
        AddSectionObject(clear)

        local hint = MakeText(content, "Changes apply immediately to the active project shown on the Projects page.", 10, MUTED)
        hint:SetPoint("TOPLEFT", 26, -565)
        hint:SetWidth(650)
        AddSectionObject(hint)

        SelectProjectType(selectedProjectType)
        RefreshFields()
    end

    local function BuildSounds()
        contentTitle:SetText("Sounds")
        contentDesc:SetText("Choose the sounds GoldMint uses for alerts and Breathe & Stretch reminders.")

        local function BuildSoundRow(y, title, description, settingKey, soundKind)
            SectionHeader(content, title, y)
            local desc = MakeText(content, description, 11, MUTED)
            desc:SetPoint("TOPLEFT", 26, y - 28)
            desc:SetWidth(650)
            AddSectionObject(desc)

            local choices = GoldMint.Sounds and GoldMint.Sounds.GetChoices and GoldMint.Sounds:GetChoices() or {}
            local index = 1
            local current = EnsureSettings()[settingKey]
            for i, choice in ipairs(choices) do
                if choice.key == current then index = i; break end
            end

            local selector = MakeGoldMintButton(content, "", 260, 34)
            selector:SetPoint("TOPLEFT", 26, y - 58)
            local function RefreshSelector()
                local choice = choices[index]
                selector.label:SetText((choice and choice.label or "None"))
            end
            selector:SetScript("OnClick", function()
                index = index + 1
                if index > #choices then index = 1 end
                local choice = choices[index]
                if choice then
                    Options:SetSetting(settingKey, choice.key)
                    if GoldMint.Sounds and GoldMint.Sounds.Set then GoldMint.Sounds:Set(soundKind, choice.key) end
                    RefreshSelector()
                    status:SetText(title .. " sound: " .. choice.label)
                end
            end)
            AddSectionObject(selector)

            local test = MakeGoldMintButton(content, "TEST SOUND", 140, 34)
            test:SetPoint("TOPLEFT", 296, y - 58)
            test:SetScript("OnClick", function()
                if GoldMint.Sounds and GoldMint.Sounds.Test then GoldMint.Sounds:Test(soundKind) end
            end)
            AddSectionObject(test)
            RefreshSelector()
        end

        BuildSoundRow(-100, "ALERT SOUNDS", "Sound used when a GoldMint alert card is triggered.", "alertSound", "alert")
        BuildSoundRow(-324, "BREATHE & STRETCH", "Sound used when it is time for your Breathe & Stretch reminder.", "stretchSound", "stretch")

        local note = MakeText(content, "Click a sound button to cycle through your available GoldMint sounds. Use TEST SOUND to preview it.", 10, MUTED)
        note:SetPoint("TOPLEFT", 26, -455)
        note:SetWidth(650)
        AddSectionObject(note)
    end

    local function BuildData()
        contentTitle:SetText("Data & Reset")
        contentDesc:SetText("Manage GoldMint preferences without deleting your economic history.")
        SectionHeader(content, "SETTINGS", -100)
        local info = MakeText(content, "Resetting settings restores preferences to their defaults. Saved farming, market, recipe, and economic history is not deleted.", 11, MUTED)
        info:SetPoint("TOPLEFT", 26, -124); info:SetWidth(650); AddSectionObject(info)
        local reset = MakeGoldMintButton(content, "RESET SETTINGS", 170, 34)
        reset:SetPoint("TOPLEFT", 26, -174)
        reset:SetScript("OnClick", function()
            Options:ResetSettings()
            status:SetText("Settings restored to defaults")
            Options:RefreshUI()
        end)
        AddSectionObject(reset)
        local schema = MakeText(content, "Settings are preserved across reloads and addon upgrades.", 10, MUTED)
        schema:SetPoint("TOPLEFT", 26, -220); AddSectionObject(schema)
    end

    local builders = {
        general=BuildGeneral,
        dashboard=BuildDashboard,
        display=BuildDisplay,
        todo=BuildToDoList,
        farming=BuildFarming,
        accessibility=BuildAccessibility,
        notifications=BuildNotifications,
        worldbosstimers=BuildWorldBossTimers,
        rarerecipealerts=BuildRareRecipeAlerts,
        manageproject=BuildManageProject,
        sounds=BuildSounds,
        data=BuildData,
    }

    local navItems = {
        {"General", "general"},
        {"Dashboard", "dashboard"},
        {"Display", "display"},
        {"To-Do List", "todo"},
        {"Farming", "farming"},
        {"Accessibility", "accessibility"},
        {"Alerts & Toasts", "notifications"},
        {"World Boss Timers", "worldbosstimers"},
        {"Rare Recipe Spawn Alerts", "rarerecipealerts"},
        {"Manage Project", "manageproject"},
        {"Sounds", "sounds"},
        {"Data & Reset", "data"},
    }

    local function ApplyNav(key, active, hover)
        local b = navButtons[key]
        if not b then return end
        if active then
            b:SetBackdropColor(0.08, 0.18, 0.28, 0.62)
            b.text:SetTextColor(unpack(GOLD)); b.accent:Show()
        elseif hover then
            b:SetBackdropColor(0.08, 0.18, 0.28, 0.45)
            b.text:SetTextColor(unpack(GOLD)); b.accent:Hide()
        else
            b:SetBackdropColor(0,0,0,0)
            b.text:SetTextColor(unpack(MUTED)); b.accent:Hide()
        end
    end

    local function ShowSection(key)
        currentSection = key
        HideGuildMenu()
        ClearSection()
        for navKey in pairs(navButtons) do ApplyNav(navKey, navKey == key, false) end
        if builders[key] then builders[key]() end
        if key == "general" and guildButton then guildButton.label:SetText(GuildLabel()) end
    end

    for i,item in ipairs(navItems) do
        local b = CreateFrame("Button", nil, rail, "BackdropTemplate")
        b:SetSize(224, 46)
        b:SetPoint("TOPLEFT", 0, -66 - ((i-1)*48))
        b:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=16})
        b:SetBackdropColor(0,0,0,0)
        b.text = MakeText(b, item[1], 13, MUTED, "GameFontNormal")
        b.text:SetPoint("LEFT", 24, 0)
        b.accent = b:CreateTexture(nil, "ARTWORK")
        b.accent:SetColorTexture(0.08, 0.78, 1.0, 0.95)
        b.accent:SetSize(3, 46); b.accent:SetPoint("TOPLEFT", 0, 0); b.accent:Hide()
        navButtons[item[2]] = b
        b._goldMintSectionKey = item[2]
        b:SetScript("OnEnter", function() if currentSection ~= item[2] then ApplyNav(item[2], false, true) end end)
        b:SetScript("OnLeave", function() ApplyNav(item[2], currentSection == item[2], false) end)
        b:SetScript("OnClick", function() ShowSection(item[2]) end)
    end

    local footer = MakeText(rail, "GoldMint Settings", 10, MUTED)
    footer:SetPoint("BOTTOMLEFT", 20, 18)
    local version = MakeText(rail, "Preferences apply immediately", 9, MUTED)
    version:SetPoint("BOTTOMLEFT", 20, 4)

    f:SetScript("OnMouseDown", function() HideGuildMenu() end)
    f:SetScript("OnShow", function()
        f._uiLifecycle = (f._uiLifecycle or 0) + 1
        ShowSection(f._requestedSection or currentSection or "general")
        f._requestedSection = nil
        status:SetText("Changes apply immediately")
    end)
    f:SetScript("OnHide", function()
        f._uiLifecycle = (f._uiLifecycle or 0) + 1
        HideGuildMenu()
    end)

    f:Hide()
    ShowSection("general")
    return f
end

function Options:OpenSection(key)
    key = key or "general"
    if key == "alerts" or key == "toasts" then key = "notifications" end
    if not self.frame then self:Create() end
    self._requestedSection = key
    if self.frame and self.frame.rail then
        for _, child in ipairs({self.frame.rail:GetChildren()}) do
            if child._goldMintSectionKey == key then
                child:Click()
                return
            end
        end
    end
end

function Options:RefreshUI()
    if not self.frame or not self.frame:IsShown() then return end
    local key = "general"
    -- Rebuild the currently selected section from the live settings store.
    if self.frame.contentTitle then
        local title = self.frame.contentTitle:GetText() or ""
        local map = {General="general", Dashboard="dashboard", Alerts="notifications", ["Alerts & Toasts"]="notifications", Display="display", ToDoList="todo", ["To-Do List"]="todo", Farming="farming", Toasts="notifications", Notifications="notifications", Accessibility="accessibility", ["World Boss Timers"]="worldbosstimers", ["Rare Recipe Spawn Alerts"]="rarerecipealerts", ["Manage Project"]="manageproject", Sounds="sounds", ["Data & Reset"]="data"}
        key = map[title] or "general"
    end
    -- The section is rebuilt by clicking its rail button; use the title mapping
    -- above so reset controls can refresh without exposing internal UI objects.
    if self.frame.rail then
        for _, child in ipairs({self.frame.rail:GetChildren()}) do
            if child.text and child.text:GetText() == (self.frame.contentTitle:GetText() or "") then
                child:Click()
                return
            end
        end
    end
end

function GoldMint:OpenOptions(section)
    -- Options is deliberately independent from the dashboard. Opening it
    -- always closes the dashboard so the two large windows never overlap.
    if GoldMint.Dashboard and GoldMint.Dashboard.Hide then
        GoldMint.Dashboard:Hide()
    end
    local f = Options:Create()
    if section then Options:OpenSection(section) end
    f:Show()
    f:Raise()
end

function Options:Toggle()
    if self.frame and self.frame:IsShown() then
        self.frame:Hide()
    else
        GoldMint:OpenOptions()
    end
end
