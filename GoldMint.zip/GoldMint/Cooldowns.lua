local ADDON_NAME, GoldMint = ...

-- ============================================================================
-- GOLDMINT PROFESSION COOLDOWNS — TOAST NOTIFICATIONS
-- ============================================================================
--
-- Passive, account-wide profession cooldown tracking.
--
-- Rules:
--   * No manual scan is required.
--   * Opening a profession silently updates its cooldown data.
--   * Only recipes for which WoW reports an actual cooldown/charge system are
--     recorded; there is no hardcoded list of transmutes, cloth, etc.
--   * Ready times are saved as absolute server timestamps so they survive
--     logout, reloads, and changing characters.
--   * A cooldown becoming ready produces at most one notification per ready
--     cycle.  The addon does not repeatedly spam chat.
--
-- WoW 12.1 exposes C_TradeSkillUI.GetRecipeCooldown(recipeID), which returns
-- remaining seconds, a day-cooldown flag, and charge data.
-- ============================================================================

GoldMint.Cooldowns = {}
local Cooldowns = GoldMint.Cooldowns

-- Thin GoldMint scrollbar matching the dashboard reference skin.
local function CreateGoldMintScrollFrame(parent, topLeftX, topLeftY, bottomRightX, bottomRightY, contentWidth)
    local scroll = CreateFrame("ScrollFrame", nil, parent)
    scroll:SetPoint("TOPLEFT", topLeftX or 0, topLeftY or 0)
    scroll:SetPoint("BOTTOMRIGHT", bottomRightX or 0, bottomRightY or 0)
    scroll:EnableMouseWheel(true)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(contentWidth or 600, 1)
    scroll:SetScrollChild(content)

    local bar = CreateFrame("Frame", nil, parent)
    bar:SetWidth(16)
    bar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -3, topLeftY or 0)
    bar:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -3, bottomRightY or 0)
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0.008,0.030,0.050,0.92); track:SetPoint("TOPLEFT",4,0); track:SetPoint("BOTTOMRIGHT",-4,0)
    local line = bar:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(0.20,0.78,1.0,0.42); line:SetWidth(2); line:SetPoint("TOP",0,0); line:SetPoint("BOTTOM",0,0)
    local thumb = CreateFrame("Button", nil, bar)
    thumb:SetWidth(8); thumb:SetHeight(44); thumb:SetPoint("TOP",0,0)
    local thumbBG = thumb:CreateTexture(nil,"BACKGROUND"); thumbBG:SetColorTexture(0.015,0.075,0.115,0.96); thumbBG:SetAllPoints()
    local thumbLine = thumb:CreateTexture(nil,"ARTWORK"); thumbLine:SetColorTexture(0.20,0.78,1.0,0.95); thumbLine:SetWidth(2); thumbLine:SetPoint("TOP",0,0); thumbLine:SetPoint("BOTTOM",0,0)
    local function UpdateBar()
        local range=math.max(0,scroll:GetVerticalScrollRange() or 0); local viewport=math.max(1,scroll:GetHeight() or 1); local th=math.max(1,bar:GetHeight() or 1)
        if range<=0 then bar:Hide(); return end
        bar:Show(); local hh=math.max(34,math.min(th,math.floor((viewport/(viewport+range))*th))); thumb:SetHeight(hh)
        local travel=math.max(0,th-hh); local f=math.max(0,math.min(1,(scroll:GetVerticalScroll() or 0)/range)); thumb:ClearAllPoints(); thumb:SetPoint("TOP",bar,"TOP",0,-travel*f)
    end
    scroll.UpdateGoldMintScrollBar=UpdateBar
    scroll._goldMintContent=content
    scroll:SetScript("OnMouseWheel",function(self,delta) local step=math.max(24,self:GetHeight()*0.18); local range=self:GetVerticalScrollRange() or 0; self:SetVerticalScroll(math.max(0,math.min(range,(self:GetVerticalScroll() or 0)-delta*step))); UpdateBar() end)
    scroll:SetScript("OnVerticalScroll",function() UpdateBar() end)
    scroll:SetScript("OnSizeChanged",function() UpdateBar() end)
    local dragging=false; local startY=0; local startScroll=0
    thumb:SetScript("OnMouseDown",function(self,button) if button=="LeftButton" then dragging=true; startY=select(2,GetCursorPosition())/UIParent:GetEffectiveScale(); startScroll=scroll:GetVerticalScroll() or 0 end end)
    thumb:SetScript("OnMouseUp",function() dragging=false end)
    thumb:SetScript("OnUpdate",function() if dragging then local y=select(2,GetCursorPosition())/UIParent:GetEffectiveScale(); local travel=math.max(1,bar:GetHeight()-thumb:GetHeight()); local range=scroll:GetVerticalScrollRange() or 0; scroll:SetVerticalScroll(math.max(0,math.min(range,startScroll+((startY-y)/travel)*range))); UpdateBar() end end)
    C_Timer.After(0,UpdateBar)
    return scroll, content
end


local UPDATE_INTERVAL = 5
local now = time

local function EnsureStore()
    GoldMintDB.cooldowns = type(GoldMintDB.cooldowns) == "table" and GoldMintDB.cooldowns or {}
    GoldMintDB.cooldowns.version = tonumber(GoldMintDB.cooldowns.version) or 1
    GoldMintDB.cooldowns.recipes = type(GoldMintDB.cooldowns.recipes) == "table" and GoldMintDB.cooldowns.recipes or {}
    GoldMintDB.cooldowns.tracking = type(GoldMintDB.cooldowns.tracking) == "table" and GoldMintDB.cooldowns.tracking or {}
    GoldMintDB.cooldowns.materialsRecipeID = tonumber(GoldMintDB.cooldowns.materialsRecipeID)

    -- Tracking is an explicit player choice.  Alpha-34/35/36 temporarily
    -- migrated every legacy cooldown as tracked, which made the dashboard
    -- report large counts such as 71 Ready / 25 On Cooldown.  On first load of
    -- the corrected selection system, discard that implicit migration and let
    -- the player choose the cooldowns that belong on the dashboard.  Once the
    -- selection version is recorded, never clear the player's choices again.
    local TRACKING_SELECTION_VERSION = 2
    if tonumber(GoldMintDB.cooldowns.trackingSelectionVersion) ~= TRACKING_SELECTION_VERSION then
        GoldMintDB.cooldowns.tracking = {}
        GoldMintDB.cooldowns.trackingSelectionVersion = TRACKING_SELECTION_VERSION
    end
    return GoldMintDB.cooldowns
end

local function GetCharacterKey()
    return GoldMint.characterKey
end

-- Character Data Cache -------------------------------------------------------
-- Cooldown state belongs to the character that was scanned. The global recipe
-- table remains the discovery/selection index, while this cache is the
-- cross-character source for the live Ready / On Cooldown dashboard state.
local CHARACTER_CACHE_VERSION = 1

local function EnsureCharacterCooldownCache(characterKey)
    if not GoldMintDB or not characterKey then return nil end
    GoldMintDB.characters = type(GoldMintDB.characters) == "table" and GoldMintDB.characters or {}
    local character = GoldMintDB.characters[characterKey]
    if type(character) ~= "table" then
        character = {}
        GoldMintDB.characters[characterKey] = character
    end

    character.cooldownCache = type(character.cooldownCache) == "table" and character.cooldownCache or {}
    character.cooldownCache.version = tonumber(character.cooldownCache.version) or CHARACTER_CACHE_VERSION
    character.cooldownCache.recipes = type(character.cooldownCache.recipes) == "table" and character.cooldownCache.recipes or {}
    return character.cooldownCache
end

local function SaveCachedState(record, characterKey, state)
    local cache = EnsureCharacterCooldownCache(characterKey)
    if not cache or not record or not state then return end

    cache.recipes[tostring(record.recipeID)] = {
        recipeID = record.recipeID,
        name = record.name,
        professionName = record.professionName,
        ready = state.ready == true,
        currentActive = state.currentActive == true,
        readyAt = state.readyAt,
        charges = state.charges,
        maxCharges = state.maxCharges,
        cooldownObserved = state.cooldownObserved == true,
        lastProfessionScanAt = state.lastProfessionScanAt,
        seen = state.seen,
        canCraft = state.canCraft == true,
    }
    cache.lastScanAt = state.lastProfessionScanAt or cache.lastScanAt or time()
end

local function RemoveCachedProfession(characterKey, professionName, seenRecipeIDs)
    local cache = EnsureCharacterCooldownCache(characterKey)
    if not cache then return end

    for recipeID, cached in pairs(cache.recipes) do
        if type(cached) == "table" and cached.professionName == professionName and not seenRecipeIDs[tonumber(recipeID) or recipeID] then
            cache.recipes[recipeID] = nil
        end
    end
end

local function MigrateLegacyCharacterCache()
    local store = EnsureStore()
    for recipeID, record in pairs(store.recipes or {}) do
        if type(record) == "table" and type(record.characters) == "table" then
            for characterKey, state in pairs(record.characters) do
                if type(state) == "table" then
                    local cache = EnsureCharacterCooldownCache(characterKey)
                    local id = tostring(record.recipeID or recipeID)
                    if cache and not cache.recipes[id] then
                        SaveCachedState(record, characterKey, state)
                    end
                end
            end
        end
    end
end

local function GetCharacterName(key)
    local character = GoldMintDB.characters and GoldMintDB.characters[key]
    if character and character.name and character.realm then
        return character.name .. "-" .. character.realm
    end
    return key
end

local function GetProfessionInfo(recipeID, fallbackProfession)
    if C_TradeSkillUI and C_TradeSkillUI.GetProfessionInfoByRecipeID then
        local ok, info = pcall(C_TradeSkillUI.GetProfessionInfoByRecipeID, recipeID)
        if ok and info then
            return info.professionName or info.parentProfessionName or fallbackProfession
        end
    end
    return fallbackProfession
end

local function GetCurrentProfessionName()
    if C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo then
        local ok, info = pcall(C_TradeSkillUI.GetBaseProfessionInfo)
        if ok and info then
            return info.professionName
        end
    end
    return nil
end

local function GetRecipeInfo(recipeID)
    if not C_TradeSkillUI or not C_TradeSkillUI.GetRecipeInfo then
        return nil
    end

    local ok, info = pcall(C_TradeSkillUI.GetRecipeInfo, recipeID)
    if ok and info then
        return info
    end
    return nil
end

local function GetCooldown(recipeID)
    if not C_TradeSkillUI or not C_TradeSkillUI.GetRecipeCooldown then
        return nil, false, nil, nil
    end

    local ok, remaining, isDayCooldown, charges, maxCharges = pcall(
        C_TradeSkillUI.GetRecipeCooldown,
        recipeID
    )

    if not ok then
        return nil, false, nil, nil
    end

    -- GetRecipeCooldown's second return is the "day cooldown" flag, not an
    -- indication that the recipe is currently on cooldown. A large number of
    -- profession recipes can have this flag while currently ready.
    return tonumber(remaining), isDayCooldown == true, tonumber(charges), tonumber(maxCharges)
end

-- ============================================================================
-- LEGACY PROFESSION SPELL COOLDOWNS
-- ============================================================================
--
-- Some older profession cooldowns are exposed as legacy spell IDs instead of
-- modern TradeSkill recipe cooldowns.  Retail 12.1 uses C_Spell.GetSpellCooldown
-- for these.  A strict 24-hour duration is treated as a real, spell-specific
-- cooldown.  Anything else (including a ready spell, zero duration, or a
-- different duration) deliberately falls back to Blizzard's regional daily
-- reset epoch.
--
-- IMPORTANT: C_Spell.GetSpellCooldown returns startTime on the WoW cooldown
-- timebase.  The expiration calculation below intentionally follows the
-- server-time conversion requested for GoldMint: GetServerTime() + duration -
-- (GetServerTime() - startTime).
-- ============================================================================

local STRICT_DAILY_COOLDOWN = 86400

local function GetRegionalDailyResetEpoch()
    local serverNow = type(GetServerTime) == "function" and tonumber(GetServerTime()) or time()
    local remaining

    if C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset then
        remaining = tonumber(C_DateAndTime.GetSecondsUntilDailyReset())
    elseif type(GetQuestResetTime) == "function" then
        remaining = tonumber(GetQuestResetTime())
    end

    if not remaining or remaining < 0 then
        remaining = STRICT_DAILY_COOLDOWN
    end

    return math.floor(serverNow - math.max(0, STRICT_DAILY_COOLDOWN - remaining))
end

local function GetLegacyProfessionSpellCooldown(spellID)
    spellID = tonumber(spellID)
    if not spellID or not C_Spell or type(C_Spell.GetSpellCooldown) ~= "function" then
        local resetAt = GetRegionalDailyResetEpoch()
        return {
            spellID = spellID,
            duration = 0,
            startTime = 0,
            readyAt = resetAt,
            remaining = math.max(0, resetAt - (type(GetServerTime) == "function" and GetServerTime() or time())),
            strict24Hour = false,
            source = "regional_daily_reset",
        }
    end

    local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
    local serverNow = type(GetServerTime) == "function" and tonumber(GetServerTime()) or time()

    if not ok or type(info) ~= "table" then
        local resetAt = GetRegionalDailyResetEpoch()
        return {
            spellID = spellID,
            duration = 0,
            startTime = 0,
            readyAt = resetAt,
            remaining = math.max(0, resetAt - serverNow),
            strict24Hour = false,
            source = "regional_daily_reset",
        }
    end

    local startTime = tonumber(info.startTime) or 0
    local duration = tonumber(info.duration) or 0

    if duration == STRICT_DAILY_COOLDOWN and startTime > 0 then
        -- Use the exact requested server-time expiration formula.
        local currentServerTime = type(GetServerTime) == "function" and tonumber(GetServerTime()) or serverNow
        local readyAt = currentServerTime + duration - (currentServerTime - startTime)
        return {
            spellID = spellID,
            duration = duration,
            startTime = startTime,
            readyAt = readyAt,
            remaining = math.max(0, readyAt - currentServerTime),
            strict24Hour = true,
            source = "spell_24_hour",
            isActive = info.isActive == true,
        }
    end

    -- Do not manufacture a spell-specific timer for any other duration.
    -- GoldMint intentionally follows the regional daily reset in this case.
    local resetAt = GetRegionalDailyResetEpoch()
    return {
        spellID = spellID,
        duration = duration,
        startTime = startTime,
        readyAt = resetAt,
        remaining = math.max(0, resetAt - serverNow),
        strict24Hour = false,
        source = "regional_daily_reset",
        isActive = info.isActive == true,
    }
end

function Cooldowns:GetLegacyProfessionSpellCooldown(spellID)
    return GetLegacyProfessionSpellCooldown(spellID)
end

local function IsCooldownRecipe(remaining, isDayCooldown, charges, maxCharges, knownRecipe)
    -- Track recipes that WoW identifies as daily cooldowns, plus any recipe
    -- that is actively cooling down.  Do not use maxCharges by itself as a
    -- discovery signal: many ordinary profession recipes expose charge
    -- metadata and would otherwise flood the cooldown list.
    if remaining and remaining > 0 then
        return true
    end

    if isDayCooldown then
        return true
    end

    -- Preserve a previously discovered non-daily cooldown only when its live
    -- state says it was actually active/ready or has a saved timer. This avoids
    -- resurrecting legacy records created from generic charge metadata.
    if knownRecipe then
        return true
    end

    return false
end

local function IsTracked(recipeID)
    local store = EnsureStore()
    local key = tostring(recipeID)
    return store.tracking[key] == true
end

function Cooldowns:IsTracked(recipeID)
    return IsTracked(recipeID)
end

function Cooldowns:SetTracked(recipeID, tracked)
    if not recipeID then return false end
    local store = EnsureStore()
    local key = tostring(recipeID)
    local enabled = tracked == true
    store.tracking[key] = enabled

    -- The most recently tracked recipe is also the recipe whose reagent
    -- shopping list should drive the Materials Gathering Tracker. Refresh its
    -- schematic immediately so the tracker has the actual reagent quantities.
    if enabled then
        store.materialsRecipeID = tonumber(recipeID)
        if GoldMint.CraftingProfit and GoldMint.CraftingProfit.RefreshRecipe then
            pcall(GoldMint.CraftingProfit.RefreshRecipe, GoldMint.CraftingProfit, tonumber(recipeID))
        end
    elseif tonumber(store.materialsRecipeID) == tonumber(recipeID) then
        store.materialsRecipeID = nil
    end

    return true
end

function Cooldowns:GetMaterialsRecipe()
    local store = EnsureStore()
    local recipeID = tonumber(store.materialsRecipeID)
    if not recipeID then return nil end

    local record = GoldMintDB and GoldMintDB.recipes and GoldMintDB.recipes[recipeID]
    if type(record) ~= "table" or type(record.reagents) ~= "table" or #record.reagents == 0 then
        if GoldMint.CraftingProfit and GoldMint.CraftingProfit.RefreshRecipe then
            pcall(GoldMint.CraftingProfit.RefreshRecipe, GoldMint.CraftingProfit, recipeID)
        end
        record = GoldMintDB and GoldMintDB.recipes and GoldMintDB.recipes[recipeID]
    end
    return type(record) == "table" and record or nil
end

function Cooldowns:GetDiscoveredRecipes()
    local result = {}
    local store = EnsureStore()
    for recipeID, record in pairs(store.recipes or {}) do
        if type(record) == "table" and record.name then
            result[#result + 1] = {
                recipeID = tonumber(recipeID) or record.recipeID,
                name = record.name,
                professionName = record.professionName or "Profession",
                tracked = IsTracked(recipeID),
            }
        end
    end
    table.sort(result, function(a, b)
        local ap = (a.professionName or "") .. " " .. (a.name or "")
        local bp = (b.professionName or "") .. " " .. (b.name or "")
        return ap < bp
    end)
    return result
end

function Cooldowns:SetAllTracked(tracked)
    local store = EnsureStore()
    for recipeID in pairs(store.recipes or {}) do
        store.tracking[tostring(recipeID)] = tracked == true
    end
end

local function NotifyReady(record, characterKey)
    if record.notifiedAt and record.readyAt and record.notifiedAt >= record.readyAt then
        return
    end

    ShowReadyToast(record, characterKey)
    record.notifiedAt = now()
end

local function UpdateRecord(record, characterKey, remaining, isDayCooldown, charges, maxCharges)
    local timestamp = now()
    local state = record.characters[characterKey]

    if not state then
        state = {
            seen = timestamp,
            ready = false,
            readyAt = nil,
            notifiedAt = nil,
        }
        record.characters[characterKey] = state
    end

    local wasActive = state.currentActive == true
    local wasWaiting = state.readyAt ~= nil

    state.seen = timestamp
    state.charges = charges
    state.maxCharges = maxCharges
    state.lastProfessionScanAt = timestamp
    state.cooldownObserved = true

    -- A positive remaining value is the authoritative definition of
    -- "On Cooldown".  The daily flag only tells us that this recipe has a
    -- daily cooldown and is therefore a trackable opportunity when ready.
    if remaining and remaining > 0 then
        state.currentActive = true
        state.ready = false
        state.cooldownActiveObserved = true
        state.readyAt = timestamp + math.ceil(remaining)
        state.notifiedAt = nil
        return false
    end

    state.currentActive = false

    -- Daily cooldown recipes are immediately Ready when WoW reports no
    -- remaining timer. This is the important distinction between a recipe
    -- that has a daily cooldown and one that is actually On Cooldown.
    if isDayCooldown then
        state.ready = true
        state.readyAt = nil
        state.cooldownActiveObserved = false

        if wasActive or wasWaiting then
            NotifyReady(record, characterKey)
            return true
        end
        return false
    end

    -- For a previously observed non-daily cooldown, a scan with no remaining
    -- timer means the cooldown has completed. Keep it Ready without requiring
    -- a special profession-specific rule.
    if wasActive or state.readyAt ~= nil then
        state.ready = true
        state.readyAt = nil
        state.cooldownActiveObserved = false
        if wasActive then
            NotifyReady(record, characterKey)
            return true
        end
    elseif state.ready then
        state.ready = true
    else
        state.ready = false
    end

    return false
end

function Cooldowns:UpdateCurrentProfession()
    if not GoldMintDB or not GoldMint.characterKey then
        return 0
    end

    if not C_TradeSkillUI or not C_TradeSkillUI.GetAllRecipeIDs then
        return 0
    end

    local recipeIDs = C_TradeSkillUI.GetAllRecipeIDs()
    if type(recipeIDs) ~= "table" then
        return 0
    end

    local professionName = GetCurrentProfessionName()
    local store = EnsureStore()
    local characterKey = GetCharacterKey()
    local captured = 0
    local scannedAt = now()
    local seenCooldownRecipes = {}
    local cache = EnsureCharacterCooldownCache(characterKey)
    if cache then
        cache.lastScanAt = scannedAt
        cache.lastProfession = professionName or cache.lastProfession
    end

    for _, recipeID in ipairs(recipeIDs) do
        local remaining, isDayCooldown, charges, maxCharges = GetCooldown(recipeID)
        local existingRecord = store.recipes[recipeID]
        local existingState = existingRecord and existingRecord.characters
            and existingRecord.characters[characterKey]
        local knownRecipe = existingState and (
            existingState.ready == true
            or existingState.readyAt ~= nil
            or existingState.currentActive == true
        )
        local isCooldown = IsCooldownRecipe(
            remaining,
            isDayCooldown,
            charges,
            maxCharges,
            knownRecipe
        )

        if isCooldown then
            local info = GetRecipeInfo(recipeID)
            if info and info.name then
                local record = store.recipes[recipeID]

                if not record then
                    record = {
                        recipeID = recipeID,
                        name = info.name,
                        professionName = GetProfessionInfo(recipeID, professionName),
                        firstSeen = scannedAt,
                        lastSeen = scannedAt,
                        characters = {},
                    }
                    store.recipes[recipeID] = record
                end

                record.name = info.name
                record.professionName = GetProfessionInfo(recipeID, professionName) or record.professionName
                record.lastSeen = scannedAt
                record.characters = type(record.characters) == "table" and record.characters or {}

                UpdateRecord(
                    record,
                    characterKey,
                    remaining,
                    isDayCooldown,
                    charges,
                    maxCharges
                )

                local state = record.characters[characterKey]
                if state then
                    state.lastProfessionScanAt = scannedAt
                    -- Store the live profession-side craftability for this
                    -- character.  A tracked cooldown may exist on a character
                    -- that knows the recipe but cannot currently craft it.
                    local learned = info.learned == true
                    local craftable = info.craftable == true
                    if C_TradeSkillUI and C_TradeSkillUI.IsRecipeProfessionLearned then
                        local okLearned, professionLearned = pcall(
                            C_TradeSkillUI.IsRecipeProfessionLearned,
                            recipeID
                        )
                        if okLearned then
                            learned = professionLearned == true
                        end
                    end
                    state.canCraft = learned and craftable
                    SaveCachedState(record, characterKey, state)
                end

                seenCooldownRecipes[recipeID] = true
                captured = captured + 1
            end
        end
    end

    -- Reconcile the character data cache for the profession just scanned.
    -- Other characters and other professions remain untouched.
    RemoveCachedProfession(characterKey, professionName, seenCooldownRecipes)

    -- A previous scan can leave an old active record behind after its cooldown
    -- finishes or the recipe is no longer reported as a cooldown. Reconcile
    -- only the current character's records so other characters remain intact.
    for recipeID, record in pairs(store.recipes) do
        local state = record.characters and record.characters[characterKey]
        if state and state.lastProfessionScanAt ~= scannedAt then
            -- The current profession scan is a complete snapshot for this
            -- character. Remove anything that was not observed this pass,
            -- regardless of the old profession label, so stale cooldowns from
            -- earlier scans cannot remain in the dashboard.
            record.characters[characterKey] = nil
        end
    end

    return captured
end

function Cooldowns:CheckReadyStates()
    local store = EnsureStore()
    local timestamp = now()
    local readyCount = 0

    -- The character cache is authoritative for cross-character cooldown state.
    for characterKey, character in pairs(GoldMintDB.characters or {}) do
        local cache = character and character.cooldownCache
        if type(cache) == "table" and type(cache.recipes) == "table" then
            for recipeID, state in pairs(cache.recipes) do
                if IsTracked(recipeID) and type(state) == "table" then
                    if state.readyAt and timestamp >= state.readyAt then
                        state.readyAt = nil
                        state.currentActive = false
                        state.ready = true
                        readyCount = readyCount + 1

                        local record = store.recipes[recipeID] or store.recipes[tonumber(recipeID)]
                        if record then
                            NotifyReady(record, characterKey)
                            local legacyState = record.characters and record.characters[characterKey]
                            if legacyState then
                                legacyState.readyAt = nil
                                legacyState.currentActive = false
                                legacyState.ready = true
                            end
                        end
                    elseif state.ready then
                        readyCount = readyCount + 1
                    end
                end
            end
        end
    end

    return readyCount
end

function Cooldowns:GetSummary()
    local ready, active = 0, 0
    local timestamp = now()

    EnsureStore()
    MigrateLegacyCharacterCache()

    for characterKey, character in pairs(GoldMintDB.characters or {}) do
        local cache = character and character.cooldownCache
        if type(cache) == "table" and type(cache.recipes) == "table" then
            for recipeID, state in pairs(cache.recipes) do
                if IsTracked(recipeID) and type(state) == "table" then
                    if state.readyAt and state.readyAt > timestamp then
                        active = active + 1
                    elseif state.currentActive then
                        active = active + 1
                    elseif state.ready then
                        ready = ready + 1
                    end
                end
            end
        end
    end

    return ready, active
end

function Cooldowns:GetBestReadyProfitableCooldown()
    local timestamp = now()
    local store = EnsureStore()
    self:CheckReadyStates()

    local best = nil
    for characterKey, character in pairs(GoldMintDB.characters or {}) do
        local cache = character and character.cooldownCache
        if type(cache) == "table" and type(cache.recipes) == "table" then
            for recipeID, state in pairs(cache.recipes) do
                if IsTracked(recipeID) and type(state) == "table" then
                    local ready = state.ready == true or (state.readyAt and timestamp >= state.readyAt)
                    if ready then
                        local record = store.recipes[recipeID] or store.recipes[tonumber(recipeID)]
                        local profitData = record and record.profit
                        local profit = profitData and tonumber(profitData.profit)
                        if profit and profit > 0 then
                            local entry = {
                                recipeID = record and record.recipeID or tonumber(recipeID) or recipeID,
                                name = state.name or (record and record.name) or "Cooldown",
                                professionName = state.professionName or (record and record.professionName) or "Profession",
                                characterKey = characterKey,
                                characterName = GetCharacterName(characterKey),
                                profit = profit,
                                canCraft = state.canCraft == true,
                            }
                            if not best or profit > (best.profit or 0) then
                                best = entry
                            end
                        end
                    end
                end
            end
        end
    end

    return best
end

function Cooldowns:GetTrackedCooldowns()
    local result = {}
    local timestamp = now()
    local store = EnsureStore()

    -- Bring absolute timers forward before the dashboard renders. This keeps
    -- the list accurate even when the player has not opened a profession.
    self:CheckReadyStates()

    for characterKey, character in pairs(GoldMintDB.characters or {}) do
        local cache = character and character.cooldownCache
        if type(cache) == "table" and type(cache.recipes) == "table" then
            for recipeID, state in pairs(cache.recipes) do
                if IsTracked(recipeID) and type(state) == "table" then
                    local record = store.recipes[recipeID] or store.recipes[tonumber(recipeID)]
                    local ready = state.ready == true or (state.readyAt and timestamp >= state.readyAt)
                    local readyAt = ready and nil or tonumber(state.readyAt)
                    local remaining = readyAt and math.max(0, readyAt - timestamp) or 0

                    local icon = nil
                    if record and record.recipeID then
                        local info = GetRecipeInfo(record.recipeID)
                        if info then
                            icon = info.icon or info.iconID or info.texture
                        end
                    end

                    result[#result + 1] = {
                        recipeID = record and record.recipeID or tonumber(recipeID) or recipeID,
                        name = state.name or (record and record.name) or "Cooldown",
                        professionName = state.professionName or (record and record.professionName) or "Profession",
                        characterKey = characterKey,
                        characterName = GetCharacterName(characterKey),
                        ready = ready == true,
                        readyAt = readyAt,
                        remaining = remaining,
                        charges = tonumber(state.charges),
                        maxCharges = tonumber(state.maxCharges),
                        icon = icon,
                        lastSeen = state.seen,
                        canCraft = state.canCraft == true,
                    }
                end
            end
        end
    end

    table.sort(result, function(a, b)
        if a.ready ~= b.ready then
            return a.ready
        end
        if not a.ready and a.remaining ~= b.remaining then
            return a.remaining < b.remaining
        end
        if (a.characterName or "") ~= (b.characterName or "") then
            return (a.characterName or "") < (b.characterName or "")
        end
        return (a.name or "") < (b.name or "")
    end)

    return result
end

-- ============================================================================
-- RESTOCKING MATERIALS
-- ============================================================================
-- Builds a single shopping list from the cooldowns the player has explicitly
-- chosen to track.  Each tracked character/cooldown contributes one craft's
-- reagent requirement.
-- ============================================================================
local function GetRestockItemInfo(itemID)
    itemID = tonumber(itemID)
    if not itemID then return nil, nil end

    local name, icon

    -- C_Item.GetItemInfo can return nil until Blizzard has loaded the item
    -- data.  The icon API is often available independently, so prefer it.
    if C_Item and C_Item.GetItemIconByID then
        local ok, value = pcall(C_Item.GetItemIconByID, itemID)
        if ok and value then icon = value end
    end

    if C_Item and C_Item.GetItemNameByID then
        local ok, value = pcall(C_Item.GetItemNameByID, itemID)
        if ok and value then name = value end
    end

    if not icon or not name then
        local ok, n, _, _, _, _, _, _, _, _, texture = pcall(C_Item.GetItemInfo, itemID)
        if ok then
            name = name or n
            icon = icon or texture
        end
    end

    -- Ask Blizzard to load uncached item data.  The Dashboard refreshes when
    -- ITEM_DATA_LOAD_RESULT fires, so the question-mark placeholder is only
    -- temporary and does not require opening the profession window.
    if (not icon or not name) and C_Item and C_Item.RequestLoadItemDataByID then
        pcall(C_Item.RequestLoadItemDataByID, itemID)
    end

    return name or ("Item " .. tostring(itemID)), icon
end

function Cooldowns:GetRestockingMaterials()
    local totals = {}
    local tracked = self:GetTrackedCooldowns()

    for _, entry in ipairs(tracked or {}) do
        local recipeID = tonumber(entry.recipeID)
        local record = recipeID and GoldMintDB and GoldMintDB.recipes and (
            GoldMintDB.recipes[recipeID] or GoldMintDB.recipes[tostring(recipeID)]
        )
        local reagents = record and record.reagents

        if type(reagents) == "table" then
            for _, reagent in ipairs(reagents) do
                local needed = tonumber(reagent.quantity) or 0
                local option = reagent.options and reagent.options[1]
                local itemID = option and tonumber(option.itemID)
                if itemID and needed > 0 then
                    local bucket = totals[itemID]
                    if not bucket then
                        local name, texture = GetRestockItemInfo(itemID)
                        bucket = {
                            itemID = itemID,
                            name = name or ("Item " .. tostring(itemID)),
                            icon = texture,
                            needed = 0,
                            have = 0,
                            missing = 0,
                        }
                        totals[itemID] = bucket
                    end
                    bucket.needed = bucket.needed + needed
                end
            end
        end
    end

    local result = {}
    for itemID, bucket in pairs(totals) do
        if C_Item and C_Item.GetItemCount then
            local ok, count = pcall(C_Item.GetItemCount, itemID, true, true, true, true)
            bucket.have = ok and (tonumber(count) or 0) or 0
        end
        bucket.missing = math.max(0, bucket.needed - bucket.have)
        result[#result + 1] = bucket
    end

    table.sort(result, function(a, b)
        if a.missing ~= b.missing then return a.missing > b.missing end
        return (a.name or "") < (b.name or "")
    end)

    return result
end

-- ============================================================================
-- ITEM DURATIONS
-- ============================================================================
-- Only tracks items whose actual Blizzard item tooltip contains a
-- "Duration:" line (for example: Pulsating Sac -> Duration: 7 days).
-- This intentionally does NOT use the container cooldown API, because that
-- API can report cooldowns for many ordinary usable items that do not have
-- the item-duration behavior the Dashboard panel is meant to show.
-- ============================================================================
local ITEM_DURATION_SCAN_INTERVAL = 5
local ITEM_DURATION_CONTAINERS = {
    { index = 0,  label = "Bags" },
    { index = 1,  label = "Bags" },
    { index = 2,  label = "Bags" },
    { index = 3,  label = "Bags" },
    { index = 4,  label = "Bags" },
    { index = 5,  label = "Bags" },
    { index = -1, label = "Bank" },
    { index = 6,  label = "Bank" },
    { index = 7,  label = "Bank" },
    { index = 8,  label = "Bank" },
    { index = 9,  label = "Bank" },
    { index = 10, label = "Bank" },
    { index = 11, label = "Bank" },
    { index = 12, label = "Warbank" },
    { index = 13, label = "Warbank" },
    { index = 14, label = "Warbank" },
    { index = 15, label = "Warbank" },
    { index = 16, label = "Warbank" },
    { index = 17, label = "Warbank" },
}

local function EnsureItemDurationStore()
    local store = EnsureStore()
    store.itemDurations = type(store.itemDurations) == "table" and store.itemDurations or {}
    return store.itemDurations
end

local function GetItemDisplayInfo(itemID)
    local name, _, _, _, _, _, _, _, _, texture = C_Item.GetItemInfo(itemID)
    return name or ("Item " .. tostring(itemID)), texture
end

local function FindDurationInTooltip(data)
    if type(data) ~= "table" or type(data.lines) ~= "table" then
        return nil
    end

    for _, line in ipairs(data.lines) do
        if type(line) == "table" then
            local leftText = line.leftText
            local rightText = line.rightText

            for _, text in ipairs({ leftText, rightText }) do
                if type(text) == "string" then
                    -- English client text is "Duration: 7 days".  Keep the
                    -- value exactly as Blizzard formats it instead of
                    -- converting it into our own countdown format.
                    local durationText = text:match("^%s*Duration:%s*(.+)%s*$")
                    if durationText and durationText ~= "" then
                        return durationText
                    end
                end
            end
        end
    end

    return nil
end

local durationScannerTooltip

local function EnsureDurationScannerTooltip()
    if durationScannerTooltip then
        return durationScannerTooltip
    end

    durationScannerTooltip = CreateFrame("GameTooltip", "GoldMintItemDurationScannerTooltip", UIParent, "GameTooltipTemplate")
    durationScannerTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    durationScannerTooltip:Hide()
    return durationScannerTooltip
end

local function FindDurationInGameTooltip(tooltip)
    if not tooltip or not tooltip.NumLines then
        return nil
    end

    local count = tooltip:NumLines() or 0
    for i = 1, count do
        local left = tooltip:GetLeftLine(i)
        local right = tooltip:GetRightLine(i)
        for _, fontString in ipairs({ left, right }) do
            if fontString and fontString.GetText then
                local text = fontString:GetText()
                if type(text) == "string" then
                    local durationText = text:match("^%s*Duration:%s*(.+)%s*$")
                    if durationText and durationText ~= "" then
                        return durationText
                    end
                end
            end
        end
    end

    return nil
end

local function GetBagItemDuration(containerIndex, slotIndex, itemID)
    -- First use the actual GameTooltip renderer. This is intentional: the
    -- Duration line shown to the player (for example, "Duration: 7 days") is
    -- guaranteed to be the same line GoldMint is looking for.
    local tooltip = EnsureDurationScannerTooltip()
    tooltip:ClearLines()
    local okSet, result = pcall(tooltip.SetBagItem, tooltip, containerIndex, slotIndex)
    if okSet and result ~= false then
        local durationText = FindDurationInGameTooltip(tooltip)
        tooltip:Hide()
        if durationText then
            return durationText
        end
    else
        tooltip:Hide()
    end

    -- Also inspect the structured tooltip API when available.
    if C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local ok, data = pcall(C_TooltipInfo.GetBagItem, containerIndex, slotIndex)
        if ok then
            local durationText = FindDurationInTooltip(data)
            if durationText then
                return durationText
            end
        end
    end

    -- Final fallback for an item whose static tooltip data is already cached.
    if C_TooltipInfo and C_TooltipInfo.GetItemByID and itemID then
        local ok, data = pcall(C_TooltipInfo.GetItemByID, itemID)
        if ok then
            return FindDurationInTooltip(data)
        end
    end

    return nil
end

local function ScanItemDurationContainers()
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then
        return
    end

    local store = EnsureItemDurationStore()
    local timestamp = time()

    for _, container in ipairs(ITEM_DURATION_CONTAINERS) do
        local numSlots = 0
        local ok, value = pcall(C_Container.GetContainerNumSlots, container.index)
        if ok then numSlots = tonumber(value) or 0 end

        for slot = 1, numSlots do
            local infoOK, info = pcall(C_Container.GetContainerItemInfo, container.index, slot)
            if infoOK and type(info) == "table" and info.itemID then
                local itemID = tonumber(info.itemID)
                if itemID then
                    local durationText = GetBagItemDuration(container.index, slot, itemID)
                    if durationText then
                        local key = tostring(itemID)
                        local name, texture = GetItemDisplayInfo(itemID)
                        local record = store[key]

                        if not record then
                            record = { itemID = itemID }
                            store[key] = record
                        end

                        record.itemID = itemID
                        record.name = name or record.name
                        record.icon = texture or record.icon
                        record.location = container.label
                        record.durationText = durationText
                        record.lastSeen = timestamp
                    end
                end
            end
        end
    end
end

function Cooldowns:ScanItemCooldowns(force)
    local store = EnsureStore()
    local timestamp = time()
    if not force and store.itemDurationLastScan and timestamp - store.itemDurationLastScan < ITEM_DURATION_SCAN_INTERVAL then
        return
    end
    store.itemDurationLastScan = timestamp
    pcall(ScanItemDurationContainers)
end

function Cooldowns:GetItemCooldowns()
    self:ScanItemCooldowns(false)
    local itemStore = EnsureItemDurationStore()
    local result = {}

    for _, record in pairs(itemStore) do
        if type(record) == "table" and record.itemID and record.durationText then
            result[#result + 1] = {
                itemID = record.itemID,
                name = record.name or ("Item " .. tostring(record.itemID)),
                icon = record.icon,
                location = record.location or "Bags",
                durationText = record.durationText,
            }
        end
    end

    table.sort(result, function(a, b)
        return (a.name or "") < (b.name or "")
    end)

    return result
end

-- Bank contents are not reliably available until Blizzard opens the bank
-- frame. Scan again when a bank/warbank becomes available, and refresh the
-- Dashboard immediately if it is already open.
local itemDurationEventFrame = CreateFrame("Frame")
itemDurationEventFrame:RegisterEvent("BANKFRAME_OPENED")
itemDurationEventFrame:RegisterEvent("PLAYERBANKSLOTS_CHANGED")
itemDurationEventFrame:RegisterEvent("PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED")
itemDurationEventFrame:RegisterEvent("BANK_TABS_CHANGED")
itemDurationEventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
itemDurationEventFrame:SetScript("OnEvent", function(_, event)
    if event == "BANKFRAME_OPENED" or event == "BANK_TABS_CHANGED" then
        -- Give Blizzard one frame to finish populating the bank containers.
        C_Timer.After(0.20, function()
            Cooldowns:ScanItemCooldowns(true)
            if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
                pcall(GoldMint.Dashboard.Refresh, GoldMint.Dashboard)
            end
        end)
    else
        Cooldowns:ScanItemCooldowns(true)
        if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
            pcall(GoldMint.Dashboard.Refresh, GoldMint.Dashboard)
        end
    end
end)

-- Item icons may be uncached when the Cooldowns page first opens.  Blizzard
-- notifies us when the requested item data arrives; refresh the Dashboard so
-- the real material icon replaces the question-mark placeholder immediately.
local restockItemDataEventFrame = CreateFrame("Frame")
restockItemDataEventFrame:RegisterEvent("ITEM_DATA_LOAD_RESULT")
restockItemDataEventFrame:SetScript("OnEvent", function(_, _, itemID)
    if not itemID then return end
    if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
        C_Timer.After(0, function()
            pcall(GoldMint.Dashboard.Refresh, GoldMint.Dashboard)
        end)
    end
end)

function Cooldowns:GetCharacterCooldowns(characterKey)
    characterKey = characterKey or GetCharacterKey()
    local result = {}
    local timestamp = now()
    local cache = EnsureCharacterCooldownCache(characterKey)
    if not cache then return result end

    local store = EnsureStore()
    for recipeID, state in pairs(cache.recipes or {}) do
        if IsTracked(recipeID) and type(state) == "table" then
            local record = store.recipes[recipeID] or store.recipes[tonumber(recipeID)]
            local ready = state.ready == true or (state.readyAt and timestamp >= state.readyAt)
            result[#result + 1] = {
                recipeID = record and record.recipeID or tonumber(recipeID) or recipeID,
                name = state.name or (record and record.name) or "Cooldown",
                professionName = state.professionName or (record and record.professionName) or "Profession",
                ready = ready == true,
                readyAt = ready and nil or state.readyAt,
                charges = state.charges,
                maxCharges = state.maxCharges,
                lastSeen = state.seen,
            }
        end
    end

    table.sort(result, function(a, b)
        if a.ready ~= b.ready then
            return a.ready
        end
        return (a.name or "") < (b.name or "")
    end)

    return result
end

-- Opens the GoldMint cooldown selection window. Selection is account-wide per
-- recipe, while the current cooldown state remains per character.
function Cooldowns:OpenTracker()
    if self._trackerFrame then
        self:RefreshTracker()
        self._trackerFrame:Show()
        return
    end

    local frame = CreateFrame("Frame", "GoldMintCooldownTracker", UIParent, "BackdropTemplate")
    frame:SetSize(600, 620)
    frame:SetPoint("CENTER")
    -- The tracker must appear above the GoldMint dashboard so its selection
    -- controls remain usable without closing the dashboard first.
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(200)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)
    -- Use a solid color texture for the body so the dashboard can never
    -- bleed through the tracker, regardless of the dialog background asset.
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 8, edgeSize = 18,
        insets = { left = 6, right = 6, top = 6, bottom = 6 },
    })
    frame:SetBackdropColor(0.004, 0.010, 0.016, 1.0)
    frame:SetBackdropBorderColor(0.18, 0.58, 0.78, 0.95)

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOPLEFT", 22, -18)
    title:SetText("GOLDMINT COOLDOWN TRACKER")
    title:SetTextColor(1.0, 0.82, 0.25)

    local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    subtitle:SetPoint("TOPLEFT", 22, -45)
    subtitle:SetText("Choose which profession cooldowns GoldMint should track.")
    subtitle:SetTextColor(0.68, 0.78, 0.88)

    -- GoldMint close button: never use Blizzard's default red X.
    local close = CreateFrame("Button", nil, frame, "BackdropTemplate")
    close:SetSize(30, 30)
    close:SetPoint("TOPRIGHT", -10, -10)
    close:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    close:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
    close:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
    local closeText = close:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    closeText:SetPoint("CENTER", 0, 0)
    closeText:SetText("×")
    closeText:SetTextColor(0.60, 0.74, 0.88)
    close:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
        self:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
        closeText:SetTextColor(1.0, 0.86, 0.38)
    end)
    close:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        self:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
        closeText:SetTextColor(0.60, 0.74, 0.88)
    end)
    close:SetScript("OnClick", function() frame:Hide() end)

    local function MakeTrackerButton(text, width, point, x, y)
        local b = CreateFrame("Button", nil, frame, "BackdropTemplate")
        b:SetSize(width, 28)
        b:SetPoint(point, frame, point, x, y)
        b:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = true, tileSize = 8, edgeSize = 1,
            insets = {left = 1, right = 1, top = 1, bottom = 1},
        })
        b:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        b:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        b.text:SetPoint("CENTER")
        b.text:SetText(text)
        b.text:SetTextColor(0.60, 0.74, 0.88)
        b:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
            self:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
            self.text:SetTextColor(1.0, 0.86, 0.38)
        end)
        b:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
            self:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
            self.text:SetTextColor(0.60, 0.74, 0.88)
        end)
        return b
    end

    -- Keep the title and close button on the top row.  Place the tracking
    -- actions beneath the subtitle so the controls never overlap each other
    -- or the descriptive text.
    local all = MakeTrackerButton("Track All", 105, "TOPRIGHT", -10, -52)
    all:SetScript("OnClick", function()
        Cooldowns:SetAllTracked(true)
        Cooldowns:RefreshTracker()
    end)

    local none = MakeTrackerButton("Track None", 105, "TOPRIGHT", -125, -52)
    none:SetScript("OnClick", function()
        Cooldowns:SetAllTracked(false)
        Cooldowns:RefreshTracker()
    end)

    local scroll, content = CreateGoldMintScrollFrame(frame, 18, -92, -32, 18, 537)

    frame._content = content
    frame._rows = {}
    self._trackerFrame = frame

    function self:RefreshTracker()
        if not self._trackerFrame then return end
        local f = self._trackerFrame
        local contentFrame = f._content
        local rows = f._rows
        local recipes = self:GetDiscoveredRecipes()

        for _, row in ipairs(rows) do row:Hide() end

        if #recipes == 0 then
            if not f._empty then
                f._empty = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                f._empty:SetPoint("TOPLEFT", 10, -10)
                f._empty:SetWidth(520)
                f._empty:SetWordWrap(true)
                f._empty:SetTextColor(0.68, 0.78, 0.88)
            end
            f._empty:SetText("No cooldown-capable profession recipes have been discovered yet. Open a profession panel to let GoldMint scan it.")
            f._empty:Show()
            contentFrame:SetHeight(60)
            return
        end

        if f._empty then f._empty:Hide() end
        local y = -4
        for i, recipe in ipairs(recipes) do
            local row = rows[i]
            if not row then
                row = CreateFrame("Button", nil, contentFrame, "BackdropTemplate")
                row:SetSize(535, 42)
                row:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 6 })
                row:SetBackdropColor(0.008, 0.025, 0.045, 1.0)
                row:SetBackdropBorderColor(0.08, 0.25, 0.38, 0.8)

                local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
                check:SetPoint("LEFT", 6, 0)
                check:SetSize(30, 30)
                row.check = check
                local checkTexture = check:GetCheckedTexture()
                if checkTexture then
                    checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                end

                local name = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                name:SetPoint("LEFT", 42, 4)
                name:SetWidth(315)
                name:SetJustifyH("LEFT")
                row.name = name

                local profession = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                profession:SetPoint("LEFT", 42, -14)
                profession:SetWidth(315)
                profession:SetJustifyH("LEFT")
                profession:SetTextColor(0.55, 0.70, 0.82)
                row.profession = profession

                local status = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                status:SetPoint("RIGHT", -12, 0)
                status:SetWidth(150)
                status:SetJustifyH("RIGHT")
                row.status = status

                check:SetScript("OnClick", function(btn)
                    local id = btn:GetParent().recipeID
                    Cooldowns:SetTracked(id, btn:GetChecked() == true)
                    Cooldowns:RefreshTracker()
                    if GoldMint.Dashboard then GoldMint.Dashboard:Refresh() end
                end)

                rows[i] = row
            end

            row.recipeID = recipe.recipeID
            row.name:SetText(recipe.name)
            row.profession:SetText(recipe.professionName)
            row.check:SetChecked(recipe.tracked)
            row.status:SetText(recipe.tracked and "TRACKING" or "NOT TRACKED")
            row.status:SetTextColor(recipe.tracked and 0.25 or 0.55, recipe.tracked and 1.0 or 0.55, recipe.tracked and 0.55 or 0.65)
            row:SetPoint("TOPLEFT", 4, y)
            row:Show()
            y = y - 46
        end
        contentFrame:SetHeight(math.max(1, math.abs(y) + 8))
    end

    self:RefreshTracker()
end

function Cooldowns:Initialize()
    if self._initialized then
        return
    end

    self._initialized = true
    EnsureStore()
    MigrateLegacyCharacterCache()

    -- Immediately evaluate saved absolute timestamps. This is what makes the
    -- cooldown system useful when the player logs into a different character.
    self:CheckReadyStates()

    -- Use a timer instead of a frame OnUpdate. Cooldown readiness is a
    -- 5-second concern, so there is no benefit to accumulating frame-time
    -- every render frame.
    self._ticker = C_Timer.NewTicker(UPDATE_INTERVAL, function()
        -- First evaluate timers saved from another character/session.
        self:CheckReadyStates()

        -- Then, if a profession is open, silently refresh the live cooldown
        -- state from Blizzard's current profession API.
        if ProfessionsFrame and ProfessionsFrame.IsShown and ProfessionsFrame:IsShown() then
            self:UpdateCurrentProfession()
        end
    end)
end
