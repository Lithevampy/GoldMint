local ADDON_NAME, GoldMint = ...

GoldMint.WorldQuestTracker = GoldMint.WorldQuestTracker or {}
local Tracker = GoldMint.WorldQuestTracker

-- World Quest detection follows the approach used by WQAchievements:
-- scan the actual Blizzard task-quest map data, then wait for reward data to
-- finish loading before classifying the quest.
local CACHE = {}
local LAST_SCAN = 0
local SCAN_INTERVAL = 3600 -- Full World Quest refresh once per hour.
local WORLD_QUEST_MIN_GOLD = 200 * 10000 -- 200 gold in copper
local INITIAL_SCAN = true
local RETRY_TIMER
local RETRY_COUNT = 0
local RETRY_DELAY = 2
local EVENT_TIMER
local EVENT_SUPPRESS_ALERTS = true
local LOGIN_GRACE_UNTIL = 0
local LAST_EVENT_SCAN = -math.huge
local EVENT_SCAN_MIN_INTERVAL = 30 -- Event-driven refreshes are rare and only used for genuinely new quest IDs.
local ON_CHANGED
local LAST_SIGNATURE

local function BuildSignature(rows)
    local parts = {}
    for _, row in ipairs(rows or {}) do
        parts[#parts + 1] = table.concat({
            tostring(row.questID or 0),
            row.mount and "M" or "",
            row.achievement and "A" or "",
            row.gold and tostring(row.gold) or "",
        }, ":")
    end
    table.sort(parts)
    return table.concat(parts, "|")
end

local function GetPersistentState()
    if type(GoldMintDB) ~= "table" then return nil end
    if type(GoldMintDB.worldQuestTracker) ~= "table" then
        GoldMintDB.worldQuestTracker = {}
    end
    local state = GoldMintDB.worldQuestTracker
    if type(state.lastMatching) ~= "table" then state.lastMatching = {} end
    if type(state.lastActive) ~= "table" then state.lastActive = {} end
    if state.baselineEstablished ~= true then state.baselineEstablished = false end
    return state
end

local function SafeCall(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d, e, f = pcall(fn, ...)
    if ok then return a, b, c, d, e, f end
end

local function Lower(text)
    return string.lower(tostring(text or ""))
end
-- Never run the World Quest scanner while Blizzard is presenting a quest
-- or gossip interaction. The scanner can query reward/tooltip data for many
-- quests and must not compete with the quest dialog for the UI thread.
local function IsQuestInteractionOpen()
    local frames = {
        _G.QuestFrame,
        _G.QuestFrameGreetingPanel,
        _G.QuestFrameDetailPanel,
        _G.QuestFrameProgressPanel,
        _G.QuestFrameRewardPanel,
        _G.GossipFrame,
    }
    for _, frame in ipairs(frames) do
        if frame and frame.IsShown and frame:IsShown() then
            return true
        end
    end
    return false
end


local function AddReason(reasons, key)
    if not reasons[key] then
        reasons[key] = true
        reasons[#reasons + 1] = key
    end
end

local function IsWorldQuest(questID)
    questID = tonumber(questID)
    if not questID then return false end

    -- Current API first.
    if C_QuestLog and C_QuestLog.IsWorldQuest then
        local result = SafeCall(C_QuestLog.IsWorldQuest, questID)
        if result ~= nil then return result == true end
    end

    -- WQAchievements' fallback is still useful on clients exposing the helper.
    if QuestUtils_IsQuestWorldQuest then
        local result = SafeCall(QuestUtils_IsQuestWorldQuest, questID)
        if result ~= nil then return result == true end
    end

    return false
end

local function IsActiveWorldQuest(questID)
    if C_TaskQuest and C_TaskQuest.IsActive then
        local result = SafeCall(C_TaskQuest.IsActive, questID)
        if result ~= nil then
            return result == true
        end
    end
    return true
end

local function HaveRewardData(questID)
    if type(HaveQuestRewardData) ~= "function" then return true end
    return SafeCall(HaveQuestRewardData, questID) == true
end

local function RequestRewardData(questID)
    if C_TaskQuest and C_TaskQuest.RequestPreloadRewardData then
        SafeCall(C_TaskQuest.RequestPreloadRewardData, questID)
    end
end

local function GetQuestTitle(questID)
    if C_TaskQuest and C_TaskQuest.GetQuestInfoByQuestID then
        local title = SafeCall(C_TaskQuest.GetQuestInfoByQuestID, questID)
        if title and title ~= "" then return title end
    end
    if C_QuestLog and C_QuestLog.GetTitleForQuestID then
        local title = SafeCall(C_QuestLog.GetTitleForQuestID, questID)
        if title and title ~= "" then return title end
    end
    return "World Quest " .. tostring(questID)
end

local function GetTimeLeft(questID)
    if C_TaskQuest and C_TaskQuest.GetQuestTimeLeftSeconds then
        local seconds = SafeCall(C_TaskQuest.GetQuestTimeLeftSeconds, questID)
        if tonumber(seconds) then return tonumber(seconds) end
    end
    if C_TaskQuest and C_TaskQuest.GetQuestTimeLeftMinutes then
        local minutes = SafeCall(C_TaskQuest.GetQuestTimeLeftMinutes, questID)
        if tonumber(minutes) then return tonumber(minutes) * 60 end
    end
    return nil
end

local function GetZoneName(mapID)
    if C_Map and C_Map.GetMapInfo then
        local info = SafeCall(C_Map.GetMapInfo, mapID)
        if type(info) == "table" and info.name then return info.name end
    end
    return "World Quest"
end

local function FormatMoney(copper)
    copper = math.max(0, math.floor(tonumber(copper) or 0))
    local gold = math.floor(copper / 10000)
    local silver = math.floor((copper % 10000) / 100)
    local copperRemainder = copper % 100
    if gold > 0 then return string.format("%dg", gold) end
    if silver > 0 then return string.format("%ds", silver) end
    return string.format("%dc", copperRemainder)
end

local function FormatTime(seconds)
    seconds = tonumber(seconds)
    if not seconds then return "TIME UNKNOWN" end
    seconds = math.max(0, math.floor(seconds))
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    if hours > 24 then return string.format("%dd %dh", math.floor(hours / 24), hours % 24) end
    if hours > 0 then return string.format("%dh %dm", hours, minutes) end
    return string.format("%dm", math.max(1, minutes))
end

-- WQAchievements keeps an explicit list of expansion/zone map IDs. That is
-- considerably more reliable for a background scan than depending on whatever
-- map hierarchy happens to be open in the World Map UI.
local WQ_MAP_IDS = {
    619,627,630,641,650,680,634,646,790,885,830,882,
    14,62,875,876,862,863,864,895,942,896,1161,1165,1355,1462,1527,1530,
    1525,1533,1536,1565,1543,1961,1970,
    2022,2023,2024,2025,1978,2085,2112,2151,2133,2200,
    2213,2214,2215,2216,2248,2255,2256,2339,2369,2346,2371,
    2395,2413,2437,2405,2393,2424,2541,2444,
}

local function BuildMapList()
    local maps, seen = {}, {}
    local function add(mapID)
        mapID = tonumber(mapID)
        if mapID and not seen[mapID] then
            seen[mapID] = true
            maps[#maps + 1] = mapID
        end
    end

    for _, mapID in ipairs(WQ_MAP_IDS) do add(mapID) end

    -- Always include the player's actual map as a live-data fallback.
    if C_Map and C_Map.GetBestMapForUnit then
        add(SafeCall(C_Map.GetBestMapForUnit, "player"))
    end
    if WorldMapFrame and WorldMapFrame.mapID then
        add(WorldMapFrame.mapID)
    end

    return maps
end

local function GetMapQuests(mapID)
    -- C_TaskQuest.GetQuestsForPlayerByMapID was deprecated in 11.0.5 and
    -- removed in 12.0.0. Use GetQuestsOnMap, the API used by WQAchievements
    -- and the current Blizzard documentation.
    if C_TaskQuest and C_TaskQuest.GetQuestsOnMap then
        return SafeCall(C_TaskQuest.GetQuestsOnMap, mapID)
    end
    if C_QuestLog and C_QuestLog.GetQuestsOnMap then
        return SafeCall(C_QuestLog.GetQuestsOnMap, mapID)
    end
end

local function TooltipMentionsAchievement(questID)
    if not C_TooltipInfo or not C_TooltipInfo.GetHyperlink then return false end
    local data = SafeCall(C_TooltipInfo.GetHyperlink, "quest:" .. tostring(questID))
    if type(data) ~= "table" or type(data.lines) ~= "table" then return false end
    for _, line in ipairs(data.lines) do
        local left = Lower(line.leftText)
        local right = Lower(line.rightText)
        if left:find("achievement", 1, true) or right:find("achievement", 1, true) then
            return true
        end
    end
    return false
end

local function HasMountReward(questID)
    if C_QuestInfoSystem and C_QuestInfoSystem.GetQuestRewardSpells then
        local spells = SafeCall(C_QuestInfoSystem.GetQuestRewardSpells, questID)
        if type(spells) == "table" and C_MountJournal and C_MountJournal.GetMountFromSpell then
            for _, spellID in ipairs(spells) do
                if SafeCall(C_MountJournal.GetMountFromSpell, spellID) then
                    return true
                end
            end
        end
    end

    if C_QuestLog and C_QuestLog.GetQuestRewardSpellInfo then
        -- Some client builds expose spell information through QuestInfoSystem
        -- only, so this is deliberately just a fallback.
        local spells = SafeCall(C_QuestLog.GetQuestRewardSpellInfo, questID)
        if type(spells) == "table" and C_MountJournal and C_MountJournal.GetMountFromSpell then
            for _, spellID in ipairs(spells) do
                if SafeCall(C_MountJournal.GetMountFromSpell, spellID) then
                    return true
                end
            end
        end
    end

    if GetNumQuestLogRewards and GetQuestLogRewardInfo and C_MountJournal and C_MountJournal.GetMountFromItem then
        local count = SafeCall(GetNumQuestLogRewards, questID) or 0
        for i = 1, tonumber(count) or 0 do
            local _, _, _, _, _, itemID = SafeCall(GetQuestLogRewardInfo, i, questID)
            if itemID and SafeCall(C_MountJournal.GetMountFromItem, itemID) then
                return true
            end
        end
    end

    if GetNumQuestLogChoices and GetQuestLogChoiceInfo and C_MountJournal and C_MountJournal.GetMountFromItem then
        local count = SafeCall(GetNumQuestLogChoices, questID) or 0
        for i = 1, tonumber(count) or 0 do
            local _, _, _, _, _, itemID = SafeCall(GetQuestLogChoiceInfo, i, questID)
            if itemID and SafeCall(C_MountJournal.GetMountFromItem, itemID) then
                return true
            end
        end
    end

    return false
end

local function GetRewardFlags(questID)
    local reasons = {}
    local interesting = false

    local money = SafeCall(GetQuestLogRewardMoney, questID)
    if tonumber(money) and tonumber(money) >= WORLD_QUEST_MIN_GOLD then
        reasons.gold = tonumber(money)
        AddReason(reasons, "GOLD")
        interesting = true
    end

    if HasMountReward(questID) then
        reasons.mount = true
        AddReason(reasons, "MOUNT")
        interesting = true
    end

    local achievement = false
    if TooltipMentionsAchievement(questID) then
        achievement = true
    end
    if achievement then
        reasons.achievement = true
        AddReason(reasons, "ACHIEVEMENT")
        interesting = true
    end

    return reasons, interesting
end

local function Scan(force, suppressAlerts)
    -- Quest dialogs are latency-sensitive Blizzard UI. If one is open, leave
    -- the cached results alone and let the normal retry/timer pick this scan
    -- up after the interaction closes.
    if IsQuestInteractionOpen() then
        if not RETRY_TIMER and C_Timer and C_Timer.NewTimer then
            RETRY_TIMER = C_Timer.NewTimer(1.0, function()
                RETRY_TIMER = nil
                LAST_SCAN = 0
                if not IsQuestInteractionOpen() then
                    Scan(true, true)
                end
            end)
        end
        return
    end

    local now = GetTime and GetTime() or 0
    if not force and now - LAST_SCAN < SCAN_INTERVAL then return end
    LAST_SCAN = now

    local found = {}
    local rewardRetry = false

    for _, mapID in ipairs(BuildMapList()) do
        local quests = GetMapQuests(mapID)
        if type(quests) == "table" then
            for _, poi in ipairs(quests) do
                local questID = type(poi) == "table" and tonumber(poi.questID) or tonumber(poi)
                if questID and not found[questID] and IsWorldQuest(questID) and IsActiveWorldQuest(questID) then
                    found[questID] = {
                        questID = questID,
                        mapID = tonumber(type(poi) == "table" and poi.mapID) or mapID,
                        poi = poi,
                    }
                end
            end
        end
    end

    local rows = {}
    local state = GetPersistentState()
    if state then
        -- Keep a cheap persistent set of all currently active World Quest IDs.
        -- This lets QUEST_DATA_LOAD_RESULT tell us whether a genuinely new WQ
        -- appeared without forcing a full multi-map scan for every quest-data event.
        state.lastActive = state.lastActive or {}
    end
    for questID, raw in pairs(found) do
        -- Match WQAchievements' important sequencing: request the reward data
        -- first, then retry rather than treating an unloaded reward as "no reward".
        if type(HaveQuestData) == "function" and not SafeCall(HaveQuestData, questID) then
            RequestRewardData(questID)
            rewardRetry = true
        elseif not HaveRewardData(questID) then
            RequestRewardData(questID)
            rewardRetry = true
        else
            local reasons, interesting = GetRewardFlags(questID)
            if interesting then
                rows[#rows + 1] = {
                    questID = questID,
                    title = GetQuestTitle(questID),
                    zone = GetZoneName(raw.mapID),
                    mapID = raw.mapID,
                    timeLeft = GetTimeLeft(questID),
                    reasons = reasons,
                    rewardText = table.concat(reasons, " • "),
                    gold = reasons.gold,
                    mount = reasons.mount,
                    achievement = reasons.achievement,
                }
            end
        end
    end

    table.sort(rows, function(a, b)
        local function rank(row)
            if row.mount then return 1 end
            if row.achievement then return 2 end
            return 3
        end
        local ar, br = rank(a), rank(b)
        if ar ~= br then return ar < br end
        return tostring(a.title) < tostring(b.title)
    end)

    if state then
        local active = {}
        for questID in pairs(found) do
            active[questID] = true
        end
        state.lastActive = active
    end

    -- Persist the last known *matching* World Quest set. This is deliberately
    -- separate from the transient CACHE/ALERT state so /reload and relog do not
    -- forget which quests were already on screen. A quest only alerts when it
    -- appears in the current matching set and was not in the previous matching
    -- set. The first-ever scan establishes the baseline silently.
    local previousMatching = state and state.lastMatching or {}
    local currentMatching = {}

    for _, row in ipairs(rows) do
        local questID = row.questID
        currentMatching[questID] = true
        local isNew = not previousMatching[questID]
        if state and not state.baselineEstablished then
            isNew = false
        end
        if not suppressAlerts and isNew and GoldMint.Alerts and GoldMint.Alerts.Push then
            local reward = row.mount and "Mount reward"
                or (row.achievement and "Achievement-related reward"
                or "Gold reward: " .. FormatMoney(row.gold))
            GoldMint.Alerts:Push(
                "WORLD QUEST AVAILABLE",
                tostring(row.title) .. " — " .. tostring(row.zone) .. "\n" .. reward,
                {
                    id = "world-quest-" .. tostring(row.questID),
                    dedupeKey = "world-quest-" .. tostring(row.questID),
                    priority = row.mount and 95 or (row.achievement and 90 or 85),
                    category = "world-quest",
                    ttl = 18,
                }
            )
        end
    end

    if state then
        -- Only remove quests that are genuinely gone from Blizzard's active
        -- quest map data. If reward data is still loading, keep the previous
        -- matching entry so a retry cannot manufacture a second "new" alert.
        for questID in pairs(previousMatching) do
            if found[questID] == nil then
                previousMatching[questID] = nil
            end
        end
        for questID in pairs(currentMatching) do
            previousMatching[questID] = true
        end
        state.lastMatching = previousMatching
        state.baselineEstablished = true
    end

    INITIAL_SCAN = false

    -- The scanner may run periodically so Blizzard's live World Quest data
    -- stays current, but the UI should only be rebuilt when the actual set of
    -- matching quests/rewards changes. In particular, reward-data retries and
    -- the background scan itself must not cause a visible panel repaint.
    local signature = BuildSignature(rows)
    local changed = signature ~= LAST_SIGNATURE
    CACHE = rows
    LAST_SIGNATURE = signature
    if changed and ON_CHANGED then
        pcall(ON_CHANGED, rows)
    end

    if rewardRetry and not RETRY_TIMER then
        -- Reward data arrives asynchronously. Older versions used a repeating
        -- ticker here, which could perform several full multi-map scans while
        -- Blizzard was still populating quest data. Use one delayed retry; the
        -- QUEST_DATA_LOAD_RESULT event will schedule another scan if needed.
        RETRY_COUNT = RETRY_COUNT + 1
        if RETRY_COUNT <= 2 then
            RETRY_TIMER = C_Timer.NewTimer(RETRY_DELAY + 2, function()
                RETRY_TIMER = nil
                LAST_EVENT_SCAN = GetTime and GetTime() or 0
                LAST_SCAN = 0
                Scan(true, suppressAlerts or (GetTime() < LOGIN_GRACE_UNTIL))
            end)
        else
            RETRY_COUNT = 0
        end
    elseif not rewardRetry then
        if RETRY_TIMER then
            RETRY_TIMER:Cancel()
            RETRY_TIMER = nil
        end
        RETRY_COUNT = 0
    end
end

function Tracker:Refresh(force)
    Scan(force == true, true)
    return CACHE
end

function Tracker:GetRows()
    Scan(false, true)
    return CACHE
end

function Tracker:SetOnChanged(callback)
    ON_CHANGED = type(callback) == "function" and callback or nil
end

function Tracker:FormatMoney(copper)
    return FormatMoney(copper)
end

function Tracker:FormatTime(seconds)
    return FormatTime(seconds)
end

local eventFrame = CreateFrame("Frame")
for _, event in ipairs({
    "PLAYER_ENTERING_WORLD",
    "QUEST_DATA_LOAD_RESULT",
    "ZONE_CHANGED_NEW_AREA",
}) do
    eventFrame:RegisterEvent(event)
end

local function ScheduleEventScan(delay, suppressAlerts)
    suppressAlerts = suppressAlerts == true
    EVENT_SUPPRESS_ALERTS = EVENT_SUPPRESS_ALERTS or suppressAlerts
    if EVENT_TIMER then return end

    local now = GetTime and GetTime() or 0
    local wait = tonumber(delay) or 1.0
    local sinceLast = now - LAST_EVENT_SCAN
    if sinceLast < EVENT_SCAN_MIN_INTERVAL then
        wait = math.max(wait, EVENT_SCAN_MIN_INTERVAL - sinceLast)
    end

    EVENT_TIMER = C_Timer.NewTimer(wait, function()
        EVENT_TIMER = nil
        LAST_EVENT_SCAN = GetTime and GetTime() or 0
        LAST_SCAN = 0
        local quiet = EVENT_SUPPRESS_ALERTS or (GetTime() < LOGIN_GRACE_UNTIL)
        EVENT_SUPPRESS_ALERTS = false
        Scan(true, quiet)
    end)
end

eventFrame:SetScript("OnEvent", function(_, event, questID, success)
    if event == "PLAYER_ENTERING_WORLD" then
        -- Blizzard populates a large amount of quest data during login/reload.
        -- Do not run a full scan during that burst. The hourly scan is the
        -- normal refresh; the saved baseline prevents login/reload spam.
        INITIAL_SCAN = false
        LOGIN_GRACE_UNTIL = (GetTime() or 0) + 6
        EVENT_SUPPRESS_ALERTS = true
        if RETRY_TIMER then
            RETRY_TIMER:Cancel()
            RETRY_TIMER = nil
            RETRY_COUNT = 0
        end
        -- Establish/refresh the baseline only through the normal hourly timer.
        return
    end

    if event == "QUEST_DATA_LOAD_RESULT" then
        -- This event is the only event allowed to trigger an early refresh.
        -- Only do it when Blizzard reports a successful quest-data load for a
        -- quest ID that was not present in our last full-scan active set. That
        -- means a genuinely new World Quest can appear immediately without
        -- turning every quest-data callback into a full multi-map scan.
        questID = tonumber(questID)
        if not questID or success ~= true then return end
        if GetTime() < LOGIN_GRACE_UNTIL then return end

        local state = GetPersistentState()
        if state and state.lastActive and not state.lastActive[questID] then
            ScheduleEventScan(1.0, false)
        end
        return
    end

    if event == "ZONE_CHANGED_NEW_AREA" then
        -- Changing zones can expose a new local WQ set, but do not force a scan
        -- here. The next hourly refresh or QUEST_DATA_LOAD_RESULT handles it.
        return
    end
end)

-- No manual scan button. The tracker starts quietly and continues to refresh
-- even if the player never opens the World Map.
C_Timer.After(10, function()
    -- Do not compete with Blizzard's login/quest-data burst. If a quest or
    -- gossip window is open, Scan() defers itself until the interaction ends.
    if not EVENT_TIMER and not IsQuestInteractionOpen() then
        Scan(true, true)
    end

    C_Timer.NewTicker(SCAN_INTERVAL, function()
        -- Hourly safety/full refresh. The World Quest card is rebuilt only when
        -- the actual matching quest signature changes. Scan() itself refuses
        -- to run while a quest/gossip dialog is open.
        if not IsQuestInteractionOpen() then
            Scan(true, true)
        end
    end)
end)
