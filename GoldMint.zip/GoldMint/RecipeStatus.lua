local ADDON_NAME, GoldMint = ...

-- GoldMint recipe-source tooltip integration.
--
-- This watches ITEM tooltips, not the profession panel.  The goal is to answer
-- the player's question when a recipe/teaching item is found in loot, bags,
-- vendors, or the Auction House:
--   "Does my current character know this, and who else can learn/knows it?"
--
-- Midnight 12.1 exposes recipe-teaching information through the modern
-- TooltipDataProcessor system.  The teaching spell ID is not guaranteed to be
-- identical to the recipe ID stored by every profession API path, so this file
-- deliberately has several matching fallbacks:
--   1. ItemSpellTriggerLearn.spellID
--   2. recipeSpellIndex
--   3. C_TradeSkillUI.GetRecipeInfo(spellID).recipeID
--   4. Exact/contained recipe-name matching against the tooltip text/item name

local Status = {}
GoldMint.RecipeStatus = Status

local LEARN_LINE_TYPE = (Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.ItemSpellTriggerLearn) or 38

local function GetRecipeRecord(recipeID)
    if not recipeID or not GoldMintDB or not GoldMintDB.recipes then
        return nil
    end
    return GoldMintDB.recipes[recipeID]
end

local function GetCharacterDisplayName(key)
    local char = GoldMintDB and GoldMintDB.characters and GoldMintDB.characters[key]
    if char and char.name and char.realm then
        return char.name .. "-" .. char.realm
    end
    return key
end

local function CharacterHasProfessionForRecipe(key, record)
    local char = GoldMintDB and GoldMintDB.characters and GoldMintDB.characters[key]
    if not char or not char.professions then
        return false
    end

    local professionID = record and record.professionID
    if professionID and char.professions[professionID] then
        return true
    end

    local professionName = record and (record.professionName or record.profession)
    if professionName then
        for _, profession in pairs(char.professions) do
            if profession.name == professionName then
                return true
            end
        end
    end

    return false
end

local function BuildStatus(record)
    if not record then
        return nil
    end

    local currentKey = GoldMint.characterKey
    local currentState = record.characters and record.characters[currentKey]
    local currentKnown = currentState and currentState.learned == true
    local currentCanLearn = (not currentKnown) and CharacterHasProfessionForRecipe(currentKey, record)

    local known = {}
    local canLearn = {}

    for key, state in pairs(record.characters or {}) do
        if state.learned == true then
            known[#known + 1] = key
        elseif CharacterHasProfessionForRecipe(key, record) then
            canLearn[#canLearn + 1] = key
        end
    end

    table.sort(known, function(a, b)
        return GetCharacterDisplayName(a) < GetCharacterDisplayName(b)
    end)
    table.sort(canLearn, function(a, b)
        return GetCharacterDisplayName(a) < GetCharacterDisplayName(b)
    end)

    return {
        record = record,
        currentKnown = currentKnown,
        currentCanLearn = currentCanLearn,
        known = known,
        canLearn = canLearn,
    }
end

local function NormalizeName(text)
    if type(text) ~= "string" then
        return ""
    end

    text = strlower(text)
    text = text:gsub("|c%x%x%x%x%x%x%x%x", "")
    text = text:gsub("|r", "")
    text = text:gsub("%b[]", function(value)
        return value:gsub("[|]c%x%x%x%x%x%x%x%x", ""):gsub("[|]r", "")
    end)
    text = text:gsub("%s+", " ")
    return strtrim(text)
end

local function FindRecordByName(name)
    local needle = NormalizeName(name)
    if needle == "" or not GoldMintDB or not GoldMintDB.recipes then
        return nil
    end

    -- First pass: exact recipe-name match.
    for _, record in pairs(GoldMintDB.recipes) do
        if record.name and NormalizeName(record.name) == needle then
            return record
        end
    end

    -- Second pass: the tooltip may say e.g. "Teaches you how to cut a
    -- Rigid Azure Moonstone." while the stored recipe name is just
    -- "Rigid Azure Moonstone".
    for _, record in pairs(GoldMintDB.recipes) do
        if record.name then
            local recipeName = NormalizeName(record.name)
            if recipeName ~= "" and strfind(needle, recipeName, 1, true) then
                return record
            end
        end
    end

    return nil
end

local function FindRecordByTooltipText(text)
    local normalized = NormalizeName(text)
    if normalized == "" then
        return nil
    end

    local record = FindRecordByName(normalized)
    if record then
        return record
    end

    -- Strip common localized teaching wording. We intentionally do not depend
    -- on the English wording being present; this is only an additional fallback.
    local stripped = normalized
    stripped = stripped:gsub("^.-teaches you how to cut a ", "")
    stripped = stripped:gsub("^.-teaches you how to learn a ", "")
    stripped = stripped:gsub("^.-teaches you how to craft a ", "")
    stripped = stripped:gsub("%.$", "")

    if stripped ~= normalized then
        return FindRecordByName(stripped)
    end

    return nil
end

local function GetIntField(line, fieldName)
    if type(line) ~= "table" then
        return nil
    end

    local direct = tonumber(line[fieldName])
    if direct then
        return direct
    end

    -- Some TooltipDataLine payloads expose typed arguments rather than direct
    -- fields. Support both shapes without assuming one exact internal layout.
    local args = line.args or line.arguments
    if type(args) == "table" then
        for _, arg in pairs(args) do
            if type(arg) == "table" then
                if arg.field == fieldName then
                    return tonumber(arg.intVal or arg.value or arg.number)
                end
            end
        end
    end

    return nil
end

local function GetRecipeIDFromItemTooltipData(data)
    if type(data) ~= "table" or type(data.lines) ~= "table" then
        return nil
    end

    local fallbackText

    for _, line in ipairs(data.lines) do
        if type(line) == "table" then
            if line.type == LEARN_LINE_TYPE then
                local spellID = GetIntField(line, "spellID")
                if spellID then
                    return spellID
                end
            end

            -- Keep likely recipe text as a fallback when the teaching line's
            -- structured argument isn't exposed by the current client build.
            if line.leftText then
                fallbackText = fallbackText or line.leftText
            end
            if line.rightText then
                fallbackText = fallbackText or line.rightText
            end
        end
    end

    if fallbackText then
        local record = FindRecordByTooltipText(fallbackText)
        if record then
            return record.recipeID
        end
    end

    return nil
end

local function IsRecipeTeachingTooltip(data)
    if type(data) ~= "table" or type(data.lines) ~= "table" then
        return false
    end

    -- The authoritative signal is WoW's structured "this item teaches a
    -- recipe" tooltip line.  This prevents normal items (flasks, gear,
    -- materials, toys, etc.) from ever entering the recipe-status resolver.
    for _, line in ipairs(data.lines) do
        if type(line) == "table" and line.type == LEARN_LINE_TYPE then
            return true
        end
    end

    -- Fallback for client/UI states where the structured line is not exposed:
    -- only accept tooltips that visibly contain recipe-teaching language.
    -- This is deliberately a narrow gate; ordinary item names are never used
    -- by themselves to decide that an item is a recipe.
    local textParts = {}
    for _, line in ipairs(data.lines) do
        if type(line) == "table" then
            if type(line.leftText) == "string" then
                textParts[#textParts + 1] = line.leftText
            end
            if type(line.rightText) == "string" then
                textParts[#textParts + 1] = line.rightText
            end
        end
    end

    local text = NormalizeName(table.concat(textParts, " "))
    if text == "" then
        return false
    end

    -- Keep this fallback limited to explicit teaching wording.  The structured
    -- line above is preferred and remains language-independent.
    return strfind(text, "teaches you how to", 1, true) ~= nil
end

local function ResolveRecord(data)
    if type(data) ~= "table" or not IsRecipeTeachingTooltip(data) then
        return nil
    end

    local recipeID = GetRecipeIDFromItemTooltipData(data)
    if recipeID then
        local record = GetRecipeRecord(recipeID)
        if record then
            return record
        end

        if GoldMintDB and GoldMintDB.recipeSpellIndex then
            local mappedID = GoldMintDB.recipeSpellIndex[recipeID]
            if mappedID then
                record = GetRecipeRecord(mappedID)
                if record then
                    return record
                end
            end
        end

        -- The teaching spell can be different from the stored recipe ID on
        -- some recipe sources. Ask the profession API whether it can resolve
        -- the teaching spell into a recipe record.
        if C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo then
            local ok, info = pcall(C_TradeSkillUI.GetRecipeInfo, recipeID)
            if ok and info and info.recipeID then
                record = GetRecipeRecord(info.recipeID)
                if record then
                    return record
                end
            end
        end
    end

    -- Only recipe-teaching tooltips are allowed to use name matching. This is
    -- intentionally the final fallback and can no longer classify a normal
    -- item merely because its name happens to resemble a stored recipe.
    local itemName
    if data.id and C_Item and C_Item.GetItemNameByID then
        local ok, name = pcall(C_Item.GetItemNameByID, data.id)
        if ok then
            itemName = name
        end
    end

    if not itemName and data.id and GetItemInfo then
        local ok, name = pcall(GetItemInfo, data.id)
        if ok then
            itemName = name
        end
    end

    return FindRecordByTooltipText(itemName)
end

local function AddLine(tooltip, text, r, g, b)
    if tooltip and tooltip.AddLine then
        tooltip:AddLine(text, r, g, b, true)
    end
end

local function AddRecipeStatus(tooltip, record)
    if not tooltip or not record then
        return
    end

    local status = BuildStatus(record)
    if not status then
        return
    end

    -- Tooltip frames are rebuilt by the client while item data resolves.
    -- Do not use a persistent per-tooltip marker here: the client can clear the
    -- tooltip and invoke this callback again for the same item. A marker would
    -- then prevent us from re-adding the GoldMint lines, making them appear and
    -- immediately disappear. Instead, inspect the current visible lines.
    local tooltipName = tooltip.GetName and tooltip:GetName()
    if tooltipName then
        for i = 1, (tooltip.NumLines and tooltip:NumLines() or 0) do
            local left = _G[tooltipName .. "TextLeft" .. i]
            if left and left.GetText then
                local text = left:GetText()
                if text and strfind(text, "GoldMint  •", 1, true) then
                    return
                end
            end
        end
    end

    -- Keep the tooltip focused on the characters that can actually learn or
    -- already know the recipe. We intentionally do not add a current-character
    -- "KNOWN/CAN LEARN/NOT KNOWN" banner here: that extra status is redundant
    -- when the useful account-wide information is already listed below.
    local otherKnown = {}
    for _, key in ipairs(status.known) do
        otherKnown[#otherKnown + 1] = GetCharacterDisplayName(key)
    end

    local otherCanLearn = {}
    for _, key in ipairs(status.canLearn) do
        otherCanLearn[#otherCanLearn + 1] = GetCharacterDisplayName(key)
    end

    AddLine(tooltip, " ")

    if #otherKnown > 0 then
        AddLine(tooltip, "Known on: " .. table.concat(otherKnown, ", "), 0.30, 1.00, 0.55)
    end

    if #otherCanLearn > 0 then
        AddLine(tooltip, "Can learn on: " .. table.concat(otherCanLearn, ", "), 0.55, 0.85, 1.00)
    end

    if #otherKnown == 0 and #otherCanLearn == 0 then
        AddLine(tooltip, "No scanned character matches this recipe yet.", 0.75, 0.75, 0.75)
    end

    -- AddLine() does not automatically resize/show an already-visible tooltip.
    -- Explicitly refresh it so the status remains attached to the item tooltip.
    if tooltip.Show then
        tooltip:Show()
    end
end

local function OnItemTooltip(tooltip, data)
    if not tooltip or type(data) ~= "table" then
        return
    end

    local record = ResolveRecord(data)
    if record then
        AddRecipeStatus(tooltip, record)
    else
    end
end

function Status:Initialize()
    if self._initialized then
        return
    end
    self._initialized = true

    if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, OnItemTooltip)
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function()
    Status:Initialize()
end)
