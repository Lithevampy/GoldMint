local ADDON_NAME, GoldMint = ...

GoldMint.Valuation = {}
local Valuation = GoldMint.Valuation

local STORE_VERSION = 2

local function Now()
    return time()
end

local function EnsureStore()
    GoldMintDB.valuation = type(GoldMintDB.valuation) == "table" and GoldMintDB.valuation or {}
    GoldMintDB.valuation.version = math.max(tonumber(GoldMintDB.valuation.version) or 0, STORE_VERSION)
    GoldMintDB.valuation.containers = type(GoldMintDB.valuation.containers) == "table" and GoldMintDB.valuation.containers or {}
    GoldMintDB.valuation.characters = type(GoldMintDB.valuation.characters) == "table" and GoldMintDB.valuation.characters or {}
    GoldMintDB.valuation.accountBank = type(GoldMintDB.valuation.accountBank) == "table" and GoldMintDB.valuation.accountBank or {}
    GoldMintDB.valuation.guildBanks = type(GoldMintDB.valuation.guildBanks) == "table" and GoldMintDB.valuation.guildBanks or {}
    GoldMintDB.valuation.scanState = type(GoldMintDB.valuation.scanState) == "table" and GoldMintDB.valuation.scanState or {}
    return GoldMintDB.valuation
end

local function RecordContainer(containerID, scope)
    local store = EnsureStore()
    store.containers[tostring(containerID)] = {
        id = containerID,
        scope = scope,
        name = C_Container and C_Container.GetBagName and C_Container.GetBagName(containerID) or tostring(containerID),
        character = GoldMint.characterKey,
        scannedAt = Now(),
    }
end

local function EnsureCharacterStore()
    local store = EnsureStore()
    local key = GoldMint.characterKey or "Unknown"
    store.characters[key] = type(store.characters[key]) == "table" and store.characters[key] or {}
    local character = store.characters[key]
    character.name = GoldMint.characterName or character.name or "Unknown"
    character.realm = GoldMint.characterRealm or character.realm or "Unknown"
    character.inventory = type(character.inventory) == "table" and character.inventory or {}
    character.bank = type(character.bank) == "table" and character.bank or {}
    character.scannedAt = character.scannedAt or 0
    character.bankScannedAt = character.bankScannedAt or 0
    return character
end

local function AddItem(bucket, itemID, count)
    itemID = tonumber(itemID)
    count = tonumber(count) or 0
    if not itemID or count <= 0 then return end
    bucket[itemID] = (tonumber(bucket[itemID]) or 0) + count
end

-- GoldMint inventory value is intended to represent sellable/tradable assets only.
-- Never value items that are already soul/account bound, Warbound/account-bound,
-- Bind on Pickup, quest-bound, or otherwise restricted. A Bind on Equip item is
-- allowed only while it is still actually unbound.
local function IsValuableInventoryItem(containerID, slot, itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end

    -- WuE can report the generic OnEquip bind type, so inspect Blizzard's
    -- structured tooltip binding data as well. Binding values 9 and 10 are
    -- the two Warbound-until-equipped states.
    local function TooltipSaysWuE(data)
        if type(data) ~= "table" or type(data.lines) ~= "table" then return false end
        for _, line in ipairs(data.lines) do
            if type(line) == "table" then
                local bonding = tonumber(line.bonding)
                if bonding == 9 or bonding == 10 then return true end
            end
        end
        return false
    end

    if containerID ~= nil and slot ~= nil and C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local ok, data = pcall(C_TooltipInfo.GetBagItem, containerID, slot)
        if ok and TooltipSaysWuE(data) then return false end
    end

    local bindType
    local getInfo = C_Item and C_Item.GetItemInfo
    if getInfo then
        local ok, _, _, _, _, _, _, _, _, _, _, _, _, bt = pcall(getInfo, itemID)
        if ok then bindType = tonumber(bt) end
    elseif GetItemInfo then
        local ok, _, _, _, _, _, _, _, _, _, _, _, _, bt = pcall(GetItemInfo, itemID)
        if ok then bindType = tonumber(bt) end
    end

    -- If Blizzard has not returned item data yet, fail closed. This prevents a
    -- large bound item from being counted during the brief post-login cache fill.
    if bindType == nil then
        if C_Item and C_Item.RequestLoadItemDataByID then
            pcall(C_Item.RequestLoadItemDataByID, itemID)
        end
        return false
    end

    -- 0 = unbound, 2 = Bind on Equip. Everything else is excluded.
    if bindType ~= 0 and bindType ~= 2 then
        return false
    end

    -- BindType describes what will happen when an item binds; it does not tell us
    -- whether a BoE item has already become soulbound. Check the actual item slot.
    if ItemLocation and ItemLocation.CreateFromBagAndSlot and C_Item then
        local ok, itemLocation = pcall(ItemLocation.CreateFromBagAndSlot, containerID, slot)
        if ok and itemLocation then
            if C_Item.IsBound then
                local boundOK, isBound = pcall(C_Item.IsBound, itemLocation)
                if boundOK and isBound then
                    return false
                end
            end
            if C_Item.IsBoundToAccountUntilEquip then
                local accountOK, accountBoundUntilEquip = pcall(C_Item.IsBoundToAccountUntilEquip, itemLocation)
                if accountOK and accountBoundUntilEquip then
                    return false
                end
            end
        end
    end

    -- Explicit account/Warband binding checks cover items whose bind state is
    -- represented by the item data rather than the legacy bindType value.
    if C_Item and C_Item.IsItemBindToAccount then
        local ok, accountBound = pcall(C_Item.IsItemBindToAccount, itemID)
        if ok and accountBound then return false end
    end
    if C_Item and C_Item.IsItemBindToAccountUntilEquip then
        local ok, accountBoundUntilEquip = pcall(C_Item.IsItemBindToAccountUntilEquip, itemID)
        if ok and accountBoundUntilEquip then return false end
    end
    if C_TooltipInfo and C_TooltipInfo.GetItemByID then
        local ok, data = pcall(C_TooltipInfo.GetItemByID, itemID)
        if ok and TooltipSaysWuE(data) then return false end
    end

    return true
end

function Valuation:ScanContainer(containerID, bucket, scope)
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then return 0 end
    local ok, slots = pcall(C_Container.GetContainerNumSlots, containerID)
    if not ok or not slots or slots <= 0 then return 0 end

    RecordContainer(containerID, scope)
    local scanned = 0

    for slot = 1, slots do
        local okInfo, info = pcall(C_Container.GetContainerItemInfo, containerID, slot)
        if not okInfo then info = nil end
        if info and info.itemID and (tonumber(info.stackCount) or 0) > 0 then
            local itemID = tonumber(info.itemID)
            local count = tonumber(info.stackCount) or 0
            if itemID then
                -- Market tracking may see every bag item, but Wealth valuation may
                -- only see genuinely tradable/unbound items.
                if GoldMint.Market then
                    GoldMint.Market:RecordItem(itemID)
                    GoldMint.Market:CaptureTSM(itemID)
                end

                if IsValuableInventoryItem(containerID, slot, itemID) then
                    AddItem(bucket, itemID, count)
                    scanned = scanned + 1
                end
            end
        end
    end

    return scanned
end

local INVENTORY_SCAN_BATCH = 20
local inventoryScanGeneration = 0

function Valuation:_ScanContainersBatched(containers, bucket, scope, onComplete)
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then
        if onComplete then onComplete(0) end
        return false
    end

    inventoryScanGeneration = inventoryScanGeneration + 1
    local generation = inventoryScanGeneration
    local index, slot, scanned = 1, 1, 0
    local function step()
        if generation ~= inventoryScanGeneration then return end
        if GoldMint.IsMerchantOpen and GoldMint:IsMerchantOpen() then
            if onComplete then onComplete(scanned, true) end
            return
        end

        local processed = 0
        while index <= #containers and processed < INVENTORY_SCAN_BATCH do
            local containerID = containers[index]
            local okSlots, slots = pcall(C_Container.GetContainerNumSlots, containerID)
            slots = okSlots and (tonumber(slots) or 0) or 0
            if slot > slots then
                index = index + 1
                slot = 1
            else
                local okInfo, info = pcall(C_Container.GetContainerItemInfo, containerID, slot)
                if okInfo and info and info.itemID and (tonumber(info.stackCount) or 0) > 0 then
                    local itemID = tonumber(info.itemID)
                    local count = tonumber(info.stackCount) or 0
                    if itemID then
                        if GoldMint.Market then
                            GoldMint.Market:RecordItem(itemID)
                            GoldMint.Market:CaptureTSM(itemID)
                        end
                        if IsValuableInventoryItem(containerID, slot, itemID) then
                            AddItem(bucket, itemID, count)
                            scanned = scanned + 1
                        end
                    end
                end
                slot = slot + 1
                processed = processed + 1
            end
        end

        if index <= #containers then
            C_Timer.After(0, step)
        elseif onComplete then
            onComplete(scanned, false)
        end
    end
    C_Timer.After(0, step)
    return true
end

function Valuation:ScanCharacterContainers()
    if not C_Container or not C_Container.GetContainerNumSlots then return 0 end
    local character = EnsureCharacterStore()
    local inventory = {}
    self:_ScanContainersBatched({0,1,2,3,4,5}, inventory, "character_inventory", function(scanned, aborted)
        if not aborted then
            character.inventory = inventory
            character.scannedAt = Now()
            EnsureStore().scanState.characterInventory = Now()
        end
    end)
    return 0
end

function Valuation:ScanCharacterBank()
    if not C_Container or not C_Container.GetContainerNumSlots then return 0 end
    local character = EnsureCharacterStore()
    local bank = {}
    self:_ScanContainersBatched({-1,-2,6,7,8,9,10,11}, bank, "character_bank", function(scanned, aborted)
        if not aborted then
            character.bank = bank
            character.bankScannedAt = Now()
            EnsureStore().scanState.characterBank = Now()
        end
    end)
    return 0
end

function Valuation:ScanAccountBank()
    if not C_Container or not C_Container.GetContainerNumSlots then return 0 end
    local accountBank = {}
    self:_ScanContainersBatched({12,13,14,15,16,17}, accountBank, "account_bank", function(scanned, aborted)
        if not aborted then
            local store = EnsureStore()
            store.accountBank = accountBank
            store.scanState.accountBank = Now()
        end
    end)
    return 0
end

function Valuation:GetContainerValue(containerID)
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then return 0 end
    local ok, slots = pcall(C_Container.GetContainerNumSlots, containerID)
    if not ok or not slots then return 0 end
    local total = 0

    for slot = 1, slots do
        local okInfo, info = pcall(C_Container.GetContainerItemInfo, containerID, slot)
        if not okInfo then info = nil end
        if info and info.itemID and info.stackCount and IsValuableInventoryItem(containerID, slot, info.itemID) then
            local value = GoldMint.Market and GoldMint.Market:GetUnitValue(info.itemID)
            if value and value > 0 then
                total = total + value * (tonumber(info.stackCount) or 0)
            end
        end
    end
    return total
end

function Valuation:GetVisibleCharacterValue()
    local total = 0
    for bag = 0, 5 do
        total = total + self:GetContainerValue(bag)
    end
    return total
end

function Valuation:GetVisibleBankValue()
    local total = 0
    for _, containerID in ipairs({ -1, -2, 6, 7, 8, 9, 10, 11 }) do
        total = total + self:GetContainerValue(containerID)
    end
    return total
end

local function ValueBucket(bucket)
    local total = 0
    local itemCount = 0
    for itemID, count in pairs(bucket or {}) do
        local value = GoldMint.Market and GoldMint.Market:GetUnitValue(itemID)
        if value and value > 0 then
            total = total + value * (tonumber(count) or 0)
            itemCount = itemCount + (tonumber(count) or 0)
        end
    end
    return total, itemCount
end

function Valuation:GetKnownHoardValue()
    local store = EnsureStore()
    local total = 0
    local currentCharacter = 0
    local accountBank = 0
    local knownCharacters = 0

    for key, character in pairs(store.characters or {}) do
        if type(character) == "table" and (character.name or character.realm) then
            local inventoryValue = ValueBucket(character.inventory)
            local bankValue = ValueBucket(character.bank)
            total = total + inventoryValue + bankValue
            if key == GoldMint.characterKey then
                -- Wealth's "Inventory Value" is bags only. Character-bank
                -- contents are not silently folded into the inventory figure.
                currentCharacter = inventoryValue
            end
            knownCharacters = knownCharacters + 1
        end
    end

    accountBank = ValueBucket(store.accountBank)
    total = total + accountBank

    return {
        total = total,
        currentCharacter = currentCharacter,
        accountBank = accountBank,
        knownCharacters = knownCharacters,
        updatedAt = Now(),
    }
end

local function GetGuildKey(guild)
    if type(guild) ~= "table" or not guild.name or guild.name == "" then return nil end
    return string.lower(tostring(guild.realm or "Unknown")) .. "|" .. string.lower(tostring(guild.name))
end

local function GetGuildBankType()
    if Enum and Enum.BankType and Enum.BankType.Guild then
        return Enum.BankType.Guild
    end
    return 1
end

local function GetCurrentGuildBankGold()
    local bankType = GetGuildBankType()
    local modernAmount = 0
    local legacyAmount = 0

    -- The modern C_Bank API is authoritative on current clients, but during
    -- the first few guild-bank events it can briefly report the pre-load
    -- value.  The legacy guild-bank API is still exposed and often updates
    -- first.  Read both and keep the larger value so a freshly deposited
    -- balance cannot be overwritten by a transient zero.
    if C_Bank and C_Bank.FetchDepositedMoney then
        local ok, amount = pcall(C_Bank.FetchDepositedMoney, bankType)
        if ok and amount ~= nil then modernAmount = tonumber(amount) or 0 end
    end
    if type(GetGuildBankMoney) == "function" then
        local ok, amount = pcall(GetGuildBankMoney)
        if ok and amount ~= nil then legacyAmount = tonumber(amount) or 0 end
    end

    return math.max(modernAmount, legacyAmount)
end

function Valuation:ScanGuildBank()
    -- Guild-bank contents are delivered asynchronously.  The reliable pattern
    -- on current Retail is: QueryGuildBankTab() -> wait for
    -- GUILDBANKBAGSLOTS_CHANGED -> read GetGuildBankItemInfo/Link.
    local selected = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
    if not selected then return false, "no_selected_guild" end

    local currentName = GetGuildInfo and GetGuildInfo("player") or nil
    local currentRealm = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "Unknown"
    if not currentName or string.lower(tostring(currentName)) ~= string.lower(tostring(selected.name))
        or string.lower(tostring(currentRealm)) ~= string.lower(tostring(selected.realm or "Unknown")) then
        return false, "current_character_not_in_selected_guild"
    end

    local state = self._guildBankScan
    if state and state.active then
        state.pending = true
        return false, "scan_in_progress"
    end

    local store = EnsureStore()
    local key = GetGuildKey(selected)
    if not key then return false, "invalid_guild" end

    local tabCount = 0
    if type(GetNumGuildBankTabs) == "function" then
        local ok, count = pcall(GetNumGuildBankTabs)
        if ok then tabCount = tonumber(count) or 0 end
    end
    if tabCount <= 0 and C_Bank and C_Bank.FetchNumPurchasedBankTabs then
        local bankType = GetGuildBankType()
        local ok, count = pcall(C_Bank.FetchNumPurchasedBankTabs, bankType)
        if ok then tabCount = tonumber(count) or 0 end
    end
    if tabCount <= 0 then return false, "no_guild_bank_tabs" end

    state = {
        active = true,
        pending = false,
        key = key,
        guildName = selected.name,
        guildRealm = selected.realm or currentRealm,
        tabCount = tabCount,
        tabs = {},
        gold = GetCurrentGuildBankGold(),
        attempts = {},
    }
    self._guildBankScan = state

    local function IsValuableGuildBankItem(itemID)
        itemID = tonumber(itemID)
        if not itemID then return false end
        local bindType
        if C_Item and C_Item.GetItemInfo then
            local ok, _, _, _, _, _, _, _, _, _, _, _, _, bt = pcall(C_Item.GetItemInfo, itemID)
            if ok then bindType = tonumber(bt) end
        elseif GetItemInfo then
            local ok, _, _, _, _, _, _, _, _, _, _, _, _, bt = pcall(GetItemInfo, itemID)
            if ok then bindType = tonumber(bt) end
        end
        if bindType == nil then
            if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, itemID) end
            return false
        end
        if bindType ~= 0 and bindType ~= 2 then return false end
        if C_Item and C_Item.IsItemBindToAccount then
            local ok, accountBound = pcall(C_Item.IsItemBindToAccount, itemID)
            if ok and accountBound then return false end
        end
        if C_Item and C_Item.IsItemBindToAccountUntilEquip then
            local ok, accountBoundUntilEquip = pcall(C_Item.IsItemBindToAccountUntilEquip, itemID)
            if ok and accountBoundUntilEquip then return false end
        end
        return true
    end

    local function finalize()
        if self._guildBankScan ~= state or not state.active then return end
        local combined = {}
        local scannedSlots = 0
        for _, tabItems in pairs(state.tabs) do
            for itemID, count in pairs(tabItems) do
                combined[itemID] = (combined[itemID] or 0) + count
                scannedSlots = scannedSlots + 1
            end
        end

        local items = {}
        for itemID, count in pairs(combined) do
            if IsValuableGuildBankItem(itemID) then
                items[itemID] = count
                if GoldMint.Market then
                    GoldMint.Market:RecordItem(itemID)
                    GoldMint.Market:CaptureTSM(itemID)
                end
            end
        end

        local itemValue, itemCount = ValueBucket(items)
        local record = {
            guildName = selected.name,
            guildRealm = selected.realm or currentRealm,
            gold = GetCurrentGuildBankGold(),
            items = items,
            itemValue = itemValue,
            itemCount = itemCount,
            value = (tonumber(GetCurrentGuildBankGold()) or 0) + (tonumber(itemValue) or 0),
            scannedSlots = scannedSlots,
            tracked = true,
            scannedAt = Now(),
        }
        store.guildBanks[key] = record
        store.scanState.guildBank = Now()
        state.active = false
        self._guildBankScan = nil

        if GoldMint.Economy and GoldMint.Economy.Refresh then
            GoldMint.Economy:ScheduleRefresh("guildbank_scan_complete")
        end
        if state.pending and C_Timer and C_Timer.After then
            C_Timer.After(0.75, function()
                if GoldMint.Valuation and GoldMint.Valuation.ScanGuildBank then
                    GoldMint.Valuation:ScanGuildBank()
                end
            end)
        end
    end

    local function captureTab(tab)
        if self._guildBankScan ~= state or not state.active then return end
        local tabItems = {}
        local found = 0
        for slot = 1, 98 do
            local itemCount = 0
            if type(GetGuildBankItemInfo) == "function" then
                local ok, _, count = pcall(GetGuildBankItemInfo, tab, slot)
                if ok then itemCount = tonumber(count) or 0 end
            end
            if itemCount > 0 and type(GetGuildBankItemLink) == "function" then
                local ok, link = pcall(GetGuildBankItemLink, tab, slot)
                if ok and link then
                    local itemID = tonumber(string.match(tostring(link), "item:(%d+)"))
                    if not itemID and C_Item and C_Item.GetItemInfoInstant then
                        local instantOK, id = pcall(C_Item.GetItemInfoInstant, link)
                        if instantOK then itemID = tonumber(id) end
                    end
                    if itemID then
                        tabItems[itemID] = (tabItems[itemID] or 0) + itemCount
                        found = found + 1
                    end
                end
            end
        end

        if found > 0 then
            state.tabs[tab] = tabItems
            state.attempts[tab] = 99
        else
            state.attempts[tab] = (state.attempts[tab] or 0) + 1
            if state.attempts[tab] < 6 then
                if type(QueryGuildBankTab) == "function" then pcall(QueryGuildBankTab, tab) end
                C_Timer.After(0.75, function() captureTab(tab) end)
                return
            end
        end

        local allDone = true
        for tab = 1, state.tabCount do
            if not state.tabs[tab] and (state.attempts[tab] or 0) < 6 then
                allDone = false
                break
            end
        end
        if allDone then finalize() end
    end

    for tab = 1, state.tabCount do
        if type(GetGuildBankTabInfo) == "function" then
            local ok, _, _, viewable = pcall(GetGuildBankTabInfo, tab)
            if ok and viewable == false then
                state.attempts[tab] = 6
            else
                if type(QueryGuildBankTab) == "function" then pcall(QueryGuildBankTab, tab) end
                state.attempts[tab] = 0
                C_Timer.After(1.0, function() captureTab(tab) end)
            end
        else
            if type(QueryGuildBankTab) == "function" then pcall(QueryGuildBankTab, tab) end
            state.attempts[tab] = 0
            C_Timer.After(1.0, function() captureTab(tab) end)
        end
    end

    return true, "scan_started"
end

function Valuation:RefreshGuildBankGold()
    local selected = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
    if not selected then return false end

    local currentName = GetGuildInfo and GetGuildInfo("player") or nil
    local currentRealm = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "Unknown"
    if not currentName or string.lower(tostring(currentName)) ~= string.lower(tostring(selected.name))
        or string.lower(tostring(currentRealm)) ~= string.lower(tostring(selected.realm or "Unknown")) then
        return false
    end

    local store = EnsureStore()
    local key = GetGuildKey(selected)
    local record = key and store.guildBanks[key]
    if type(record) ~= "table" then return false end

    local gold = GetCurrentGuildBankGold()
    record.gold = gold
    record.value = (tonumber(record.gold) or 0) + (tonumber(record.itemValue) or 0)
    record.tracked = record.tracked == true
    record.scannedAt = tonumber(record.scannedAt) or Now()
    store.scanState.guildBank = Now()
    return true
end

function Valuation:GetGoldMakingGuildBankValue()
    local selected = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
    if not selected then
        return { value = 0, gold = 0, itemValue = 0, itemCount = 0, tracked = false, selected = nil, updatedAt = Now() }
    end

    local store = EnsureStore()
    local key = GetGuildKey(selected)
    local record = key and store.guildBanks[key]
    if type(record) ~= "table" then
        return {
            value = 0, gold = 0, itemValue = 0, itemCount = 0,
            tracked = false, selected = selected, scannedAt = 0, updatedAt = Now()
        }
    end

    return {
        value = tonumber(record.value) or 0,
        gold = tonumber(record.gold) or 0,
        itemValue = tonumber(record.itemValue) or 0,
        itemCount = tonumber(record.itemCount) or 0,
        tracked = record.tracked == true,
        selected = selected,
        scannedAt = tonumber(record.scannedAt) or 0,
        updatedAt = Now(),
    }
end

function Valuation:GetAccountLiquidValue()
    local gold = GoldMint.Ledger and GoldMint.Ledger:GetAccountWallet().totalGold or 0
    local hoard = self:GetKnownHoardValue()

    return {
        gold = tonumber(gold) or 0,
        items = hoard.total,
        total = (tonumber(gold) or 0) + hoard.total,
        currentCharacterItems = hoard.currentCharacter,
        accountBankItems = hoard.accountBank,
        knownCharacterItemValue = hoard.total - hoard.accountBank,
        knownCharacters = hoard.knownCharacters,
        updatedAt = Now(),
    }
end

function Valuation:GetStatus()
    local result = self:GetAccountLiquidValue()
    result.visibleCharacterItems = self:GetVisibleCharacterValue()
    result.visibleBankItems = self:GetVisibleBankValue()
    result.trackedMarketItems = GoldMint.Market and GoldMint.Market:GetTrackedCount() or 0
    return result
end

function Valuation:Initialize()
    if self._initialized then return end
    self._initialized = true
    EnsureStore()
    EnsureCharacterStore()

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("BAG_UPDATE_DELAYED")
    frame:RegisterEvent("BANKFRAME_OPENED")
    frame:RegisterEvent("ITEM_DATA_LOAD_RESULT")

    frame:SetScript("OnEvent", function(_, event)
        if event == "BAG_UPDATE_DELAYED" then
            -- Vendor opening can emit bag updates. Do not scan/TSM-value inventory
            -- while the merchant frame is appearing; Core performs one deferred
            -- inventory pass after MERCHANT_CLOSED.
            if GoldMint._merchantOpen or (MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown()) then
                return
            end
            -- Vendor interactions can produce a short burst of bag events.
            -- Defer and coalesce the inventory valuation pass.
            if not self._bagScanPending then
                self._bagScanPending = true
                GoldMint:ScheduleGuardedCallback(self, "valuation bag scan", 0.45, function()
                    self._bagScanPending = false
                    self:ScanCharacterContainers()
                    if GoldMint.Economy then GoldMint.Economy:ScheduleRefresh("valuation_bags") end
                end)
            end
        elseif event == "ITEM_DATA_LOAD_RESULT" then
            -- Item data can arrive in a burst while a merchant is opening. Never
            -- perform a full bag/TSM scan from this event; mark the inventory dirty
            -- and let the post-merchant refresh (or a coalesced timer) handle it.
            self._itemDataScanPending = true
            if GoldMint:IsMerchantOpen() then
                return
            end
            if self._itemDataScanTimer then return end
            self._itemDataScanTimer = true
            GoldMint:ScheduleGuardedCallback(self, "valuation item data scan", 0.50, function()
                self._itemDataScanTimer = false
                if GoldMint:IsMerchantOpen() then return end
                if not self._itemDataScanPending then return end
                self._itemDataScanPending = false
                self:ScanCharacterContainers()
                if GoldMint.Economy then GoldMint.Economy:ScheduleRefresh("valuation_item_data") end
            end)
        elseif event == "BANKFRAME_OPENED" then
            self:ScanCharacterContainers()
            self:ScanCharacterBank()
            self:ScanAccountBank()
            if GoldMint.Economy then GoldMint.Economy:ScheduleRefresh("valuation_bank") end
        end
    end)

    GoldMint:ScheduleGuardedCallback(self, "valuation initial scan", 2, function()
        self:ScanCharacterContainers()
        if GoldMint.Economy then GoldMint.Economy:ScheduleRefresh("valuation_initial") end
    end, function() return self._initialized end)
end
