local ADDON_NAME, GoldMint = ...

-- ============================================================================
-- GOLDMINT PROFESSIONS
-- ============================================================================
-- This module intentionally scans ONLY the profession that the player has
-- actually opened in the WoW Profession UI. It does not enumerate every
-- profession known by the character or every profession stored elsewhere.
--
-- When a profession tab is opened, Blizzard exposes the parent profession and
-- its expansion-specific child skill lines. We record those child skill lines,
-- their rank/max rank, and the expansion-specific display name. The dashboard
-- then uses only these explicitly scanned profession tabs.
-- ============================================================================

GoldMint.Professions = GoldMint.Professions or {}
local Professions = GoldMint.Professions

local EXPANSIONS = {
    "Midnight",
    "The War Within",
    "Dragon Isles",
    "Dragonflight",
    "Shadowlands",
    "Kul Tiran",
    "Zandalari",
    "Battle for Azeroth",
    "Legion",
    "Warlords of Draenor",
    "Mists of Pandaria",
    "Cataclysm",
    "Wrath of the Lich King",
    "The Burning Crusade",
    "Classic",
}

local function CharacterKey()
    if GoldMint.characterKey then
        return GoldMint.characterKey
    end

    local name = UnitName and UnitName("player") or "Unknown"
    local realm = GetRealmName and GetRealmName() or "Unknown"
    return tostring(name) .. "-" .. tostring(realm):gsub("%s+", "")
end

local function EnsureCharacter()
    GoldMintDB = GoldMintDB or {}
    GoldMintDB.characters = GoldMintDB.characters or {}

    local key = CharacterKey()
    local character = GoldMintDB.characters[key]
    if type(character) ~= "table" then
        character = {}
        GoldMintDB.characters[key] = character
    end

    character.name = character.name or (UnitName and UnitName("player")) or key
    character.realm = character.realm or (GetRealmName and GetRealmName()) or ""
    character.professionScans = type(character.professionScans) == "table" and character.professionScans or {}

    return key, character
end

-- GoldMint's core character key is authoritative, but older saved data can
-- contain the same character under a slightly different realm/key format.
-- Resolve the current record defensively so the dashboard does not go blank
-- just because the character-key format changed between addon versions.
local function GetCurrentCharacterRecord()
    GoldMintDB = GoldMintDB or {}
    GoldMintDB.characters = GoldMintDB.characters or {}

    local key = CharacterKey()
    local characters = GoldMintDB.characters
    local character = characters[key]
    if type(character) == "table" then
        return key, character
    end

    local playerName = UnitName and UnitName("player") or nil
    local playerRealm = GetRealmName and GetRealmName() or nil
    local normalizedRealm = playerRealm and tostring(playerRealm):gsub("%s+", "") or nil

    -- Prefer an explicitly active/current-session record.
    for savedKey, saved in pairs(characters) do
        if type(saved) == "table" and (saved.currentSession == true or saved.lastActive == true) then
            if (not playerName or saved.name == playerName)
                and (not playerRealm or saved.realm == playerRealm or tostring(saved.realm or ""):gsub("%s+", "") == normalizedRealm) then
                return savedKey, saved
            end
        end
    end

    -- Finally match by character name + realm, covering records created by
    -- older GoldMint versions that used a different key format.
    for savedKey, saved in pairs(characters) do
        if type(saved) == "table" and saved.name == playerName then
            local savedRealm = tostring(saved.realm or "")
            if not playerRealm or savedRealm == playerRealm or savedRealm:gsub("%s+", "") == normalizedRealm then
                return savedKey, saved
            end
        end
    end

    return key, nil
end

local function CleanName(value)
    if value == nil then return "" end
    return tostring(value):gsub("^%s+", ""):gsub("%s+$", "")
end

local function IsMaxed(row)
    local rank = tonumber(row and row.rank)
    local maxRank = tonumber(row and row.maxRank)
    return rank ~= nil and maxRank ~= nil and maxRank > 0 and rank >= maxRank
end

local function GetExpansionFromDisplay(displayName, professionName, explicitExpansion)
    displayName = CleanName(displayName)
    professionName = CleanName(professionName)
    explicitExpansion = CleanName(explicitExpansion)

    -- Retail's ProfessionInfo has the authoritative expansionName.
    -- GetChildProfessionInfos() can report "Unknown" for this field on some
    -- builds, so only use it when Blizzard actually supplied a useful value.
    if explicitExpansion ~= "" and explicitExpansion ~= "Unknown" then
        return explicitExpansion
    end

    -- The child profession name is also expansion-specific, for example:
    -- "Kul Tiran Leatherworking" or "Kul Tiran Skinning".
    for _, expansion in ipairs(EXPANSIONS) do
        if displayName:find(expansion, 1, true) or professionName:find(expansion, 1, true) then
            return expansion
        end
    end

    if professionName ~= "" then
        local remainder = displayName:gsub("^%s*", "")
        remainder = remainder:gsub("%s*" .. professionName:gsub("([%%%^%$%(%)%.%[%]%*%+%-%?])", "%%%1") .. "%s*$", "")
        if remainder ~= "" and remainder ~= displayName then
            return remainder
        end
    end

    return nil
end

local function GetProfessionInfo(skillLineID)
    if not C_TradeSkillUI or not C_TradeSkillUI.GetProfessionInfoBySkillLineID then
        return nil
    end

    local ok, info = pcall(C_TradeSkillUI.GetProfessionInfoBySkillLineID, skillLineID)
    if ok and type(info) == "table" then
        return info
    end

    return nil
end

local function GetProfessionDisplayName(skillLineID, fallback)
    if C_TradeSkillUI and C_TradeSkillUI.GetTradeSkillDisplayName then
        local ok, name = pcall(C_TradeSkillUI.GetTradeSkillDisplayName, skillLineID)
        if ok and name and name ~= "" then
            return CleanName(name)
        end
    end
    return CleanName(fallback)
end

local function ReadChildProfession(info)
    if type(info) ~= "table" then return nil end

    local skillLineID = tonumber(info.professionID)
    if not skillLineID then return nil end

    local professionName = CleanName(info.professionName or info.parentProfessionName)
    local displayName = GetProfessionDisplayName(skillLineID, professionName)
    local expansion = GetExpansionFromDisplay(displayName, professionName, info.expansionName)

    -- GetProfessionInfoBySkillLineID() gives us the expansion-specific
    -- profession name/rank when the child API's display name is too generic.
    local detailed = GetProfessionInfo(skillLineID)
    if detailed then
        local detailedName = CleanName(detailed.professionName)
        local detailedExpansion = GetExpansionFromDisplay(
            detailedName,
            detailed.parentProfessionName or professionName,
            detailed.expansionName
        )
        if detailedName ~= "" and detailedName ~= "Unknown" then
            displayName = detailedName
            if professionName == "" or professionName == CleanName(info.parentProfessionName) then
                professionName = CleanName(detailed.parentProfessionName or professionName)
            end
        end
        expansion = detailedExpansion or expansion
    end

    return {
        skillLineID = skillLineID,
        parentSkillLineID = tonumber(info.parentProfessionID),
        name = professionName ~= "" and professionName or displayName,
        displayName = displayName,
        expansion = expansion,
        rank = tonumber(info.skillLevel),
        maxRank = tonumber(info.maxSkillLevel),
        modifier = tonumber(info.skillModifier) or 0,
        lastSeen = time and time() or 0,
        scanned = true,
    }
end

local function ScanOpenProfession()
    if not C_TradeSkillUI or not C_TradeSkillUI.GetTradeSkillLine then
        return nil
    end

    local ok, skillLineID, displayName, rank, maxRank, modifier, parentID, parentName = pcall(
        C_TradeSkillUI.GetTradeSkillLine
    )
    if not ok or not tonumber(skillLineID) then
        return nil
    end

    skillLineID = tonumber(skillLineID)
    parentID = tonumber(parentID) or skillLineID
    parentName = CleanName(parentName or displayName)

    local key, character = EnsureCharacter()
    local scans = character.professionScans

    -- Resolve the authoritative parent profession BEFORE selecting the saved
    -- record.  The legacy GetTradeSkillLine() result can identify the current
    -- expansion child first, while GetBaseProfessionInfo() can then reveal the
    -- actual parent profession.  The previous implementation created
    -- professionScan before this resolution and then changed professionKey
    -- afterward, which meant variants were sometimes written into one record
    -- while GetRoadmap() looked at another record.
    if C_TradeSkillUI.GetBaseProfessionInfo then
        local baseOK, baseInfo = pcall(C_TradeSkillUI.GetBaseProfessionInfo)
        if baseOK and type(baseInfo) == "table" then
            parentID = tonumber(baseInfo.professionID) or parentID
            parentName = CleanName(baseInfo.professionName or baseInfo.parentProfessionName or parentName)
        end
    end

    local professionKey = tostring(parentID)
    local professionScan = scans[professionKey]

    if type(professionScan) ~= "table" then
        professionScan = {
            skillLineID = parentID,
            name = parentName,
            variants = {},
            lastScanned = 0,
        }
        scans[professionKey] = professionScan
    end

    professionScan.skillLineID = parentID
    professionScan.name = parentName
    professionScan.lastScanned = time and time() or 0
    professionScan.variants = type(professionScan.variants) == "table" and professionScan.variants or {}

    -- Always capture the exact child profession currently displayed. This is
    -- important because GetTradeSkillLine() returns the selected expansion's
    -- skill line, while the base profession ID identifies Leatherworking,
    -- Skinning, etc.
    -- Retail's newer profession UI exposes the authoritative parent/child
    -- relationship through GetBaseProfessionInfo/GetChildProfessionInfo.
    -- Prefer those values when available, while retaining GetTradeSkillLine
    -- as a compatibility fallback.
    local currentChildID = skillLineID
    if C_TradeSkillUI.GetProfessionChildSkillLineID then
        local childOK, childID = pcall(C_TradeSkillUI.GetProfessionChildSkillLineID)
        if childOK and tonumber(childID) then
            currentChildID = tonumber(childID)
        end
    end

    local function SaveVariant(variantID, fallbackName, fallbackRank, fallbackMax, fallbackModifier)
        variantID = tonumber(variantID)
        if not variantID then return end

        local info = GetProfessionInfo(variantID)

        -- On some Retail builds GetProfessionInfoBySkillLineID can return
        -- parent-level rank data for an expansion skill line. Query the
        -- specific TradeSkillLine ID as the authoritative rank source.
        local lineName, lineRank, lineMax, lineModifier
        if C_TradeSkillUI and C_TradeSkillUI.GetTradeSkillLineInfoByID then
            local lineOK, a, b, c, d = pcall(C_TradeSkillUI.GetTradeSkillLineInfoByID, variantID)
            if lineOK then
                lineName, lineRank, lineMax, lineModifier = a, b, c, d
            end
        end

        local variantName = GetProfessionDisplayName(variantID, lineName or fallbackName)
        if CleanName(variantName) == "" and lineName then
            variantName = CleanName(lineName)
        end

        local parentVariantName = info and CleanName(info.parentProfessionName) or parentName
        if parentVariantName == "" or parentVariantName == "Unknown" then
            parentVariantName = parentName
        end

        local variantRank = tonumber(lineRank) or (info and tonumber(info.skillLevel)) or tonumber(fallbackRank)
        local variantMax = tonumber(lineMax) or (info and tonumber(info.maxSkillLevel)) or tonumber(fallbackMax)
        local variantModifier = tonumber(lineModifier) or (info and tonumber(info.skillModifier)) or tonumber(fallbackModifier) or 0
        local expansion = GetExpansionFromDisplay(variantName, parentVariantName, info and info.expansionName)

        professionScan.variants[tostring(variantID)] = {
            skillLineID = variantID,
            parentSkillLineID = parentID,
            name = parentName,
            displayName = variantName,
            expansion = expansion,
            rank = variantRank,
            maxRank = variantMax,
            modifier = variantModifier,
            lastSeen = time and time() or 0,
            scanned = true,
        }
    end

    SaveVariant(currentChildID, displayName, rank, maxRank, modifier)

    -- GetChildProfessionInfo() describes the expansion currently selected in
    -- the Blizzard profession window. On current Retail this is often the most
    -- reliable source for the actual rank/max-rank pair.
    if C_TradeSkillUI.GetChildProfessionInfo then
        local childInfoOK, childInfo = pcall(C_TradeSkillUI.GetChildProfessionInfo)
        if childInfoOK and type(childInfo) == "table" then
            local childRank = tonumber(childInfo.skillLevel)
            local childMax = tonumber(childInfo.maxSkillLevel)
            if childRank ~= nil and childMax ~= nil then
                SaveVariant(
                    currentChildID,
                    childInfo.professionName or displayName,
                    childRank,
                    childMax,
                    childInfo.skillModifier
                )
            end
        end
    end

    -- Retail exposes every profession skill-line the character has learned
    -- through GetAllProfessionTradeSkillLines(). Once the player has opened a
    -- profession, use that list to collect ALL of its expansion-specific
    -- variants. This is what lets GoldMint see an unfinished Kul Tiran tier
    -- even when the Blizzard window initially opens on a newer expansion.
    if C_TradeSkillUI.GetAllProfessionTradeSkillLines then
        local allOK, skillLines = pcall(C_TradeSkillUI.GetAllProfessionTradeSkillLines)
        if allOK and type(skillLines) == "table" then
            for index, value in pairs(skillLines) do
                -- GetAllProfessionTradeSkillLines() is documented as a numeric
                -- array, but treating both the value and key as candidates makes
                -- this tolerant of Retail builds that expose the IDs as keys.
                local candidates = { tonumber(value), tonumber(index) }
                for _, variantID in ipairs(candidates) do
                    if variantID then
                        local info = GetProfessionInfo(variantID)
                        local infoParent = info and tonumber(info.parentProfessionID)
                        local infoProfession = info and tonumber(info.professionID)
                        if infoParent == parentID or infoProfession == parentID or variantID == currentChildID then
                            SaveVariant(
                                variantID,
                                (info and info.professionName) or parentName,
                                info and info.skillLevel,
                                info and info.maxSkillLevel,
                                info and info.skillModifier
                            )
                            break
                        end
                    end
                end
            end
        end
    end

    -- Keep the child-profession API as a secondary source. Its professionID
    -- is the parent tradeskill on current Retail builds, so it must NOT be
    -- treated as the variant skill-line ID.
    if C_TradeSkillUI.GetChildProfessionInfos then
        local childOK, children = pcall(C_TradeSkillUI.GetChildProfessionInfos)
        if childOK and type(children) == "table" then
            for _, info in ipairs(children) do
                if type(info) == "table" then
                    local childParent = tonumber(info.parentProfessionID) or tonumber(info.professionID)
                    if childParent == parentID then
                        -- If this info describes the currently selected child,
                        -- refresh it with the exact child skill-line ID. Do not
                        -- invent a variant ID from info.professionID.
                        local selectedID
                        if C_TradeSkillUI.GetProfessionChildSkillLineID then
                            local selectedOK, value = pcall(C_TradeSkillUI.GetProfessionChildSkillLineID)
                            if selectedOK then
                                selectedID = tonumber(value)
                            end
                        end
                        if selectedID then
                            SaveVariant(selectedID, info.professionName or parentName, info.skillLevel, info.maxSkillLevel, info.skillModifier)
                        end
                    end
                end
            end
        end
    end

    character.professionScans = scans
    return key, character, professionScan
end

function Professions:ScanCurrentCharacter()
    return ScanOpenProfession()
end

function Professions:GetRoadmap()
    local result = {}
    local currentKey, character = GetCurrentCharacterRecord()

    -- The dashboard is character-specific.  Older versions built the roadmap
    -- from every character in GoldMintDB, which caused another character's
    -- profession tier to appear on the character currently being viewed.
    -- That is exactly how a maxed Midnight Leatherworking tier (or a second
    -- Skinning row) could leak into this character's panel.
    if type(character) ~= "table" then
        return result
    end

    -- A profession can have several expansion-specific child skill lines.
    -- Show ONE actionable unfinished tier per profession, preferring the most
    -- recent expansion.  Use professionScans as the authoritative progression
    -- source; the recipe registry can contain stale/partial rank data and is
    -- not needed to decide which tier needs leveling.
    local bestByProfession = {}

    local function ExpansionPriority(name)
        name = CleanName(name)
        for index, expansion in ipairs(EXPANSIONS) do
            if name == expansion or name:find(expansion, 1, true) then
                return #EXPANSIONS - index + 1
            end
        end
        return 0
    end

    local function InferExpansion(displayName, professionName, explicit)
        local expansion = GetExpansionFromDisplay(displayName, professionName, explicit)
        if expansion and expansion ~= "" and expansion ~= "Unknown" then
            return expansion
        end
        return CleanName(displayName or "")
    end

    local function AddVariant(professionScan, professionName, variant)
        if type(variant) ~= "table" then return end

        local rank = tonumber(variant.rank)
        local maxRank = tonumber(variant.maxRank)
        if not rank or not maxRank or maxRank <= 0 or rank >= maxRank then
            -- Maxed tiers are intentionally ignored.  If Midnight is maxed,
            -- the next unfinished tier (for example Kul Tiran) is shown.
            return
        end

        professionName = CleanName(professionName or variant.parentProfessionName or variant.name)
        if professionName == "" then
            professionName = CleanName(variant.displayName or variant.name or "Profession")
        end

        local displayName = CleanName(variant.displayName or variant.name or professionName)
        local expansion = InferExpansion(displayName, professionName, variant.expansion)

        local parentID = tonumber(variant.parentSkillLineID)
            or tonumber(professionScan and professionScan.skillLineID)
        local childID = tonumber(variant.skillLineID)

        -- A parent/base skill line is not an expansion tier. Some API/cache
        -- paths can save the parent line with an expansion-looking display name
        -- and its aggregate rank (for example the bogus 300/800 Midnight
        -- Leatherworking row). Only child skill lines should reach the roadmap.
        if parentID and childID and childID == parentID then
            return
        end
        if professionScan and tonumber(professionScan.skillLineID) and childID
            and childID == tonumber(professionScan.skillLineID) then
            return
        end

        -- Use the canonical parent profession name as the identity. Cached
        -- records can have different parent skill-line IDs, which was allowing
        -- the same profession (notably Skinning) to appear twice.
        local professionIdentity = strlower(CleanName(professionName))
        professionIdentity = professionIdentity:gsub("%s+", " ")
        local professionKey = currentKey .. ":" .. professionIdentity

        local candidate = {
            key = professionKey,
            character = (character.name and character.realm and character.name ~= "")
                and (character.name .. "-" .. character.realm)
                or (character.name or currentKey),
            characterKey = currentKey,
            faction = character.faction,
            name = professionName,
            expansion = expansion,
            displayName = displayName,
            rank = rank,
            maxRank = maxRank,
            skillLineID = tonumber(variant.skillLineID),
            parentSkillLineID = parentID,
            lastSeen = tonumber(variant.lastSeen) or 0,
        }

        local existing = bestByProfession[professionKey]
        if not existing then
            bestByProfession[professionKey] = candidate
            return
        end

        local cp = ExpansionPriority(candidate.expansion or candidate.displayName)
        local ep = ExpansionPriority(existing.expansion or existing.displayName)
        local cr = tonumber(candidate.rank) or math.huge
        local er = tonumber(existing.rank) or math.huge
        local cid = tonumber(candidate.skillLineID) or 0
        local eid = tonumber(existing.skillLineID) or 0

        if cp > ep
            or (cp == ep and cr < er)
            or (cp == ep and cr == er and cid > eid) then
            bestByProfession[professionKey] = candidate
        end
    end

    if type(character.professionScans) == "table" then
        for _, professionScan in pairs(character.professionScans) do
            if type(professionScan) == "table" and type(professionScan.variants) == "table" then
                local professionName = CleanName(professionScan.name)
                for _, variant in pairs(professionScan.variants) do
                    if type(variant) == "table" and (variant.scanned ~= false) then
                        AddVariant(professionScan, professionName, variant)
                    end
                end
            end
        end
    end

    -- Keep the older profession cache as a fallback.  This is still restricted
    -- to the CURRENT character, so it cannot reintroduce another character's
    -- Alchemy/Leatherworking data.  It also lets older saved data continue to
    -- populate the panel until the player opens that profession again.
    if type(character.professions) == "table" then
        for _, profession in pairs(character.professions) do
            if type(profession) == "table" then
                local professionName = CleanName(profession.name or profession.professionName)
                if type(profession.variants) == "table" then
                    for _, variant in pairs(profession.variants) do
                        if type(variant) == "table" then
                            AddVariant(profession, professionName, variant)
                        end
                    end
                else
                    AddVariant(profession, professionName, profession)
                end
            end
        end
    end

    for _, row in pairs(bestByProfession) do
        result[#result + 1] = row
    end

    table.sort(result, function(a, b)
        local ap = ExpansionPriority(a.expansion or a.displayName)
        local bp = ExpansionPriority(b.expansion or b.displayName)
        if ap ~= bp then return ap > bp end
        return tostring(a.name) < tostring(b.name)
    end)

    return result
end

function Professions:GetRoadmapStatus()
    local _, character = GetCurrentCharacterRecord()
    local scannedCount = 0
    local unfinishedCount = 0
    local hasProfession = false

    if type(character) ~= "table" then
        return "unscanned", 0, 0
    end

    local countedProfessionKeys = {}
    local function CountVariant(professionScan, variant)
        if type(variant) ~= "table" then return end
        local rank = tonumber(variant.rank)
        local maxRank = tonumber(variant.maxRank)
        if not rank or not maxRank or maxRank <= 0 then return end
        local parentID = tonumber(variant.parentSkillLineID) or tonumber(professionScan and professionScan.skillLineID)
        local key = tostring(parentID or strlower(CleanName(variant.name or variant.displayName)))
        local tierKey = key .. ":" .. tostring(variant.skillLineID or variant.displayName or "")
        if countedProfessionKeys[tierKey] then return end
        countedProfessionKeys[tierKey] = true
        scannedCount = scannedCount + 1
        if rank < maxRank then unfinishedCount = unfinishedCount + 1 end
    end

    if type(character.professionScans) == "table" then
        for _, professionScan in pairs(character.professionScans) do
            if type(professionScan) == "table" then
                hasProfession = true
                if type(professionScan.variants) == "table" then
                    for _, variant in pairs(professionScan.variants) do
                        CountVariant(professionScan, variant)
                    end
                end
            end
        end
    end

    if type(character.professions) == "table" then
        for _, profession in pairs(character.professions) do
            if type(profession) == "table" then
                hasProfession = true
                if type(profession.variants) == "table" then
                    for _, variant in pairs(profession.variants) do
                        CountVariant(profession, variant)
                    end
                else
                    CountVariant(profession, profession)
                end
            end
        end
    end

    if unfinishedCount > 0 then
        return "unfinished", scannedCount, unfinishedCount
    elseif scannedCount > 0 then
        return "maxed", scannedCount, 0
    elseif hasProfession then
        return "unavailable", 0, 0
    end

    return "unscanned", 0, 0
end

function Professions:Refresh()
    -- A profession scan updates saved profession data only. It must not repaint
    -- the entire GoldMint dashboard: Blizzard can emit several profession events
    -- while the crafting UI is settling, and a full dashboard rebuild is much
    -- more expensive than the data change itself.
    return self:ScanCurrentCharacter()
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("TRADE_SKILL_SHOW")
-- TRADE_SKILL_LIST_UPDATE can fire repeatedly while the modern profession UI is
-- rendering/crafting. The explicit profession-selection callbacks below are the
-- authoritative triggers for the account scan, so do not rescan the full recipe
-- book for every list update.
eventFrame:RegisterEvent("SKILL_LINES_CHANGED")

local lastAutomaticScanAt = 0
local lastAutomaticSkillLine = nil

local function ScheduleProfessionScan(delay)
    -- Collapse bursts of profession events into one scan. The generation guard
    -- cancels the older scheduled scan whenever a newer event arrives.
    GoldMint:ScheduleGuardedCallback(Professions, "profession-data-scan", delay or 0.12, function()
        if not (C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo) then return end
        local info = C_TradeSkillUI.GetBaseProfessionInfo()
        local skillLine = info and (info.professionID or info.skillLineID)
        local now = GetTime()
        -- One automatic scan per profession within the short settling window.
        -- This prevents repeated callbacks from walking hundreds/thousands of
        -- recipe IDs while the player is crafting.
        if skillLine and skillLine == lastAutomaticSkillLine and (now - lastAutomaticScanAt) < 30 then
            return
        end
        Professions:Refresh()
        lastAutomaticSkillLine = skillLine
        lastAutomaticScanAt = now
    end, function()
        return C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo ~= nil
    end)
end

eventFrame:SetScript("OnEvent", function(_, event)
    -- Profession data can arrive a frame after the Blizzard UI changes. Debounce
    -- all of the related events instead of starting multiple independent timers.
    ScheduleProfessionScan(event == "TRADE_SKILL_SHOW" and 0.15 or 0.10)
end)

-- The modern Blizzard Profession UI communicates profession/tab changes
-- through EventRegistry rather than only the legacy TRADE_SKILL_* events.
-- Hook these so changing Leatherworking/Skinning tabs causes an immediate
-- rescan of the expansion tier that is actually selected.
if UIParentLoadAddOn then
    pcall(UIParentLoadAddOn, "Blizzard_Professions")
end

if EventRegistry and EventRegistry.RegisterCallback then
    local callbackEvents = {
        "ProfessionsFrame.Show",
        "ProfessionsFrame.TabSet",
        "ProfessionsFrame.ProfessionSelected",
        "Professions.ProfessionSelected",
    }

    for _, callbackName in ipairs(callbackEvents) do
        pcall(EventRegistry.RegisterCallback, EventRegistry, callbackName, function()
            -- One debounced scan is enough. The old two-pass 0.12/0.35 second
            -- schedule could rescan the same profession twice for one UI change.
            ScheduleProfessionScan(0.18)
        end, eventFrame)
    end
end

Professions._eventFrame = eventFrame
