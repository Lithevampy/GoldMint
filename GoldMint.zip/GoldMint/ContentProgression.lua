local ADDON_NAME, GoldMint = ...

-- GoldMint content/progression capability backend.
--
-- This module records only positive evidence about a character's access to
-- content. It does not guess that a character has unlocked a hub simply
-- because the activity exists in the catalog.

GoldMint.ContentProgression = {}
local Progression = GoldMint.ContentProgression

local STORE_VERSION = 2
local CURRENT_EXPANSION = 11
local MIN_EXPANSION_ID = 0
local MAX_EXPANSION_ID = 11

local function EnsureStore()
    GoldMintDB.contentCapabilities = type(GoldMintDB.contentCapabilities) == "table" and GoldMintDB.contentCapabilities or {}
    local store = GoldMintDB.contentCapabilities
    store.version = math.max(tonumber(store.version) or 0, STORE_VERSION)
    store.characters = type(store.characters) == "table" and store.characters or {}
    return store
end

local function CharacterKey(key)
    return key or GoldMint.characterKey
end

local function GetCharacterRecord(key)
    key = CharacterKey(key)
    local store = EnsureStore()
    return store.characters[key]
end

local function GetExpansionIDFromQuestRecord(record)
    return record and tonumber(record.expansionID) or nil
end

local function RecordExpansionEvidence(character, expansionID)
    expansionID = tonumber(expansionID)
    if not expansionID or expansionID < 0 then
        return
    end
    character.observedExpansions = type(character.observedExpansions) == "table" and character.observedExpansions or {}
    character.observedExpansions[expansionID] = time()
end

function Progression:Initialize()
    if self._initialized then
        return
    end
    self._initialized = true
    EnsureStore()
    self:SyncCharacter()
end

function Progression:SyncCharacter()
    local key = CharacterKey()
    if not key then
        return nil
    end

    local store = EnsureStore()
    local character = store.characters[key] or {}
    local base = GoldMintDB.characters and GoldMintDB.characters[key] or nil

    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.level = tonumber((base and base.level) or UnitLevel("player") or 0) or 0
    character.currentExpansion = (GetExpansionLevel and tonumber(GetExpansionLevel())) or CURRENT_EXPANSION

    -- Record only direct, game-reported expansion landing-page unlocks.
    -- This is stronger evidence than simply seeing an expansion in the catalog,
    -- but it is intentionally not treated as proof that every activity in that
    -- expansion is available to the character.
    character.landingPages = type(character.landingPages) == "table" and character.landingPages or {}
    if C_PlayerInfo and C_PlayerInfo.IsExpansionLandingPageUnlockedForPlayer then
        for expansionID = MIN_EXPANSION_ID, MAX_EXPANSION_ID do
            local ok, unlocked = pcall(C_PlayerInfo.IsExpansionLandingPageUnlockedForPlayer, expansionID)
            if ok and unlocked == true then
                character.landingPages[expansionID] = time()
                character.observedExpansions = character.observedExpansions or {}
                character.observedExpansions[expansionID] = character.observedExpansions[expansionID] or time()
            end
        end
    end

    character.lastSync = time()
    character.observedExpansions = type(character.observedExpansions) == "table" and character.observedExpansions or {}

    -- A character who is currently playing in the live expansion provides
    -- positive evidence that the expansion exists in their current context.
    if character.currentExpansion then
        RecordExpansionEvidence(character, character.currentExpansion)
    end

    store.characters[key] = character
    return character
end

function Progression:ObserveQuestRecord(record, characterKey)
    characterKey = CharacterKey(characterKey)
    if not characterKey or not record then
        return
    end

    local store = EnsureStore()
    local character = store.characters[characterKey] or {}
    character.observedExpansions = type(character.observedExpansions) == "table" and character.observedExpansions or {}
    character.level = tonumber(character.level) or 0
    character.name = character.name or GoldMint.characterName
    character.realm = character.realm or GoldMint.characterRealm

    local expansionID = GetExpansionIDFromQuestRecord(record)
    if expansionID ~= nil then
        RecordExpansionEvidence(character, expansionID)
    end

    character.lastEvidence = time()
    store.characters[characterKey] = character
end

function Progression:ObserveAllRoutineRecords(characterKey)
    characterKey = CharacterKey(characterKey)
    local store = EnsureStore()
    local character = store.characters[characterKey] or {}
    character.observedExpansions = type(character.observedExpansions) == "table" and character.observedExpansions or {}

    if GoldMintDB.routines and GoldMintDB.routines.quests then
        for _, record in pairs(GoldMintDB.routines.quests) do
            local chars = record.characters
            if chars and chars[characterKey] then
                self:ObserveQuestRecord(record, characterKey)
            end
        end
    end
end

function Progression:GetCapability(characterKey)
    characterKey = CharacterKey(characterKey)
    local character = GetCharacterRecord(characterKey)
    if not character then
        return nil
    end

    return {
        level = tonumber(character.level) or 0,
        currentExpansion = tonumber(character.currentExpansion),
        observedExpansions = character.observedExpansions or {},
        access = character.access or {},
        landingPages = character.landingPages or {},
        lastSync = character.lastSync,
        lastEvidence = character.lastEvidence,
    }
end

function Progression:HasExpansionEvidence(expansionID, characterKey, capability)
    expansionID = tonumber(expansionID)
    if expansionID == nil then
        return false
    end

    capability = capability or self:GetCapability(characterKey)
    if not capability then
        return false
    end

    return capability.observedExpansions and capability.observedExpansions[expansionID] ~= nil
end

function Progression:IsActivityAccessible(activity, characterKey, capability)
    if not activity then
        return false
    end

    characterKey = CharacterKey(characterKey)
    capability = capability or self:GetCapability(characterKey)
    if not capability then
        return true
    end

    local level = tonumber(capability.level) or 0
    local minLevel = tonumber(activity.minLevel)
    if minLevel and level > 0 and level < minLevel then
        return false
    end

    local expansionID = tonumber(activity.expansionID)
    if not expansionID then
        return true
    end

    -- Current-expansion activities can be evaluated from the character's
    -- level/content context. Legacy activities require positive evidence before
    -- GoldMint claims that a character has reached that expansion.
    if expansionID == CURRENT_EXPANSION then
        return true
    end

    if self:HasExpansionEvidence(expansionID, characterKey, capability) then
        return true
    end

    -- Unobserved legacy catalog entries are not treated as unavailable here;
    -- their eventual quest evidence can resolve them. Returning nil preserves
    -- the distinction between "not observed" and "not applicable".
    return nil
end

function Progression:Refresh()
    self:SyncCharacter()
    self:ObserveAllRoutineRecords()
end
