local ADDON_NAME, GoldMint = ...

GoldMint.Accessibility = {}
local Accessibility = GoldMint.Accessibility

local STORE_VERSION = 1
local DEFAULT_STRETCH_INTERVAL = 3600
local DEFAULT_STRETCH_DURATION = 60
local MAX_MAIL_QUEUE = 100
local MAX_TAGS = 25
local MAX_NOTE_LENGTH = 500
local REMINDER_POLL = 1

local function Now()
    return time()
end

local function EnsureStore()
    GoldMintDB.accessibility = type(GoldMintDB.accessibility) == "table" and GoldMintDB.accessibility or {}
    local store = GoldMintDB.accessibility
    store.version = math.max(tonumber(store.version) or 0, STORE_VERSION)
    store.mail = type(store.mail) == "table" and store.mail or {}
    store.mail.enabled = store.mail.enabled == true
    store.mail.recipient = tostring(store.mail.recipient or "")
    store.mail.minQuality = tonumber(store.mail.minQuality) or 0
    store.mail.minValue = tonumber(store.mail.minValue) or 0
    store.mail.onlyUnbound = store.mail.onlyUnbound ~= false
    store.mail.excludeQuestItems = store.mail.excludeQuestItems ~= false
    store.mail.excludeCraftingReagents = store.mail.excludeCraftingReagents ~= false
    store.mail.queue = type(store.mail.queue) == "table" and store.mail.queue or {}
    store.mail.lastPreparedAt = tonumber(store.mail.lastPreparedAt) or 0
    store.mail.lastPreparedCount = tonumber(store.mail.lastPreparedCount) or 0
    store.mail.lastScannedCount = tonumber(store.mail.lastScannedCount) or 0
    store.stretch = type(store.stretch) == "table" and store.stretch or {}
    store.stretch.interval = tonumber(store.stretch.interval) or DEFAULT_STRETCH_INTERVAL
    store.stretch.duration = tonumber(store.stretch.duration) or DEFAULT_STRETCH_DURATION
    store.stretch.enabled = store.stretch.enabled ~= false
    store.stretch.active = store.stretch.active == true
    store.stretch.startedAt = tonumber(store.stretch.startedAt) or 0
    store.stretch.nextAt = tonumber(store.stretch.nextAt) or 0
    store.tags = type(store.tags) == "table" and store.tags or {}
    store.notes = type(store.notes) == "table" and store.notes or {}
    return store
end

function Accessibility:GetSettings()
    return EnsureStore()
end

-- ============================================================
-- Smart-Dump mail preparation
-- ============================================================
-- Midnight protects actual SendMail() calls. GoldMint therefore never silently
-- sends mail in the background. This backend prepares a persistent, filtered
-- queue that the future UI can present for one-click player-confirmed mailing.
local function IsQuestItem(bag, slot)
    if not C_Container or not C_Container.GetContainerItemQuestInfo then return false end
    local ok, info = pcall(C_Container.GetContainerItemQuestInfo, bag, slot)
    return ok and type(info) == "table" and info.isQuestItem == true
end

-- WuE items are not Auction House eligible. Their generic bindType can still
-- look like BindOnEquip, so use Blizzard tooltip binding data / item-location
-- state instead of treating them as ordinary BoE inventory.
local function IsWarboundUntilEquipped(bag, slot, itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end
    local function TooltipSaysWuE(data)
        if type(data) ~= "table" or type(data.lines) ~= "table" then return false end
        for _, line in ipairs(data.lines) do
            if type(line) == "table" then
                local bonding = tonumber(line.bonding)
                if bonding == 9 or bonding == 10 then return true end
            end
        end
        return false
    end
    if C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
        if ok and TooltipSaysWuE(data) then return true end
    end
    if ItemLocation and ItemLocation.CreateFromBagAndSlot and C_Item and C_Item.IsBoundToAccountUntilEquip then
        local okLoc, loc = pcall(ItemLocation.CreateFromBagAndSlot, bag, slot)
        if okLoc and loc then
            local ok, result = pcall(C_Item.IsBoundToAccountUntilEquip, loc)
            if ok and result == true then return true end
        end
    end
    if C_Item and C_Item.IsItemBindToAccountUntilEquip then
        local ok, result = pcall(C_Item.IsItemBindToAccountUntilEquip, itemID)
        if ok and result == true then return true end
    end
    return false
end

local function GetUnitValue(itemID)
    if GoldMint.Market and GoldMint.Market.GetUnitValue then
        local value, source = GoldMint.Market:GetUnitValue(itemID)
        return tonumber(value), source
    end
    return nil, nil
end

local function GetActiveGoalItem()
    if GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal then
        local goal = GoldMint.Milestones:GetActiveGoal()
        if type(goal) == "table" and tonumber(goal.itemID) then
            return tonumber(goal.itemID), tostring(goal.name or "Active goal")
        end
    end
    return nil, nil
end

local function ShouldQueue(info, settings)
    if not info or not info.itemID then return false, "empty" end
    if settings.onlyUnbound and info.isBound then return false, "bound" end
    if settings.excludeQuestItems and info.isQuestItem then return false, "quest" end
    if settings.excludeCraftingReagents and info.isCraftingReagent then return false, "crafting-reagent" end
    if (tonumber(info.quality) or 0) < (tonumber(settings.minQuality) or 0) then return false, "quality" end
    if (tonumber(settings.minValue) or 0) > 0 and (tonumber(info.unitValue) or 0) < settings.minValue then
        return false, "value"
    end
    return true
end

function Accessibility:PrepareSmartDump()
    local store = EnsureStore()
    local settings = store.mail
    local queue = {}
    local scanned, accepted = 0, 0

    -- BAG_UPDATE_DELAYED can rebuild the queue after an unrelated inventory
    -- change. Preserve player-confirmed decisions across that rebuild so a
    -- harmless bag update never silently resets SELL/BANK/KEEP choices.
    local previousDecisions = {}
    for _, previous in ipairs(settings.queue or {}) do
        local previousItemID = tonumber(previous.itemID)
        local previousDecision = tostring(previous.decision or ""):upper()
        if previousItemID and previousDecision ~= "" then
            previousDecisions[previousItemID] = previousDecision
        end
    end

    if not C_Container then return queue, scanned, accepted end

    for bag = 0, 5 do
        local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, bag)
        local slots = okSlots and (tonumber(rawSlots) or 0) or 0
        for slot = 1, slots do
            local okInfo, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
            if not okInfo then info = nil end
            if info and info.itemID then
                scanned = scanned + 1
                local itemID = tonumber(info.itemID)
                local value, source = GetUnitValue(itemID)
                local quest = IsQuestItem(bag, slot)
                local record = {
                    bag = bag,
                    slot = slot,
                    itemID = itemID,
                    itemLink = info.hyperlink,
                    itemName = info.itemName,
                    quantity = tonumber(info.stackCount) or 1,
                    quality = tonumber(info.quality) or 0,
                    isBound = info.isBound == true or IsWarboundUntilEquipped(bag, slot, itemID),
                    isQuestItem = quest,
                    isCraftingReagent = false,
                    unitValue = value,
                    totalValue = value and value * (tonumber(info.stackCount) or 1) or nil,
                    valueSource = source,
                    preparedAt = Now(),
                    character = GoldMint.characterKey,
                }

                if C_Item and C_Item.GetItemInfo then
                    local result = { pcall(C_Item.GetItemInfo, itemID) }
                    local ok = table.remove(result, 1)
                    if ok then record.isCraftingReagent = result[17] == true end
                end

                local good = ShouldQueue(record, settings)
                if good then
                    local tags = self:GetItemTags(itemID) or {}
                    local tagMap = {}
                    for _, tag in ipairs(tags) do tagMap[tag] = true end

                    -- Personal rules take precedence over GoldMint's generic suggestion
                    -- rules. They are suggestions only; the player still confirms actions.
                    local destination = "LATER"
                    local personalRule = nil
                    local goalProtected = false
                    local goalName = nil
                    if tagMap.doNotSell then
                        destination, personalRule = "BANK", "DO NOT SELL"
                    elseif tagMap.goal then
                        destination, personalRule = "KEEP", "GOAL"
                    elseif tagMap.keep then
                        destination, personalRule = "KEEP", "KEEP"
                    elseif tagMap.bank then
                        destination, personalRule = "BANK", "BANK"
                    elseif tagMap.craft then
                        destination, personalRule = "CRAFT", "CRAFT"
                    elseif tagMap.sell then
                        destination, personalRule = "SELL", "SELL"
                    else
                        local activeGoalItemID, activeGoalName = GetActiveGoalItem()
                        if activeGoalItemID and tonumber(activeGoalItemID) == itemID then
                            -- An active goal outranks generic sell/vendor/crafting suggestions.
                            -- Explicit personal rules above remain higher priority.
                            destination = "KEEP"
                            personalRule = "ACTIVE GOAL"
                            goalProtected = true
                            goalName = activeGoalName
                        elseif record.isCraftingReagent then
                            destination = "CRAFT"
                        elseif (tonumber(record.unitValue) or 0) >= math.max(tonumber(settings.minValue) or 0, 10000) then
                            destination = "SELL"
                        elseif (tonumber(record.quality) or 0) == 0 then
                            destination = "VENDOR"
                        end
                    end
                    -- A player-confirmed decision outranks the freshly
                    -- generated suggestion. Keep it when the queue is rebuilt
                    -- after BAG_UPDATE_DELAYED or another inventory refresh.
                    local previousDecision = previousDecisions[itemID]
                    if previousDecision == "KEEP" or previousDecision == "BANK"
                        or previousDecision == "SELL" or previousDecision == "CRAFT"
                        or previousDecision == "VENDOR" or previousDecision == "LATER"
                        or previousDecision == "IGNORE" then
                        destination = previousDecision
                        record.decision = previousDecision
                        record.decisionAt = record.decisionAt or Now()
                    end
                    record.destination = destination
                    record.personalRule = personalRule
                    record.goalProtected = goalProtected
                    record.goalName = goalName
                    record.personalNote = self:GetItemNote(itemID)
                    accepted = accepted + 1
                    queue[#queue + 1] = record
                end
            end
        end
    end

    -- Keep goal-protected items at the front so they are not lost when the
    -- persistent queue reaches its maximum size. Explicit personal rules are
    -- next; ordinary valuation suggestions remain lowest priority.
    table.sort(queue, function(a, b)
        local ap = a.goalProtected and 0 or (a.personalRule and 1 or 2)
        local bp = b.goalProtected and 0 or (b.personalRule and 1 or 2)
        if ap ~= bp then return ap < bp end
        local av = tonumber(a.totalValue) or 0
        local bv = tonumber(b.totalValue) or 0
        if av ~= bv then return av > bv end
        return tostring(a.itemName or a.itemLink or "") < tostring(b.itemName or b.itemLink or "")
    end)

    while #queue > MAX_MAIL_QUEUE do
        table.remove(queue, #queue)
    end

    store.mail.queue = queue
    store.mail.lastPreparedAt = Now()
    store.mail.lastPreparedCount = accepted
    store.mail.lastScannedCount = scanned
    return queue, scanned, accepted
end

function Accessibility:GetSmartDumpQueue()
    return EnsureStore().mail.queue
end

function Accessibility:ClearSmartDumpQueue()
    -- Invalidate any already-scheduled bag refresh. Without this generation
    -- guard, a delayed BAG_UPDATE_DELAYED callback could repopulate a queue
    -- immediately after the player explicitly cleared it.
    self._smartDumpGeneration = (tonumber(self._smartDumpGeneration) or 0) + 1
    EnsureStore().mail.queue = {}
end

function Accessibility:RemoveSmartDumpEntry(index)
    local queue = EnsureStore().mail.queue
    index = tonumber(index)
    if not index or not queue[index] then return false end
    table.remove(queue, index)
    return true
end

function Accessibility:SetSmartDumpDestination(index, destination)
    local queue = EnsureStore().mail.queue
    index = tonumber(index)
    destination = tostring(destination or "LATER"):upper()
    local allowed = { KEEP=true, BANK=true, SELL=true, CRAFT=true, VENDOR=true, LATER=true, IGNORE=true }
    if not index or not queue[index] or not allowed[destination] then return false end
    queue[index].destination = destination
    queue[index].decision = destination
    queue[index].decisionAt = Now()
    return true
end

function Accessibility:GetSmartDumpDecisionEntries(decision)
    local queue = EnsureStore().mail.queue
    decision = tostring(decision or ""):upper()
    local result = {}
    for index, entry in ipairs(queue) do
        if tostring(entry.destination or "LATER"):upper() == decision then
            result[#result + 1] = { index = index, entry = entry }
        end
    end
    return result
end

function Accessibility:PrepareSmartDumpDecision(decision)
    decision = tostring(decision or ""):upper()
    local allowed = { KEEP=true, BANK=true, SELL=true, CRAFT=true, VENDOR=true, LATER=true, IGNORE=true }
    if not allowed[decision] then return false, 0, 0 end

    local entries = self:GetSmartDumpDecisionEntries(decision)
    local totalValue = 0
    for _, wrapped in ipairs(entries) do
        totalValue = totalValue + (tonumber(wrapped.entry.totalValue) or 0)
    end

    local titles = {
        KEEP = "Keep Smart-Dump items",
        BANK = "Move Smart-Dump items to the bank",
        SELL = "Prepare Smart-Dump items for sale",
        CRAFT = "Use Smart-Dump crafting materials",
        VENDOR = "Vendor Smart-Dump items",
        LATER = "Review Smart-Dump items later",
        IGNORE = "Ignore Smart-Dump items",
    }
    local details = {
        KEEP = "GoldMint has marked these items to keep. No item movement is performed automatically.",
        BANK = "These items are marked for banking. Open your bank and move them manually; GoldMint does not automate protected item movement.",
        SELL = "These items are marked for sale. Review their current value and post them manually at the Auction House.",
        CRAFT = "These items are marked for crafting. Open your crafting workflow and use them when appropriate.",
        VENDOR = "These items are marked for vendor sale. Confirm the item list before selling anything.",
        LATER = "These items are intentionally deferred. GoldMint will keep the decision in the queue.",
        IGNORE = "These items are intentionally ignored. GoldMint will not create another action for them.",
    }

    if GoldMint.WorkflowState and #entries > 0 then
        GoldMint.WorkflowState:SetSystemNextAction(
            string.format("%s (%d item(s))", titles[decision], #entries),
            "smart-dump-" .. decision:lower(),
            string.format("%s Estimated queued value: %s.", details[decision], GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(totalValue) or tostring(totalValue)),
            "smart-dump"
        )
    end

    return true, #entries, totalValue
end

function Accessibility:CompleteSmartDumpDecision(decision, note)
    decision = tostring(decision or ""):upper()
    local allowed = { KEEP=true, BANK=true, SELL=true, CRAFT=true, VENDOR=true, LATER=true, IGNORE=true }
    if not allowed[decision] then return false, 0, nil end

    local store = EnsureStore()
    local queue = store.mail.queue
    local remaining = {}
    local completed = 0
    for _, entry in ipairs(queue) do
        local destination = tostring(entry.destination or "LATER"):upper()
        if destination == decision then
            completed = completed + 1
            entry.completedAt = Now()
            entry.completionNote = note and tostring(note) or "completed"
        else
            remaining[#remaining + 1] = entry
        end
    end
    if completed == 0 then return false, 0, nil end

    store.mail.queue = remaining
    local summary = self:GetSmartDumpDecisionSummary()
    local priority = { BANK="BANK", SELL="SELL", CRAFT="CRAFT", VENDOR="VENDOR", KEEP="KEEP", LATER="LATER", IGNORE="IGNORE" }
    local nextDecision
    for _, candidate in ipairs({"BANK", "SELL", "CRAFT", "VENDOR", "KEEP", "LATER", "IGNORE"}) do
        if (summary[candidate] or 0) > 0 then
            nextDecision = candidate
            break
        end
    end

    if GoldMint.WorkflowState then
        if nextDecision then
            self:PrepareSmartDumpDecision(nextDecision)
        else
            GoldMint.WorkflowState:ClearNextAction()
        end
    end

    return true, completed, nextDecision
end

function Accessibility:CompleteSmartDumpCurrentAction(note)
    local workflow = GoldMint.WorkflowState
    if not workflow or not workflow.GetNextAction then return false, 0, nil end
    local action = workflow:GetNextAction()
    local taskID = action and tostring(action.taskID or action.id or "") or ""
    local decision = taskID:match("^smart%-dump%-(%a+)$")
    if not decision then return false, 0, nil end
    return self:CompleteSmartDumpDecision(decision, note or "player-confirmed")
end

function Accessibility:GetSmartDumpCompletionStatus()
    local summary = self:GetSmartDumpDecisionSummary()
    local pending = (summary.BANK or 0) + (summary.SELL or 0) + (summary.CRAFT or 0) + (summary.VENDOR or 0) + (summary.KEEP or 0) + (summary.LATER or 0) + (summary.IGNORE or 0)
    return { pending = pending, summary = summary }
end

function Accessibility:GetSmartDumpDecisionSummary()
    local queue = EnsureStore().mail.queue
    local summary = { KEEP=0, BANK=0, SELL=0, CRAFT=0, VENDOR=0, LATER=0, IGNORE=0, count=#queue }
    for _, entry in ipairs(queue) do
        local destination = tostring(entry.destination or "LATER"):upper()
        if summary[destination] ~= nil then summary[destination] = summary[destination] + 1
        else summary.LATER = summary.LATER + 1 end
    end
    return summary
end

function Accessibility:SetMailSetting(name, value)
    local settings = EnsureStore().mail
    local allowed = {
        enabled = true,
        recipient = true,
        minQuality = true,
        minValue = true,
        onlyUnbound = true,
        excludeQuestItems = true,
        excludeCraftingReagents = true,
    }
    if not allowed[name] then return false end
    settings[name] = value
    return true
end

function Accessibility:GetMailSettings()
    return EnsureStore().mail
end

function Accessibility:SetSmartDumpEnabled(enabled)
    local settings = EnsureStore().mail
    settings.enabled = enabled == true
    if settings.enabled then
        self:PrepareSmartDump()
    else
        self._smartDumpGeneration = (tonumber(self._smartDumpGeneration) or 0) + 1
        settings.queue = {}
    end
    return settings.enabled
end

function Accessibility:GetSmartDumpSummary()
    local settings = EnsureStore().mail
    local totalValue = 0
    for _, entry in ipairs(settings.queue) do
        totalValue = totalValue + (tonumber(entry.totalValue) or 0)
    end
    return {
        enabled = settings.enabled == true,
        recipient = settings.recipient,
        count = #settings.queue,
        totalValue = totalValue,
        lastPreparedAt = settings.lastPreparedAt,
        lastPreparedCount = settings.lastPreparedCount,
        lastScannedCount = settings.lastScannedCount,
    }
end

-- ============================================================
-- Breathe & Stretch timer
-- ============================================================
function Accessibility:SetStretchEnabled(enabled)
    local store = EnsureStore()
    store.stretch.enabled = enabled == true
    if not store.stretch.enabled then
        store.stretch.active = false
        store.stretch.startedAt = 0
        store.stretch.nextAt = 0
    end
    return self:GetStretchStatus()
end

function Accessibility:StartStretchTimer()
    local store = EnsureStore()
    if store.stretch.enabled ~= true then return self:GetStretchStatus() end
    local now = Now()
    store.stretch.startedAt = now
    store.stretch.nextAt = now + math.max(60, tonumber(store.stretch.interval) or DEFAULT_STRETCH_INTERVAL)
    store.stretch.active = true
    return self:GetStretchStatus()
end

function Accessibility:StopStretchTimer()
    local store = EnsureStore()
    store.stretch.active = false
    store.stretch.startedAt = 0
    store.stretch.nextAt = 0
    return self:GetStretchStatus()
end

function Accessibility:SetStretchSettings(interval, duration)
    local store = EnsureStore()
    interval = tonumber(interval)
    duration = tonumber(duration)
    if interval and interval >= 60 then store.stretch.interval = math.floor(interval) end
    if duration and duration >= 5 then store.stretch.duration = math.floor(duration) end
    if store.stretch.active then
        store.stretch.nextAt = Now() + store.stretch.interval
    end
    return self:GetStretchStatus()
end

function Accessibility:GetStretchStatus()
    local stretch = EnsureStore().stretch
    local now = Now()
    local remaining = math.max((tonumber(stretch.nextAt) or 0) - now, 0)
    return {
        enabled = stretch.enabled == true,
        active = stretch.active == true,
        interval = tonumber(stretch.interval) or DEFAULT_STRETCH_INTERVAL,
        duration = tonumber(stretch.duration) or DEFAULT_STRETCH_DURATION,
        startedAt = tonumber(stretch.startedAt) or 0,
        nextAt = tonumber(stretch.nextAt) or 0,
        remaining = remaining,
        due = stretch.active == true and stretch.enabled == true and remaining <= 0,
        lastReminderAt = tonumber(stretch.lastReminderAt) or 0,
    }
end

function Accessibility:ConsumeStretchReminder()
    local store = EnsureStore()
    if not store.stretch.active or store.stretch.enabled ~= true then return false end
    local now = Now()
    if now < (tonumber(store.stretch.nextAt) or 0) then return false end
    store.stretch.nextAt = now + math.max(60, tonumber(store.stretch.interval) or DEFAULT_STRETCH_INTERVAL)
    store.stretch.lastReminderAt = now
    return true, tonumber(store.stretch.duration) or DEFAULT_STRETCH_DURATION
end

-- ============================================================
-- Personal visual tags and notes
-- ============================================================
function Accessibility:SetItemTag(itemID, tag, enabled)
    local store = EnsureStore()
    itemID = tonumber(itemID)
    tag = tostring(tag or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if not itemID or tag == "" then return false end
    store.tags[itemID] = type(store.tags[itemID]) == "table" and store.tags[itemID] or {}
    if enabled == false then
        store.tags[itemID][tag] = nil
    else
        if not store.tags[itemID][tag] and #store.tags[itemID] >= MAX_TAGS then return false end
        store.tags[itemID][tag] = true
    end
    if next(store.tags[itemID]) == nil then store.tags[itemID] = nil end
    return true
end

function Accessibility:GetItemTags(itemID)
    local tags = EnsureStore().tags[tonumber(itemID)] or {}
    local result = {}
    for tag in pairs(tags) do result[#result + 1] = tag end
    table.sort(result)
    return result
end

function Accessibility:SetItemNote(itemID, note)
    local store = EnsureStore()
    itemID = tonumber(itemID)
    if not itemID then return false end
    note = tostring(note or "")
    if #note > MAX_NOTE_LENGTH then note = note:sub(1, MAX_NOTE_LENGTH) end
    if note == "" then store.notes[itemID] = nil else store.notes[itemID] = note end
    return true
end

function Accessibility:GetItemNote(itemID)
    return EnsureStore().notes[tonumber(itemID)]
end

function Accessibility:GetPersonalization(itemID)
    return {
        tags = self:GetItemTags(itemID),
        note = self:GetItemNote(itemID),
    }
end

function Accessibility:GetGoalFocusSummary()
    local result = {
        taggedItems = {},
        activeGoal = nil,
        aligned = false,
        hasFocus = false,
        suggestedAction = nil,
    }

    local store = EnsureStore()
    for itemID, tags in pairs(store.tags or {}) do
        if type(tags) == "table" and (tags.goal == true or tags.GOAL == true) then
            itemID = tonumber(itemID)
            if itemID then
                local itemName
                if C_Item and C_Item.GetItemNameByID then
                    local okName, value = pcall(C_Item.GetItemNameByID, itemID)
                    if okName then itemName = value end
                end
                result.taggedItems[#result.taggedItems + 1] = {
                    itemID = itemID,
                    itemName = itemName or ("Item " .. tostring(itemID)),
                    note = self:GetItemNote(itemID),
                }
            end
        end
    end
    table.sort(result.taggedItems, function(a, b)
        return tostring(a.itemName) < tostring(b.itemName)
    end)

    result.hasFocus = #result.taggedItems > 0
    if GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal then
        result.activeGoal = GoldMint.Milestones:GetActiveGoal()
    end

    if result.activeGoal and result.activeGoal.itemID then
        for _, item in ipairs(result.taggedItems) do
            if tonumber(item.itemID) == tonumber(result.activeGoal.itemID) then
                result.aligned = true
                break
            end
        end
    end

    local focus = result.taggedItems[1]
    if focus then
        if result.activeGoal and result.aligned then
            result.suggestedAction = "Continue toward " .. tostring(result.activeGoal.name or "your goal") .. " — " .. tostring(focus.itemName)
        elseif result.activeGoal then
            result.suggestedAction = "Review goal focus — " .. tostring(focus.itemName)
        else
            result.suggestedAction = "Set a goal for " .. tostring(focus.itemName)
        end
    elseif result.activeGoal then
        result.suggestedAction = "Continue toward " .. tostring(result.activeGoal.name or "your goal")
    end

    return result
end

function Accessibility:SyncGoalFocusWorkflow()
    local focus = self:GetGoalFocusSummary()
    if not focus.suggestedAction or not GoldMint.WorkflowState then return false end

    local current = GoldMint.WorkflowState.GetNextAction and GoldMint.WorkflowState:GetNextAction() or nil
    local currentSource = current and tostring(current.source or "") or ""
    -- Never overwrite a player-authored next action. Goal focus is a gentle
    -- fallback that keeps the larger workflow aware of personal goal tags.
    if current and currentSource ~= "goal-focus" and currentSource ~= "system" then
        return false
    end

    local details
    if focus.activeGoal and focus.aligned then
        details = "Your personal GOAL tag is aligned with the active project. Keep this item in your goal workflow; GoldMint will not move or sell it automatically."
    elseif focus.activeGoal then
        details = "A personal GOAL tag is pointing at a different item than the active project. Review the goal before changing anything."
    else
        details = "A personal GOAL tag identifies the item you care about. Create or edit a GoldMint goal if you want progress tracking and checkpoints."
    end

    GoldMint.WorkflowState:SetSystemNextAction(
        focus.suggestedAction,
        "goal-focus",
        details,
        "goal-focus"
    )
    return true
end

function Accessibility:GetSmartDumpPersonalRule(itemID)
    local tags = self:GetItemTags(itemID) or {}
    local map = {}
    for _, tag in ipairs(tags) do map[tag] = true end
    if map.doNotSell then return "BANK", "DO NOT SELL" end
    if map.goal then return "KEEP", "GOAL" end
    if map.keep then return "KEEP", "KEEP" end
    if map.bank then return "BANK", "BANK" end
    if map.craft then return "CRAFT", "CRAFT" end
    if map.sell then return "SELL", "SELL" end
    return nil, nil
end

function Accessibility:GetGoalProgressRecommendation()
    local result = {
        hasGoal = false,
        action = "NO GOAL",
        title = "No active goal",
        details = "Create an active goal to let GoldMint turn your progress into one clear recommendation.",
        reason = "no-goal",
        remaining = 0,
        current = 0,
        target = 0,
        progress = 0,
        sellValue = 0,
        sessionRate = 0,
        etaHours = nil,
    }

    local milestone = GoldMint.Milestones
    local goal = milestone and milestone.GetActiveGoal and milestone:GetActiveGoal() or nil
    if not goal then return result end

    result.hasGoal = true
    result.goal = goal
    result.current = tonumber(goal.currentValue) or 0
    result.target = tonumber(goal.target) or 0
    result.remaining = math.max(tonumber(goal.remaining) or (result.target - result.current), 0)
    result.progress = tonumber(goal.progress) or 0

    local queue = self:GetSmartDumpQueue() or {}
    for _, entry in ipairs(queue) do
        local destination = tostring(entry.destination or "LATER"):upper()
        if destination == "SELL" then
            result.sellValue = result.sellValue + (tonumber(entry.totalValue) or 0)
        end
    end

    if GoldMint.Ledger and GoldMint.Ledger.GetSessionSourceRate then
        result.sessionRate = tonumber(GoldMint.Ledger:GetSessionSourceRate("total")) or 0
    end
    if result.sessionRate <= 0 and GoldMint.Ledger and GoldMint.Ledger.GetSession then
        local session = GoldMint.Ledger:GetSession()
        if session then
            local elapsed = math.max(time() - (tonumber(session.startedAtWall or session.startedAt) or time()), 1)
            local gained = tonumber(session.income) or tonumber(session.net) or 0
            if gained > 0 then result.sessionRate = gained / (elapsed / 3600) end
        end
    end

    -- Item goals are counted directly from the account. This keeps the
    -- recommendation useful even when the goal is a mount/material/item
    -- target rather than a gold target.
    if tostring(goal.type or "gold") == "item" and goal.itemID and C_Item and C_Item.GetItemCount then
        local okCount, rawCount = pcall(C_Item.GetItemCount, goal.itemID, true, true, true, true)
        local count = okCount and (tonumber(rawCount) or 0) or 0
        result.current = count
        result.target = tonumber(goal.target) or 0
        result.remaining = math.max(result.target - count, 0)
        result.progress = result.target > 0 and math.min(1, count / result.target) or 0
        if result.remaining <= 0 then
            result.action = "KEEP / COMPLETE"
            result.title = "Goal item target reached"
            result.details = string.format("You have %d of %d required. Review the goal and mark it complete when you are ready.", count, result.target)
            result.reason = "item-complete"
        else
            result.action = "FARM / CRAFT"
            result.title = string.format("Collect %d more", result.remaining)
            result.details = string.format("You have %d of %d. Focus on obtaining the remaining goal items; GoldMint will protect the goal item from generic sell/vendor suggestions.", count, result.target)
            result.reason = "item-progress"
        end
        return result
    end

    if result.remaining <= 0 then
        result.action = "COMPLETE GOAL"
        result.title = "Goal target reached"
        result.details = "Your current progress has reached the target. Review the goal and mark it complete when you are ready."
        result.reason = "complete"
        return result
    end

    if result.sellValue > 0 and result.sellValue >= result.remaining then
        result.action = "SELL QUEUED"
        result.title = "Sell the prepared items"
        result.details = string.format("Your Smart-Dump SELL queue is worth about %s, enough to cover the remaining %s on this goal.",
            GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(result.sellValue) or tostring(result.sellValue),
            GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(result.remaining) or tostring(result.remaining))
        result.reason = "sell-covers-goal"
        return result
    end

    local weekly = goal.weekly or {}
    if weekly.status == "behind" then
        result.action = "INCREASE PACE"
        result.title = "Increase goal pace"
        result.details = "GoldMint's seven-day pace is behind the goal schedule. Prioritize a reliable gold-making activity before lower-priority tasks."
        result.reason = "behind"
    elseif weekly.status == "ahead" then
        result.action = "MAINTAIN PACE"
        result.title = "Maintain your current pace"
        result.details = "You are ahead of the measured goal pace. Keep the next action small and avoid unnecessary extra farming."
        result.reason = "ahead"
    elseif result.sessionRate > 0 then
        result.etaHours = result.remaining / result.sessionRate
        result.action = "KEEP EARNING"
        result.title = string.format("Keep earning • ~%s", string.format("%.1fh", result.etaHours))
        result.details = string.format("At the current session rate, the remaining %s is roughly %.1f hours of earning.",
            GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(result.remaining) or tostring(result.remaining), result.etaHours)
        result.reason = "session-pace"
    else
        result.action = "CHOOSE METHOD"
        result.title = "Choose one gold-making method"
        result.details = string.format("You still need about %s. Pick one reliable farming, crafting, or selling activity and let GoldMint track the result.",
            GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(result.remaining) or tostring(result.remaining))
        result.reason = "no-rate"
    end

    return result
end

function Accessibility:GetGoalMethodRecommendations(goalRecommendation)
    local rec = goalRecommendation or self:GetGoalProgressRecommendation()
    local result = {
        goal = rec.goal,
        methods = {},
        best = nil,
    }
    if not rec.hasGoal or (tonumber(rec.remaining) or 0) <= 0 then
        return result
    end

    local function Add(method, title, details, score, source)
        result.methods[#result.methods + 1] = {
            method = method,
            title = title,
            details = details,
            score = tonumber(score) or 0,
            source = source,
        }
    end

    -- A prepared SELL queue is the most concrete short-term method because
    -- the player has already identified the inventory and only needs to act.
    if (tonumber(rec.sellValue) or 0) > 0 then
        local coverage = (tonumber(rec.remaining) or 0) > 0 and (tonumber(rec.sellValue) or 0) / rec.remaining or 0
        Add("SELL", "Sell prepared items", string.format("Prepared SELL value is about %s (%.0f%% of the remaining goal).", GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(rec.sellValue) or tostring(rec.sellValue), math.min(coverage * 100, 999)), 100 + math.min(coverage * 50, 50), "smart-dump")
    end

    -- Prefer a known profitable craft. For item goals, prefer recipes whose
    -- output is the actual target item.
    local targetItemID = rec.goal and tonumber(rec.goal.itemID)
    local recipes = GoldMintDB and GoldMintDB.recipes
    local bestCraft
    if type(recipes) == "table" then
        for recipeID, record in pairs(recipes) do
            local profit = record and record.profit
            profit = type(profit) == "table" and tonumber(profit.profit) or tonumber(profit)
            local outputID = tonumber(record and record.outputItemID)
            if profit and profit > 0 and (not targetItemID or outputID == targetItemID) then
                if not bestCraft or profit > bestCraft.profit then
                    bestCraft = { record = record, recipeID = tonumber(recipeID), profit = profit, targetMatch = targetItemID and outputID == targetItemID }
                end
            end
        end
    end
    if bestCraft then
        local r = bestCraft.record
        local title = bestCraft.targetMatch and "Craft the goal item" or ("Craft " .. tostring(r.name or "your best recipe"))
        local details = string.format("Best tracked profitable craft: %s • about %s profit per craft.", tostring(r.name or "Unknown recipe"), GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(bestCraft.profit) or tostring(bestCraft.profit))
        local method = {
            recipeID = bestCraft.recipeID,
            targetMatch = bestCraft.targetMatch,
        }
        Add("CRAFT", title, details, bestCraft.targetMatch and 145 or 85, "crafting")
        result.methods[#result.methods].recipeID = method.recipeID
        result.methods[#result.methods].targetMatch = method.targetMatch
    end

    -- A previous farm session is useful as a real measured baseline. We do
    -- not invent a farm route; we only recommend continuing a method that
    -- GoldMint has actually tracked.
    local farmDB = GoldMintDB and GoldMintDB.farmTracker
    local lastFarm = farmDB and farmDB.lastSession
    if type(lastFarm) == "table" then
        local elapsed = tonumber(lastFarm.startedAt) and tonumber(lastFarm.endedAt) and (tonumber(lastFarm.endedAt) - tonumber(lastFarm.startedAt)) or 0
        if elapsed <= 0 then elapsed = tonumber(lastFarm.duration) or 0 end
        local net = (tonumber(lastFarm.rawGold) or 0) + (tonumber(lastFarm.lootValue) or 0) - (tonumber(lastFarm.expenses) or 0)
        local rate = elapsed > 0 and net / (elapsed / 3600) or 0
        if rate > 0 then
            Add("FARM", "Repeat your measured farm", string.format("Your last tracked farm averaged about %s/hour. GoldMint will track the next session so the estimate can improve.", GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(rate) or tostring(rate)), 75, "farm-tracker")
            result.methods[#result.methods].rate = rate
            result.methods[#result.methods].session = lastFarm
        end
    end

    table.sort(result.methods, function(a, b)
        if a.score ~= b.score then return a.score > b.score end
        return tostring(a.title) < tostring(b.title)
    end)
    result.best = result.methods[1]
    return result
end

function Accessibility:SetGoalMethodNextAction(method)
    method = type(method) == "table" and method or nil
    if not method then return false end
    local goal = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil
    if not goal then return false end
    local kind = tostring(method.method or ""):upper()
    local allowed = { SELL=true, CRAFT=true, FARM=true }
    if not allowed[kind] then return false end

    local title = tostring(method.title or kind)
    local details = tostring(method.details or "")
    if kind == "CRAFT" and method.recipeID then
        details = details .. " Recipe ID: " .. tostring(method.recipeID) .. "."
    elseif kind == "FARM" and method.rate then
        details = details .. " Measured rate: " .. tostring(math.floor(tonumber(method.rate) or 0)) .. " gold/hour."
    end
    details = details .. " When you finish this player-confirmed step, use COMPLETE / CLEAR and GoldMint will reassess the goal."

    if GoldMint.WorkflowState and GoldMint.WorkflowState.SetSystemNextAction then
        return GoldMint.WorkflowState:SetSystemNextAction(
            title,
            "goal-method-" .. kind:lower(),
            details,
            "goal-method"
        ) ~= false
    end
    return false
end

function Accessibility:CompleteGoalMethodCurrentAction(note)
    local workflow = GoldMint.WorkflowState
    if not workflow or not workflow.GetNextAction then return false, nil end
    local action = workflow:GetNextAction()
    local taskID = action and tostring(action.taskID or action.id or "") or ""
    local kind = taskID:match("^goal%-method%-(%a+)$")
    if not kind then return false, nil end

    workflow:ClearNextAction()
    local rec = self:GetGoalProgressRecommendation()
    if not rec.hasGoal or (tonumber(rec.remaining) or 0) <= 0 then
        return true, "complete"
    end

    local strategy = self:GetGoalMethodRecommendations(rec)
    local best = strategy and strategy.best
    if best then
        self:SetGoalMethodNextAction(best)
        return true, tostring(best.method or "next")
    end

    -- No measured method is available yet. Preserve a simple reassessment
    -- action rather than leaving a stale completed goal-method task behind.
    if workflow.SetSystemNextAction then
        workflow:SetSystemNextAction(
            rec.title or rec.action or "Reassess goal",
            "goal-strategy",
            rec.details or "Choose a new method for the active goal.",
            "goal-strategy"
        )
    end
    return true, "reassess"
end

function Accessibility:ConsumePendingStretchReminder()
    if not self._stretchReminderPending then return false end
    self._stretchReminderPending = false
    return true, tonumber(EnsureStore().stretch.duration) or DEFAULT_STRETCH_DURATION
end

function Accessibility:GetGoalWorkflowSummary()
    local result = {
        hasGoal = false,
        goal = nil,
        progress = 0,
        method = nil,
        nextAction = nil,
        status = "NO ACTIVE GOAL",
    }

    local milestones = GoldMint.Milestones
    local goal = milestones and milestones.GetActiveGoal and milestones:GetActiveGoal() or nil
    if goal then
        result.hasGoal = true
        result.goal = goal
        local rec = self:GetGoalProgressRecommendation()
        result.progress = tonumber(rec and rec.progress) or 0
        result.status = tostring(rec and (rec.action or rec.title) or "GOAL ACTIVE")

        local strategy = self:GetGoalMethodRecommendations(rec)
        local best = strategy and strategy.best
        if best then
            result.method = best
        end
    end

    local workflow = GoldMint.WorkflowState
    if workflow and workflow.GetNextAction then
        result.nextAction = workflow:GetNextAction()
    end

    return result
end

function Accessibility:GetSummary()
    return {
        smartDump = self:GetSmartDumpSummary(),
        stretch = self:GetStretchStatus(),
        goalFocus = self:GetGoalFocusSummary(),
    }
end

function Accessibility:Initialize()
    if self._initialized then return end
    self._initialized = true
    EnsureStore()

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("BAG_UPDATE_DELAYED")
    frame:RegisterEvent("MAIL_INBOX_UPDATE")
    frame:RegisterEvent("MAIL_SHOW")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")

    -- Reminder state is independent of frame rendering; use a timer rather
    -- than an always-running frame OnUpdate loop.
    local function PollStretchReminder()
        local store = EnsureStore()
        if store.stretch.enabled == true and store.stretch.active == true and self:ConsumeStretchReminder() then
            self._stretchReminderPending = true
            if GoldMint.Sounds and GoldMint.Sounds.Play then
                GoldMint.Sounds:Play("stretch")
            end
            if GoldMint.Alerts and GoldMint.Alerts.Push then
                GoldMint.Alerts:Push("BREATHE, STRETCH & HYDRATE", "Breathe, Stretch and Hydrate.", { sound = false,
                    id = "breathe-stretch", dedupeKey = "breathe-stretch", priority = 85, category = "accessibility", ttl = tonumber(store.stretch.duration) or DEFAULT_STRETCH_DURATION,
                })
            end
        end
    end

    self._reminderTicker = C_Timer.NewTicker(REMINDER_POLL, PollStretchReminder)

    frame:SetScript("OnEvent", function(_, event)
        if event == "BAG_UPDATE_DELAYED" then
            -- Smart-Dump preparation can be expensive. Never run it while a
            -- merchant is opening/visible; Core performs the post-close refresh.
            if GoldMint._merchantOpen or (MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown()) then
                return
            end
            local store = EnsureStore()
            if store.mail.enabled and not self._smartDumpPending then
                self._smartDumpPending = true
                self._smartDumpGeneration = tonumber(self._smartDumpGeneration) or 0
                local generation = self._smartDumpGeneration
                C_Timer.After(0.60, function()
                    self._smartDumpPending = false
                    if self._initialized and generation == (tonumber(self._smartDumpGeneration) or 0)
                        and not GoldMint:IsMerchantOpen() then
                        local current = EnsureStore()
                        if current.mail.enabled then
                            self:PrepareSmartDump()
                        end
                    end
                end)
            end
        elseif event == "MAIL_INBOX_UPDATE" or event == "MAIL_SHOW" then
            -- Inbox state is intentionally observed but never auto-looted/deleted.
            -- Future UI can present mailbox actions without taking irreversible steps.
        elseif event == "PLAYER_ENTERING_WORLD" then
            local store = EnsureStore()
            if store.mail.enabled then
                C_Timer.After(2, function()
                    if self._initialized then self:PrepareSmartDump() end
                end)
            end
        end
    end)
end
