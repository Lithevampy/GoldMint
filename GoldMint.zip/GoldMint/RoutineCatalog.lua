local ADDON_NAME, GoldMint = ...

-- GoldMint's built-in routine catalog.
--
-- This is intentionally separate from the routine observer.  The catalog tells
-- GoldMint what an activity IS; the observer tells us what each character has
-- actually encountered or completed.  Characters do not need to travel to a
-- hub just to populate the catalog.
--
-- Only stable, explicitly identified repeatable quests are seeded here. The
-- observer also learns additional daily/weekly/scheduled quests from the live
-- quest log, so this list can grow without changing the scanner logic.

GoldMint.RoutineCatalog = GoldMint.RoutineCatalog or {}
local Catalog = GoldMint.RoutineCatalog

Catalog.version = 3

-- Expansion buckets used by the future routine UI.  Quest entries remain
-- separate from this metadata so adding an expansion does not invent or
-- imply activities that a character has never actually encountered.
Catalog.expansions = {
    [0]  = { name = "Classic", era = "Legacy", order = 0 },
    [1]  = { name = "The Burning Crusade", era = "Legacy", order = 1 },
    [2]  = { name = "Wrath of the Lich King", era = "Legacy", order = 2 },
    [3]  = { name = "Cataclysm", era = "Legacy", order = 3 },
    [4]  = { name = "Mists of Pandaria", era = "Legacy", order = 4 },
    [5]  = { name = "Warlords of Draenor", era = "Legacy", order = 5 },
    [6]  = { name = "Legion", era = "Legacy", order = 6 },
    [7]  = { name = "Battle for Azeroth", era = "Legacy", order = 7 },
    [8]  = { name = "Shadowlands", era = "Legacy", order = 8 },
    [9]  = { name = "Dragonflight", era = "Legacy", order = 9 },
    [10] = { name = "The War Within", era = "Legacy", order = 10 },
    [11] = { name = "Midnight", era = "Current", order = 11 },
}

function Catalog:GetExpansion(expansionID)
    expansionID = tonumber(expansionID)
    return expansionID and self.expansions[expansionID] or nil
end

function Catalog:GetEra(expansionID)
    local expansion = self:GetExpansion(expansionID)
    return expansion and expansion.era or "Legacy"
end
Catalog.version = 5

-- Built-in PvE activity catalog.  These entries describe activities even when
-- there is no stable quest ID we can use for automatic character-state checks.
-- The live quest observer remains the source of truth for actual quest state.
-- PvP is intentionally excluded from this catalog.
Catalog.activities = {
    -- Midnight Season 2
    { id="midnight_s2_stormarion", expansionID=11, season=2, category="World", frequency="Weekly", title="Stormarion Assault", minLevel=90 },
    { id="midnight_s2_abundance", expansionID=11, season=2, category="World", frequency="Weekly", title="Abundance", minLevel=90 },
    { id="midnight_s2_soiree", expansionID=11, season=2, category="World", frequency="Weekly", title="Saltheril's Soiree", minLevel=90 },
    { id="midnight_s2_atalutek", expansionID=11, season=2, category="World", frequency="Weekly", title="Vaults of Atal'Utek", minLevel=90 },
    { id="midnight_s2_prey", expansionID=11, season=2, category="Outdoor", frequency="Weekly", title="Prey", minLevel=90 },
    { id="midnight_s2_bountiful_delves", expansionID=11, season=2, category="Delves", frequency="Daily", title="Bountiful Delves", minLevel=90 },
    { id="midnight_s2_lair", expansionID=11, season=2, category="Lair", frequency="Weekly", title="The Tidebound Grotto — Nymrissa Wavecaller", minLevel=90 },
    { id="midnight_s2_raid", expansionID=11, season=2, category="Raid", frequency="Weekly", title="The Venomous Abyss", minLevel=90 },
    { id="midnight_s2_mplus", expansionID=11, season=2, category="Mythic+", frequency="Weekly", title="Mythic+ Season 2", minLevel=90 },
    { id="midnight_s2_world_boss", expansionID=11, season=2, category="World Boss", frequency="Weekly", title="Midnight World Boss", minLevel=90 },
    { id="midnight_s2_great_vault", expansionID=11, season=2, category="Great Vault", frequency="Weekly", title="Great Vault — PvE Progress", minLevel=90 },
    { id="midnight_s2_profession", expansionID=11, season=2, category="Profession", frequency="Weekly", title="Profession Weekly Activities", minLevel=90, professions={"Alchemy", "Blacksmithing", "Enchanting", "Engineering", "Herbalism", "Inscription", "Jewelcrafting", "Leatherworking", "Mining", "Skinning", "Tailoring", "Cooking"} },
    { id="midnight_s2_coiled_isle", expansionID=11, season=2, category="Outdoor", frequency="Weekly", title="Coiled Isle Weekly Activities", minLevel=90 },
    { id="midnight_s2_voidforge", expansionID=11, season=2, category="Progression", frequency="Weekly", title="Voidforge / Voidcore Progress", minLevel=90 },

    -- Midnight recurring PvE activity families (kept for continuity with the
    -- original catalog; individual quest state is learned from the live game).
    { id="midnight_s1_world_quests", expansionID=11, season=1, category="World", frequency="Daily", title="World Quests", minLevel=90 },
    { id="midnight_s1_ritual_sites", expansionID=11, season=1, category="World", frequency="Weekly", title="Ritual Sites", minLevel=90 },
    { id="midnight_s1_void_assaults", expansionID=11, season=1, category="World", frequency="Weekly", title="Void Assaults", minLevel=90 },
    { id="midnight_s1_delves", expansionID=11, season=1, category="Delves", frequency="Daily", title="Delves", minLevel=90 },

    -- Legacy activity families.  We deliberately don't invent quest IDs here;
    -- the live quest observer will attach verified quest records when a
    -- character encounters them.
    { id="tww_weeklies", expansionID=10, category="World", frequency="Weekly", title="The War Within — Weekly Activities" },
    { id="tww_delves", expansionID=10, category="Delves", frequency="Daily", title="The War Within — Delves" },
    { id="dragonflight_weeklies", expansionID=9, category="World", frequency="Weekly", title="Dragonflight — Weekly Activities" },
    { id="dragonflight_world_quests", expansionID=9, category="World", frequency="Daily", title="Dragonflight — World Quests" },
    { id="shadowlands_weeklies", expansionID=8, category="World", frequency="Weekly", title="Shadowlands — Weekly Activities" },
    { id="shadowlands_world_quests", expansionID=8, category="World", frequency="Daily", title="Shadowlands — World Quests" },
    { id="bfa_weeklies", expansionID=7, category="World", frequency="Weekly", title="Battle for Azeroth — Weekly Activities" },
    { id="bfa_world_quests", expansionID=7, category="World", frequency="Daily", title="Battle for Azeroth — World Quests" },
    { id="legion_weeklies", expansionID=6, category="World", frequency="Weekly", title="Legion — Weekly Activities" },
    { id="legion_world_quests", expansionID=6, category="World", frequency="Daily", title="Legion — World Quests" },
    { id="wod_weeklies", expansionID=5, category="World", frequency="Weekly", title="Warlords of Draenor — Weekly Activities" },
    { id="wod_garrison", expansionID=5, category="Garrison", frequency="Daily", title="Warlords of Draenor — Garrison Activities" },
    { id="mop_weeklies", expansionID=4, category="World", frequency="Weekly", title="Mists of Pandaria — Weekly Activities" },
    { id="cata_weeklies", expansionID=3, category="World", frequency="Weekly", title="Cataclysm — Weekly Activities" },
    { id="wotlk_weeklies", expansionID=2, category="World", frequency="Weekly", title="Wrath of the Lich King — Weekly Activities" },
    { id="tbc_weeklies", expansionID=1, category="World", frequency="Weekly", title="The Burning Crusade — Weekly Activities" },
    { id="classic_weeklies", expansionID=0, category="World", frequency="Weekly", title="Classic — Weekly Activities" },
}

-- Quest-backed entries used for automatic state tracking.  Only verified
-- repeatable quests are placed here; PvP quests are intentionally omitted.
Catalog.quests = {
    [93889] = { title="Midnight: Saltheril's Soiree", expansionID=11, season=2, category="World", activity="Saltheril's Soiree", frequency=2 },
    [93890] = { title="Midnight: Abundance", expansionID=11, season=2, category="World", activity="Abundance", frequency=2 },
    [93892] = { title="Midnight: Stormarion Assault", expansionID=11, season=2, category="World", activity="Stormarion Assault", frequency=2 },
    [98232] = { title="Midnight: Vaults of Atal'Utek", expansionID=11, season=2, category="World", activity="Vaults of Atal'Utek", frequency=2 },
    [95245] = { title="Midnight: World Tour", expansionID=11, season=2, category="World", activity="Midnight World Tour", frequency=2 },
    [94623] = { title="Building the Voidforge", expansionID=11, season=2, category="Progression", activity="Voidforge", frequency=2 },
    [94625] = { title="An Elementary Voidcore", expansionID=11, season=2, category="Progression", activity="Voidforge", frequency=2 },
}

function Catalog:GetActivity(activityID)
    if not activityID then return nil end
    for _, entry in ipairs(self.activities) do
        if entry.id == activityID then
            return entry
        end
    end
    return nil
end

function Catalog:GetActivities(expansionID, season)
    local result = {}
    for _, entry in ipairs(self.activities) do
        if (expansionID == nil or tonumber(entry.expansionID) == tonumber(expansionID))
            and (season == nil or tonumber(entry.season) == tonumber(season)) then
            result[#result + 1] = entry
        end
    end
    return result
end

function Catalog:GetCurrentActivities()
    return self:GetActivities(11, 2)
end

function Catalog:Get(questID)
    return self.quests[tonumber(questID)]
end

-- Normalize era labels for every catalog quest.
for _, entry in pairs(Catalog.quests) do
    if entry.expansionID == nil then
        entry.expansionID = 11
    end
    local expansion = Catalog:GetExpansion(entry.expansionID)
    if expansion then
        entry.expansionName = entry.expansionName or expansion.name
        entry.era = expansion.era
    end
end
