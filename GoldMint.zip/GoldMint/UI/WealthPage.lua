local ADDON_NAME, addon = ...
local GoldMint = addon or _G.GoldMint
if not GoldMint then return end

-- GoldMint Wealth Page
-- Flat smoky panels, one-pixel cyan borders, and a texture-only velocity ring.

local COPPER_PER_GOLD = 10000
local TARGET_GOLD = 5000000 * COPPER_PER_GOLD
local BUCKET_SECONDS = 300
local BUCKET_COUNT = 6
local WINDOW_SECONDS = BUCKET_SECONDS * BUCKET_COUNT
local MAX_GPH = 10000
local GAUGE_START_OFFSET = 0.25 -- 90 degrees: left endpoint of the upper semicircle
local GAUGE_END_OFFSET = 0.75   -- 270 degrees: right endpoint of the upper semicircle
local GAUGE_LERP_SPEED = 10.0
local GAUGE_SNAP_THRESHOLD = 0.001

local CYAN       = {0.00, 0.85, 1.00, 1.00}
local BLUE       = {0.00, 0.705, 1.00, 1.00}
local WHITE      = {1.00, 1.00, 1.00, 1.00}
local MUTED      = {0.72, 0.76, 0.80, 1.00}
local GREEN      = {0.25, 1.00, 0.55, 1.00}
local GOLD       = {1.00, 0.82, 0.35, 1.00}
local PANEL_BG   = {0.01, 0.03, 0.05, 0.85}
local TRACK_BG   = {0.01, 0.045, 0.06, 0.82}

local page
local ticker
local moneyEvents
local lastMoney
local refs = {
    trendLines = {},
    velocity = {},
}

local function Num(value, fallback)
    value = tonumber(value)
    if value == nil then return fallback or 0 end
    return value
end

local function Now()
    if type(GetTimePreciseSec) == "function" then return GetTimePreciseSec() end
    return time()
end

local function Money()
    if type(GetMoney) == "function" then return Num(GetMoney()) end
    return 0
end

local function Integer(value)
    local text = tostring(math.floor(Num(value)))
    local changed
    repeat
        text, changed = text:gsub("^(%-?%d+)(%d%d%d)", "%1,%2")
    until changed == 0
    return text
end

local function GoldText(value)
    -- WoW money APIs and the Wealth ledger store currency in copper.
    -- Wealth UI values are intentionally displayed as whole gold.
    return Integer(Num(value) / COPPER_PER_GOLD) .. " G"
end

local function FlatFont(fs, size)
    fs:SetFont("Fonts\\FRIZQT__.TTF", size, "")
    fs:SetShadowColor(0, 0, 0, 0)
    fs:SetShadowOffset(0, 0)
    fs:SetAlpha(1)
end

local function Text(parent, value, size, color)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    FlatFont(fs, size)
    fs:SetText(value or "")
    fs:SetTextColor(unpack(color or WHITE))
    fs:SetJustifyV("MIDDLE")
    fs:SetShadowColor(0, 0, 0, 0)
    fs:SetShadowOffset(0, 0)
    return fs
end

local function PutText(fs, value, color)
    if not fs then return end
    fs:SetText(value or "")
    if color then fs:SetTextColor(unpack(color)) end
end

local function Panel(parent)
    local f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    f:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false,
        tileSize = 1,
        edgeSize = 1,
        insets = {left = 0, right = 0, top = 0, bottom = 0},
    })
    f:SetBackdropColor(unpack(PANEL_BG))
    f:SetBackdropBorderColor(unpack(CYAN))
    return f
end

local function Line(parent, layer, alpha)
    local t = parent:CreateTexture(nil, layer or "ARTWORK")
    t:SetTexture("Interface\\Buttons\\WHITE8X8")
    t:SetVertexColor(0.00, 0.72, 0.92, alpha or 0.55)
    return t
end

local function SectionTitle(parent, text, x, y)
    local title = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", x or 18, y or -14)
    title:SetText(text or "")
    title:SetTextColor(unpack(CYAN))
    title:SetJustifyH("LEFT")
    title:SetShadowOffset(1, -1)

    local accent = parent:CreateTexture(nil, "ARTWORK")
    accent:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], CYAN[4])
    accent:SetSize(38, 2)
    accent:SetPoint("TOPLEFT", x or 18, (y or -14) - 18)

    return title
end

local function Session()
    local ledger = GoldMint.Ledger
    if not ledger then return nil end
    if type(ledger.GetSession) == "function" then
        local ok, result = pcall(ledger.GetSession, ledger)
        if ok and type(result) == "table" then return result end
    end
    return type(ledger.session) == "table" and ledger.session or nil
end

local function StartingGold(session)
    if session and Num(session.startingGold) > 0 then return Num(session.startingGold) end
    if type(GoldMintCharDB) == "table" and Num(GoldMintCharDB.StartingGold) > 0 then
        return Num(GoldMintCharDB.StartingGold)
    end
    return Money()
end

local function CurrentGold(session)
    if session then
        if Num(session.endingGold) > 0 then return Num(session.endingGold) end
        if Num(session.lastGold) > 0 then return Num(session.lastGold) end
    end
    return Money()
end

local function SessionProfit(session)
    if session then return Num(session.netGold) end
    return CurrentGold(session) - StartingGold(session)
end

local function RollingBuckets(session)
    local buckets = {}
    local currentStart = math.floor(time() / BUCKET_SECONDS) * BUCKET_SECONDS

    for i = 1, BUCKET_COUNT do
        buckets[i] = {
            start = currentStart - ((BUCKET_COUNT - i) * BUCKET_SECONDS),
            amount = 0,
        }
    end

    if not session or type(session.transactions) ~= "table" then return buckets end

    local first = currentStart - WINDOW_SECONDS
    for _, tx in ipairs(session.transactions) do
        if type(tx) == "table" and Num(tx.amount) > 0 and tostring(tx.type or "") ~= "transfer" then
            local stamp = Num(tx.time)
            if stamp >= first then
                local index = math.floor((stamp - first) / BUCKET_SECONDS) + 1
                index = math.max(1, math.min(BUCKET_COUNT, index))
                buckets[index].amount = buckets[index].amount + Num(tx.amount)
            end
        end
    end

    return buckets
end

local function RollingGPH(session)
    local buckets = RollingBuckets(session)
    local total = 0
    local oldest = nil
    local now = time()

    -- Use the actual observed transaction timestamps.  While the rolling
    -- window is still filling, annualize over the time we have actually
    -- observed instead of dividing by a fixed 30 minutes.  Once the window
    -- is full, it becomes a true rolling 30-minute rate.
    if session and type(session.transactions) == "table" then
        local first = now - WINDOW_SECONDS
        for _, tx in ipairs(session.transactions) do
            if type(tx) == "table" and Num(tx.amount) > 0 and tostring(tx.type or "") ~= "transfer" then
                local stamp = Num(tx.time)
                if stamp >= first and stamp <= now then
                    if not oldest or stamp < oldest then oldest = stamp end
                end
            end
        end
    end

    for i = 1, BUCKET_COUNT do total = total + Num(buckets[i].amount) end
    if total <= 0 then return 0, buckets end

    local elapsed = WINDOW_SECONDS
    if oldest then
        elapsed = math.max(1, math.min(WINDOW_SECONDS, now - oldest))
    end
    return math.floor((total / elapsed) * 3600 + 0.5), buckets
end

local function SourceBreakdown(session)
    local totals = session and session.sourceTotals or {}
    local values = {0, 0, 0}
    local sourceNames = {
        [1] = { ["Looted Gold"] = true, ["Other Income"] = true, ["Quest Reward"] = true },
        [2] = { ["Vendor Sale"] = true },
        [3] = { ["Auction House Sale"] = true, ["Auction House Mail"] = true, ["Mail Received"] = true, ["Trade Received"] = true },
    }

    local total = 0
    for source, bucket in pairs(totals) do
        local income = Num(bucket and bucket.income)
        total = total + income
        for i = 1, 3 do
            if sourceNames[i][source] then values[i] = values[i] + income end
        end
    end

    if total <= 0 then return {0, 0, 0} end
    return {
        values[1] / total,
        values[2] / total,
        values[3] / total,
    }
end

local function SessionHigh(current)
    local high = Num(current)
    if type(GoldMintCharDB) == "table" then
        local stored = Num(GoldMintCharDB.WealthSessionHigh)
        if stored > high then high = stored end
        if high > stored then GoldMintCharDB.WealthSessionHigh = high end
    end
    return high
end

local function Lerp(a, b, t)
    return a + (b - a) * t
end

-- Convert live gold/hour into the gauge's safe 0..1 range.
-- Looted gold is recorded by the Ledger from PLAYER_MONEY, so every wallet
-- increase immediately changes the rolling 30-minute velocity and therefore
-- the visible neon-cyan arc.  The clamp prevents the artwork from exceeding
-- its full semicircle during a large loot event.
local function UpdateWealthVelocity(rawGPH)
    if not refs.speedoFrame then return 0 end

    local gph = math.max(0, Num(rawGPH))
    local pct = math.max(0, math.min(1, gph / MAX_GPH))
    refs.speedoFrame.targetProgress = pct
    refs.speedoFrame.lastGoldPerHour = gph
    return pct
end

local function ApplyGaugeProgress(frame, progress)
    if not frame or not frame.progressGlow then return end

    progress = math.max(0, math.min(1, Num(progress)))

    -- Midnight 12.1+ provides native radial masking directly on textures.
    -- This is preferable to warping a rectangular texture or abusing a
    -- Cooldown swipe: the glow remains a true semicircular arc.
    if frame.progressGlow.SetRadialProgressBarPercent then
        frame.progressGlow:SetRadialProgressBarPercent(progress)
    elseif frame.progressCooldown then
        -- Compatibility fallback for clients without radial texture masking.
        -- The cooldown is constrained to the same 180-degree arc.
        local duration = 1
        local now = GetTime()
        frame.progressCooldown:SetCooldown(now - (duration * progress), duration)
    end
end

local function CreateGauge(panel)
    local gaugeFrame = CreateFrame("Frame", nil, panel)
    refs.speedoFrame = gaugeFrame
    gaugeFrame.targetProgress = 0
    gaugeFrame.visualProgress = 0

    -- Supplied 30-minute wealth gauge artwork. The TGA is a lossless RGBA
    -- conversion of the supplied PNG so the artwork itself is not recreated,
    -- recolored, or approximated with WoW primitives.
    local gaugeTex = gaugeFrame:CreateTexture(nil, "ARTWORK")
    gaugeTex:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMint30MinuteGauge")
    gaugeTex:SetTexCoord(0, 1, 0, 1)
    gaugeTex:SetVertexColor(1.00, 1.00, 1.00, 1.00)
    refs.gaugeTex = gaugeTex

    -- Thick neon-cyan progress glow layered over the supplied background arc.
    -- The asset is already shaped as a perfect semicircle, while the native
    -- radial-progress mask reveals it without stretching or warping it.
    local progressGlow = gaugeFrame:CreateTexture(nil, "OVERLAY")
    progressGlow:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintWealthProgressGlow")
    progressGlow:SetTexCoord(0, 1, 0, 1)
    progressGlow:SetVertexColor(0.00, 1.00, 1.00, 1.00)
    progressGlow:SetBlendMode("ADD")

    if progressGlow.SetRadialProgressBarStartOffset then
        progressGlow:SetRadialProgressBarStartOffset(GAUGE_START_OFFSET)
        progressGlow:SetRadialProgressBarEndOffset(GAUGE_END_OFFSET)
        progressGlow:SetRadialProgressBarReverse(false)
        progressGlow:SetRadialProgressBarFeather(0.0125)
        progressGlow:SetRadialProgressBarPercent(0)
    else
        -- Pre-12.1 fallback: keep a Cooldown available for clients that do not
        -- expose the native radial texture-progress API.
        local cooldown = CreateFrame("Cooldown", nil, gaugeFrame)
        cooldown:SetDrawSwipe(true)
        cooldown:SetDrawEdge(false)
        cooldown:SetDrawBling(false)
        cooldown:SetReverse(true)
        cooldown:SetSwipeTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintWealthProgressGlow")
        cooldown:SetSwipeColor(0.00, 1.00, 1.00, 1.00)
        cooldown:SetRotation(math.pi)
        cooldown:SetHideCountdownNumbers(true)
        gaugeFrame.progressCooldown = cooldown
        refs.progressCooldown = cooldown
        progressGlow:SetAlpha(0)
    end

    gaugeFrame.progressGlow = progressGlow
    refs.progressGlow = progressGlow

    -- Smoothly move the visible line toward the latest target percentage.
    -- Once the difference is <= 0.001, snap exactly to the target so the
    -- OnUpdate loop cannot micro-stutter forever on floating-point residue.
    gaugeFrame:SetScript("OnUpdate", function(self, elapsed)
        local current = self.visualProgress or 0
        local target = self.targetProgress or 0
        local delta = target - current

        if math.abs(delta) <= GAUGE_SNAP_THRESHOLD then
            if current ~= target then
                current = target
                self.visualProgress = current
                ApplyGaugeProgress(self, current)
            end
            return
        end

        local step = math.min(1, math.max(0, elapsed) * GAUGE_LERP_SPEED)
        current = Lerp(current, target, step)
        self.visualProgress = current
        ApplyGaugeProgress(self, current)
    end)

    refs.gph = Text(gaugeFrame, "0", 34, WHITE)
    refs.gph:SetJustifyH("CENTER")
    refs.gph:SetJustifyV("MIDDLE")

    refs.gphUnit = Text(gaugeFrame, "GPH", 18, CYAN)
    refs.gphUnit:SetJustifyH("CENTER")
    refs.gphUnit:SetJustifyV("MIDDLE")
end

local function DrawTrend(values)
    local chart = refs.chart
    if not chart then return end

    for _, line in ipairs(refs.trendLines) do line:Hide() end
    if #values < 2 then return end

    local minValue, maxValue = math.huge, -math.huge
    for i = 1, #values do
        minValue = math.min(minValue, values[i])
        maxValue = math.max(maxValue, values[i])
    end
    local span = math.max(1, maxValue - minValue)
    local width = math.max(1, chart:GetWidth() - 10)
    local height = math.max(1, chart:GetHeight() - 10)

    for i = 1, #values - 1 do
        local x1 = 5 + ((i - 1) / (#values - 1)) * width
        local x2 = 5 + (i / (#values - 1)) * width
        local y1 = 5 + ((values[i] - minValue) / span) * height
        local y2 = 5 + ((values[i + 1] - minValue) / span) * height
        local dx, dy = x2 - x1, y2 - y1
        local line = refs.trendLines[i]

        if not line then
            line = Line(chart, "OVERLAY", 0.95)
            refs.trendLines[i] = line
        end

        line:ClearAllPoints()
        line:SetSize(math.max(1, math.sqrt(dx * dx + dy * dy)), 2)
        line:SetPoint("CENTER", chart, "BOTTOMLEFT", (x1 + x2) * 0.5, (y1 + y2) * 0.5)
        if line.SetRotation then line:SetRotation(math.atan(dy, dx)) end
        line:Show()
    end
end

local function BuildWallet(parent)
    local f = Panel(parent)
    refs.wallet = f

    refs.walletTitle = SectionTitle(f, "CHARACTER WALLET & SESSION BASELINE", 22, -12)

    refs.activeLabel = Text(f, "Active Character Gold:", 21, WHITE)
    refs.activeLabel:SetPoint("TOPLEFT", 22, -56)

    refs.activeGold = Text(f, "0 G", 40, WHITE)
    refs.activeGold:SetPoint("TOPLEFT", 22, -91)
    refs.activeGold:SetPoint("RIGHT", -22, 0)
    refs.activeGold:SetJustifyH("LEFT")
end

local function BuildSummary(parent)
    local f = Panel(parent)
    refs.summary = f

    refs.summaryTitle = SectionTitle(f, "SESSION SUMMARY", 22, -12)

    local function Row(label, y, key, color, size)
        local l = Text(f, label, 20, WHITE)
        l:SetPoint("TOPLEFT", 22, -y)
        local v = Text(f, "0 G", size or 20, color or WHITE)
        v:SetPoint("TOPRIGHT", -22, -y)
        v:SetJustifyH("RIGHT")
        refs[key] = v
    end

    Row("Starting Gold:", 52, "startingGold", WHITE, 20)
    Row("Current Gold:", 80, "currentGold", WHITE, 20)

    local rule = Line(f, "ARTWORK", 0.55)
    rule:SetHeight(1)
    rule:SetPoint("TOPLEFT", 22, -107)
    rule:SetPoint("TOPRIGHT", -22, -107)

    Row("Total Session Profit:", 118, "sessionProfit", GREEN, 22)
end

local function BuildBreakdown(parent)
    local f = Panel(parent)
    refs.breakdown = f

    local title = SectionTitle(f, "ADVANCED VELOCITY BREAKDOWN", 22, -12)

    local sub = Text(f, "Velocity Dissection (GPH)", 20, WHITE)
    sub:SetPoint("TOPLEFT", 22, -47)

    local names = {"Looting / Raw Gold", "Vendor Sales", "Professions / Orders"}

    for i = 1, 3 do
        local y = 80 + ((i - 1) * 57)
        local name = Text(f, names[i], 18, MUTED)
        name:SetPoint("TOPLEFT", 22, -y)

        local pct = Text(f, "0%", 18, CYAN)
        pct:SetPoint("TOPRIGHT", -22, -y)
        pct:SetJustifyH("RIGHT")

        local track = f:CreateTexture(nil, "ARTWORK")
        track:SetTexture("Interface\\Buttons\\WHITE8X8")
        track:SetVertexColor(unpack(TRACK_BG))
        track:SetPoint("TOPLEFT", 22, -(y + 25))
        track:SetPoint("TOPRIGHT", -22, -(y + 25))
        track:SetHeight(14)

        local fill = f:CreateTexture(nil, "OVERLAY")
        fill:SetTexture("Interface\\Buttons\\WHITE8X8")
        fill:SetVertexColor(0.00, 0.78, 0.80, 0.88)
        fill:SetPoint("LEFT", track, "LEFT", 1, 0)
        fill:SetHeight(10)
        refs.velocity[i] = {fill = fill, track = track, ratio = 0, pct = pct}
    end
end

local function BuildSpeedometer(parent)
    local f = Panel(parent)
    refs.speedo = f

    local title = SectionTitle(f, "30-MINUTE WEALTH VELOCITY", 22, -12)

    CreateGauge(f)

    local footer = Text(f, "Rolling 30min window", 15, MUTED)
    footer:SetPoint("BOTTOM", 0, 11)
    footer:SetJustifyH("CENTER")
    footer:SetWordWrap(false)
end

local function BuildFooter(parent)
    local f = Panel(parent)
    refs.footer = f

    local title = SectionTitle(f, "TREND & EFFICIENCY", 22, -12)

    local trendTitle = Text(f, "Wealth Velocity Trend", 20, WHITE)
    trendTitle:SetPoint("TOPLEFT", 22, -48)

    refs.chart = CreateFrame("Frame", nil, f)
    refs.chart:SetPoint("TOPLEFT", 22, -78)
    refs.chart:SetSize(360, 70)

    refs.sessionHigh = Text(f, "Session High: 0 GPH", 16, MUTED)
    refs.sessionHigh:SetPoint("TOPLEFT", 22, -148)

    local divider = Line(f, "ARTWORK", 0.60)
    divider:SetWidth(1)
    divider:SetPoint("TOP", 0, -43)
    divider:SetPoint("BOTTOM", 0, 14)

    local targetTitle = Text(f, "Time-to-Target Calculation", 20, WHITE)
    refs.targetTitle = targetTitle
    targetTitle:SetPoint("TOPLEFT", 430, -48)

    local target1 = Text(f, "At current raw gold velocity,", 16, MUTED)
    refs.target1 = target1
    target1:SetPoint("TOPLEFT", 430, -82)

    local target2 = Text(f, "5 Million gold goal is", 16, MUTED)
    refs.target2 = target2
    target2:SetPoint("TOPLEFT", 430, -106)

    refs.target = Text(f, "~0.0 hours away.", 19, GOLD)
    refs.target:SetPoint("TOPLEFT", 430, -130)
end

local function Layout()
    if not page then return end

    local w = math.max(600, page:GetWidth())
    local h = math.max(500, page:GetHeight())
    -- Match the supplied Wealth screenshot proportions: 168px top row,
    -- 245px middle row, 12px gutters, and the remaining space for the footer
    -- on the reference 636px-high canvas.  Keep the same proportions when
    -- the dashboard is scaled to another resolution.
    local gap = 12
    local topH = math.floor((h * 0.26415) + 0.5)
    local midH = math.floor((h * 0.38522) + 0.5)
    local topY = 0
    local midY = topY + topH + gap
    local footerY = midY + midH + gap
    local footerH = math.max(1, h - footerY)

    local leftTopW = math.floor((w - gap) * 0.50)
    local rightTopW = w - gap - leftTopW

    refs.wallet:ClearAllPoints()
    refs.wallet:SetPoint("TOPLEFT", 0, -topY)
    refs.wallet:SetSize(leftTopW, topH)

    refs.summary:ClearAllPoints()
    refs.summary:SetPoint("TOPLEFT", leftTopW + gap, -topY)
    refs.summary:SetSize(rightTopW, topH)

    local leftMidW = math.floor((w - gap) * 0.64)
    local rightMidW = w - gap - leftMidW

    refs.breakdown:ClearAllPoints()
    refs.breakdown:SetPoint("TOPLEFT", 0, -midY)
    refs.breakdown:SetSize(leftMidW, midH)

    refs.speedo:ClearAllPoints()
    refs.speedo:SetPoint("TOPLEFT", leftMidW + gap, -midY)
    refs.speedo:SetSize(rightMidW, midH)

    refs.footer:ClearAllPoints()
    refs.footer:SetPoint("TOPLEFT", 0, -footerY)
    refs.footer:SetPoint("TOPRIGHT", 0, -footerY)
    refs.footer:SetHeight(footerH)

    refs.chart:SetWidth(math.max(180, math.floor(leftMidW * 0.47)))
    refs.chart:SetHeight(math.max(48, footerH - 84))

    -- Move the Time-to-Target block fully to the right of the center divider.
    -- Use the actual footer width so the spacing remains correct at different sizes.
    local targetX = math.floor(refs.footer:GetWidth() * 0.55)

    refs.targetTitle:ClearAllPoints()
    refs.targetTitle:SetPoint("TOPLEFT", refs.footer, "TOPLEFT", targetX, -48)

    refs.target1:ClearAllPoints()
    refs.target1:SetPoint("TOPLEFT", refs.footer, "TOPLEFT", targetX, -82)

    refs.target2:ClearAllPoints()
    refs.target2:SetPoint("TOPLEFT", refs.footer, "TOPLEFT", targetX, -106)

    refs.target:ClearAllPoints()
    refs.target:SetPoint("TOPLEFT", refs.footer, "TOPLEFT", targetX, -130)

    -- The supplied 1024x528 semicircular gauge artwork is preserved at its
    -- native aspect ratio so none of the custom artwork is stretched or cropped.
    local gaugeW = math.max(260, rightMidW - 24)
    local gaugeH = gaugeW * (528 / 1024)
    local maxGaugeH = math.max(140, midH - 72)
    if gaugeH > maxGaugeH then
        gaugeH = maxGaugeH
        gaugeW = gaugeH * (1024 / 528)
    end

    refs.speedoFrame:ClearAllPoints()
    refs.speedoFrame:SetSize(gaugeW, gaugeH)
    -- The supplied artwork has a transparent left/right margin that makes its
    -- visible gauge sit slightly right of the texture's mathematical center.
    -- Nudge the texture frame left so the actual visible speedometer is centered
    -- in the 30-minute panel without stretching or cropping the artwork.
    local gaugeVisualCenterOffset = gaugeW * 0.037
    refs.speedoFrame:SetPoint("TOP", refs.speedo, "TOP", -gaugeVisualCenterOffset, -42)
    refs.gaugeTex:SetAllPoints(refs.speedoFrame)
    refs.progressGlow:SetAllPoints(refs.speedoFrame)
    if refs.progressCooldown then
        refs.progressCooldown:ClearAllPoints()
        refs.progressCooldown:SetAllPoints(refs.speedoFrame)
    end
    ApplyGaugeProgress(refs.speedoFrame, refs.speedoFrame.visualProgress or 0)

    -- Position the live value over the open center of the supplied gauge.
    -- These coordinates correspond to the visual center of the original
    -- 1024x528 artwork and scale with the gauge without distorting it.
    local valueX = gaugeW * 0.037
    local valueY = -gaugeH * 0.165
    refs.gph:SetPoint("CENTER", refs.speedoFrame, "CENTER", valueX, valueY)
    refs.gph:SetWidth(gaugeW * 0.36)
    refs.gphUnit:SetPoint("CENTER", refs.speedoFrame, "CENTER", valueX, valueY - 25)
    refs.gphUnit:SetWidth(gaugeW * 0.30)

    for i = 1, 3 do
        local v = refs.velocity[i]
        local width = math.max(1, v.track:GetWidth() - 2)
        v.fill:SetWidth(math.max(1, width * v.ratio))
    end

    DrawTrend(refs.trendValues or {})
end

local function Refresh()
    if not page then return end

    local session = Session()
    local current = CurrentGold(session)
    local starting = StartingGold(session)
    local profit = SessionProfit(session)
    local gph, buckets = RollingGPH(session)
    local high = SessionHigh(gph)

    PutText(refs.activeGold, GoldText(current), WHITE)
    PutText(refs.startingGold, GoldText(starting), WHITE)
    PutText(refs.currentGold, GoldText(current), WHITE)
    PutText(refs.sessionProfit, (profit >= 0 and "+" or "-") .. GoldText(math.abs(profit)), profit >= 0 and GREEN or {1.00, 0.35, 0.35, 1.00})
    local goldPerHour = gph / COPPER_PER_GOLD
    PutText(refs.gph, Integer(goldPerHour), WHITE)
    PutText(refs.sessionHigh, "Session High: " .. Integer(high / COPPER_PER_GOLD) .. " GPH", MUTED)
    UpdateWealthVelocity(goldPerHour)

    local remaining = math.max(0, TARGET_GOLD - current)
    local rawVelocity = gph
    if remaining <= 0 then
        PutText(refs.target, "Target reached.", GOLD)
    elseif rawVelocity > 0 then
        PutText(refs.target, string.format("~%.1f hours away.", remaining / rawVelocity), GOLD)
    else
        PutText(refs.target, "Waiting for velocity data.", GOLD)
    end

    refs.trendValues = {}
    for i = 1, BUCKET_COUNT do
        refs.trendValues[i] = Num(buckets[i].amount) * 12
    end

    -- Replace the old illustrative 60/25/15 split with live source data.
    local ratios = SourceBreakdown(session)
    for i = 1, 3 do
        local v = refs.velocity[i]
        v.ratio = ratios[i]
        local width = math.max(1, v.track:GetWidth() - 2)
        v.fill:SetWidth(math.max(1, width * v.ratio))
        PutText(v.pct, string.format("%d%%", math.floor(v.ratio * 100 + 0.5)), CYAN)
    end

    DrawTrend(refs.trendValues)
    Layout()
end

local function StartTicker()
    if ticker or not C_Timer or not C_Timer.NewTicker then return end
    ticker = C_Timer.NewTicker(5, function()
        if page and page:IsShown() then Refresh() end
    end)
end

local function StopTicker()
    if ticker then ticker:Cancel(); ticker = nil end
end

local function Build()
    if page then return page end

    page = CreateFrame("Frame", "GoldMintWealthPage")
    page:SetClipsChildren(false)

    BuildWallet(page)
    BuildSummary(page)
    BuildBreakdown(page)
    BuildSpeedometer(page)
    BuildFooter(page)

    page:SetScript("OnSizeChanged", function()
        if page:IsShown() then Layout() end
    end)
    page:SetScript("OnShow", function()
        Refresh()
        StartTicker()
    end)
    page:SetScript("OnHide", StopTicker)

    page.Refresh = Refresh
    page.RefreshSessionSummary = Refresh
    page.GetRollingGPH = function()
        return RollingGPH(Session())
    end
    page.UpdateWealthVelocity = UpdateWealthVelocity

    if not moneyEvents then
        moneyEvents = CreateFrame("Frame")
        moneyEvents:RegisterEvent("PLAYER_MONEY")
        moneyEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
        moneyEvents:RegisterEvent("LOOT_OPENED")
        moneyEvents:SetScript("OnEvent", function(_, event)
            if not (page and page:IsShown()) then return end

            -- Refresh on the authoritative PLAYER_MONEY event and also when
            -- LOOT_OPENED fires.  PLAYER_MONEY is the actual wallet change,
            -- while LOOT_OPENED makes the gauge ready for the incoming gold
            -- before the next normal five-second Wealth refresh.
            local delay = event == "LOOT_OPENED" and 0.05 or 0
            if C_Timer and C_Timer.After then
                C_Timer.After(delay, function()
                    if page and page:IsShown() then Refresh() end
                end)
            else
                Refresh()
            end
        end)
    end

    lastMoney = Money()
    return page
end

function GoldMint.BuildWealthPage(content)
    if not content then return nil end

    local wealth = Build()
    wealth:SetParent(content)
    wealth:ClearAllPoints()

    -- Keep Wealth visually in the same compact scale as the other GoldMint
    -- pages.  The canvas stays aligned to the navigation at the top-left,
    -- while the Wealth artwork uses a modest inset instead of filling every
    -- available pixel of the dashboard.
    local function SizeWealthCanvas()
        local width = math.max(1, content:GetWidth())
        local height = math.max(1, content:GetHeight())
        wealth:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
        wealth:SetSize(width * 0.94, height * 0.94)
        Layout()
    end

    SizeWealthCanvas()

    if not content._goldMintWealthResizeHook then
        content._goldMintWealthResizeHook = true
        content:HookScript("OnSizeChanged", function()
            if wealth and wealth:IsShown() then
                SizeWealthCanvas()
            end
        end)
    end

    wealth:Show()
    Layout()
    Refresh()
    return wealth
end

function GoldMint.RefreshWealthPage()
    if page then Refresh() end
end

-- Public hook for other GoldMint UI code. Pass GPH in gold/hour.
GoldMint.UpdateWealthVelocity = UpdateWealthVelocity
