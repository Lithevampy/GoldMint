local GoldMint = _G.GoldMint

-- ============================================================================
-- GOLDMINT DASHBOARD
-- ============================================================================
-- Presentation layer only. All values come from the existing GoldMint systems.
-- The dashboard is deliberately data-driven so later pages can reuse the same
-- APIs without moving ownership of ledger, market, routine, mail, or milestone
-- state into the UI.
-- ============================================================================

GoldMint.Dashboard = {}
local Dashboard = GoldMint.Dashboard

local frame
local labels = {}
local bars = {}
local buttons = {}
local panels = {}
Dashboard.panels = panels
local initialized = false
local minimapButton

-- The dashboard is authored on a 1400x840 design canvas.  All pages live
-- inside this same frame, so the safest responsive strategy is to scale the
-- complete canvas as one unit when the available UI space is smaller.  This
-- keeps every page's internal proportions/anchors intact while preventing
-- panels and text from colliding on smaller resolutions or larger WoW UI
-- scales.
local DASHBOARD_BASE_WIDTH = 1400
local DASHBOARD_BASE_HEIGHT = 840
local DASHBOARD_SCREEN_MARGIN = 24

local function UpdateResponsiveScale()
    if not frame or not UIParent then return end

    local uiWidth = tonumber(UIParent:GetWidth()) or DASHBOARD_BASE_WIDTH
    local uiHeight = tonumber(UIParent:GetHeight()) or DASHBOARD_BASE_HEIGHT
    local availableWidth = math.max(1, uiWidth - (DASHBOARD_SCREEN_MARGIN * 2))
    local availableHeight = math.max(1, uiHeight - (DASHBOARD_SCREEN_MARGIN * 2))

    local scaleX = availableWidth / DASHBOARD_BASE_WIDTH
    local scaleY = availableHeight / DASHBOARD_BASE_HEIGHT
    local scale = math.min(1, scaleX, scaleY)

    -- Never allow an invalid/vanishing scale if WoW reports dimensions during
    -- a display transition.
    if scale ~= scale or scale <= 0 then
        scale = 1
    end

    local userScale = 1.0
    if GoldMintDB and GoldMintDB.settings then
        userScale = tonumber(GoldMintDB.settings.dashboardScale) or 1.0
    end
    userScale = math.max(0.75, math.min(1.25, userScale))
    frame:SetScale(scale * userScale)
    frame._goldMintResponsiveScale = scale
    frame._goldMintUserScale = userScale
end
local OpenGoalEditor
local OpenProjects
local OpenPlanner
local OpenOperations
local navButtons = {}
local activeNavKey = "dashboard"

local GOLD = {1.0, 0.82, 0.25}
local CYAN = {0.20, 0.78, 1.0}
local GREEN = {0.25, 1.0, 0.55}
local RED = {1.0, 0.35, 0.35}
local MUTED = {0.60, 0.74, 0.88}
local DARK = {0.006, 0.028, 0.050, 0.965}

local function ApplyNavState(button, active, hover)
    if not button then return end
    if active then
        button:SetBackdropColor(0.08, 0.18, 0.28, 0.62)
        if button.text then button.text:SetTextColor(unpack(GOLD)) end
        if button.icon then
            button.icon:SetVertexColor(1.0, 0.82, 0.25, 1.0)
            if button.iconGlow then button.iconGlow:Hide() end
        end
        if button.accent then button.accent:Show() end
    elseif hover then
        -- Hover should illuminate the icon only; do not show a rectangular
        -- button/background box over the navigation pane.
        button:SetBackdropColor(0, 0, 0, 0)
        if button.text then button.text:SetTextColor(unpack(GOLD)) end
        if button.icon then
            button.icon:SetVertexColor(0.35, 0.85, 1.0, 1.0)
        end
        if button.accent then button.accent:Hide() end
    else
        button:SetBackdropColor(0, 0, 0, 0)
        if button.text then button.text:SetTextColor(unpack(MUTED)) end
        if button.icon then
            button.icon:SetVertexColor(1.0, 1.0, 1.0, 1.0)
            if button.iconGlow then button.iconGlow:Hide() end
        end
        if button.accent then button.accent:Hide() end
    end
end
local wealthLiveLabels = {}
local cooldownFilterMenu

local function SetNavigationActive(key)
    activeNavKey = key or "dashboard"
    for navKey, b in pairs(navButtons) do
        ApplyNavState(b, navKey == activeNavKey, false)
    end
end

local function FormatGold(amount)
    if GoldMint.Ledger and GoldMint.Ledger.FormatGoldFull then
        return GoldMint.Ledger:FormatGoldFull(tonumber(amount) or 0)
    end
    return tostring(math.floor(tonumber(amount) or 0)) .. "g"
end

local function FormatWealthAmount(amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then
        return "0"
    end
    return FormatGold(amount)
end

local function FormatWholeGold(amount)
    amount = math.floor((tonumber(amount) or 0) / 10000)
    local s = tostring(amount)
    local out = s
    while true do
        local n; out, n = string.gsub(out, "^(%-?%d+)(%d%d%d)", "%1,%2")
        if n == 0 then break end
    end
    return out
end

local function FormatRate(amount)
    if GoldMint.Ledger and GoldMint.Ledger.FormatRate then
        return GoldMint.Ledger:FormatRate(tonumber(amount) or 0)
    end
    return tostring(math.floor(tonumber(amount) or 0)) .. "g"
end

-- Profit/loss values need to inherit the FontString color. GetMoneyString()
-- embeds Blizzard's gold/silver/copper color escape codes, which override
-- SetTextColor() and can make a positive value appear red or otherwise ignore
-- GoldMint's profit/loss color rules. Use the plain ledger formatter for
-- dashboard P&L values so positive is always green and negative is red.
local function FormatProfitGold(amount)
    amount = tonumber(amount) or 0
    if GoldMint.Ledger and GoldMint.Ledger.FormatGold then
        return GoldMint.Ledger:FormatGold(amount)
    end
    return tostring(math.floor(amount)) .. "g"
end

-- Token prices are plain numbers in the header card.  Do not use GetMoneyString
-- here because its second argument adds a gold-coin texture underneath/after
-- the value, which is not appropriate for the WoW Token tracker.
local function FormatTokenPrice(amount)
    amount = math.floor(tonumber(amount) or 0)
    if BreakUpLargeNumbers then
        return BreakUpLargeNumbers(amount)
    end
    local text = tostring(amount)
    local changed
    repeat
        text, changed = text:gsub("^(%d+)(%d%d%d)", "%1,%2")
    until changed == 0
    return text
end

local function ShortGold(amount)
    amount = tonumber(amount) or 0
    local abs = math.abs(amount)
    if abs >= 1000000 then
        return string.format("%.2fm", amount / 1000000)
    elseif abs >= 1000 then
        return string.format("%.1fk", amount / 1000)
    end
    return string.format("%.0f", amount)
end

local function CraftingEllipsis(value, maxChars)
    value = tostring(value or "")
    maxChars = tonumber(maxChars) or 24
    if #value <= maxChars then return value end
    return value:sub(1, math.max(1, maxChars - 2)) .. ".."
end

local function MakeLabel(parent, template, text, width)
    local label = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormal")
    label:SetJustifyH("LEFT")
    label:SetText(text or "")
    if width then label:SetWidth(width) end
    return label
end

local function Panel(parent, width, height, point, x, y, borderColor)
    local p = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    p:SetSize(width, height)
    p:SetPoint(point, parent, point, x or 0, y or 0)
    p:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = {left = 5, right = 5, top = 5, bottom = 5},
    })
    p:SetBackdropColor(0.006, 0.018, 0.032, 0.985)
    local c = borderColor or {0.10, 0.34, 0.52, 0.90}
    p:SetBackdropBorderColor(c[1], c[2], c[3], c[4] or 0.90)
    return p
end

local function Accent(parent, point, x, y, width, color)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetColorTexture(color[1], color[2], color[3], color[4] or 1)
    t:SetSize(width, 2)
    t:SetPoint(point, parent, point, x, y)
    return t
end

local function MakeButton(parent, text, width, height, variant)
    -- GoldMint standard button: dark navy body, cyan border, gold hover glow.
    -- All action buttons use the same visual language; variant is retained only
    -- for compatibility with existing callers.
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height)
    b:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })

    local textLabel = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    textLabel:SetPoint("CENTER")
    textLabel:SetText(text)
    textLabel:SetTextColor(unpack(MUTED))
    b.text = textLabel

    local function ApplyNormal()
        b:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        b:SetBackdropBorderColor(unpack(CYAN))
        b.text:SetTextColor(unpack(GOLD))
    end

    local function ApplyHover()
        b:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
        b:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
        b.text:SetTextColor(1.0, 0.86, 0.38)
    end

    ApplyNormal()
    -- Explicitly opt every GoldMint button into mouse interaction.  This is
    -- important for dynamically-created buttons inside the project editor,
    -- where parent/child frame layering can otherwise make the button appear
    -- clickable without reliably receiving the click.
    b:EnableMouse(true)
    b:RegisterForClicks("LeftButtonUp")
    b:SetFrameLevel((parent:GetFrameLevel() or 0) + 2)
    b:SetScript("OnEnter", ApplyHover)
    b:SetScript("OnLeave", ApplyNormal)
    return b
end

local function SetBar(bar, fraction)
    fraction = math.max(0, math.min(1, tonumber(fraction) or 0))
    bar:SetValue(fraction)
end

local function SetText(name, text)
    if labels[name] then labels[name]:SetText(text or "") end
end

local function SetStatus(label, state)
    if not label then return end
    if state == "ahead" or state == "profit" or state == "ready" then
        label:SetTextColor(unpack(GREEN))
    elseif state == "behind" or state == "warning" then
        label:SetTextColor(unpack(RED))
    elseif state == "gold" then
        label:SetTextColor(unpack(GOLD))
    else
        label:SetTextColor(unpack(MUTED))
    end
end

local function AddSectionTitle(parent, key, text, color, x, y)
    labels[key] = MakeLabel(parent, "GameFontNormalLarge", text)
    labels[key]:SetPoint("TOPLEFT", x or 18, y or -14)
    labels[key]:SetTextColor(unpack(color or CYAN))
    labels[key]:SetShadowOffset(1, -1)
    local titleColor = color or CYAN
    local titleX = x or 18
    local titleY = y or -14
    Accent(parent, "TOPLEFT", titleX, titleY - 18, 38, titleColor)
end

local ACTIVE_COOLDOWN_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintActiveCooldowns.tga"

local function AddActiveCooldownIcon(parent, x, y, size)
    local icon = parent:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(ACTIVE_COOLDOWN_ICON)
    local s = size or 20
    icon:SetSize(s, s)
    icon:SetPoint("TOP", parent, "TOP", x or 0, y or 0)
    icon:SetTexCoord(0, 1, 0, 1)
    return icon
end

local RECENT_PROFIT_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintRecent.tga"
local MILESTONE_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintMilestone.tga"
local SHIELD_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintShield.tga"

local function AddUtilityIcon(parent, texturePath, x, y, size)
    local icon = parent:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(texturePath)
    local s = size or 18
    icon:SetSize(s, s)
    icon:SetPoint("LEFT", parent, "TOPLEFT", x or 12, y or -14)
    icon:SetTexCoord(0, 1, 0, 1)
    return icon
end

-- ============================================================================
-- GOLDMINT CUSTOM SCROLL FRAME
-- Replaces Blizzard's default UIPanelScrollFrameTemplate with the thin,
-- dark-navy/cyan scrollbar shown in the GoldMint visual references.
-- ============================================================================
local function CreateGoldMintScrollFrame(parent, topLeftX, topLeftY, bottomRightX, bottomRightY, contentWidth)
    local scroll = CreateFrame("ScrollFrame", nil, parent)
    scroll:SetPoint("TOPLEFT", topLeftX or 0, topLeftY or 0)
    scroll:SetPoint("BOTTOMRIGHT", bottomRightX or 0, bottomRightY or 0)
    scroll:EnableMouseWheel(true)

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(contentWidth or 600, 1)
    scroll:SetScrollChild(content)

    local bar = CreateFrame("Frame", nil, parent)
    bar:SetWidth(16)
    bar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -3, topLeftY or 0)
    bar:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -3, bottomRightY or 0)
    bar:EnableMouse(true)

    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0.008, 0.030, 0.050, 0.92)
    track:SetPoint("TOPLEFT", 4, 0)
    track:SetPoint("BOTTOMRIGHT", -4, 0)

    local trackLine = bar:CreateTexture(nil, "ARTWORK")
    trackLine:SetColorTexture(0.08, 0.34, 0.52, 0.85)
    trackLine:SetWidth(2)
    trackLine:SetPoint("TOP", bar, "TOP", 0, 0)
    trackLine:SetPoint("BOTTOM", bar, "BOTTOM", 0, 0)

    local innerLine = bar:CreateTexture(nil, "ARTWORK")
    innerLine:SetColorTexture(0.20, 0.78, 1.0, 0.42)
    innerLine:SetWidth(1)
    innerLine:SetPoint("TOP", bar, "TOP", 0, 0)
    innerLine:SetPoint("BOTTOM", bar, "BOTTOM", 0, 0)

    local thumb = CreateFrame("Button", nil, bar)
    thumb:SetWidth(8)
    thumb:SetHeight(44)
    thumb:SetPoint("TOP", bar, "TOP", 0, 0)
    thumb:EnableMouse(true)

    local thumbBG = thumb:CreateTexture(nil, "BACKGROUND")
    thumbBG:SetColorTexture(0.015, 0.075, 0.115, 0.96)
    thumbBG:SetAllPoints()

    local thumbLine = thumb:CreateTexture(nil, "ARTWORK")
    thumbLine:SetColorTexture(0.20, 0.78, 1.0, 0.95)
    thumbLine:SetWidth(2)
    thumbLine:SetPoint("TOP", thumb, "TOP", 0, 0)
    thumbLine:SetPoint("BOTTOM", thumb, "BOTTOM", 0, 0)

    local thumbEdge = thumb:CreateTexture(nil, "OVERLAY")
    thumbEdge:SetColorTexture(0.10, 0.34, 0.52, 0.9)
    thumbEdge:SetWidth(1)
    thumbEdge:SetPoint("TOP", thumb, "TOP", -3, 0)
    thumbEdge:SetPoint("BOTTOM", thumb, "BOTTOM", -3, 0)
    local thumbEdge2 = thumb:CreateTexture(nil, "OVERLAY")
    thumbEdge2:SetColorTexture(0.10, 0.34, 0.52, 0.9)
    thumbEdge2:SetWidth(1)
    thumbEdge2:SetPoint("TOP", thumb, "TOP", 3, 0)
    thumbEdge2:SetPoint("BOTTOM", thumb, "BOTTOM", 3, 0)

    local function UpdateBar()
        if not scroll:IsShown() then return end
        local range = math.max(0, scroll:GetVerticalScrollRange() or 0)
        local viewport = math.max(1, scroll:GetHeight() or 1)
        local trackHeight = math.max(1, bar:GetHeight() or 1)
        if range <= 0 then
            bar:Hide()
            return
        end
        bar:Show()
        local thumbHeight = math.max(34, math.min(trackHeight, math.floor((viewport / (viewport + range)) * trackHeight)))
        thumb:SetHeight(thumbHeight)
        local travel = math.max(0, trackHeight - thumbHeight)
        local frac = math.max(0, math.min(1, (scroll:GetVerticalScroll() or 0) / range))
        thumb:ClearAllPoints()
        thumb:SetPoint("TOP", bar, "TOP", 0, -travel * frac)
    end

    scroll.UpdateGoldMintScrollBar = UpdateBar
    scroll._goldMintBar = bar
    scroll._goldMintThumb = thumb
    scroll._goldMintContent = content

    scroll:SetScript("OnMouseWheel", function(self, delta)
        local step = math.max(24, self:GetHeight() * 0.18)
        local current = self:GetVerticalScroll() or 0
        local range = self:GetVerticalScrollRange() or 0
        self:SetVerticalScroll(math.max(0, math.min(range, current - delta * step)))
        UpdateBar()
    end)
    scroll:SetScript("OnVerticalScroll", function()
        UpdateBar()
    end)
    scroll:SetScript("OnSizeChanged", function()
        UpdateBar()
    end)
    scroll:SetScript("OnShow", function()
        C_Timer.After(0, UpdateBar)
    end)

    local dragging = false
    local dragStartY = 0
    local dragStartScroll = 0
    thumb:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        dragging = true
        dragStartY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        dragStartScroll = scroll:GetVerticalScroll() or 0
        self:SetAlpha(1.0)
    end)
    thumb:SetScript("OnMouseUp", function()
        dragging = false
    end)
    thumb:SetScript("OnHide", function()
        dragging = false
    end)
    bar:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local barTop = select(2, bar:GetTop()) or 0
        local localY = barTop - cursorY
        local trackHeight = math.max(1, bar:GetHeight())
        local thumbHeight = math.max(1, thumb:GetHeight())
        local travel = math.max(1, trackHeight - thumbHeight)
        local target = math.max(0, math.min(1, (localY - thumbHeight / 2) / travel))
        local range = scroll:GetVerticalScrollRange() or 0
        scroll:SetVerticalScroll(target * range)
        UpdateBar()
    end)
    thumb:SetScript("OnUpdate", function()
        if not dragging then return end
        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local delta = dragStartY - cursorY
        local travel = math.max(1, bar:GetHeight() - thumb:GetHeight())
        local range = scroll:GetVerticalScrollRange() or 0
        scroll:SetVerticalScroll(math.max(0, math.min(range, dragStartScroll + (delta / travel) * range)))
        UpdateBar()
    end)

    -- Row/layout changes are event-driven; avoid a per-frame size poll for the
    -- scrollbar.  Every content resize now updates the bar immediately.
    content:SetScript("OnSizeChanged", function(self)
        self._goldMintLastContentHeight = self:GetHeight()
        UpdateBar()
    end)

    C_Timer.After(0, UpdateBar)
    return scroll, content
end

local function BuildHeader()
    -- Dedicated top bar matching the reference: deep navy, subtle cyan framing,
    -- gold branding, and separated metric blocks.  It is a texture on the main
    -- frame so it can never cover the labels that sit above it.
    -- Build the header as three artwork sections so the decorative left and
    -- right ends stay visually intact while only the middle stretches to fit
    -- the dashboard width. This avoids the "single stretched box" look.
    local headerLeft = frame:CreateTexture(nil, "ARTWORK")
    headerLeft:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeader")
    headerLeft:SetPoint("TOPLEFT", -24, 22)
    headerLeft:SetSize(434, 115)
    headerLeft:SetTexCoord(0, 0.288, 0, 1)

    local headerCenter = frame:CreateTexture(nil, "ARTWORK")
    headerCenter:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeader")
    headerCenter:SetPoint("TOPLEFT", 410, 22)
    headerCenter:SetSize(580, 115)
    headerCenter:SetTexCoord(0.288, 0.712, 0, 1)

    local headerRight = frame:CreateTexture(nil, "ARTWORK")
    headerRight:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeader")
    headerRight:SetPoint("TOPLEFT", 990, 22)
    headerRight:SetSize(434, 115)
    headerRight:SetTexCoord(0.712, 1, 0, 1)

    panels.header = headerCenter
    panels.headerLeft = headerLeft
    panels.headerRight = headerRight

    local separatorXs = {690, 920, 1145}
    for _, x in ipairs(separatorXs) do
        local line = frame:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(0.14, 0.40, 0.58, 0.55)
        line:SetSize(1, 54)
        line:SetPoint("TOPLEFT", x, -15)
    end

    -- Supplied combined GoldMint header branding.  This replaces the separate
    -- logo/title/subtitle so the artwork stays proportioned as one coherent mark.
    local headerBrand = frame:CreateTexture(nil, "OVERLAY")
    headerBrand:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintHeaderBrand")
    headerBrand:SetSize(310, 99)
    headerBrand:SetPoint("TOPLEFT", 20, 14)
    headerBrand:SetTexCoord(0, 1, 0, 1)
    panels.headerBrand = headerBrand

    local coin = frame:CreateTexture(nil, "ARTWORK")
    coin:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintGoldCoin")
    coin:SetSize(22, 22)
    coin:SetPoint("TOPLEFT", 460, -17)
    labels.headerCoin = coin

    labels.headerGold = MakeLabel(frame, "GameFontHighlightLarge", "0g")
    labels.headerGold:SetPoint("TOPLEFT", 492, -20)
    labels.headerGold:SetWidth(235)
    labels.headerGold:SetTextColor(unpack(GOLD))
    labels.headerValue = MakeLabel(frame, "GameFontNormal", "Total Gold")
    labels.headerValue:SetPoint("TOPLEFT", 494, -51)
    labels.headerValue:SetWidth(220)
    labels.headerValue:SetTextColor(unpack(MUTED))

    -- Intention header card: frame the live Daily Focus intention so it reads
    -- as a deliberate header metric rather than loose text.  The card stays
    -- inside the existing header spacing and does not alter the label/value
    -- positions.
    local intentionCard = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    intentionCard:SetSize(218, 62)
    intentionCard:SetPoint("TOPLEFT", 702, -10)
    intentionCard:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 8, edgeSize = 10,
        insets = {left = 2, right = 2, top = 2, bottom = 2},
    })
    intentionCard:SetBackdropBorderColor(0.04, 0.30, 0.48, 0.95)
    panels.intentionCard = intentionCard

    labels.headerWeek = MakeLabel(frame, "GameFontHighlight", "—")
    labels.headerWeek:SetPoint("TOPLEFT", 718, -20)
    labels.headerWeek:SetTextColor(unpack(GREEN))
    labels.headerWeekLabel = MakeLabel(frame, "GameFontNormal", "Intention")
    labels.headerWeekLabel:SetPoint("TOPLEFT", 720, -51)
    labels.headerWeekLabel:SetTextColor(unpack(MUTED))

    -- Mail header card: keep the existing metric-card footprint, but use it
    -- as a simple current-character mail indicator. Daily Profit already has
    -- a dedicated place in the Overview, so it does not need to be duplicated
    -- in the header.
    local mailCard = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    mailCard:SetSize(166, 62)
    mailCard:SetPoint("TOPLEFT", 928, -10)
    mailCard:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 8, edgeSize = 10,
        insets = {left = 2, right = 2, top = 2, bottom = 2},
    })
    mailCard:SetBackdropBorderColor(0.04, 0.30, 0.48, 0.95)
    panels.mailCard = mailCard

    labels.mailTitle = MakeLabel(mailCard, "GameFontNormalSmall", "Mail", 146)
    labels.mailTitle:SetPoint("TOPLEFT", 10, -10)
    labels.mailTitle:SetTextColor(unpack(MUTED))
    labels.mailTitle:SetWordWrap(false)

    -- The supplied envelope artwork is shown only when mail is actually waiting.
    -- Keep the existing card footprint; the icon is an indicator, not a replacement
    -- for the mailbox status text.
    local mailIcon = mailCard:CreateTexture(nil, "ARTWORK")
    mailIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintMail")
    mailIcon:SetSize(46, 31)
    mailIcon:SetPoint("TOPLEFT", 7, -22)
    mailIcon:Hide()
    labels.mailIcon = mailIcon

    labels.mailStatus = MakeLabel(mailCard, "GameFontHighlightLarge", "—", 92)
    labels.mailStatus:SetPoint("TOPLEFT", 65, -27)
    labels.mailStatus:SetTextColor(unpack(MUTED))
    labels.mailStatus:SetWordWrap(false)

    labels.mailDetail = MakeLabel(mailCard, "GameFontNormalSmall", "Mailbox not scanned", 146)
    labels.mailDetail:SetPoint("TOPLEFT", 10, -48)
    labels.mailDetail:SetTextColor(unpack(MUTED))
    labels.mailDetail:SetWordWrap(false)

    -- Header metric cards use the compact glassy card treatment: framed graph
    -- tile, title, live value, and a real up/down artwork indicator.
    local function CreateHeaderMetricCard(key, x, accentColor)
        local card = CreateFrame("Frame", nil, frame, "BackdropTemplate")
        card:SetSize(198, 62)
        card:SetPoint("TOPLEFT", x, -10)
        card:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 8, edgeSize = 10,
            insets = {left = 2, right = 2, top = 2, bottom = 2},
        })
        card:SetBackdropColor(0.004, 0.018, 0.032, 0.82)
        card:SetBackdropBorderColor(0.04, 0.30, 0.48, 0.95)

        local iconBox = CreateFrame("Frame", nil, card, "BackdropTemplate")
        iconBox:SetSize(72, 52)
        iconBox:SetPoint("LEFT", 5, 0)
        iconBox:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = true, tileSize = 8, edgeSize = 1,
        })
        iconBox:SetBackdropColor(0.008, 0.035, 0.058, 0.94)
        iconBox:SetBackdropBorderColor(0.05, 0.32, 0.48, 0.95)

        local iconBase = iconBox:CreateTexture(nil, "ARTWORK")
        iconBase:SetColorTexture(0.01, 0.055, 0.085, 0.80)
        iconBase:SetPoint("TOPLEFT", 2, -2)
        iconBase:SetPoint("BOTTOMRIGHT", -2, 2)

        local graphLines = {}
        for i = 1, 7 do
            local line = iconBox:CreateTexture(nil, "OVERLAY")
            line:SetColorTexture(accentColor[1], accentColor[2], accentColor[3], 0.95)
            line:SetHeight(2)
            line:Hide()
            graphLines[i] = line
        end

        local title = MakeLabel(card, "GameFontNormal", "")
        title:SetPoint("TOPLEFT", 84, -13)
        title:SetWidth(104)
        title:SetTextColor(unpack(MUTED))

        local valueTemplate = key == "token" and "GameFontNormal" or "GameFontHighlightLarge"
        local value = MakeLabel(card, valueTemplate, "—")
        value:SetPoint("TOPLEFT", 84, -31)
        value:SetWidth(key == "token" and 100 or 84)
        value:SetMaxLines(1)
        value:SetWordWrap(false)
        value:SetTextColor(unpack(accentColor))

        local trend = card:CreateTexture(nil, "OVERLAY")
        trend:SetSize(18, 18)
        -- Keep the trend arrow beside the token value, but place it below the
        -- number so it does not compete with the price text.
        trend:SetPoint("TOPRIGHT", -10, -43)
        trend:Hide()

        labels[key .. "Card"] = card
        labels[key .. "IconBox"] = iconBox
        labels[key .. "IconBase"] = iconBase
        labels[key .. "GraphLines"] = graphLines
        labels[key .. "Title"] = title
        labels[key .. "Value"] = value
        labels[key .. "Trend"] = trend
        return card
    end

    CreateHeaderMetricCard("token", 1100, GOLD)

    labels.tokenTitle:SetText("|TInterface\\Icons\\WoW_Token01:16:16:0:0|t WoW Token")
    labels.tokenValue:SetText("—")

    -- Blizzard-style settings control in the former refresh-button position.
    -- The old red close X is intentionally removed; the dashboard is now
    -- visually controlled by the single circular gear button.
    local gear = CreateFrame("Button", "GoldMintDashboardSettingsButton", frame)
    gear:SetSize(34, 34)
    gear:SetPoint("TOPRIGHT", -48, -6)
    gear:SetFrameLevel(frame:GetFrameLevel() + 20)

    local gearIcon = gear:CreateTexture(nil, "ARTWORK")
    gearIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintSettingsGear")
    gearIcon:SetAllPoints(gear)

    gear:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    gear:SetScript("OnClick", function()
        if GoldMint.OpenOptions then
            GoldMint:OpenOptions()
        elseif InterfaceOptionsFrame_OpenToCategory then
            InterfaceOptionsFrame_OpenToCategory("GoldMint")
        else
            GoldMint.Print("GoldMint settings are not available yet.")
        end
    end)
    buttons.refresh = gear
    buttons.settings = gear
end

local function UpdateGoldProgress(widget, current, maxVal)
    current = tonumber(current) or 0
    maxVal = tonumber(maxVal) or 0
    local percentage = maxVal > 0 and math.min(math.max(current / maxVal, 0), 1.0) or 0

    local progressArc = widget and widget.ProgressArc
    if progressArc then
        progressArc:SetMinMaxValues(0, 100)
        progressArc:SetValue(percentage * 100)
        if progressArc.Fill then
            progressArc.Fill:Hide()
        end
    end

    -- The supplied glow line is the precise tracker for the current goal.
    if widget and widget.ProgressLine then
        widget.ProgressLine:SetMinMaxValues(0, 1)
        widget.ProgressLine:SetValue(percentage)
    end

    -- Legacy fallback segments are retained only for compatibility with older
    -- saved UI state/builds. The new glow line is the visible tracker.
    local segments = progressArc and progressArc._fallbackSegments or nil
    if segments then
        for _, seg in ipairs(segments) do seg:Hide() end
    end

    return percentage
end

local function CreateGoalWidget(parent)
    -- Pure-Lua goal tracker. The goal graph is a circular progress ring made
    -- entirely from Lua-created textures. The supplied line_graph.tga is used
    -- as the glowing blue artwork for every segment of the ring.
    local widget = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    widget:SetSize(440, 160)

    local leftBracket = widget:CreateTexture(nil, "BORDER")
    leftBracket:SetTexture("Interface\\Artifacts\\ArtifactTextures")
    leftBracket:SetSize(40, 140)
    leftBracket:SetPoint("CENTER", widget, "CENTER", -100, 15)
    leftBracket:SetTexCoord(0.45, 0.55, 0.10, 0.90)
    leftBracket:SetVertexColor(0.15, 0.25, 0.35, 0.80)
    widget.LeftBracket = leftBracket

    local rightBracket = widget:CreateTexture(nil, "BORDER")
    rightBracket:SetTexture("Interface\\Artifacts\\ArtifactTextures")
    rightBracket:SetSize(40, 140)
    rightBracket:SetPoint("CENTER", widget, "CENTER", 100, 15)
    rightBracket:SetTexCoord(0.55, 0.45, 0.10, 0.90)
    rightBracket:SetVertexColor(0.15, 0.25, 0.35, 0.80)
    widget.RightBracket = rightBracket

    -- Goal coin artwork sits immediately beside the left edge of the goal
    -- title. Keep a small gap so the icon never overlaps the "Y" in YOUR.
    local goalCoins = widget:CreateTexture(nil, "ARTWORK")
    goalCoins:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintGoalCoins.tga")
    goalCoins:SetSize(42, 37)
    goalCoins:SetPoint("TOPLEFT", widget, "TOPLEFT", 10, -1)
    goalCoins:SetTexCoord(0, 1, 0, 1)
    goalCoins:SetVertexColor(1, 1, 1, 1)
    widget.GoalCoins = goalCoins

    local title = widget:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetSize(350, 20)
    title:SetPoint("TOPLEFT", widget, "TOPLEFT", 60, -7)
    title:SetJustifyH("LEFT")
    title:SetTextColor(unpack(CYAN))
    widget.Title = title

    -- Underline the "YOU" portion of YOUR GOAL with a thick cyan rule.
    -- Keep it as its own texture so the underline remains fixed even when
    -- the active goal name changes.
    local goalUnderline = widget:CreateTexture(nil, "ARTWORK")
    goalUnderline:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 1)
    -- Match the standard dashboard section-title accent used by the other
    -- Home panels: identical width and thickness for a clean, symmetrical rail.
    goalUnderline:SetSize(38, 2)
    goalUnderline:SetPoint("TOPLEFT", widget, "TOPLEFT", 60, -27)
    widget.GoalYouUnderline = goalUnderline

    --------------------------------------------------------------------------
    -- Circular goal graph
    --
    -- WoW StatusBars are rectangular, so a circular graph is built from a
    -- ring of small textures. Each texture uses Assets/line_graph.tga and is
    -- rotated around the center. This keeps the exact supplied glow artwork
    -- while giving us a true circular 0-100% progress display.
    --------------------------------------------------------------------------
    local progressArc = CreateFrame("Frame", nil, widget)
    progressArc:SetSize(150, 150)
    progressArc:SetPoint("CENTER", widget, "CENTER", 0, -30)
    progressArc:SetFrameLevel(widget:GetFrameLevel() + 2)

    local RING_TEXTURE = "Interface\\AddOns\\GoldMint\\Assets\\line_graph"
    local SEGMENTS = 96
    local RADIUS = 58
    local SEGMENT_W = 7
    local SEGMENT_H = 8
    local TAU = math.pi * 2

    local ringBackground = {}
    local ringProgress = {}

    local function PositionRingSegment(tex, index)
        local angle = ((index - 1) / SEGMENTS) * TAU - (math.pi / 2)
        local x = math.cos(angle) * RADIUS
        local y = math.sin(angle) * RADIUS
        tex:SetPoint("CENTER", progressArc, "CENTER", x, y)
        tex:SetRotation(angle + (math.pi / 2))
    end

    local function CreateRingSegment(layer, index)
        local tex = progressArc:CreateTexture(nil, layer)
        tex:SetTexture(RING_TEXTURE)
        tex:SetSize(SEGMENT_W, SEGMENT_H)
        -- line_graph.tga is a large transparent canvas with the actual glow
        -- occupying only a narrow strip near the lower-middle of the image.
        -- Crop to the real glow artwork before rotating each progress segment.
        tex:SetTexCoord(0.281, 0.719, 0.500, 0.527)
        tex:SetBlendMode("ADD")
        PositionRingSegment(tex, index)
        return tex
    end

    for i = 1, SEGMENTS do
        -- Background is intentionally a plain, dim ring. Do NOT use the glow
        -- texture for the background or a 0% goal will look like a full ring.
        local bg = progressArc:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(0.035, 0.12, 0.16, 0.55)
        bg:SetSize(SEGMENT_W, 3)
        PositionRingSegment(bg, i)
        ringBackground[i] = bg

        local fill = CreateRingSegment("ARTWORK", i)
        fill:SetVertexColor(0.0, 0.75, 1.0, 0.98)
        fill:Hide()
        ringProgress[i] = fill
    end

    -- Compatibility methods keep the existing Refresh/update pipeline intact.
    function progressArc:SetMinMaxValues(minValue, maxValue)
        self._minValue = tonumber(minValue) or 0
        self._maxValue = tonumber(maxValue) or 100
    end

    function progressArc:SetValue(value)
        local minValue = self._minValue or 0
        local maxValue = self._maxValue or 100
        local numeric = tonumber(value) or minValue
        local range = maxValue - minValue
        local fraction = range > 0 and ((numeric - minValue) / range) or 0
        fraction = math.max(0, math.min(1, fraction))
        self._fraction = fraction

        local visible = math.floor((fraction * SEGMENTS) + 0.5)
        for i = 1, SEGMENTS do
            ringProgress[i]:SetShown(i <= visible)
        end
    end

    function progressArc:GetValue()
        return self._fraction or 0
    end

    progressArc:SetMinMaxValues(0, 100)
    progressArc:SetValue(0)
    progressArc.RingBackground = ringBackground
    progressArc.RingProgress = ringProgress
    progressArc._fallbackSegments = {}
    widget.ProgressArc = progressArc

    -- Percentage centered inside the circular graph.
    local percent = progressArc:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    percent:SetSize(200, 20)
    percent:SetPoint("CENTER", progressArc, "CENTER", 0, 0)
    percent:SetJustifyH("CENTER")
    percent:SetText("0%")
    percent:SetTextColor(unpack(GOLD))
    percent:SetShadowOffset(1, -1)
    progressArc.Text = percent

    -- Retained as a hidden compatibility handle. The line_graph texture is now
    -- used by the circular ring itself rather than a separate horizontal bar.
    local progressLine = CreateFrame("StatusBar", nil, widget)
    progressLine:SetSize(1, 1)
    progressLine:SetMinMaxValues(0, 1)
    progressLine:SetValue(0)
    progressLine:SetStatusBarTexture(RING_TEXTURE)
    progressLine:Hide()
    widget.ProgressLine = progressLine

    local pacing = widget:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    pacing:SetSize(300, 14)
    pacing:SetPoint("BOTTOMLEFT", widget, "BOTTOMLEFT", 16, -35)
    pacing:SetJustifyH("LEFT")
    pacing:SetText("Current Pacing: —")
    pacing:SetTextColor(unpack(MUTED))
    widget.PacingText = pacing

    local estimate = widget:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    estimate:SetSize(300, 14)
    estimate:SetPoint("BOTTOMLEFT", widget, "BOTTOMLEFT", 16, -47)
    estimate:SetJustifyH("LEFT")
    estimate:SetText("Goal Est: —")
    estimate:SetTextColor(unpack(MUTED))
    widget.EstText = estimate

    local manageBtn = CreateFrame("Button", nil, widget, "BackdropTemplate")
    manageBtn:SetSize(104, 24)
    manageBtn:SetPoint("BOTTOMRIGHT", widget, "BOTTOMRIGHT", -16, -47)
    manageBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true,
        tileSize = 8,
        edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    manageBtn:SetBackdropColor(0.03, 0.07, 0.10, 0.92)
    manageBtn:SetBackdropBorderColor(unpack(CYAN))

    local manageText = manageBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    manageText:SetPoint("CENTER")
    manageText:SetText("MANAGE GOAL")
    manageText:SetTextColor(unpack(GOLD))
    manageBtn:SetFontString(manageText)
    manageBtn:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(1, 0.82, 0.0, 1)
    end)
    manageBtn:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(unpack(CYAN))
    end)
    manageBtn:SetScript("OnClick", function()
        OpenGoalEditor()
    end)
    widget.ManageButton = manageBtn

    return widget
end

local function BuildGoalPanel()
    local p = Panel(frame, 445, 235, "TOPLEFT", 225, -126, {0.16, 0.38, 0.58, 0.95})
    panels.goal = p

    local goalWidget = CreateGoalWidget(p)
    goalWidget:SetPoint("TOPLEFT", 2, -12)
    goalWidget:SetFrameLevel(p:GetFrameLevel() + 1)
    panels.goalWidget = goalWidget

    bars.goalCircle = goalWidget.ProgressArc
    bars.goalSegments = goalWidget.ProgressArc._fallbackSegments
    bars.goalWidget = goalWidget

    labels.goalName = goalWidget.Title
    labels.goalTarget = goalWidget.ProgressArc.Text
    labels.goalProgressLine = goalWidget.ProgressLine
    labels.goalProgress = goalWidget.ProgressArc.Text
    labels.goalRemaining = goalWidget.EstText
    labels.checkpoint = goalWidget.PacingText
    labels.checkpointDistance = goalWidget.EstText
    labels.pacing = goalWidget.PacingText
    labels.goalAction = goalWidget.Title

    -- Hidden compatibility bar retained for older dashboard code.
    bars.goal = CreateFrame("StatusBar", nil, p)
    bars.goal:SetSize(1, 1)
    bars.goal:SetMinMaxValues(0, 1)
    bars.goal:Hide()
end

local goalEditor
local goalFields = {}

local function MakeEditBox(parent, labelText, width, y, numeric)
    local label = MakeLabel(parent, "GameFontNormal", labelText)
    label:SetPoint("TOPLEFT", 24, y)
    label:SetTextColor(unpack(MUTED))

    local edit = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    edit:SetSize(width, 30)
    edit:SetPoint("TOPLEFT", 22, y - 24)
    edit:SetAutoFocus(false)
    edit:SetTextInsets(8, 8, 0, 0)
    if numeric then
        edit:SetNumeric(true)
    end
    return edit
end

local function ParseGoldInput(text)
    text = tostring(text or "")
    text = text:gsub("[, ]", "")
    local n = tonumber(text)
    if not n then return nil end
    return math.floor(n * 10000)
end

local function ParseDaysInput(text)
    text = tostring(text or ""):gsub("[, ]", "")
    if text == "" then return nil end
    local n = tonumber(text)
    if not n or n < 1 then return nil end
    return math.floor(n)
end

local function CloseGoalEditor()
    if goalEditor then goalEditor:Hide() end
end

OpenGoalEditor = function()
    if not goalEditor then
        goalEditor = CreateFrame("Frame", "GoldMintGoalEditor", frame, "BackdropTemplate")
        goalEditor:SetSize(620, 610)
        goalEditor:SetPoint("CENTER")
        goalEditor:SetFrameStrata("DIALOG")
        goalEditor:SetFrameLevel(250)
        if UISpecialFrames then
            tinsert(UISpecialFrames, "GoldMintGoalEditor")
        end
        goalEditor:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 18,
            insets = {left = 6, right = 6, top = 6, bottom = 6},
        })
        goalEditor:SetBackdropColor(0.004, 0.010, 0.016, 1.0)
        goalEditor:SetBackdropBorderColor(0.10, 0.42, 0.66, 0.98)

        AddSectionTitle(goalEditor, "goalEditorTitle", "PROJECT MANAGEMENT", CYAN)

        goalFields.name = MakeEditBox(goalEditor, "Project Name", 572, -52, false)
        goalFields.target = MakeEditBox(goalEditor, "Target Gold", 260, -122, true)

        local deadlineLabel = MakeLabel(goalEditor, "GameFontNormal", "Deadline (days, optional)")
        deadlineLabel:SetPoint("TOPLEFT", 324, -122)
        deadlineLabel:SetTextColor(unpack(MUTED))
        goalFields.deadline = CreateFrame("EditBox", nil, goalEditor, "InputBoxTemplate")
        goalFields.deadline:SetSize(260, 30)
        goalFields.deadline:SetPoint("TOPLEFT", 322, -146)
        goalFields.deadline:SetAutoFocus(false)
        goalFields.deadline:SetNumeric(true)
        goalFields.deadline:SetTextInsets(8, 8, 0, 0)

        local projectTypeLabel = MakeLabel(goalEditor, "GameFontNormal", "Project Type")
        projectTypeLabel:SetPoint("TOPLEFT", 24, -202)
        projectTypeLabel:SetTextColor(unpack(MUTED))
        local projectTypes = { "Gold Goal", "Stockpile", "Buy & Resell" }
        local selectedProjectType = "Gold Goal"
        local projectTypeButtons = {}
        local function SelectProjectType(value)
            selectedProjectType = value
            for typeName, button in pairs(projectTypeButtons) do
                if typeName == selectedProjectType then
                    button:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
                    button:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
                    button.text:SetTextColor(1.0, 0.86, 0.38)
                else
                    button:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
                    button:SetBackdropBorderColor(unpack(CYAN))
                    button.text:SetTextColor(unpack(MUTED))
                end
            end
        end
        -- Five project-type buttons must fit inside the 620px editor without
        -- touching the dialog border.  Keep a compact 8px gap and leave a
        -- consistent 18px inset on both sides.
        local projectTypeButtonWidth = 104
        local projectTypeGap = 8
        for i, typeName in ipairs(projectTypes) do
            local b = MakeButton(goalEditor, typeName, projectTypeButtonWidth, 28, "secondary")
            b:SetPoint("TOPLEFT", 18 + (i - 1) * (projectTypeButtonWidth + projectTypeGap), -218)
            projectTypeButtons[typeName] = b
            b:SetScript("OnClick", function(self, button)
                if button == "LeftButton" then
                    SelectProjectType(typeName)
                end
            end)
        end
        SelectProjectType(selectedProjectType)

        goalFields.budget = MakeEditBox(goalEditor, "Capital Budget (optional)", 260, -266, true)
        goalFields.expectedRevenue = MakeEditBox(goalEditor, "Expected Revenue (optional)", 260, -266, true)
        goalFields.expectedRevenue:SetPoint("TOPLEFT", 322, -290)
        goalFields.expectedRevenue:SetTextInsets(8, 8, 0, 0)

        goalFields.expectedCost = MakeEditBox(goalEditor, "Expected Cost (optional)", 260, -336, true)
        goalFields.nextAction = MakeEditBox(goalEditor, "Next Action (optional)", 260, -336, false)
        goalFields.nextAction:SetPoint("TOPLEFT", 322, -360)
        goalFields.nextAction:SetTextInsets(8, 8, 0, 0)

        local checkpointLabel = MakeLabel(goalEditor, "GameFontNormal", "Checkpoint (optional)")
        checkpointLabel:SetPoint("TOPLEFT", 24, -404)
        checkpointLabel:SetTextColor(unpack(MUTED))

        goalFields.checkpoint = CreateFrame("EditBox", nil, goalEditor, "InputBoxTemplate")
        goalFields.checkpoint:SetSize(260, 30)
        goalFields.checkpoint:SetPoint("TOPLEFT", 22, -428)
        goalFields.checkpoint:SetAutoFocus(false)
        goalFields.checkpoint:SetNumeric(true)
        goalFields.checkpoint:SetTextInsets(8, 8, 0, 0)

        goalFields.checkpointName = CreateFrame("EditBox", nil, goalEditor, "InputBoxTemplate")
        goalFields.checkpointName:SetSize(260, 30)
        goalFields.checkpointName:SetPoint("TOPLEFT", 322, -428)
        goalFields.checkpointName:SetAutoFocus(false)
        goalFields.checkpointName:SetTextInsets(8, 8, 0, 0)

        local cpHint = MakeLabel(goalEditor, "GameFontNormalSmall", "Gold amount     Checkpoint name")
        cpHint:SetPoint("TOPLEFT", 28, -462)
        cpHint:SetTextColor(unpack(MUTED))

        -- Keep all four actions on one clean row with fixed spacing.
        -- The previous positions caused CANCEL and MARK COMPLETE to overlap.
        -- Four actions, equal visual spacing, and no overlap.
        local save = MakeButton(goalEditor, "SAVE GOAL", 120, 34, "primary")
        save:SetPoint("BOTTOMLEFT", 18, 18)

        local cancel = MakeButton(goalEditor, "CANCEL", 90, 34, "secondary")
        cancel:SetPoint("BOTTOMLEFT", 146, 18)

        local complete = MakeButton(goalEditor, "MARK COMPLETE", 120, 34, "secondary")
        complete:SetPoint("BOTTOMLEFT", 244, 18)

        local clear = MakeButton(goalEditor, "CLEAR GOAL", 110, 34, "secondary")
        clear:SetPoint("BOTTOMLEFT", 372, 18)

        local function RefreshEditorFields()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                goalFields.name:SetText(active.name or "")
                goalFields.target:SetText(tostring(math.floor((tonumber(active.target) or 0) / 10000)))
                local days = active.deadline and math.ceil(math.max(0, (tonumber(active.deadline) - time()) / 86400)) or nil
                goalFields.deadline:SetText(days and tostring(days) or "")
                selectedProjectType = active.projectType or "Gold Goal"
                SelectProjectType(selectedProjectType)
                goalFields.budget:SetText((tonumber(active.budget) or 0) > 0 and tostring(math.floor((tonumber(active.budget) or 0) / 10000)) or "")
                goalFields.expectedRevenue:SetText((tonumber(active.expectedRevenue) or 0) > 0 and tostring(math.floor((tonumber(active.expectedRevenue) or 0) / 10000)) or "")
                goalFields.expectedCost:SetText((tonumber(active.expectedCost) or 0) > 0 and tostring(math.floor((tonumber(active.expectedCost) or 0) / 10000)) or "")
                goalFields.nextAction:SetText(active.nextAction or "")
                if active.nextCheckpoint then
                    goalFields.checkpoint:SetText(tostring(math.floor((tonumber(active.nextCheckpoint.amount) or 0) / 10000)))
                    goalFields.checkpointName:SetText(active.nextCheckpoint.name or "")
                else
                    goalFields.checkpoint:SetText("")
                    goalFields.checkpointName:SetText("")
                end
            else
                goalFields.name:SetText("")
                goalFields.target:SetText("")
                goalFields.deadline:SetText("")
                selectedProjectType = "Gold Goal"
                SelectProjectType(selectedProjectType)
                goalFields.budget:SetText("")
                goalFields.expectedRevenue:SetText("")
                goalFields.expectedCost:SetText("")
                goalFields.nextAction:SetText("")
                goalFields.checkpoint:SetText("")
                goalFields.checkpointName:SetText("")
            end
        end

        save:SetScript("OnClick", function()
            local name = strtrim(goalFields.name:GetText() or "")
            local target = ParseGoldInput(goalFields.target:GetText())
            local days = ParseDaysInput(goalFields.deadline:GetText())
            if name == "" then
                GoldMint.Print("Goal name is required.")
                return
            end
            if not target or target <= 0 then
                GoldMint.Print("Target gold must be greater than 0.")
                return
            end

            local deadline = days and (time() + days * 86400) or nil
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            local result, err
            if active then
                result, err = GoldMint.Milestones:UpdateGoal(active.id, {
                    name = name, target = target, deadline = deadline, type = "gold",
                    projectType = selectedProjectType,
                    budget = ParseGoldInput(goalFields.budget:GetText()) or 0,
                    expectedRevenue = ParseGoldInput(goalFields.expectedRevenue:GetText()) or 0,
                    expectedCost = ParseGoldInput(goalFields.expectedCost:GetText()) or 0,
                    nextAction = strtrim(goalFields.nextAction:GetText() or "") ~= "" and strtrim(goalFields.nextAction:GetText()) or nil,
                })
            else
                result, err = GoldMint.Milestones:CreateGoal(name, target, {
                    type = "gold", deadline = deadline,
                    projectType = selectedProjectType,
                    budget = ParseGoldInput(goalFields.budget:GetText()) or 0,
                    expectedRevenue = ParseGoldInput(goalFields.expectedRevenue:GetText()) or 0,
                    expectedCost = ParseGoldInput(goalFields.expectedCost:GetText()) or 0,
                    nextAction = strtrim(goalFields.nextAction:GetText() or "") ~= "" and strtrim(goalFields.nextAction:GetText()) or nil,
                })
            end
            if not result then
                GoldMint.Print("Unable to save goal: " .. tostring(err))
                return
            end

            local cp = ParseGoldInput(goalFields.checkpoint:GetText())
            local cpName = strtrim(goalFields.checkpointName:GetText() or "")
            if cp then
                if cp >= target then
                    GoldMint.Print("Checkpoint must be below the goal target.")
                    return
                end
                local current = GoldMint.Milestones:GetActiveGoal()
                if current then
                    local cpResult, cpErr = GoldMint.Milestones:SetCheckpoint(current.id, cp, cpName ~= "" and cpName or nil)
                    if not cpResult then
                        GoldMint.Print("Unable to save checkpoint: " .. tostring(cpErr))
                    end
                end
            end

            CloseGoalEditor()
            Refresh()
            GoldMint.Print("Project saved: " .. name .. " | Target: " .. FormatGold(target))
        end)

        cancel:SetScript("OnClick", CloseGoalEditor)

        clear:SetScript("OnClick", function()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:DeleteGoal(active.id)
                CloseGoalEditor()
                Refresh()
                GoldMint.Print("Active project cleared.")
            else
                GoldMint.Print("No active project to clear.")
            end
        end)

        complete:SetScript("OnClick", function()
            local active = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:CompleteGoal(active.id, "manual")
                CloseGoalEditor()
                Refresh()
                GoldMint.Print("Project marked complete: " .. tostring(active.name))
            else
                GoldMint.Print("No active project to complete.")
            end
        end)

        goalEditor:SetScript("OnShow", RefreshEditorFields)
    end

    goalEditor:Show()
    goalEditor:Raise()
end

local function BuildMomentumPanel()
    local p = Panel(frame, 300, 235, "TOPLEFT", 685, -126, {0.10, 0.45, 0.42, 0.95})
    panels.momentum = p
    -- Profit & Velocity uses the supplied market-growth artwork immediately
    -- beside the P in the section title.  The source image is stored as a
    -- transparent TGA so WoW can render it without a black background.
    local profitVelocityIcon = p:CreateTexture(nil, "ARTWORK")
    profitVelocityIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintProfitVelocity.tga")
    profitVelocityIcon:SetSize(22, 20)
    profitVelocityIcon:SetPoint("TOPLEFT", p, "TOPLEFT", 18, -12)
    profitVelocityIcon:SetTexCoord(0, 1, 0, 1)
    labels.momentumProfitVelocityIcon = profitVelocityIcon

    AddSectionTitle(p, "momentumTitle", "PROFIT & VELOCITY", CYAN, 44, -14)

    labels.momentumStatus = MakeLabel(p, "GameFontNormalSmall", "This Week", 250)
    labels.momentumStatus:SetPoint("TOPLEFT", 18, -39)
    labels.momentumStatus:SetTextColor(unpack(MUTED))

    labels.momentumHint = MakeLabel(p, "GameFontNormalSmall", "", 250)
    labels.momentumHint:SetPoint("TOPLEFT", 18, -207)
    labels.momentumHint:SetTextColor(unpack(MUTED))
    labels.momentumHint:SetJustifyH("CENTER")

    labels.momentumEarnedValue = MakeLabel(p, "GameFontHighlightLarge", "+0g", 260)
    labels.momentumEarnedValue:SetPoint("TOPLEFT", 18, -59)
    labels.momentumEarnedValue:SetTextColor(unpack(GREEN))
    labels.momentumEarnedValue:SetJustifyH("CENTER")

    labels.momentumSpentValue = MakeLabel(p, "GameFontNormalSmall", "Hourly Rate: —", 260)
    labels.momentumSpentValue:SetPoint("TOPLEFT", 18, -171)
    labels.momentumSpentValue:SetTextColor(unpack(MUTED))
    labels.momentumSpentValue:SetJustifyH("CENTER")

    labels.momentumNetValue = MakeLabel(p, "GameFontNormalSmall", "", 1)
    labels.momentumNetValue:Hide()

    -- Seven-point profit trend. Render this as a compact dashboard graph:
    -- subtle grid, translucent area fill, a thin trend line, and glowing
    -- point markers. The data still comes from the same saved history.
    labels.momentumGraphLines = {}
    labels.momentumGraphPoints = {}
    labels.momentumGraphFill = {}
    labels.momentumGraphGrid = {}

    local gx, gy, gw, gh = 24, 91, 252, 60

    -- Grid: four horizontal guides and six vertical guides, kept deliberately
    -- faint so the profit trend remains the visual focus.
    for i = 0, 4 do
        local grid = p:CreateTexture(nil, "BACKGROUND")
        grid:SetColorTexture(0.16, 0.27, 0.32, 0.42)
        grid:SetSize(gw, 1)
        grid:SetPoint("TOPLEFT", p, "TOPLEFT", gx, -(gy + (gh * i / 4)))
        labels.momentumGraphGrid[#labels.momentumGraphGrid + 1] = grid
    end
    for i = 0, 6 do
        local grid = p:CreateTexture(nil, "BACKGROUND")
        grid:SetColorTexture(0.16, 0.27, 0.32, 0.30)
        grid:SetSize(1, gh)
        grid:SetPoint("TOPLEFT", p, "TOPLEFT", gx + (gw * i / 6), -gy)
        labels.momentumGraphGrid[#labels.momentumGraphGrid + 1] = grid
    end

    -- Translucent area under the seven-point trend. Each vertical strip is
    -- clipped to the graph bounds and sized from the baseline to the line.
    for i = 0, gw - 1, 2 do
        local fill = p:CreateTexture(nil, "ARTWORK")
        fill:SetColorTexture(0.05, 0.34, 0.43, 0.18)
        fill:SetWidth(2)
        fill:SetPoint("TOPLEFT", p, "TOPLEFT", gx + i, -(gy + gh))
        fill:SetHeight(1)
        fill:Hide()
        labels.momentumGraphFill[#labels.momentumGraphFill + 1] = fill
    end

    -- Six line segments connect the seven data points.
    for i = 1, 6 do
        local line = p:CreateTexture(nil, "OVERLAY")
        line:SetColorTexture(0.70, 0.82, 0.84, 0.90)
        line:SetHeight(2)
        line:Hide()
        labels.momentumGraphLines[i] = line
    end

    -- Small outer glow + bright center for each data point.
    for i = 1, 7 do
        local glow = p:CreateTexture(nil, "OVERLAY")
        glow:SetColorTexture(0.18, 0.72, 0.82, 0.16)
        glow:SetSize(12, 12)
        glow:Hide()

        local dot = p:CreateTexture(nil, "OVERLAY")
        dot:SetColorTexture(0.78, 0.90, 0.91, 0.98)
        dot:SetSize(6, 6)
        dot:Hide()

        labels.momentumGraphPoints[i] = {glow = glow, dot = dot}
    end

    labels.momentumGraphArea = {x=gx, y=gy, w=gw, h=gh}

    labels.momentumAxisLeft = MakeLabel(p, "GameFontNormalSmall", "7 Day", 45)
    labels.momentumAxisLeft:SetPoint("TOPLEFT", 18, -151)
    labels.momentumAxisLeft:SetTextColor(unpack(MUTED))
    labels.momentumAxisRight = MakeLabel(p, "GameFontNormalSmall", "7 Day", 45)
    labels.momentumAxisRight:SetPoint("TOPRIGHT", -18, -151)
    labels.momentumAxisRight:SetTextColor(unpack(MUTED))
    labels.momentumWeekTotal = MakeLabel(p, "GameFontNormalSmall", "Total Week: —", 260)
    labels.momentumWeekTotal:SetPoint("TOPLEFT", 18, -188)
    labels.momentumWeekTotal:SetTextColor(unpack(MUTED))
    labels.momentumWeekTotal:SetJustifyH("CENTER")

    -- Preserve the old row keys for compatibility with refresh logic, but keep
    -- them visually subordinate to the new hero graph.
    for _, key in ipairs({"momentumEarnedName", "momentumSpentName", "momentumNetName"}) do
        if labels[key] then labels[key]:Hide() end
    end
end

local function GetOnboardingState()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    local state = GoldMintDB.settings.onboarding
    if type(state) ~= "table" then
        state = {}
        GoldMintDB.settings.onboarding = state
    end
    state.version = tonumber(state.version) or 1
    state.skipped = type(state.skipped) == "table" and state.skipped or {}
    return state
end

local function GetOnboardingSteps()
    local characterKey = GoldMint.characterKey
    local mailCharacter = characterKey and GoldMintDB.mailTracking and GoldMintDB.mailTracking.characters and GoldMintDB.mailTracking.characters[characterKey] or nil
    return {
        {
            id = "mail",
            title = "Scan your mailbox",
            detail = "Open your mailbox once so incoming gold and items can be tracked.",
            done = mailCharacter and tonumber(mailCharacter.lastScanAt or 0) > 0,
            open = function()
                GoldMint.Print("Open your WoW mailbox. GoldMint will track incoming gold and items while it is open.")
            end,
        },
    }
end

local function GetNextOnboardingStep()
    local state = GetOnboardingState()
    for _, step in ipairs(GetOnboardingSteps()) do
        if step.done then
            state.skipped[step.id] = nil
        elseif not state.skipped[step.id] then
            return step
        end
    end
    return nil
end

local NEXT_STEP_ICON = "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNextStep.tga"

local function BuildNextStepPanel()
    local p = Panel(frame, 445, 220, "TOPLEFT", 225, -382, {0.45, 0.34, 0.10, 0.95})
    panels.next = p

    local icon = p:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(NEXT_STEP_ICON)
    icon:SetSize(28, 34)
    icon:SetPoint("TOPLEFT", p, "TOPLEFT", 18, -7)
    icon:SetTexCoord(0, 1, 0, 1)
    icon:SetVertexColor(1, 1, 1, 1)
    panels.nextStepIcon = icon

    labels.nextTitle = MakeLabel(p, "GameFontNormalLarge", "YOUR NEXT STEP")
    labels.nextTitle:SetPoint("TOPLEFT", p, "TOPLEFT", 52, -14)
    -- Match the cyan section-header treatment used by the other dashboard panels.
    labels.nextTitle:SetTextColor(unpack(CYAN))
    labels.nextTitle:SetShadowOffset(1, -1)
    Accent(p, "TOPLEFT", 52, -32, 38, CYAN)

    labels.nextText = MakeLabel(p, "GameFontHighlight", "No immediate recommendation")
    labels.nextText:SetPoint("TOPLEFT", 20, -54)
    labels.nextText:SetWidth(400)
    labels.nextText:SetHeight(48)

    labels.nextDetail = MakeLabel(p, "GameFontNormal", "")
    labels.nextDetail:SetPoint("TOPLEFT", 20, -108)
    labels.nextDetail:SetWidth(400)
    labels.nextDetail:SetHeight(62)
    labels.nextDetail:SetTextColor(unpack(MUTED))
    labels.nextDetail:SetWordWrap(true)

    buttons.next = MakeButton(p, "DO THIS", 145, 30, "primary")
    buttons.next:SetPoint("BOTTOMLEFT", 20, 20)
    buttons.next:Disable()

    buttons.nextLater = MakeButton(p, "NOT NOW", 145, 30, "secondary")
    buttons.nextLater:SetPoint("BOTTOMRIGHT", -20, 20)
end

local function BuildSessionPanel()
    local p = Panel(frame, 325, 235, "TOPLEFT", 1010, -126, {0.10, 0.45, 0.42, 0.95})
    panels.session = p

    -- Session Momentum icon: the user-supplied stopwatch artwork is loaded
    -- from the addon assets and sits immediately to the left of the S.
    local sessionMomentumIcon = p:CreateTexture(nil, "ARTWORK")
    sessionMomentumIcon:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintSessionMomentum.tga")
    sessionMomentumIcon:SetSize(24, 24)
    sessionMomentumIcon:SetPoint("TOPLEFT", p, "TOPLEFT", 16, -8)
    sessionMomentumIcon:SetTexCoord(0, 1, 0, 1)
    labels.sessionMomentumIcon = sessionMomentumIcon

    AddSectionTitle(p, "sessionTitle", "SESSION MOMENTUM", CYAN, 46, -14)

    labels.sessionNet = MakeLabel(p, "GameFontHighlightLarge", "+0g", 285)
    labels.sessionNet:SetPoint("TOPLEFT", 18, -48)
    labels.sessionNet:SetJustifyH("CENTER")
    labels.sessionNet:SetTextColor(unpack(GOLD))

    labels.sessionStartName = MakeLabel(p, "GameFontNormalSmall", "SESSION PROFIT", 285)
    labels.sessionStartName:SetPoint("TOPLEFT", 18, -84)
    labels.sessionStartName:SetJustifyH("CENTER")
    labels.sessionStartName:SetTextColor(unpack(MUTED))

    labels.sessionRate = MakeLabel(p, "GameFontNormal", "+0g/hr", 285)
    labels.sessionRate:SetPoint("TOPLEFT", 18, -116)
    labels.sessionRate:SetJustifyH("CENTER")
    labels.sessionRate:SetTextColor(unpack(GREEN))

    labels.sessionEndName = MakeLabel(p, "GameFontNormalSmall", "Current Hourly Rate", 285)
    labels.sessionEndName:SetPoint("TOPLEFT", 18, -142)
    labels.sessionEndName:SetJustifyH("CENTER")
    labels.sessionEndName:SetTextColor(unpack(MUTED))

    labels.sessionStart = MakeLabel(p, "GameFontNormalSmall", "", 1)
    labels.sessionStart:Hide()
    labels.sessionEnd = MakeLabel(p, "GameFontNormalSmall", "", 1)
    labels.sessionEnd:Hide()

    labels.sessionTopSources = MakeLabel(p, "GameFontNormalSmall", "Sources: —", 285)
    labels.sessionTopSources:SetPoint("TOPLEFT", 18, -174)
    labels.sessionTopSources:SetJustifyH("CENTER")
    labels.sessionTopSources:SetTextColor(unpack(MUTED))

    labels.sessionNetDetail = MakeLabel(p, "GameFontNormalSmall", "", 285)
    labels.sessionNetDetail:SetPoint("TOPLEFT", 18, -202)
    labels.sessionNetDetail:SetJustifyH("CENTER")
    labels.sessionNetDetail:SetTextColor(unpack(MUTED))
end

local function BuildBottomPanels()
    local rail = CreateFrame("Frame", nil, frame)
    rail:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 225, 32)
    rail:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 32)
    rail:SetHeight(150)
    rail:SetFrameLevel(frame:GetFrameLevel() + 4)
    panels.homeUtilityRail = rail

    local function HomeCard(w, x)
        return Panel(rail, w, 150, "BOTTOMLEFT", x, 0, {0.08,0.30,0.46,0.92})
    end

    -- Active Cooldowns now lives beside the Getting Started / Next Step panel
    -- on the main Home canvas instead of in the bottom utility rail.
    -- Keeping it on the main canvas makes the profession status immediately
    -- visible without giving Cooldowns its own page.
    panels.cooldowns = Panel(frame, 300, 220, "TOPLEFT", 685, -382, {0.08,0.30,0.46,0.92})
    panels.milestone = HomeCard(252, 0)
    panels.shield = HomeCard(312, 262)

    local p = panels.cooldowns
    local cooldownTitleIcon = AddActiveCooldownIcon(p, 0, 0, 18)
    cooldownTitleIcon:ClearAllPoints(); cooldownTitleIcon:SetPoint("TOPLEFT", p, "TOPLEFT", 18, -12)
    cooldownTitleIcon:SetSize(22, 20)
    AddSectionTitle(p, "cooldownsTitle", "ACTIVE COOLDOWNS", CYAN, 44, -14)
    labels.cooldownsTitle:SetWidth(202)
    labels.cooldownsTitle:SetWordWrap(false)
    local choose = CreateFrame("Button", nil, p, "BackdropTemplate")
    choose:SetSize(64, 28)
    choose:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 12, 10)
    choose:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    choose:SetBackdropColor(0.004, 0.010, 0.016, 0.98)
    choose:SetBackdropBorderColor(0.10, 0.72, 0.88, 1.0)
    local chooseText = choose:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    chooseText:SetPoint("CENTER", 0, 0)
    chooseText:SetText("TRACK")
    chooseText:SetTextColor(1.0, 0.82, 0.25)
    choose:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.025, 0.075, 0.095, 1.0)
        self:SetBackdropBorderColor(0.22, 0.92, 1.0, 1.0)
        chooseText:SetTextColor(1.0, 0.90, 0.42)
    end)
    choose:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0.004, 0.010, 0.016, 0.98)
        self:SetBackdropBorderColor(0.10, 0.72, 0.88, 1.0)
        chooseText:SetTextColor(1.0, 0.82, 0.25)
    end)
    choose:SetScript("OnClick", function()
        if panels.cooldownPicker then panels.cooldownPicker:Hide(); panels.cooldownPicker = nil end
        local picker = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        panels.cooldownPicker = picker
        picker:SetFrameStrata("DIALOG"); picker:SetFrameLevel(100)
        picker:SetSize(310, 340); picker:SetPoint("TOPLEFT", p, "BOTTOMLEFT", 0, -4)
        picker:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=8,right=8,top=8,bottom=8}})
        local title = picker:CreateFontString(nil,"OVERLAY","GameFontNormal")
        title:SetPoint("TOPLEFT",16,-14); title:SetText("Choose Home Cooldowns")
        local close = CreateFrame("Button",nil,picker,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",-4,-4)
        local recipes = GoldMint.Cooldowns and GoldMint.Cooldowns.GetDiscoveredRecipes and GoldMint.Cooldowns:GetDiscoveredRecipes() or {}
        local scroll = CreateFrame("ScrollFrame",nil,picker,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",14,-42); scroll:SetPoint("BOTTOMRIGHT",-30,14)
        local content = CreateFrame("Frame",nil,scroll); content:SetSize(250, math.max(1,#recipes*24)); scroll:SetScrollChild(content)
        if #recipes == 0 then
            local empty = content:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            empty:SetPoint("TOPLEFT",4,-4); empty:SetText("Open a profession to discover cooldowns.")
        end
        for i, recipe in ipairs(recipes) do
            local cb = CreateFrame("CheckButton",nil,content,"UICheckButtonTemplate")
            cb:SetPoint("TOPLEFT",0,-((i-1)*24)); cb:SetSize(24,24)
            cb:SetChecked(recipe.tracked)
            local name = cb:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            name:SetPoint("LEFT",cb,"RIGHT",2,0); name:SetWidth(220); name:SetJustifyH("LEFT")
            name:SetText((recipe.professionName or "Profession")..": "..(recipe.name or "Cooldown"))
            cb:SetScript("OnClick",function(self)
                GoldMint.Cooldowns:SetTracked(recipe.recipeID,self:GetChecked())
            end)
        end
    end)
    labels.cooldownsReady = MakeLabel(p, "GameFontNormalSmall", "", 220)
    labels.cooldownsReady:SetPoint("TOPLEFT", 14, -40); labels.cooldownsReady:SetTextColor(unpack(GREEN)); labels.cooldownsReady:SetWordWrap(false)
    labels.cooldownsActive = MakeLabel(p, "GameFontNormalSmall", "", 220)
    labels.cooldownsActive:SetPoint("TOPLEFT", 14, -62); labels.cooldownsActive:SetTextColor(unpack(GOLD)); labels.cooldownsActive:SetWordWrap(false)
    labels.cooldownsDetail = MakeLabel(p, "GameFontNormalSmall", "Open a profession to scan cooldowns", 220)
    labels.cooldownsDetail:SetPoint("TOPLEFT", 14, -84); labels.cooldownsDetail:SetWidth(220); labels.cooldownsDetail:SetWordWrap(false); labels.cooldownsDetail:SetTextColor(unpack(MUTED))

    p = panels.milestone
    AddUtilityIcon(p, MILESTONE_ICON, 14, -16, 17)
    labels.milestoneTitle = MakeLabel(p, "GameFontNormalSmall", "NEXT MILESTONE", 202)
    labels.milestoneTitle:SetPoint("TOPLEFT", 37, -15); labels.milestoneTitle:SetTextColor(unpack(CYAN)); labels.milestoneTitle:SetWordWrap(false)
    labels.milestone = MakeLabel(p, "GameFontNormalLarge", "—", 228)
    labels.milestone:SetPoint("TOPLEFT", 14, -43); labels.milestone:SetTextColor(unpack(GOLD))
    labels.milestoneDetail = MakeLabel(p, "GameFontNormalSmall", "No active goal", 228)
    labels.milestoneDetail:SetPoint("TOPLEFT", 14, -84); labels.milestoneDetail:SetTextColor(unpack(MUTED))

    p = panels.shield
    AddUtilityIcon(p, SHIELD_ICON, 14, -16, 17)
    labels.shieldTitle = MakeLabel(p, "GameFontNormalSmall", "TIME-BLINDNESS SHIELD", 268)
    labels.shieldTitle:SetPoint("TOPLEFT", 37, -15); labels.shieldTitle:SetTextColor(unpack(CYAN)); labels.shieldTitle:SetWordWrap(false)
    labels.shield = MakeLabel(p, "GameFontNormal", "Building baseline", 288)
    labels.shield:SetPoint("TOPLEFT", 14, -43); labels.shield:SetTextColor(unpack(GREEN))
    labels.shieldDetail = MakeLabel(p, "GameFontNormalSmall", "More 7-day history is needed.", 288)
    labels.shieldDetail:SetPoint("TOPLEFT", 14, -70); labels.shieldDetail:SetTextColor(unpack(MUTED))
end

local function SetHomePanelsShown(shown)
    local homePanels = {
        panels.goal, panels.momentum, panels.next, panels.session,
        panels.cooldowns, panels.milestone, panels.shield,
    }

    if not shown then
        if panels.homeUtilityRail then panels.homeUtilityRail:Hide() end
        for _, p in ipairs(homePanels) do
            if p then p:Hide() end
        end
        if panels.homePopupButtons then panels.homePopupButtons:Hide() end
        return
    end

    -- Returning to Home must respect the user's saved panel toggles.
    -- Previously this function unconditionally called :Show() on every panel,
    -- which meant the Options checkboxes appeared to save but were immediately
    -- overridden the next time Home was opened.
    local settings = GoldMintDB and GoldMintDB.settings or {}
    local anyVisible = false
    local function ShowPanel(panel, key)
        if not panel then return end
        local visible = settings[key] ~= false
        panel:SetShown(visible)
        if visible then anyVisible = true end
    end

    ShowPanel(panels.goal, "showGoalPanel")
    ShowPanel(panels.momentum, "showMomentumPanel")
    ShowPanel(panels.next, "showNextStepPanel")
    ShowPanel(panels.session, "showSessionPanel")
    ShowPanel(panels.cooldowns, "showCooldownPanel")
    ShowPanel(panels.milestone, "showMilestonePanel")
    ShowPanel(panels.shield, "showShieldPanel")

    if panels.homePopupButtons then panels.homePopupButtons:Show() end
    -- The utility rail only contains the milestone and shield cards now.
    -- Cooldowns is positioned beside Getting Started and is not part of this rail.
    local railVisible = (settings["showMilestonePanel"] ~= false) or (settings["showShieldPanel"] ~= false)
    if panels.homeUtilityRail then panels.homeUtilityRail:SetShown(railVisible) end
end

local function ApplyHomePanelVisibility()
    local settings = GoldMintDB and GoldMintDB.settings or {}
    local anyVisible = false
    local function ShowPanel(panel, key)
        if not panel then return end
        local visible = settings[key] ~= false
        panel:SetShown(visible)
        if visible then anyVisible = true end
    end

    ShowPanel(panels.goal, "showGoalPanel")
    ShowPanel(panels.momentum, "showMomentumPanel")
    ShowPanel(panels.next, "showNextStepPanel")
    ShowPanel(panels.session, "showSessionPanel")
    ShowPanel(panels.cooldowns, "showCooldownPanel")
    ShowPanel(panels.milestone, "showMilestonePanel")
    ShowPanel(panels.shield, "showShieldPanel")

    local railVisible = (settings["showMilestonePanel"] ~= false) or (settings["showShieldPanel"] ~= false)
    if panels.homeUtilityRail then
        panels.homeUtilityRail:SetShown(railVisible)
    end
end

OpenProjects = function()
    if not panels.projectsView then
        local view = CreateFrame("Frame", "GoldMintProjectsView", frame, "BackdropTemplate")
        view:SetPoint("TOPLEFT", frame, "TOPLEFT", 225, -126)
        view:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, -18)
        view:SetFrameStrata("DIALOG")
        view:SetFrameLevel(120)
        view:SetBackdrop(nil)

        local function PL(parent, text, x, y, w, color, font, justify)
            local l = MakeLabel(parent, font or "GameFontNormal", text or "", w)
            l:SetPoint("TOPLEFT", x, y)
            l:SetTextColor(unpack(color or MUTED))
            if justify then l:SetJustifyH(justify) end
            return l
        end

        local function PCard(parent, w, h, x, y, border)
            return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
        end

        local function PButton(parent, text, w, h, x, y, kind)
            local b = MakeButton(parent, text, w, h or 28, kind or "secondary")
            b:SetPoint("TOPLEFT", x, y)
            return b
        end

        local function Checkbox(parent, x, y, checked)
            -- Use Blizzard's native check-button template so the checked state
            -- renders with the standard WoW check mark instead of a text glyph
            -- that can appear as a square on some clients/fonts.
            local box = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
            box:SetSize(18,18)
            box:SetPoint("TOPLEFT", x, y)
            box:SetChecked(checked and true or false)

            -- Keep Blizzard's native check mark, but tint the mark green.
            -- This preserves the standard WoW checkbox artwork while avoiding
            -- the square/text-glyph appearance of a custom check character.
            local checkTexture = box:GetCheckedTexture()
            if checkTexture then
                checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
            end

            return box
        end

        -- Wide project banner. It intentionally uses native GoldMint surfaces
        -- rather than external artwork so the page remains self-contained.
        local banner = CreateFrame("Frame", nil, view, "BackdropTemplate")
        banner:SetSize(1136, 104)
        banner:SetPoint("TOPLEFT", 0, -2)
        banner:SetBackdrop({
            bgFile="Interface\\Buttons\\WHITE8X8",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true, tileSize=16, edgeSize=12,
            insets={left=5,right=5,top=5,bottom=5},
        })
        banner:SetBackdropColor(0.008,0.030,0.058,0.98)
        banner:SetBackdropBorderColor(0.10,0.38,0.62,0.95)
        -- Keep the entire banner on one uniform background.
        -- The previous right-side overlay made the panel appear split into
        -- two different background colors.
        PL(banner, "PROJECT WORKSPACE", 20, -20, 300, CYAN, "GameFontNormalLarge")
        local workspaceAccent = banner:CreateTexture(nil, "ARTWORK")
        workspaceAccent:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], CYAN[4] or 1)
        workspaceAccent:SetSize(28, 2)
        workspaceAccent:SetPoint("TOPLEFT", banner, "TOPLEFT", 20, -36)
        PL(banner, "Long-term goals, farming plans, investments, and the next action.", 20, -49, 620, MUTED, "GameFontNormal")
        PL(banner, "KEEP THE PLAN VISIBLE • KEEP THE NEXT STEP SMALL", 20, -76, 500, GOLD, "GameFontNormalSmall")

        local manage = PButton(view, "MANAGE PROJECT", 140, 28, 974, -20, "primary")
        manage:SetScript("OnClick", function()
            if GoldMint.OpenOptions then
                GoldMint:OpenOptions("manageproject")
            else
                OpenGoalEditor()
            end
        end)

        local projectStatus = PL(banner, "", 560, -20, 92, MUTED, "GameFontNormalSmall", "RIGHT")

        local cards = {}
        local rows = {}

        local function ClearRows()
            for _, r in ipairs(rows) do
                if r.Hide then r:Hide() end
            end
            wipe(rows)
        end

        local function ItemInfo(itemID)
            itemID = tonumber(itemID)
            if not itemID then return nil end
            local name
            if C_Item and C_Item.GetItemNameByID then
                local okName, value = pcall(C_Item.GetItemNameByID, itemID)
                if okName then name = value end
            end
            local icon
            if C_Item and C_Item.GetItemIconByID then
                local okIcon, value = pcall(C_Item.GetItemIconByID, itemID)
                if okIcon then icon = value end
            end
            local okCount, rawCount = false, 0
            if C_Item and C_Item.GetItemCount then okCount, rawCount = pcall(C_Item.GetItemCount, itemID, true, true, true, true) end
            local count = okCount and (tonumber(rawCount) or 0) or 0
            return name or ("Item " .. tostring(itemID)), icon, tonumber(count) or 0
        end

        local function FindProjectRecipe(goal)
            -- A manually tracked recipe takes priority for the Materials
            -- Gathering Tracker. Tracking a recipe is an explicit request to
            -- show the reagents needed for that craftable, even when there is
            -- no matching active project goal.
            if GoldMint.Cooldowns and GoldMint.Cooldowns.GetMaterialsRecipe then
                local tracked = GoldMint.Cooldowns:GetMaterialsRecipe()
                if tracked and type(tracked.reagents) == "table" and #tracked.reagents > 0 then
                    return tracked
                end
            end

            if not goal or not goal.itemID or not GoldMintDB or not GoldMintDB.recipes then return nil end
            local best
            for recipeID, record in pairs(GoldMintDB.recipes) do
                if tonumber(record.outputItemID) == tonumber(goal.itemID) and type(record.reagents) == "table" then
                    local current = record.characters and record.characters[GoldMint.characterKey]
                    if current and current.learned then
                        return record
                    end
                    best = best or record
                end
            end
            return best
        end

        local function RefreshProjects()
            ClearRows()

            local milestone = GoldMint.Milestones
            local goals = milestone and milestone.GetGoals and milestone:GetGoals() or {}
            local active = milestone and milestone.GetActiveGoal and milestone:GetActiveGoal() or nil
            local completed = 0
            local activeCount = 0
            local capital = 0
            local revenue = 0
            local cost = 0
            for _, goal in ipairs(goals) do
                if goal.completeAt or goal.progress >= 1 then
                    completed = completed + 1
                else
                    activeCount = activeCount + 1
                    capital = capital + (tonumber(goal.budget) or 0)
                    revenue = revenue + (tonumber(goal.expectedRevenue) or 0)
                    cost = cost + (tonumber(goal.expectedCost) or 0)
                end
            end
            local expectedProfit = revenue - cost
            local profitState = expectedProfit > 0 and GREEN or (expectedProfit < 0 and RED or MUTED)

            if active then
                local pct = math.floor(math.max(0, math.min(1, tonumber(active.progress) or 0)) * 100 + 0.5)
                projectStatus:SetText(string.format("%d%% • ACTIVE", pct))
                projectStatus:SetTextColor(unpack(GREEN))
            else
                projectStatus:SetText(completed > 0 and (tostring(completed) .. " COMPLETED") or "NO ACTIVE PROJECT")
                projectStatus:SetTextColor(unpack(MUTED))
            end

            for _, card in ipairs(cards) do card:Hide() end
            wipe(cards)

            -- Compact project metrics strip: this is the quick gold-farmer readout.
            local metricData = {
                { label = "ACTIVE PROJECTS", value = tostring(activeCount), color = CYAN },
                { label = "CAPITAL COMMITTED", value = capital > 0 and FormatGold(capital) or "Not set", color = capital > 0 and GOLD or CYAN },
                { label = "EXPECTED REVENUE", value = revenue > 0 and FormatGold(revenue) or "Not set", color = CYAN },
                { label = "EXPECTED PROFIT", value = expectedProfit ~= 0 and FormatGold(expectedProfit) or "Not set", color = expectedProfit ~= 0 and profitState or CYAN },
            }
            for i, metric in ipairs(metricData) do
                local x = (i - 1) * 284
                local card = PCard(view, 270, 62, x, -116, {0.08,0.30,0.44,0.90})
                cards[#cards + 1] = card
                local metricHeader = PL(card, metric.label, 14, -12, 240, CYAN, "GameFontNormal")
                PL(card, metric.value, 14, -34, 240, metric.color, "GameFontHighlight")
            end

            local goalCard = PCard(view, 527, 190, 0, -188, {0.38,0.30,0.08,0.95})
            cards[#cards+1] = goalCard
            local activeProjectHeader = PL(goalCard, "ACTIVE PROJECT", 16, -18, 360, CYAN, "GameFontNormalLarge")
            activeProjectHeader:SetShadowOffset(1, -1)
            local activeProjectAccent = Accent(goalCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if activeProjectHeader and activeProjectAccent then
                    local font, size, flags = activeProjectHeader:GetFont()
                    if font and size then
                        local measure = goalCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("Act")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        activeProjectAccent:SetWidth(width)
                    end
                end
            end)
            if active then
                local current = tonumber(active.currentValue) or 0
                local target = tonumber(active.target) or 0
                local pct = math.max(0, math.min(1, tonumber(active.progress) or 0))
                local nextCP = active.nextCheckpoint
                PL(goalCard, tostring(active.name or "Active Project"), 16, -50, 340, GOLD, "GameFontHighlight")
                PL(goalCard, tostring(active.projectType or "Gold Goal"), 16, -74, 180, CYAN, "GameFontNormalSmall")
                PL(goalCard, FormatGold(current) .. " / " .. FormatGold(target), 16, -98, 250, MUTED, "GameFontNormal")
                PL(goalCard, string.format("%d%% complete", math.floor(pct * 100 + 0.5)), 285, -98, 100, CYAN, "GameFontNormalSmall", "RIGHT")
                local barBG = goalCard:CreateTexture(nil,"ARTWORK")
                barBG:SetColorTexture(0.03,0.08,0.12,0.95)
                barBG:SetSize(495,8)
                barBG:SetPoint("TOPLEFT", 16, -120)
                local bar = goalCard:CreateTexture(nil,"ARTWORK")
                bar:SetColorTexture(GREEN[1],GREEN[2],GREEN[3],0.85)
                bar:SetSize(math.max(4,495*pct),8)
                bar:SetPoint("TOPLEFT", 16, -120)
                local milestoneText = nextCP and ("Next milestone: " .. tostring(nextCP.name or FormatGold(nextCP.amount))) or "No milestone set"
                PL(goalCard, milestoneText, 16, -140, 300, nextCP and CYAN or MUTED, "GameFontNormalSmall")
                if active.deadline then
                    local days = math.ceil(math.max(0, (tonumber(active.deadline) - time()) / 86400))
                    PL(goalCard, days > 0 and (tostring(days) .. " days remaining") or "Deadline reached", 350, -140, 145, days > 0 and MUTED or RED, "GameFontNormalSmall", "RIGHT")
                end
                PL(goalCard, active.remaining > 0 and (FormatGold(active.remaining) .. " remaining") or "Goal reached", 16, -164, 300, active.remaining > 0 and MUTED or GREEN, "GameFontNormalSmall")
            else
                PL(goalCard, "No active project", 16, -56, 350, GOLD, "GameFontHighlight")
                PL(goalCard, "Create a project to give GoldMint a clear destination.", 16, -84, 450, MUTED, "GameFontNormal")
                local create = PButton(goalCard, "CREATE PROJECT", 132, 28, 16, -124, "secondary")
                create:SetScript("OnClick", OpenGoalEditor)
            end

            local nextCard = PCard(view, 586, 190, 550, -188, {0.08,0.38,0.58,0.95})
            cards[#cards+1] = nextCard
            local nextStepHeader = PL(nextCard, "THE ‘NEXT STEP’ ACTION BOX", 16, -18, 365, CYAN, "GameFontNormalLarge")
            nextStepHeader:SetShadowOffset(1, -1)
            local nextStepAccent = Accent(nextCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if nextStepHeader and nextStepAccent then
                    local font, size, flags = nextStepHeader:GetFont()
                    if font and size then
                        local measure = nextCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("THE")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        nextStepAccent:SetWidth(width)
                    end
                end
            end)
            local action = GoldMint.WorkflowState and GoldMint.WorkflowState.GetNextAction and GoldMint.WorkflowState:GetNextAction() or nil
            local task = GoldMint.WorkflowState and GoldMint.WorkflowState.GetCurrentTask and GoldMint.WorkflowState:GetCurrentTask() or nil
            local actionTitle = (active and active.nextAction) or (action and action.title)
            local actionDetail = action and action.details
            if not actionTitle and active then
                if active.nextCheckpoint then
                    actionTitle = "Reach " .. tostring(active.nextCheckpoint.name or FormatGold(active.nextCheckpoint.amount))
                    actionDetail = FormatGold(active.nextCheckpoint.remaining) .. " remaining to the next milestone."
                else
                    actionTitle = "Continue toward " .. tostring(active.name or "your project")
                    actionDetail = active.remaining > 0 and (FormatGold(active.remaining) .. " remaining toward the project target.") or "Goal reached."
                end
            end
            if not actionTitle and task then
                actionTitle = task.title
                actionDetail = task.details
            end
            if actionTitle then
                PL(nextCard, actionTitle, 18, -55, 390, GOLD, "GameFontHighlight")
                PL(nextCard, actionDetail or "One clear action keeps the project moving.", 18, -82, 390, MUTED, "GameFontNormalSmall")
                local track = PButton(nextCard, "TRACK NOW", 112, 28, 18, -122, "primary")
                track:SetScript("OnClick", function()
                    if GoldMint.WorkflowState and GoldMint.WorkflowState.SetNextAction then
                        GoldMint.WorkflowState:SetNextAction(actionTitle, active and active.id or nil, actionDetail)
                        GoldMint.Print("Project next step tracked: " .. tostring(actionTitle))
                    end
                end)
                local one = Checkbox(nextCard, 148, -128, false)
                PL(nextCard, "Keep this as the only visible step", 172, -124, 205, MUTED, "GameFontNormalSmall")
            else
                PL(nextCard, "No next action is currently set.", 18, -55, 390, MUTED, "GameFontHighlight")
                PL(nextCard, "Use MANAGE PROJECT to define the next action.", 18, -84, 390, MUTED, "GameFontNormalSmall")
            end

            -- Detailed farming controls live in the dedicated minimap farming tool.
            -- Projects only keeps the measured farming performance summary below.
            local tracker = GoldMint.FarmTracker
            local performance = tracker and tracker.GetRoutePerformance and tracker:GetRoutePerformance() or nil
            local historicalGPH = tracker and tracker.GetHistoricalGPH and tracker:GetHistoricalGPH() or nil

            -- WorthIt-derived route intelligence. The route library is bundled
            -- inside GoldMint, so this panel never requires WorthIt at runtime.
            local worthCard = PCard(view, 527, 178, 0, -390, {0.08,0.38,0.58,0.95})
            cards[#cards+1] = worthCard
            local worthHeader = PL(worthCard, "WORTHIT INTELLIGENCE", 16, -18, 360, CYAN, "GameFontNormalLarge")
            worthHeader:SetShadowOffset(1, -1)
            local worthAccent = Accent(worthCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if worthHeader and worthAccent then
                    local font, size, flags = worthHeader:GetFont()
                    if font and size then
                        local measure = worthCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("WOR")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        worthAccent:SetWidth(width)
                    end
                end
            end)

            local routeDB = GoldMint.FarmRoutes
            local routeList = {}
            local routeCount, waypointCount, targetCount = 0, 0, 0
            local seenTargets = {}
            if routeDB and type(routeDB.routes) == "table" then
                for routeID, route in pairs(routeDB.routes) do
                    if type(route) == "table" then
                        routeCount = routeCount + 1
                        waypointCount = waypointCount + (tonumber(route.waypointCount) or (type(route.waypoints) == "table" and #route.waypoints or 0))
                        for _, itemID in ipairs(route.targetItemIDs or {}) do
                            if not seenTargets[itemID] then
                                seenTargets[itemID] = true
                                targetCount = targetCount + 1
                            end
                        end
                        routeList[#routeList+1] = { id = routeID, route = route }
                    end
                end
            end
            table.sort(routeList, function(a, b)
                local an = tostring((a.route and a.route.mapKey) or "") .. "|" .. tostring((a.route and a.route.name) or a.id)
                local bn = tostring((b.route and b.route.mapKey) or "") .. "|" .. tostring((b.route and b.route.name) or b.id)
                return an < bn
            end)

            PL(worthCard, string.format("%d imported routes  •  %d waypoints  •  %d targets", routeCount, waypointCount, targetCount), 16, -46, 490, MUTED, "GameFontNormalSmall")
            PL(worthCard, "WorthIt reference data is bundled in GoldMint. Your results stay separate.", 16, -68, 490, MUTED, "GameFontNormalSmall")

            local selectedRoute = routeList[1] and routeList[1].route or nil
            local selectedRouteLabel = worthCard:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            selectedRouteLabel:SetPoint("TOPLEFT", 16, -92)
            selectedRouteLabel:SetWidth(310)
            selectedRouteLabel:SetJustifyH("LEFT")
            selectedRouteLabel:SetTextColor(unpack(GOLD))

            local selectedRouteInfo = worthCard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            selectedRouteInfo:SetPoint("TOPLEFT", 16, -116)
            selectedRouteInfo:SetWidth(490)
            selectedRouteInfo:SetJustifyH("LEFT")
            selectedRouteInfo:SetTextColor(unpack(MUTED))

            local function UpdateWorthRoute(route)
                selectedRoute = route
                if not route then
                    selectedRouteLabel:SetText("No imported route data")
                    selectedRouteInfo:SetText("Import data is unavailable.")
                    return
                end
                local targets = type(route.targetNames) == "table" and #route.targetNames > 0 and table.concat(route.targetNames, ", ") or "General farming"
                selectedRouteLabel:SetText(tostring(route.name or route.key or "Imported Route"))
                selectedRouteInfo:SetText(string.format("%s  •  %d waypoints  •  targets: %s", tostring(route.mapKey or "Unknown zone"), tonumber(route.waypointCount) or (type(route.waypoints) == "table" and #route.waypoints or 0), targets))
            end
            UpdateWorthRoute(selectedRoute)

            local routePicker = PButton(worthCard, "NEXT ROUTE", 104, 26, 402, -88, "secondary")
            routePicker:SetScript("OnClick", function()
                if #routeList == 0 then return end
                local currentID = selectedRoute and selectedRoute.id
                local index = 1
                for i, entry in ipairs(routeList) do
                    if entry.id == currentID then index = i break end
                end
                index = (index % #routeList) + 1
                UpdateWorthRoute(routeList[index].route)
            end)

            local useRoute = PButton(worthCard, "USE ROUTE", 104, 26, 402, -126, "primary")
            useRoute:SetScript("OnClick", function()
                if not selectedRoute or not GoldMint.FarmTracker or not GoldMint.FarmTracker.SetRoute then return end
                local route = {}
                for k, v in pairs(selectedRoute) do route[k] = v end
                route.itemID = route.targetItemIDs and route.targetItemIDs[1] or nil
                route.itemName = route.targetNames and route.targetNames[1] or route.name
                route.routeID = route.id or route.key
                GoldMint.FarmTracker:SetRoute(route)
                if GoldMint.Print then
                    GoldMint.Print("Imported route selected for the farming tool: " .. tostring(route.name or route.key or "route"))
                end
            end)

            local farmDataCard = PCard(view, 586, 178, 550, -390, {0.38,0.30,0.08,0.90})
            cards[#cards+1] = farmDataCard
            local farmingHeader = PL(farmDataCard, "FARMING PERFORMANCE", 16, -18, 360, CYAN, "GameFontNormalLarge")
            farmingHeader:SetShadowOffset(1, -1)
            local farmingAccent = Accent(farmDataCard, "TOPLEFT", 16, -36, 38, CYAN)
            C_Timer.After(0, function()
                if farmingHeader and farmingAccent then
                    local font, size, flags = farmingHeader:GetFont()
                    if font and size then
                        local measure = farmDataCard:CreateFontString(nil, "OVERLAY")
                        measure:SetFont(font, size, flags)
                        measure:SetText("FAR")
                        local width = math.max(1, math.ceil(measure:GetStringWidth()))
                        measure:Hide()
                        farmingAccent:SetWidth(width)
                    end
                end
            end)
            if performance then
                PL(farmDataCard, "MEASURED FARM PERFORMANCE", 16, -50, 280, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, FormatGold(performance.valuePerHour) .. "/hr", 16, -72, 220, GREEN, "GameFontHighlight")
                PL(farmDataCard, string.format("%d sessions", tonumber(performance.sessions) or 0), 410, -72, 145, CYAN, "GameFontNormalSmall", "RIGHT")
                PL(farmDataCard, "Items / hour", 16, -104, 150, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, string.format("%.1f", tonumber(performance.itemsPerHour) or 0), 16, -126, 120, CYAN, "GameFontHighlight")
                PL(farmDataCard, "Confidence", 205, -104, 120, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, string.format("%.0f%%", tonumber(performance.averageConfidence) or 0), 205, -126, 120, CYAN, "GameFontHighlight")
                local routeText = performance.zone and (tostring(performance.zone) .. (performance.area and (" • " .. tostring(performance.area)) or "")) or "Measured route history"
                PL(farmDataCard, routeText, 16, -154, 530, MUTED, "GameFontNormalSmall")
            elseif historicalGPH then
                PL(farmDataCard, "HISTORICAL FARM DATA", 16, -50, 280, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, FormatGold(historicalGPH) .. "/hr", 16, -72, 220, CYAN, "GameFontHighlight")
                PL(farmDataCard, "Keep farming this route to build measured evidence.", 16, -108, 500, MUTED, "GameFontNormalSmall")
            else
                PL(farmDataCard, "BUILD YOUR FARMING DATA", 16, -50, 300, GOLD, "GameFontHighlight")
                PL(farmDataCard, "GoldMint records loot, expenses, route time, and", 16, -78, 500, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, "route performance during farm sessions.", 16, -100, 500, MUTED, "GameFontNormalSmall")
                PL(farmDataCard, "Measured GPH appears after real sessions — no invented estimates.", 16, -132, 540, CYAN, "GameFontNormalSmall")
            end

        end

        view:SetScript("OnShow", RefreshProjects)
        panels.projectsView = view
        panels.projectsRefresh = RefreshProjects
    end
    SetHomePanelsShown(false)
    if panels.operationsView then panels.operationsView:Hide() end
    panels.projectsView:Show()
    panels.projectsView:Raise()
    -- Rebuild immediately on every Projects navigation click.  Relying only
    -- on OnShow is not sufficient because the frame may already be shown
    -- when the player returns to Projects, and the first navigation can also
    -- occur during frame creation.
    if panels.projectsRefresh then
        panels.projectsRefresh()
    end
    SetNavigationActive("projects")
end

OpenPlanner = function(section)
    if not panels.plannerView then
        local view = CreateFrame("Frame", "GoldMintPlannerView", frame, "BackdropTemplate")
        view:SetPoint("TOPLEFT", frame, "TOPLEFT", 210, -126)
        view:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, -18)
        view:SetFrameStrata("DIALOG")
        view:SetFrameLevel(320)
        view:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8, edgeSize=1})
        view:SetBackdropColor(0.004,0.012,0.022,0.99)
        view:SetBackdropBorderColor(0.10,0.42,0.66,0.98)
        if UISpecialFrames then tinsert(UISpecialFrames, "GoldMintPlannerView") end

        local title=MakeLabel(view,"GameFontNormalLarge","GOLDMINT PLANNER")
        title:SetPoint("TOPLEFT",22,-18); title:SetTextColor(unpack(CYAN))
        local sub=MakeLabel(view,"GameFontNormal","One decision at a time. Choose how much time or attention you have.")
        sub:SetPoint("TOPLEFT",22,-48); sub:SetTextColor(unpack(MUTED))

        local focus=MakeButton(view,"FOCUS MODE",125,28,"secondary"); focus:SetPoint("TOPRIGHT",-116,-16)

        local body=CreateFrame("Frame",nil,view); body:SetPoint("TOPLEFT",22,-82); body:SetPoint("BOTTOMRIGHT",-22,48)
        local left=Panel(body,235,438,"TOPLEFT",0,0,{0.08,0.28,0.42,0.9})
        local right=Panel(body,535,438,"TOPRIGHT",0,0,{0.08,0.28,0.42,0.9})
        local modeTitle=MakeLabel(left,"GameFontHighlight","ENERGY / PLAY STYLE"); modeTitle:SetPoint("TOPLEFT",16,-16); modeTitle:SetTextColor(unpack(GOLD))
        local modeDesc=MakeLabel(left,"GameFontNormalSmall","Recommendations adapt to effort, not just gold/hour.",190); modeDesc:SetPoint("TOPLEFT",16,-42); modeDesc:SetTextColor(unpack(MUTED)); modeDesc:SetJustifyH("LEFT")
        local modes={"Maximum Gold","Sustainable","Relaxed","Maintenance"}
        local modeButtons={}
        local render
        local function getSettings()
            GoldMintDB.settings=GoldMintDB.settings or {}
            GoldMintDB.settings.playStyle=GoldMintDB.settings.playStyle or "Sustainable"
            return GoldMintDB.settings
        end
        local function setMode(m)
            getSettings().playStyle=m
            for k,b in pairs(modeButtons) do b:SetBackdropBorderColor(k==m and 1.0 or 0.10,k==m and 0.78 or 0.34,k==m and 0.20 or 0.52,1) end
            render()
        end
        for i,m in ipairs(modes) do
            local b=MakeButton(left,m,195,30,"secondary"); b:SetPoint("TOPLEFT",16,-78-(i-1)*42); b:SetScript("OnClick",function() setMode(m) end); modeButtons[m]=b
        end
        local quickTitle=MakeLabel(left,"GameFontHighlight","I HAVE..."); quickTitle:SetPoint("TOPLEFT",16,-258); quickTitle:SetTextColor(unpack(CYAN))
        local quick={ {"5 MINUTES",5},{"10 MINUTES",10},{"20 MINUTES",20},{"30 MINUTES",30},{"1 HOUR",60} }
        local selectedMinutes=10
        for i,q in ipairs(quick) do
            local b=MakeButton(left,q[1],195,27,"secondary"); b:SetPoint("TOPLEFT",16,-284-(i-1)*31); b:SetScript("OnClick",function() selectedMinutes=q[2]; render() end)
        end

        local contentTitle=MakeLabel(right,"GameFontNormalLarge","WHAT SHOULD I DO?"); contentTitle:SetPoint("TOPLEFT",18,-16); contentTitle:SetTextColor(unpack(CYAN))
        local content=MakeLabel(right,"GameFontNormal","",480); content:SetPoint("TOPLEFT",18,-52); content:SetTextColor(unpack(MUTED)); content:SetJustifyH("LEFT"); content:SetWordWrap(true)
        local idea=CreateFrame("EditBox",nil,right,"InputBoxTemplate"); idea:SetSize(300,28); idea:SetPoint("BOTTOMLEFT",320,18); idea:SetAutoFocus(false); idea:SetTextInsets(8,8,0,0); idea:SetText("")
        local ideaAdd=MakeButton(right,"SAVE IDEA",105,30,"secondary"); ideaAdd:SetPoint("BOTTOMRIGHT",-18,18)
        local action=MakeButton(right,"USE THIS PLAN",150,30,"secondary"); action:SetPoint("BOTTOMLEFT",18,18)
        local later=MakeButton(right,"PUT IN LATER",135,30,"secondary"); later:SetPoint("BOTTOMLEFT",178,18)
        ideaAdd:SetScript("OnClick",function()
            local text=idea:GetText()
            if text and text ~= "" and GoldMint.WorkflowState and GoldMint.WorkflowState.AddReminder then
                GoldMint.WorkflowState:AddReminder(text,nil,"idea:"..string.lower((text:gsub("[^%w]+","_"))))
                idea:SetText("")
                GoldMint.Print("Saved idea for later: "..text)
            end
        end)

        local function currentData()
            local goal=GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil
            local ready,active=0,0
            if GoldMint.Cooldowns and GoldMint.Cooldowns.GetSummary then ready,active=GoldMint.Cooldowns:GetSummary() end
            local mail=GoldMint.MailTracking and GoldMint.MailTracking.GetSummary and GoldMint.MailTracking:GetSummary() or nil
            local routines=GoldMint.RoutineState and GoldMint.RoutineState.GetSummary and GoldMint.RoutineState:GetSummary() or nil
            return goal,tonumber(ready) or 0,tonumber(active) or 0,mail,routines
        end
        render=function()
            local goal,ready,active,mail,routines=currentData()
            local mode=getSettings().playStyle
            local lines={"MODE: "..mode,"TIME BUDGET: "..selectedMinutes.." minutes",""}
            if section == "inventory" then
                lines[#lines+1] = "INVENTORY RESET"
                lines[#lines+1] = "Review items without forcing a decision."
                lines[#lines+1] = "SELL  •  BANK  •  CRAFT  •  MAIL  •  VENDOR  •  DECIDE LATER"
                lines[#lines+1] = ""
            elseif section == "recipes" then
                lines[#lines+1] = "CRAFTING WORKBENCH"
                lines[#lines+1] = "Find the best crafting opportunities from your scanned profession data."
                lines[#lines+1] = ""
            elseif section == "market" then
                lines[#lines+1] = "MARKET CHECK"
                lines[#lines+1] = "Use tracked auction benchmarks and volatility before committing attention."
                lines[#lines+1] = ""
            elseif section == "wealth" then
                lines[#lines+1] = "WEALTH SNAPSHOT"
                lines[#lines+1] = "Gold, session velocity, and project pacing stay together."
                lines[#lines+1] = ""
            elseif section == "routines" then
                lines[#lines+1] = "CURRENT + LEGACY ROUTINES"
                lines[#lines+1] = "GoldMint separates current-expansion work from legacy work to reduce clutter."
                lines[#lines+1] = ""
            end
            local welcome=GoldMint.WorkflowState and GoldMint.WorkflowState.GetWelcomeBackState and GoldMint.WorkflowState:GetWelcomeBackState() or nil
            if welcome and welcome.task and welcome.task.title then
                lines[#lines+1]="WELCOME BACK"
                lines[#lines+1]="You were working on: "..tostring(welcome.task.title)
                if welcome.nextAction and welcome.nextAction.title then lines[#lines+1]="Next: "..tostring(welcome.nextAction.title) end
                lines[#lines+1]=""
            end
            local task,why="",""
            if ready>0 and selectedMinutes>=4 then
                task="Collect ready cooldowns (~4 min)"
                why=string.format("%d cooldown%s are ready now.",ready,ready==1 and " is" or "s are")
            elseif mail and tonumber(mail.attachmentCount or 0)>0 then
                task="Review incoming mail"
                why=string.format("%d attachment%s need attention.",tonumber(mail.attachmentCount or 0),tonumber(mail.attachmentCount or 0)==1 and " is" or "s are")
            elseif routines and tonumber(routines.ready or 0)>0 then
                task="Review ready routines"
                why=string.format("%d routine item%s are ready.",tonumber(routines.ready or 0),tonumber(routines.ready or 0)==1 and " is" or "s are")
            elseif goal then
                task="Continue toward "..tostring(goal.name)
                why=goal.nextCheckpoint and ("Next checkpoint: "..tostring(goal.nextCheckpoint.name or ShortGold(goal.nextCheckpoint.amount))) or "Your active savings goal is the current priority."
            else
                task="Create your first savings goal"
                why="A goal gives GoldMint a reason to prioritize your next action."
            end
            if selectedMinutes < 4 then task="Just check in"; why="No task is required for a tiny check-in." end
            lines[#lines+1]="NEXT: "..task
            lines[#lines+1]=""
            lines[#lines+1]="WHY THIS?"
            lines[#lines+1]=why
            lines[#lines+1]=""
            lines[#lines+1]="Principle: optimize gold per unit of attention, not gold/hour alone."
            content:SetText(table.concat(lines,"\n"))
            local taskID="planner:"..string.lower((task:gsub("[^%w]+","_")))
            action:SetScript("OnClick",function()
                if GoldMint.WorkflowState then
                    GoldMint.WorkflowState:SetCurrentTask(task,taskID,{reason=why,minutes=selectedMinutes,mode=mode})
                    GoldMint.WorkflowState:SetNextAction(task,taskID,{reason=why,minutes=selectedMinutes,mode=mode})
                end
                view:Hide(); Refresh(); GoldMint.Print("Current task set: "..task)
            end)
            later:SetScript("OnClick",function()
                if GoldMint.WorkflowState and GoldMint.WorkflowState.AddReminder then GoldMint.WorkflowState:AddReminder(task,nil,taskID) end
                GoldMint.Print("Saved for later: "..task)
            end)
            for k,b in pairs(modeButtons) do local activeMode=(k==mode); b:SetBackdropBorderColor(activeMode and 1.0 or 0.10,activeMode and 0.78 or 0.34,activeMode and 0.20 or 0.52,1) end
        end
        focus:SetScript("OnClick",function()
            local goal,ready=GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil,0
            if GoldMint.Cooldowns and GoldMint.Cooldowns.GetSummary then ready=GoldMint.Cooldowns:GetSummary() end
            local task=(ready and ready>0) and "Collect ready cooldowns" or (goal and "Continue toward "..tostring(goal.name) or "Create your first savings goal")
            content:SetText("FOCUS MODE\n\n"..task.."\n\nOne next action.\nNo unrelated tasks.\nNo extra notifications.")
        end)
        view:SetScript("OnShow",function() render() end)
        panels.plannerView=view
    end
    panels.plannerView:Show(); panels.plannerView:Raise()
end


OpenOperations = function(section)
    if cooldownFilterMenu then cooldownFilterMenu:Hide() end
    if not panels.operationsView then
        local view = CreateFrame("Frame", "GoldMintOperationsView", frame)
        view:SetPoint("TOPLEFT", frame, "TOPLEFT", 210, -126)
        view:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, -18)
        view:SetFrameStrata("DIALOG"); view:SetFrameLevel(120)
        local title=MakeLabel(view,"GameFontNormalLarge","GOLDMINT OPERATIONS"); title:SetPoint("TOPLEFT",22,-18); title:SetTextColor(unpack(CYAN))
        local sub=MakeLabel(view,"GameFontNormal","Mail, routines, and gentle maintenance tools."); sub:SetPoint("TOPLEFT",22,-48); sub:SetTextColor(unpack(MUTED))
        local content=CreateFrame("Frame",nil,view); content:SetPoint("TOPLEFT",22,-130); content:SetPoint("BOTTOMRIGHT",-22,22)
        local tabs={"wealth","cooldowns","routines"}; local tabButtons={}
        local function wipeContent() for _,c in ipairs({content:GetChildren()}) do c:Hide() end end
        local function L(text,x,y,w,color,font) local l=MakeLabel(content,font or "GameFontNormal",text,w); l:SetPoint("TOPLEFT",x,y); l:SetTextColor(unpack(color or MUTED)); return l end
        local show
        local function routines()
            -- Routines page: Daily Focus / Daily Task List / Weekly Overview
            -- on top, then Manual World Quests / World Boss Timers / Rare Recipe
            -- Spawn Timers below.
            for _, b in pairs(tabButtons) do b:Hide() end
            title:SetText("")
            sub:SetText("")
            content:ClearAllPoints()
            content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, -8)
            content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)

            local page = CreateFrame("Frame", nil, content)
            page:SetAllPoints(content)
            -- Keep the Routines page surface transparent. The individual
            -- routine cards provide their own dark panels while the supplied
            -- dashboard artwork remains visible between them.

            local function RL(parent, text, x, y, w, color, font, justify)
                local l = MakeLabel(parent, font or "GameFontNormal", text or "", w)
                l:SetPoint("TOPLEFT", x, y)
                l:SetTextColor(unpack(color or MUTED))
                l:SetWordWrap(false)
                l:SetNonSpaceWrap(false)
                if justify then l:SetJustifyH(justify) end
                return l
            end

            local function RCard(parent, w, h, x, y, border)
                return Panel(parent, w, h, "TOPLEFT", x, y, border or {0.08,0.38,0.58,0.95})
            end

            local function RButton(parent, text, w, h, x, y, kind)
                local b = MakeButton(parent, text, w, h or 28, kind or "secondary")
                b:SetPoint("TOPLEFT", x, y)
                return b
            end

            local function Checkbox(parent, x, y, checked, onclick)
                local box = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
                box:SetSize(22, 22)
                box:SetPoint("TOPLEFT", x, y)
                box:SetChecked(checked == true)
                local checkTexture = box:GetCheckedTexture()
                if checkTexture then
                    checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                end
                box:SetScript("OnClick", function(self)
                    if checkTexture then
                        checkTexture:SetVertexColor(0.20, 1.00, 0.20, 1.00)
                    end
                    if onclick then onclick(self) end
                end)
                return box
            end

            local dailyDetailFrame

            local function GetBountifulDelves()
                local result = {}
                -- Blizzard exposes the current Midnight bountiful rotation as
                -- Delve Area POIs on the Midnight continent map (2537).
                -- IMPORTANT: do not require isCurrentEvent here. The bountiful
                -- POIs are identified by the dedicated Blizzard atlas marker.
                local continentMapID = 2537
                if not (C_AreaPoiInfo and C_AreaPoiInfo.GetDelvesForMap and C_AreaPoiInfo.GetAreaPOIInfo) then
                    return result
                end

                local ok, poiIDs = pcall(C_AreaPoiInfo.GetDelvesForMap, continentMapID)
                if not ok or type(poiIDs) ~= "table" then
                    return result
                end

                for _, poiID in ipairs(poiIDs) do
                    local okInfo, info = pcall(C_AreaPoiInfo.GetAreaPOIInfo, continentMapID, poiID)
                    local atlas = okInfo and info and tostring(info.atlasName or "") or ""
                    if okInfo and info and info.name and atlas:lower() == "delves-bountiful" then
                        local zoneName = "Midnight"
                        local mapID = tonumber(info.linkedUiMapID)
                        if mapID and C_Map and C_Map.GetMapInfo then
                            local okMap, mapInfo = pcall(C_Map.GetMapInfo, mapID)
                            if okMap and mapInfo and mapInfo.name then
                                zoneName = mapInfo.name
                            end
                        end
                        result[#result + 1] = {
                            areaPoiID = poiID,
                            name = tostring(info.name),
                            zone = zoneName,
                            atlas = info.atlasName,
                            mapID = mapID,
                        }
                    end
                end

                table.sort(result, function(a,b) return a.name < b.name end)
                return result
            end

            local function ShowRoutineDetail(activity)
                if not dailyDetailFrame then
                    local detail = CreateFrame("Frame", "GoldMintRoutineDetail", UIParent, "BackdropTemplate")
                    detail:SetSize(430, 330)
                    detail:SetPoint("CENTER")
                    detail:SetFrameStrata("DIALOG")
                    detail:SetFrameLevel(500)
                    detail:SetBackdrop({
                        bgFile = "Interface\\Buttons\\WHITE8X8",
                        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                        tile = true, tileSize = 8, edgeSize = 14,
                        insets = {left=3,right=3,top=3,bottom=3},
                    })
                    detail:SetBackdropColor(0.006,0.018,0.030,0.98)
                    detail:SetBackdropBorderColor(0.08,0.38,0.58,0.98)
                    detail:EnableMouse(true)
                    detail:Hide()

                    local title = MakeLabel(detail, "GameFontNormalLarge", "ROUTINE DETAILS", 330)
                    title:SetPoint("TOPLEFT", 18, -16)
                    title:SetTextColor(unpack(GOLD))
                    detail.title = title

                    local close = MakeButton(detail, "CLOSE", 70, 26, "secondary")
                    close:SetPoint("TOPRIGHT", -16, -14)
                    close:SetScript("OnClick", function() detail:Hide() end)

                    local subtitle = MakeLabel(detail, "GameFontNormalSmall", "", 390)
                    subtitle:SetPoint("TOPLEFT", 18, -48)
                    subtitle:SetTextColor(unpack(MUTED))
                    detail.subtitle = subtitle

                    detail.body = CreateFrame("Frame", nil, detail)
                    detail.body:SetPoint("TOPLEFT", 18, -76)
                    detail.body:SetPoint("BOTTOMRIGHT", -18, 18)
                    dailyDetailFrame = detail
                end

                local detail = dailyDetailFrame
                detail.activity = activity
                for _, child in ipairs({detail.body:GetChildren()}) do child:Hide() end
                detail.title:SetText(tostring(activity and activity.title or "ROUTINE DETAILS"))

                if activity and tostring(activity.title or ""):lower():find("bountiful delve", 1, true) then
                    -- Always perform a live query when the detail window opens.
                    -- Opening the world map is no longer required as the trigger.
                    local delves = GetBountifulDelves()
                    detail.subtitle:SetText(#delves > 0 and (#delves .. " active bountiful delves today") or "No active bountiful delves were returned by Blizzard yet.")
                    if #delves == 0 then
                        local note = MakeLabel(detail.body, "GameFontNormal", "No active bountiful delves were returned by Blizzard yet. GoldMint will refresh automatically when Blizzard updates the Delve POIs.", 385)
                        note:SetPoint("TOPLEFT", 0, 0)
                        note:SetTextColor(unpack(MUTED))
                    else
                        for i, delve in ipairs(delves) do
                            local row = CreateFrame("Frame", nil, detail.body, "BackdropTemplate")
                            row:SetSize(390, 42)
                            row:SetPoint("TOPLEFT", 0, -((i-1)*46))
                            row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
                            row:SetBackdropColor(0.015,0.055,0.085,0.78)
                            row:SetBackdropBorderColor(0.06,0.28,0.42,0.9)

                            if delve.atlas and row.CreateTexture then
                                local icon = row:CreateTexture(nil, "ARTWORK")
                                local okAtlas = pcall(icon.SetAtlas, icon, delve.atlas)
                                if okAtlas then
                                    icon:SetSize(26,26)
                                    icon:SetPoint("LEFT", 8, 0)
                                end
                            end
                            RL(row, delve.name, 44, -8, 230, {0.88,0.92,0.98}, "GameFontNormal")
                            RL(row, delve.zone, 44, -24, 230, MUTED, "GameFontNormalSmall")
                            RL(row, "BOUNTIFUL", 300, -13, 78, GREEN, "GameFontNormalSmall", "RIGHT")
                        end
                    end
                else
                    detail.subtitle:SetText("Current routine information")
                    local name = tostring(activity and activity.title or "Routine")
                    local info = MakeLabel(detail.body, "GameFontNormal", name .. " is currently " .. tostring(activity and activity.status or "tracked") .. ".", 385)
                    info:SetPoint("TOPLEFT", 0, 0)
                    info:SetTextColor(unpack(MUTED))
                end
                detail:Show()
                detail:Raise()
            end

            -- AREA_POIS_UPDATED is a secondary refresh trigger, not the only
            -- way GoldMint learns the daily bountiful rotation. The detail
            -- window already performs an immediate live query; this event keeps
            -- an open window synchronized when Blizzard refreshes the POI data.
            do
                local refreshFrame = GoldMint.BountifulDelvesRefreshFrame
                if not refreshFrame then
                    refreshFrame = CreateFrame("Frame")
                    GoldMint.BountifulDelvesRefreshFrame = refreshFrame
                    refreshFrame:RegisterEvent("AREA_POIS_UPDATED")
                    refreshFrame:SetScript("OnEvent", function()
                        local detail = dailyDetailFrame
                        local activity = detail and detail:IsShown() and detail.activity
                        if activity and tostring(activity.title or ""):lower():find("bountiful delve", 1, true) then
                            if C_Timer and C_Timer.After then
                                C_Timer.After(0, function()
                                    if dailyDetailFrame and dailyDetailFrame:IsShown() and dailyDetailFrame.activity == activity then
                                        ShowRoutineDetail(activity)
                                    end
                                end)
                            else
                                ShowRoutineDetail(activity)
                            end
                        end
                    end)
                end
            end

            local function FrequencyIs(activity, wanted)
                return tostring(activity and activity.frequency or "") == wanted
            end

            local function GetActivities()
                local state = GoldMint.RoutineState
                if not state or not state.GetRelevantActivities then return {} end
                return state:GetRelevantActivities(GoldMint.characterKey, { currentOnly = true, season = 2 }) or {}
            end

            local function GetLegacyActivities()
                local state = GoldMint.RoutineState
                if not state or not state.GetRelevantActivities then return {} end
                local all = state:GetRelevantActivities(GoldMint.characterKey, {}) or {}
                local result = {}
                for _, activity in ipairs(all) do
                    if tonumber(activity.expansionID) ~= 11 then
                        result[#result + 1] = activity
                    end
                end
                return result
            end

            local function SortFocus(a,b)
                -- Always surface the currently rotating Midnight outdoor World
                -- Boss in Weekly Task Overview.  It is a catalog activity rather
                -- than a normal quest-backed routine, so alphabetical sorting can
                -- otherwise push it past the eight-row display limit.
                local aWorldBoss = a and a.id == "midnight_s2_world_boss"
                local bWorldBoss = b and b.id == "midnight_s2_world_boss"
                if aWorldBoss ~= bWorldBoss then
                    return aWorldBoss
                end

                local rank = { ready=1, unknown=2, completed=3, scheduled=4 }
                local ar = rank[a.status] or 5
                local br = rank[b.status] or 5
                if ar ~= br then return ar < br end
                return tostring(a.title or "") < tostring(b.title or "")
            end

            local activities = GetActivities()
            local daily, weekly = {}, {}
            for _, activity in ipairs(activities) do
                if FrequencyIs(activity, "Daily") then
                    daily[#daily + 1] = activity
                elseif FrequencyIs(activity, "Weekly") then
                    weekly[#weekly + 1] = activity
                end
            end
            table.sort(daily, SortFocus)
            table.sort(weekly, SortFocus)

            -- ================================================================
            -- TOP LEFT: DAILY FOCUS
            -- ================================================================
            local dailyFocus = RCard(page, 252, 238, 275, -4, {0.38,0.30,0.08,0.95})
            RL(dailyFocus, "DAILY FOCUS", 14, -14, 150, GOLD, "GameFontNormalLarge")
            RL(dailyFocus, "(" .. tostring(math.min(3, #daily)) .. " tasks)", 160, -16, 75, MUTED, "GameFontNormal")
            RL(dailyFocus, "Only the routines that matter today.", 14, -39, 232, MUTED, "GameFontNormalSmall")
            RL(dailyFocus, "Only the ones worth your attention.", 14, -55, 232, MUTED, "GameFontNormalSmall")

            local focusRows = {}
            local function BuildDailyFocus()
                for _, row in ipairs(focusRows) do row:Hide() end
                focusRows = {}
                if #daily == 0 then
                    RL(dailyFocus, "No daily routines observed yet.", 14, -88, 230, MUTED, "GameFontNormal")
                    RL(dailyFocus, "GoldMint will learn repeatable activities as you play.", 14, -116, 230, MUTED, "GameFontNormalSmall")
                    return
                end
                for i = 1, math.min(3, #daily) do
                    local activity = daily[i]
                    local row = CreateFrame("Frame", nil, dailyFocus, "BackdropTemplate")
                    row:SetSize(220, 46)
                    row:SetPoint("TOPLEFT", 14, -78 - ((i-1)*49))
                    row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
                    row:SetBackdropColor(i == 1 and 0.18 or 0.035, i == 1 and 0.15 or 0.075, i == 1 and 0.045 or 0.11, i == 1 and 0.72 or 0.55)
                    row:SetBackdropBorderColor(i == 1 and 0.42 or 0.12, i == 1 and 0.35 or 0.30, i == 1 and 0.10 or 0.46, 0.9)
                    Checkbox(row, 8, -14, activity.status == "completed", function()
                        GoldMint.Print("Routine completion is learned from Blizzard quest state; GoldMint updates it automatically.")
                    end)
                    local titleText = tostring(activity.title or "Routine")
                    if #titleText > 24 then titleText = titleText:sub(1,21) .. "..." end
                    RL(row, titleText, 34, -8, 120, i == 1 and {1,0.88,0.52} or MUTED, i == 1 and "GameFontNormal" or "GameFontNormalSmall")
                    local action = RButton(row, activity.status == "ready" and "VIEW" or "VIEW", 52, 24, 154, -11, "secondary")
                    action:SetScript("OnClick", function()
                        ShowRoutineDetail(activity)
                    end)
                    focusRows[#focusRows + 1] = row
                end
            end
            BuildDailyFocus()

            -- ================================================================
            -- TOP RIGHT: WEEKLY OVERVIEW
            -- ================================================================
            local weeklyCard = RCard(page, 586, 238, 550, -4, {0.08,0.38,0.58,0.95})
            RL(weeklyCard, "WEEKLY TASK OVERVIEW", 14, -14, 250, CYAN, "GameFontNormalLarge")
            RL(weeklyCard, "ROUTINE ERA", 14, -39, 100, MUTED, "GameFontNormalSmall")
            local routineEra = "current"
            -- Keep the era tabs fully inside the card.  The previous layout
            -- pushed the long CURRENT EXPANSION label too close to the card
            -- edge, which made the control look like it was overlapping the
            -- surrounding frame at smaller UI scales.
            local currentTab = RButton(weeklyCard, "CURRENT EXPANSION", 132, 24, 106, -31, "primary")
            local legacyTab = RButton(weeklyCard, "LEGACY", 72, 24, 244, -31, "secondary")
            currentTab.text:SetFontObject("GameFontNormalSmall")
            currentTab.text:SetWidth(124)
            currentTab.text:SetWordWrap(false)
            currentTab.text:SetNonSpaceWrap(false)
            legacyTab.text:SetFontObject("GameFontNormalSmall")

            -- Routines are event-driven now. No periodic or manual quest-log
            -- scan is needed; completing the quest removes it from the active
            -- list and the normal reset resolver makes it ready again later.

            local weeklyScroll, weeklyRows = CreateGoldMintScrollFrame(weeklyCard, 10, -63, -10, 10, 399)

            -- Manual weekly checklist state.  The checkbox in the Weekly Task
            -- Overview is an actionable checklist control, not just a visual
            -- reflection of Blizzard quest completion.  Keep the player's
            -- dismissals for the current weekly reset so checking a row removes
            -- it immediately and it stays out of the list when the panel is
            -- rebuilt.  A new weekly reset starts a fresh checklist.
            local function GetWeeklyChecklistReset()
                local now = time()
                if C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset then
                    local remaining = tonumber(C_DateAndTime.GetSecondsUntilWeeklyReset())
                    if remaining and remaining >= 0 then
                        return now - (7 * 24 * 60 * 60 - remaining)
                    end
                end
                return math.floor(now / (7 * 24 * 60 * 60)) * (7 * 24 * 60 * 60)
            end

            local function EnsureWeeklyChecklist()
                GoldMintDB.routineWeeklyChecklist = type(GoldMintDB.routineWeeklyChecklist) == "table" and GoldMintDB.routineWeeklyChecklist or {}
                local store = GoldMintDB.routineWeeklyChecklist
                local reset = GetWeeklyChecklistReset()
                if tonumber(store.reset) ~= tonumber(reset) then
                    store.reset = reset
                    store.dismissed = {}
                end
                store.dismissed = type(store.dismissed) == "table" and store.dismissed or {}
                return store
            end

            local function WeeklyChecklistKey(activity)
                if activity and activity.questID then
                    return "quest:" .. tostring(activity.questID)
                end
                return "activity:" .. tostring(activity and activity.category or "routine") .. "|" .. tostring(activity and activity.title or "")
            end

            local function IsWeeklyDismissed(activity)
                return EnsureWeeklyChecklist().dismissed[WeeklyChecklistKey(activity)] == true
            end

            local function DismissWeeklyActivity(activity)
                local store = EnsureWeeklyChecklist()
                store.dismissed[WeeklyChecklistKey(activity)] = true
            end

            local function SetRoutineEra(era)
                routineEra = era
                currentTab:SetBackdropBorderColor(unpack(era == "current" and GOLD or {0.08,0.30,0.46,0.95}))
                legacyTab:SetBackdropBorderColor(unpack(era == "legacy" and GOLD or {0.08,0.30,0.46,0.95}))
                for _, child in ipairs({weeklyRows:GetChildren()}) do child:Hide() end
                local sourceList = era == "current" and weekly or GetLegacyActivities()
                local list = {}
                for _, activity in ipairs(sourceList) do
                    if not IsWeeklyDismissed(activity) then
                        list[#list + 1] = activity
                    end
                end
                table.sort(list, SortFocus)
                if #list == 0 then
                    RL(weeklyRows, era == "current" and "No current-expansion weekly routines are observed." or "No legacy routines are observed.", 8, -8, 385, MUTED, "GameFontNormal")
                    weeklyRows:SetHeight(52)
                    return
                end
                local rowH = 31
                for i, activity in ipairs(list) do
                    if i > 8 then break end
                    local row = CreateFrame("Frame", nil, weeklyRows)
                    row:SetSize(390, rowH)
                    row:SetPoint("TOPLEFT", 4, -((i-1)*rowH))
                    Checkbox(row, 0, -6, false, function()
                        DismissWeeklyActivity(activity)
                        SetRoutineEra(routineEra)
                    end)
                    local prefix = activity.category and string.upper(tostring(activity.category)) or "ROUTINE"
                    local text = prefix .. ": " .. tostring(activity.title or "")
                    if #text > 48 then text = text:sub(1,45) .. "..." end
                    RL(row, text, 26, -4, 300, activity.status == "completed" and MUTED or {0.78,0.72,0.58}, "GameFontNormalSmall")
                    local statusText = activity.status == "completed" and "DONE" or (activity.status == "ready" and "READY" or "TRACK")
                    RL(row, statusText, 330, -4, 52, activity.status == "ready" and GREEN or (activity.status == "completed" and MUTED or GOLD), "GameFontNormalSmall", "RIGHT")
                end
                weeklyRows:SetHeight(math.max(52, math.min(8,#list)*rowH + 10))
            end
            currentTab:SetScript("OnClick", function() SetRoutineEra("current") end)
            legacyTab:SetScript("OnClick", function() SetRoutineEra("legacy") end)
            SetRoutineEra("current")

            -- ================================================================
            -- BOTTOM LEFT: WORLD QUEST OPPORTUNITIES
            -- ================================================================
            -- GoldMint scans Blizzard's live World Quest data and only shows
            -- quests with a gold, mount, or achievement-related reward.
            local questCard = RCard(page, 252, 538, 0, -4, {0.08,0.38,0.58,0.95})
            RL(questCard, "World Quests", 14, -14, 224, CYAN, "GameFontNormalLarge")
            RL(questCard, "GOLD • MOUNTS • ACHIEVEMENTS", 14, -37, 224, MUTED, "GameFontNormalSmall")

            local questRows = {}
            local questStatus = RL(questCard, "SCANNING WORLD QUESTS...", 14, -64, 224, GOLD, "GameFontNormalSmall")
            local questEmpty1 = RL(questCard, "", 14, -94, 224, MUTED, "GameFontNormalSmall")
            local questEmpty2 = RL(questCard, "", 14, -112, 224, MUTED, "GameFontNormalSmall")
            local questEmpty3 = RL(questCard, "", 14, -130, 224, MUTED, "GameFontNormalSmall")
            local questMore = RL(questCard, "", 14, -510, 224, MUTED, "GameFontNormalSmall")

            local function ClearWorldQuestRows()
                for _, row in ipairs(questRows) do
                    if row and row.Hide then row:Hide() end
                end
                questRows = {}
            end

            local function RewardColor(row)
                if row.mount then return GOLD end
                if row.achievement then return CYAN end
                return GREEN
            end

            local function BuildWorldQuestRows()
                ClearWorldQuestRows()
                local tracker = GoldMint.WorldQuestTracker
                local list = tracker and tracker.GetRows and tracker:GetRows() or {}

                questEmpty1:SetText("")
                questEmpty2:SetText("")
                questEmpty3:SetText("")
                questMore:SetText("")

                if #list == 0 then
                    questStatus:SetText("No matching World Quests found.")
                    questStatus:SetTextColor(unpack(MUTED))
                    questEmpty1:SetText("GoldMint checks the live World Quest")
                    questEmpty2:SetText("reward data for gold, mounts, and")
                    questEmpty3:SetText("achievement-related rewards.")
                    return
                end

                questStatus:SetText(string.format("%d matching World Quest%s", #list, #list == 1 and "" or "s"))
                questStatus:SetTextColor(unpack(GREEN))

                local maxRows = math.min(12, #list)
                for i = 1, maxRows do
                    local data = list[i]
                    local row = CreateFrame("Button", nil, questCard)
                    row:SetSize(224, 34)
                    row:SetPoint("TOPLEFT", 14, -82 - ((i-1) * 34))
                    row:EnableMouse(true)
                    row:RegisterForClicks("LeftButtonUp")

                    if i > 1 then
                        local line = row:CreateTexture(nil, "ARTWORK")
                        line:SetTexture("Interface\\Buttons\\WHITE8X8")
                        line:SetVertexColor(0.08,0.30,0.46,0.65)
                        line:SetSize(224, 1)
                        line:SetPoint("TOPLEFT", 0, 1)
                    end

                    local title = tostring(data.title or "World Quest")
                    if #title > 27 then title = title:sub(1,24) .. "..." end
                    RL(row, title, 0, -4, 156, RewardColor(data), "GameFontNormalSmall")

                    local reward = tostring(data.rewardText or "")
                    if data.gold then
                        reward = "GOLD " .. (tracker and tracker.FormatMoney and tracker:FormatMoney(data.gold) or "")
                    elseif data.mount then
                        reward = "MOUNT"
                    elseif data.achievement then
                        reward = "ACHIEVEMENT"
                    end
                    RL(row, reward, 158, -4, 66, RewardColor(data), "GameFontNormalSmall", "RIGHT")

                    local zone = tostring(data.zone or "")
                    if #zone > 22 then zone = zone:sub(1,19) .. "..." end
                    local timeText = tracker and tracker.FormatTime and tracker:FormatTime(data.timeLeft) or "TIME UNKNOWN"
                    RL(row, zone .. " • " .. timeText, 0, -20, 224, MUTED, "GameFontNormalSmall")

                    row:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:AddLine(data.title or "World Quest", 0.2, 0.9, 1)
                        GameTooltip:AddLine(data.zone or "", 0.72, 0.84, 0.96)
                        if data.gold then GameTooltip:AddLine("Gold: " .. (tracker:FormatMoney(data.gold)), 0.2, 1, 0.2) end
                        if data.mount then GameTooltip:AddLine("Mount reward", 1, 0.82, 0.2) end
                        if data.achievement then GameTooltip:AddLine("Achievement-related reward", 0.2, 0.9, 1) end
                        if data.timeLeft then GameTooltip:AddLine("Expires in: " .. tracker:FormatTime(data.timeLeft), 0.72, 0.84, 0.96) end
                        GameTooltip:AddLine("Click to view this World Quest on the map.", 0.65, 0.65, 0.65)
                        GameTooltip:Show()
                    end)
                    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    row:SetScript("OnClick", function()
                        if C_QuestLog and C_QuestLog.SetMapForQuestPOIs and data.mapID then
                            pcall(C_QuestLog.SetMapForQuestPOIs, data.mapID)
                        end
                        if C_QuestLog and C_QuestLog.SetSelectedQuest and data.questID then
                            pcall(C_QuestLog.SetSelectedQuest, data.questID)
                        end
                        if C_Map and C_Map.OpenWorldMap then
                            pcall(C_Map.OpenWorldMap, data.mapID)
                        end
                    end)

                    questRows[#questRows + 1] = row
                end

                if #list > maxRows then
                    questMore:SetText("+ " .. tostring(#list - maxRows) .. " more matching quests")
                end
            end

            -- Build once for the initial state, then let the tracker notify
            -- this card only when the matching World Quest result set changes.
            BuildWorldQuestRows()

            -- WorldQuestTracker continues scanning in the background, but it
            -- notifies the UI only when the matching World Quest result set
            -- actually changes. This prevents the card from rebuilding every
            -- few seconds while still allowing newly-appearing quests (and
            -- quests that disappear/expire) to show immediately.
            local tracker = GoldMint.WorldQuestTracker
            if tracker and tracker.SetOnChanged then
                tracker:SetOnChanged(function()
                    if questCard:IsShown() then
                        BuildWorldQuestRows()
                    end
                end)
            end

            -- ================================================================
            -- BOTTOM CENTER: WORLD BOSS TIMERS
            -- ================================================================
            -- Standalone GoldMint world-boss timer engine.
            local bossCard = RCard(page, 252, 290, 275, -252, {0.08,0.38,0.58,0.95})
            RL(bossCard, "WORLD BOSS TIMERS", 14, -14, 220, CYAN, "GameFontNormalLarge")
            RL(bossCard, "RESPAWN WINDOWS", 14, -37, 180, MUTED, "GameFontNormalSmall")

            local bossRows = {}
            local bossUpdateFrame = CreateFrame("Frame", nil, bossCard)
            bossUpdateFrame:SetAllPoints()
            local function FormatClock(seconds)
                seconds = math.max(0, math.floor(tonumber(seconds) or 0))
                local mins = math.floor(seconds / 60)
                local secs = seconds % 60
                return string.format("%02d:%02d", mins, secs)
            end

            local function FormatBossTimer(seconds)
                seconds = tonumber(seconds)
                if not seconds then return "--:--" end
                if seconds <= 0 then return "READY" end
                local s = math.floor(seconds)
                local mins = math.floor(s / 60)
                local secs = s % 60
                return string.format("%02d:%02d", mins, secs)
            end

            local function GetWorldBossRows()
                if not GoldMint.WorldBossTimers or not GoldMint.WorldBossTimers.GetRows then
                    return nil, "World Boss Timers are unavailable."
                end
                return GoldMint.WorldBossTimers:GetRows()
            end

            local function ClearBossRows()
                for _, row in ipairs(bossRows) do row:Hide() end
                bossRows = {}
            end

            local function BuildBossRows()
                ClearBossRows()
                local list, unavailable = GetWorldBossRows()
                if not list then
                    RL(bossCard, unavailable or "World Boss Timers unavailable.", 14, -70, 220, GOLD, "GameFontNormalSmall")
                    RL(bossCard, "GoldMint tracks boss deaths", 14, -94, 220, MUTED, "GameFontNormalSmall")
                    RL(bossCard, "and respawn windows automatically.", 14, -112, 220, MUTED, "GameFontNormalSmall")
                    return
                end

                if #list == 0 then
                    RL(bossCard, "No world bosses are configured.", 14, -70, 220, MUTED, "GameFontNormal")
                    return
                end

                local shown = math.min(6, #list)
                for i = 1, shown do
                    local data = list[i]
                    local row = CreateFrame("Frame", nil, bossCard)
                    row:SetSize(224, 29)
                    row:SetPoint("TOPLEFT", 14, -63 - ((i-1) * 30))

                    if i > 1 then
                        local line = row:CreateTexture(nil, "ARTWORK")
                        line:SetTexture("Interface\\Buttons\\WHITE8X8")
                        line:SetVertexColor(0.08,0.30,0.46,0.70)
                        line:SetSize(224, 1)
                        line:SetPoint("TOPLEFT", 0, 1)
                    end

                    local bossName = data.name
                    if #bossName > 23 then bossName = bossName:sub(1,20) .. "..." end
                    local nameColor = data.highlight and GOLD or (data.hasTimer and CYAN or MUTED)
                    RL(row, bossName, 0, -5, 142, nameColor, "GameFontNormalSmall")

                    local timerText
                    local timerColor
                    if data.midnightActive then
                        timerText = "ACTIVE"
                        timerColor = GREEN
                    elseif data.midnightLair then
                        timerText = "WEEKLY"
                        timerColor = GOLD
                    elseif not data.hasTimer then
                        timerText = "NO TIMER"
                        timerColor = MUTED
                    elseif data.max and data.max <= 0 then
                        timerText = "READY"
                        timerColor = GREEN
                    elseif data.random then
                        local lower = tonumber(data.min) or 0
                        local upper = tonumber(data.max) or lower
                        timerText = (lower <= 0 and "READY" or FormatClock(lower)) .. " - " .. FormatClock(upper)
                        timerColor = GOLD
                    else
                        timerText = FormatBossTimer(data.min or data.max or 0)
                        timerColor = GOLD
                    end
                    RL(row, timerText, 146, -5, 78, timerColor, "GameFontNormalSmall", "RIGHT")

                    local zone = data.zone
                    if data.saved then zone = (zone ~= "" and zone .. " • SAVED" or "SAVED") end
                    if data.realm and data.realm ~= "" then zone = (zone ~= "" and zone .. " • " or "") .. tostring(data.realm) end
                    if zone and zone ~= "" then
                        if #zone > 31 then zone = zone:sub(1,28) .. "..." end
                        RL(row, zone, 0, -20, 142, data.saved and GOLD or MUTED, "GameFontNormalSmall")
                    end

                    bossRows[#bossRows + 1] = row
                end

            end

            BuildBossRows()

            bossUpdateFrame:SetScript("OnHide", function(self)
                if self._ticker then self._ticker:Cancel(); self._ticker = nil end
            end)
            bossUpdateFrame:SetScript("OnShow", function(self)
                if self._ticker then self._ticker:Cancel() end
                self._ticker = C_Timer.NewTicker(1, function()
                    if bossCard:IsShown() then BuildBossRows() end
                end)
            end)
            if bossCard:IsShown() then bossUpdateFrame:Show() end

            local requestBossTimers = RButton(bossCard, "REQUEST TIMERS", 112, 24, 126, -250, "secondary")
            requestBossTimers:SetScript("OnClick", function()
                if GoldMint.WorldBossTimers and GoldMint.WorldBossTimers.RequestTimers then
                    GoldMint.WorldBossTimers:RequestTimers()
                    GoldMint.Print("Requested World Boss timer data from nearby players.")
                else
                    GoldMint.Print("World Boss Timers are unavailable.")
                end
                BuildBossRows()
            end)


            -- ================================================================
            -- BOTTOM RIGHT: RARE RECIPE SPAWN TIMERS
            -- ================================================================
            local rareCard = RCard(page, 586, 290, 550, -252, {0.08,0.38,0.58,0.95})
            RL(rareCard, "RARE RECIPE SPAWN TIMERS", 14, -14, 520, CYAN, "GameFontNormalLarge")
            local clock = rareCard:CreateTexture(nil, "ARTWORK")
            clock:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintRoutineStopwatch.tga")
            clock:SetSize(78,78)
            clock:SetPoint("TOPLEFT", 18, -54)

            local realmTime = RL(rareCard, "", 112, -60, 450, MUTED, "GameFontNormalSmall")
            local rareStatus = RL(rareCard, "", 112, -80, 450, MUTED, "GameFontNormal")
            local rareHint = RL(rareCard, "", 112, -104, 450, MUTED, "GameFontNormalSmall")
            local rareRows = {}

            for i = 1, 4 do
                local row = CreateFrame("Frame", nil, rareCard)
                row:SetSize(510, 24)
                row:SetPoint("TOPLEFT", 18, -132 - ((i-1) * 25))
                local label = RL(row, "", 26, 0, 330, MUTED, "GameFontNormalSmall")
                local timer = RL(row, "", 370, 0, 125, CYAN, "GameFontNormalSmall")
                rareRows[i] = {frame=row, label=label, timer=timer}
            end

            local setAlerts = RButton(rareCard, "SET ALERTS", 125, 26, 290, -250, "secondary")
            setAlerts:SetScript("OnClick", function()
                if GoldMint.OpenOptions then
                    GoldMint:OpenOptions("rarerecipealerts")
                end
            end)

            local function RefreshRareRecipeCard()
                local rare = GoldMint.RareRecipeAlerts
                local watches = rare and rare.GetWatches and rare:GetWatches() or {}
                realmTime:SetText("Realm Time: " .. date("%H:%M"))

                for _, row in ipairs(rareRows) do row.frame:Hide() end

                if not rare then
                    rareStatus:SetText("Rare recipe spawn alerts are unavailable.")
                    rareHint:SetText("Reload the interface after installing the current GoldMint build.")
                    return
                end

                if #watches == 0 then
                    rareStatus:SetText("No rare recipe sources are configured.")
                    rareHint:SetText("Use SET ALERTS to add the NPC and respawn interval.")
                    return
                end

                local shown = math.min(4, #watches)
                rareStatus:SetText(rare:GetSettings().enabled and "Spawn alerts are enabled." or "Spawn alerts are disabled.")
                rareHint:SetText("Timers begin after GoldMint detects a configured source.")

                for i = 1, shown do
                    local watch = watches[i]
                    local row = rareRows[i]
                    row.frame:Show()
                    row.label:SetText(tostring(watch.name or "Rare Recipe Source"))
                    if watch.nextSpawn and tonumber(watch.nextSpawn) > time() then
                        row.timer:SetText(rare:FormatRemaining(watch.nextSpawn))
                    else
                        row.timer:SetText("WAITING")
                    end
                end
            end

            RefreshRareRecipeCard()
            local rareUpdateFrame = CreateFrame("Frame", nil, rareCard)
            local function StartRareCardTicker()
                if rareUpdateFrame._ticker then rareUpdateFrame._ticker:Cancel(); rareUpdateFrame._ticker = nil end
                local rare = GoldMint.RareRecipeAlerts
                local watches = rare and rare.GetWatches and rare:GetWatches() or {}
                local enabled = rare and rare.GetSettings and rare:GetSettings().enabled
                if not enabled or #watches == 0 then return end
                rareUpdateFrame._ticker = C_Timer.NewTicker(60, function()
                    if rareCard:IsShown() then RefreshRareRecipeCard() else StartRareCardTicker() end
                end)
            end
            rareUpdateFrame:SetScript("OnShow", function() StartRareCardTicker() end)
            rareUpdateFrame:SetScript("OnHide", function(self)
                if self._ticker then self._ticker:Cancel(); self._ticker = nil end
            end)
            StartRareCardTicker()

        end
        local builders={routines=routines,wealth=GoldMint.BuildWealthPage,cooldowns=cooldowns}
        show = function(name)
            section=name or section or "wealth"
            SetNavigationActive(section)
            wipeContent()
            local isWealth = section == "wealth"
            local isCooldowns = section == "cooldowns"
            for k,b in pairs(tabButtons) do
                if isWealth or isCooldowns then
                    b:Hide()
                else
                    b:Show()
                    b:SetBackdropBorderColor(k==section and 1.0 or 0.10,k==section and 0.78 or 0.34,k==section and 0.20 or 0.52,1)
                end
            end
            if isWealth or isCooldowns then
                title:SetText("")
                sub:SetText("")
                content:ClearAllPoints()
                if isWealth then
                    -- Wealth has no page title. Start its panel canvas at the
                    -- exact top edge of the navigation bar so the first row
                    -- aligns horizontally with the navigation surface.
                    content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, 0)
                    content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)
                else
                    content:SetPoint("TOPLEFT", view, "TOPLEFT", 18, -8)
                    content:SetPoint("BOTTOMRIGHT", view, "BOTTOMRIGHT", -18, 18)
                end
            else
                title:SetText("GOLDMINT OPERATIONS")
                sub:SetText("Wealth, cooldowns, routines, and lightweight maintenance tools.")
                content:ClearAllPoints()
                content:SetPoint("TOPLEFT",22,-130)
                content:SetPoint("BOTTOMRIGHT",-22,22)
            end
            -- Cooldowns' header is part of the cooldown page, but we still
            -- explicitly show/hide the page here so navigation remains deterministic.
            if panels.cooldownsPage and panels.cooldownsPage.header then
                if isCooldowns then
                    panels.cooldownsPage.header:Show()
                    panels.cooldownsPage:Show()
                else
                    panels.cooldownsPage.header:Hide()
                    panels.cooldownsPage:Hide()
                end
            end

            local builder=builders[section]
            if builder then builder(content, view) else L("SECTION UNAVAILABLE",18,-16,500,RED,"GameFontHighlight"); L("GoldMint could not build this section.",18,-42,820,MUTED,"GameFontNormal") end

            -- Prime the live wallet immediately when navigating into Wealth.
            -- The character wallet can receive its final client-side value one
            -- frame/event after navigation; retrying on the next few frames
            -- prevents the header from briefly showing an older cached amount.
            if section == "wealth" then
                if GoldMint.Ledger and GoldMint.Ledger.UpdateCharacterGold then
                    GoldMint.Ledger:UpdateCharacterGold()
                end
                if GoldMint.Economy and GoldMint.Economy.ScheduleRefresh then
                    GoldMint.Economy:ScheduleRefresh("wealth_navigation", 0.05)
                end
                Refresh()
                local wealthGeneration = (frame._wealthRefreshGeneration or 0) + 1
                frame._wealthRefreshGeneration = wealthGeneration
                local function queueWealthRefresh(delay)
                    C_Timer.After(delay, function()
                        if frame and frame:IsShown() and activeNavKey == "wealth" and frame._wealthRefreshGeneration == wealthGeneration then
                            GoldMint:SafeCall("dashboard wealth repaint", Refresh)
                        end
                    end)
                end
                queueWealthRefresh(0)
                queueWealthRefresh(0.10)
                queueWealthRefresh(0.35)
            end
        end
        for i,name in ipairs(tabs) do local tabLabel = (name == "recipes") and "CRAFTING" or name:upper(); local b=MakeButton(view,tabLabel,130,30,"secondary"); b:SetPoint("TOPLEFT",22+(i-1)*142,-84); b:SetScript("OnClick",function() show(name) end); tabButtons[name]=b end
        panels.operationsShow = show
        view:SetScript("OnShow",function() show(section or "wealth") end); panels.operationsView=view
    end
    SetHomePanelsShown(false)
    if panels.projectsView then panels.projectsView:Hide() end
    panels.operationsView:Show(); panels.operationsView:Raise()
    if panels.operationsShow then
        panels.operationsShow(section or "wealth")
    end
    SetNavigationActive(section or "wealth")
end

function Dashboard:OpenSettings()
    -- Settings is a separate GoldMint window. Opening it closes the dashboard
    -- so the two large interfaces never overlap.
    if GoldMint.OpenOptions then
        GoldMint:OpenOptions()
    end
end

function Dashboard:OpenCooldownRecipe(recipeID)
    recipeID = tonumber(recipeID)
    if not recipeID then return end

    if OpenOperations then
        OpenOperations("cooldowns")
    end

    local page = panels.cooldownsPage
    if not page then return end

    page._focusRecipeID = recipeID
    page.filter = "READY"
    if page.filterText then
        page.filterText:SetText("READY")
    end
    if page.Refresh then
        page:Refresh()
    end

    -- Bring the focused recipe into view after the rows have been rebuilt.
    if page.rows and page.scroll then
        for i, row in ipairs(page.rows) do
            if row:IsShown() and tonumber(row.recipeID) == recipeID then
                local target = math.max(0, (i - 1) * 78 - 20)
                page.scroll:SetVerticalScroll(target)
                if page.scroll.UpdateGoldMintScrollBar then
                    page.scroll:UpdateGoldMintScrollBar()
                end
                break
            end
        end
    end
end

function Dashboard:ShowHome()
    if cooldownFilterMenu then cooldownFilterMenu:Hide() end
    if panels.operationsView then panels.operationsView:Hide() end
    if panels.projectsView then panels.projectsView:Hide() end
    SetHomePanelsShown(true)
    SetNavigationActive("dashboard")
    Refresh()
end

local function BuildNavigation()
    local nav = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    nav:SetPoint("TOPLEFT", 20, -126)
    nav:SetSize(190, 570)
    nav:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true,
        tileSize = 16,
        edgeSize = 1,
    })
    nav:SetBackdropColor(0.004, 0.020, 0.040, 1.0)
    nav:SetBackdropBorderColor(0.10, 0.42, 0.66, 0.85)
    panels.nav = nav

    local items = {
        {"Home", "dashboard", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavHome"},
        {"Wealth", "wealth", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavWealth"},
        {"Routines", "routines", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavRoutines"},
        {"Projects", "projects", "Interface\\AddOns\\GoldMint\\Assets\\GoldMintNavProjects"},
    }

    for i, item in ipairs(items) do
        local b = CreateFrame("Button", nil, nav, "BackdropTemplate")
        b:SetSize(188, 48)
        b:SetPoint("TOPLEFT", 0, -((i - 1) * 51))
        b:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            tile = true, tileSize = 16,
        })
        b:SetBackdropColor(0, 0, 0, 0)
        if item[3] then
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetTexture(item[3])
            b.icon:SetSize(34, 34)
            b.icon:SetPoint("CENTER", -44, 0)

            -- Keep the navigation labels beside their icons.  Use a bold
            -- outlined font so the cyan lettering stays crisp over the dark UI.
            b.text = MakeLabel(b, "GameFontNormal", item[1], 108)
            b.text:SetPoint("LEFT", 76, 0)
            b.text:SetJustifyH("LEFT")
            local font, _, _ = b.text:GetFont()
            if font then
                b.text:SetFont(font, 13, "OUTLINE")
            end
            b.text:SetShadowOffset(1, -1)
            b.text:SetTextColor(unpack(CYAN))
            b.text:SetWordWrap(false)
        else
            b.text = MakeLabel(b, "GameFontNormal", item[1])
            b.text:SetPoint("LEFT", 22, 0)
            b.text:SetShadowOffset(1, -1)
            b.text:SetTextColor(unpack(MUTED))
        end
        -- Horizontal cyan accent under every navigation icon.
        local navLine = b:CreateTexture(nil, "ARTWORK")
        navLine:SetColorTexture(0.30, 0.90, 1.0, 1.0)
        navLine:SetSize(150, 2)
        navLine:SetPoint("TOPLEFT", 20, -43)

        local navLineGlow = b:CreateTexture(nil, "BACKGROUND")
        navLineGlow:SetColorTexture(0.20, 0.78, 1.0, 0.32)
        navLineGlow:SetSize(154, 6)
        navLineGlow:SetPoint("CENTER", navLine, "CENTER", 0, 0)

        local accent = b:CreateTexture(nil, "ARTWORK")
        accent:SetColorTexture(0.08, 0.78, 1.0, 0.95)
        accent:SetSize(3, 48)
        accent:SetPoint("TOPLEFT", 0, 0)
        accent:Hide()
        b.accent = accent

        b:SetScript("OnEnter", function(self)
            if activeNavKey ~= item[2] then
                ApplyNavState(self, false, true)
            end
        end)
        b:SetScript("OnLeave", function(self)
            if activeNavKey == item[2] then
                ApplyNavState(self, true, false)
            else
                ApplyNavState(self, false, false)
            end
        end)
        navButtons[item[2]] = b

        if item[2] == "dashboard" then
            b:SetScript("OnClick", function()
                if cooldownFilterMenu then cooldownFilterMenu:Hide() end
                if panels.operationsView then panels.operationsView:Hide() end
                if panels.projectsView then panels.projectsView:Hide() end
                            SetHomePanelsShown(true)
                SetNavigationActive("dashboard")
                Refresh()
            end)
        elseif item[2] == "projects" then
            b:SetScript("OnClick", function()
                if cooldownFilterMenu then cooldownFilterMenu:Hide() end
                            SetNavigationActive("projects")
                OpenProjects()
            end)
        elseif item[2] == "cooldowns" or item[2] == "routines" or item[2] == "wealth" then
            b:SetScript("OnClick", function() OpenOperations(item[2]) end)
        end
    end

    SetNavigationActive("dashboard")

    -- Footer brand artwork uses the newly supplied horizontal GoldMint mark.
    local footerLogo = nav:CreateTexture(nil, "ARTWORK")
    footerLogo:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintFooter")
    footerLogo:SetSize(165, 79)
    footerLogo:SetPoint("BOTTOMLEFT", 18, -105)
    footerLogo:SetTexCoord(0, 1, 0, 1)
    panels.footerLogo = footerLogo
end

local function GetMinimapSettings()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    local settings = GoldMintDB.settings
    if settings.minimapButtonShown == nil then settings.minimapButtonShown = true end
    if settings.minimapButtonAngle == nil then settings.minimapButtonAngle = 45 end
    return settings
end

local function PositionMinimapButton()
    if not minimapButton or not Minimap then return end
    local settings = GetMinimapSettings()
    local angle = math.rad(tonumber(settings.minimapButtonAngle) or 45)
    -- Keep the smaller 48px button completely outside the minimap's circular edge.
    -- Calculate from the live minimap size so UI scaling/custom minimap sizes
    -- cannot pull the button back inside the map.
    local mapSize = tonumber(Minimap:GetWidth()) or 176
    local radius = (mapSize * 0.5) + 30
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

function Dashboard:BuildMinimapButton()
    -- The minimap button has a single owner: Core.lua. Reuse that same frame
    -- here instead of creating a second button or replacing its scripts.
    if GoldMint and GoldMint.BuildLightweightMinimapButton then
        minimapButton = GoldMint:BuildLightweightMinimapButton()
    end
    if minimapButton then
        panels.minimapButton = minimapButton
    end
end

local function RefreshGoal(status)
    local widget = panels.goalWidget
    if not widget then return end

    if not status then
        widget.Title:SetText("YOUR GOAL: No active goal")
        widget.ProgressArc.Text:SetText("0%")
        widget.PacingText:SetText("Current Pacing: —")
        widget.EstText:SetText("Goal Est: —")
        if widget.ProgressArc.Fill then widget.ProgressArc.Fill:Hide() end
        if widget.ProgressLine then
            widget.ProgressLine:SetValue(0)
        end
        for _, seg in ipairs(widget.ProgressArc._fallbackSegments or {}) do seg:Hide() end
        return
    end

    local progress = math.max(0, math.min(1, tonumber(status.progress) or 0))
    local current = tonumber(status.currentValue) or 0
    local target = tonumber(status.target) or 0
    local weekly = status.weekly or {}

    widget.Title:SetText("YOUR GOAL: " .. tostring(status.name or "Savings Goal"))
    widget.ProgressArc.Text:SetText(string.format("%d%%", math.floor(progress * 100 + 0.5)))

    if weekly.status == "ahead" then
        widget.PacingText:SetText("Current Pacing: Ahead by " .. FormatGold(math.abs(tonumber(weekly.aheadBehind) or 0)))
        widget.PacingText:SetTextColor(unpack(GREEN))
    elseif weekly.status == "behind" then
        widget.PacingText:SetText("Current Pacing: Behind by " .. FormatGold(math.abs(tonumber(weekly.aheadBehind) or 0)))
        widget.PacingText:SetTextColor(unpack(RED))
    elseif weekly.status == "complete" then
        widget.PacingText:SetText("Current Pacing: Goal complete")
        widget.PacingText:SetTextColor(unpack(GREEN))
    elseif weekly.status == "baseline" then
        widget.PacingText:SetText("Current Pacing: " .. FormatGold(math.max(0, tonumber(weekly.actual) or 0)) .. " / 7 days")
        widget.PacingText:SetTextColor(unpack(MUTED))
    else
        widget.PacingText:SetText("Current Pacing: Building baseline")
        widget.PacingText:SetTextColor(unpack(MUTED))
    end

    local dailyRate = math.max(0, (tonumber(weekly.actual) or 0) / 7)
    local remaining = math.max(target - current, 0)
    local estimateDays
    if remaining <= 0 then
        estimateDays = 0
    elseif dailyRate > 0 then
        estimateDays = math.ceil(remaining / dailyRate)
    end

    if estimateDays then
        widget.EstText:SetText(estimateDays > 0 and ("Goal Est: " .. tostring(estimateDays) .. " days") or "Goal Est: Reached")
    else
        widget.EstText:SetText("Goal Est: —")
    end
    widget.EstText:SetTextColor(unpack(MUTED))

    UpdateGoldProgress(widget, current, target)
end

local function GetDailyProfit()
    if GoldMint.Ledger and GoldMint.Ledger.GetDailyEconomics then
        local daily = GoldMint.Ledger:GetDailyEconomics() or {}
        return tonumber(daily.net) or 0
    end
    return 0
end

local function GetWeeklyProfitSeries()
    local now = time()
    local today = GoldMint.Ledger and GoldMint.Ledger.GetDailyEconomics and GoldMint.Ledger:GetDailyEconomics() or {}
    local todayReset = tonumber(today.resetAt) or now
    local history = GoldMint.Ledger and GoldMint.Ledger.GetDailyHistory and GoldMint.Ledger:GetDailyHistory() or {}

    local byReset = {}
    for _, entry in ipairs(history) do
        byReset[tonumber(entry.resetAt) or 0] = tonumber(entry.net) or 0
    end
    byReset[todayReset] = tonumber(today.net) or 0

    local series = {}
    local total = 0
    local runningTotal = 0
    local daySeconds = 86400
    for i = 6, 0, -1 do
        local startOfDay = todayReset - (i * daySeconds)
        local value = byReset[startOfDay] or 0
        runningTotal = runningTotal + value
        series[#series + 1] = {startOfDay, runningTotal}
        total = total + value
    end

    return series, total
end

local function GetHeaderIntention()
    -- Mirror the first/highlighted task shown in Daily Focus.  Daily Focus
    -- orders ready work first, so the header always reflects the task currently
    -- receiving the player's attention there.
    local state = GoldMint.RoutineState
    if state and state.GetRelevantActivities then
        local activities = state:GetRelevantActivities(GoldMint.characterKey, { currentOnly = true, season = 2 }) or {}
        local daily = {}
        for _, activity in ipairs(activities) do
            if tostring(activity and activity.frequency or "") == "Daily" then
                daily[#daily + 1] = activity
            end
        end

        local rank = { ready = 1, unknown = 2, completed = 3, scheduled = 4 }
        table.sort(daily, function(a, b)
            local ar = rank[a.status] or 5
            local br = rank[b.status] or 5
            if ar ~= br then return ar < br end
            return tostring(a.title or "") < tostring(b.title or "")
        end)

        if daily[1] and daily[1].title and tostring(daily[1].title) ~= "" then
            return tostring(daily[1].title)
        end
    end

    -- If Daily Focus has no observed task, fall back to the player's explicit
    -- workflow task rather than leaving the header misleadingly taskless.
    local workflow = GoldMint.WorkflowState
    if workflow and workflow.GetCurrentTask then
        local task = workflow:GetCurrentTask()
        if task and task.title and tostring(task.title) ~= "" then
            return tostring(task.title)
        end
    end

    return "—"
end

function Refresh()
    -- Keep the dashboard focused on a single clear next step when enabled.
    -- The panel can be hidden from Options without changing workflow state.
    if panels.next then
        local settings = GoldMintDB and GoldMintDB.settings or {}
        -- YOUR NEXT STEP belongs to the Home dashboard only. Refresh() also
        -- runs while Wealth/Operations pages are visible, so never let a
        -- dashboard refresh re-show this panel over another page. Respect the
        -- user's panel visibility setting as well as the workflow preference.
        local onHome = activeNavKey == "dashboard"
        local enabled = settings.showNextStepPanel ~= false
        local oneClearEnabled = settings.oneClearNextStep ~= false
        panels.next:SetShown(onHome and enabled and oneClearEnabled)
    end
    if not frame then return end
    if GoldMint:IsMerchantOpen() then
        -- Do not synchronously force Economy while a vendor is visible. The core
        -- post-merchant refresh will update the dashboard once the inventory settles.
        return
    end

    local status = GoldMint.Economy and GoldMint.Economy:GetStatus() or nil
    local session = status and status.session or nil
    -- Normalize session metrics before the dashboard compares or formats them.
    -- Older/partial Economy status payloads may omit these fields during login.
    local net = session and tonumber(session.netGold) or 0
    local rate = session and tonumber(session.goldPerHour) or 0
    local totalGold = 0
    local wallet = status and status.wallet or nil
    local valuation = status and status.valuation or nil
    local market = status and status.market or nil
    local mail = status and status.mail or nil
    local crafting = status and status.crafting or nil
    local milestoneSummary = status and status.milestones or nil

    -- Gold Total is the actual currency total: current character gold +
    -- Warbank gold. Guild Bank is intentionally excluded from GoldMint.
    local displayGold = GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney() or 0
    displayGold = tonumber(displayGold) or 0
    local displayWarbankGold = wallet and tonumber(wallet.warbandGold) or 0
    local goldTotal = displayGold + displayWarbankGold
    SetText("headerGold", FormatGold(goldTotal))
    SetText("headerValue", "Gold Total")

    -- The old weekly metric is now the live Daily Focus intention.
    SetText("headerWeek", GetHeaderIntention())
    SetText("headerWeekLabel", "Intention")

    -- Session Velocity has been removed from the header.

    -- Mail indicator replaces the duplicated Daily Profit header metric.
    -- MailTracking only reports what has actually been observed for the current
    -- character; if the mailbox has never been scanned, do not guess.
    local mailSummary = GoldMint.MailTracking and GoldMint.MailTracking.GetSummary and GoldMint.MailTracking:GetSummary() or nil
    if mailSummary then
        local scanned = tonumber(mailSummary.lastScanAt) or 0
        local mailCount = tonumber(mailSummary.mailCount) or 0
        local attachmentCount = tonumber(mailSummary.attachmentCount) or 0
        local unreadCount = tonumber(mailSummary.unreadCount) or 0
        if scanned <= 0 then
            if labels.mailIcon then labels.mailIcon:Hide() end
            labels.mailStatus:SetPoint("TOPLEFT", 10, -27)
            labels.mailStatus:SetWidth(146)
            SetText("mailStatus", "NOT SCANNED")
            SetStatus(labels.mailStatus, "muted")
            SetText("mailDetail", "Open mailbox to check")
        elseif mailCount > 0 or attachmentCount > 0 then
            if labels.mailIcon then labels.mailIcon:Show() end
            SetText("mailStatus", "MAIL WAITING")
            SetStatus(labels.mailStatus, "profit")
            local detail = string.format("%d message%s", mailCount, mailCount == 1 and "" or "s")
            if attachmentCount > 0 then
                detail = detail .. string.format(" • %d attachment%s", attachmentCount, attachmentCount == 1 and "" or "s")
            elseif unreadCount > 0 then
                detail = detail .. string.format(" • %d unread", unreadCount)
            end
            SetText("mailDetail", detail)
        else
            if labels.mailIcon then labels.mailIcon:Hide() end
            labels.mailStatus:SetPoint("TOPLEFT", 10, -27)
            labels.mailStatus:SetWidth(146)
            SetText("mailStatus", "NO MAIL")
            SetStatus(labels.mailStatus, "muted")
            SetText("mailDetail", "Mailbox is clear")
        end
    else
        if labels.mailIcon then labels.mailIcon:Hide() end
        labels.mailStatus:SetPoint("TOPLEFT", 10, -27)
        labels.mailStatus:SetWidth(146)
        SetText("mailStatus", "NOT SCANNED")
        SetStatus(labels.mailStatus, "muted")
        SetText("mailDetail", "Open mailbox to check")
    end

    -- WoW Token card uses the same visual language.  The small graph is fed
    -- by the same 24-hour token history used by the Market backend.
    -- Read the live WoW Token market price from Blizzard's public API.
    -- The previous code initialized these locals to empty values, so the card
    -- could only ever display a dash even when the API was available.
    local tokenHistory, tokenCurrent = {}, nil
    if C_WowTokenPublic then
        -- Blizzard exposes a market history in addition to the live price.
        -- Read it so the card can draw a real mini trend instead of a blank
        -- graph (or a single point with no visible line).
        if C_WowTokenPublic.GetPriceHistory then
            local ok, history = pcall(C_WowTokenPublic.GetPriceHistory)
            if ok and type(history) == "table" then
                for _, entry in ipairs(history) do
                    local price = type(entry) == "table" and tonumber(entry.price or entry[1]) or tonumber(entry)
                    if price and price > 0 then
                        if price > 1000000 then price = price / 10 end
                        tokenHistory[#tokenHistory + 1] = { price = price }
                    end
                end
            end
        end
        if C_WowTokenPublic.GetCurrentMarketPrice then
            local ok, price = pcall(C_WowTokenPublic.GetCurrentMarketPrice)
            if ok then
                tokenCurrent = tonumber(price)
                -- C_WowTokenPublic returns copper. Convert to whole gold consistently.
                if tokenCurrent and tokenCurrent > 0 then
                    tokenCurrent = math.floor(tokenCurrent / 10000)
                end
            end
        end
    end
    if tokenCurrent and tokenCurrent > 0 then
        -- Ensure the newest live quote anchors the right edge of the graph.
        if #tokenHistory == 0 or math.abs((tokenHistory[#tokenHistory].price or 0) - tokenCurrent) > 0.01 then
            tokenHistory[#tokenHistory + 1] = { price = tokenCurrent }
        end
    end
    for _, line in ipairs(labels.tokenGraphLines or {}) do line:Hide() end
    labels.tokenTrend:Hide()

    -- If Blizzard provides a current quote but no usable history yet, draw a
    -- neutral, flat sparkline across the graph area. This makes the graph
    -- visibly render without fabricating a price trend or showing a direction.
    -- Once multiple historical samples are available, the real history below
    -- replaces this fallback automatically.
    if tokenCurrent and tokenCurrent > 0 and #tokenHistory < 2 then
        tokenHistory = {}
        for i = 1, 8 do
            tokenHistory[i] = { price = tokenCurrent }
        end
    end

    if #tokenHistory > 8 then
        local sampled = {}
        local step = (#tokenHistory - 1) / 7
        for i = 0, 7 do
            local index = math.floor(i * step + 1.5)
            sampled[#sampled + 1] = tokenHistory[math.min(index, #tokenHistory)]
        end
        tokenHistory = sampled
    end

    if #tokenHistory >= 2 then
        local minPrice, maxPrice = math.huge, -math.huge
        for _, point in ipairs(tokenHistory) do
            local price = tonumber(point.price) or 0
            minPrice = math.min(minPrice, price); maxPrice = math.max(maxPrice, price)
        end
        local span = math.max(maxPrice - minPrice, math.max(maxPrice * 0.005, 1))
        minPrice = minPrice - span * 0.10; maxPrice = maxPrice + span * 0.10; span = maxPrice - minPrice
        local n = #tokenHistory
        for i = 1, math.min(n - 1, #labels.tokenGraphLines) do
            local p1, p2 = tokenHistory[i], tokenHistory[i + 1]
            local a = tonumber(p1.price) or 0
            local b = tonumber(p2.price) or 0
            local x1 = ((i - 1) / (n - 1)) * 62
            local x2 = (i / (n - 1)) * 62
            local y1 = ((a - minPrice) / span) * 42
            local y2 = ((b - minPrice) / span) * 42
            local dx, dy = x2 - x1, y2 - y1
            local len = math.sqrt(dx * dx + dy * dy)
            local line = labels.tokenGraphLines[i]
            line:ClearAllPoints(); line:SetSize(math.max(len, 1), 2)
            line:SetPoint("CENTER", labels.tokenIconBox, "BOTTOMLEFT", 5 + (x1 + x2) * 0.5, 5 + (y1 + y2) * 0.5)
            line:SetRotation(math.atan2(dy, dx)); line:Show()
        end

        local current = tonumber(tokenHistory[#tokenHistory].price) or tokenCurrent or 0
        local first = tonumber(tokenHistory[1].price) or current
        local delta = current - first
        labels.tokenValue:SetText(current > 0 and FormatTokenPrice(current) or "—")
        if delta > 0 then
            labels.tokenValue:SetTextColor(unpack(GREEN))
            labels.tokenTrend:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintTokenUp")
            labels.tokenTrend:Show()
        elseif delta < 0 then
            labels.tokenValue:SetTextColor(unpack(RED))
            labels.tokenTrend:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintTokenDown")
            labels.tokenTrend:Show()
        else
            labels.tokenValue:SetTextColor(unpack(GOLD))
        end
    elseif tokenCurrent then
        labels.tokenValue:SetText(FormatTokenPrice(tokenCurrent))
        labels.tokenValue:SetTextColor(unpack(GOLD))
    else
        labels.tokenValue:SetText("—")
        labels.tokenValue:SetTextColor(unpack(GOLD))
    end

    -- Keep the embedded Wealth page live without rebuilding its frames.
    if activeNavKey == "wealth" and wealthLiveLabels._built then
        local liveWallet = GoldMint.Ledger and GoldMint.Ledger:GetAccountWallet() or {warbandGold=0}
        local livePersonal = GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney() or 0
        livePersonal = tonumber(livePersonal) or 0
        local liveWarband = tonumber(liveWallet.warbandGold) or 0
        local liveHoard = {total=0,accountBank=0}
        local liveMail = 0
        if GoldMint.MailTracking and GoldMint.MailTracking.GetAccountExternalMoneyTotal then
            liveMail = tonumber(GoldMint.MailTracking:GetAccountExternalMoneyTotal()) or 0
        end
        local liveAuction = 0
        local liveWarbankVault = liveWarband
        -- Use the complete known account-wide item hoard for net worth rather than
        -- only the currently logged-in character's inventory.
        local liveAccountItemValue = tonumber(liveHoard.total) or 0
        local liveNetWorth = livePersonal + liveWarbankVault + liveAccountItemValue + liveMail + liveAuction
        local liveGoldTotal = livePersonal + liveWarbankVault
        if labels.headerGold then labels.headerGold:SetText(FormatGold(liveGoldTotal)) end
        if labels.headerValue then labels.headerValue:SetText("Gold Total") end
        local liveAccountItemValue = tonumber(liveHoard.total) or 0
        local liveParts = {
            {key="Liquid Gold", value=livePersonal + liveWarband, color=GOLD},
            {key="Assets", value=math.max(liveMail, 0), color=GREEN},
        }
        local liveKnown = 0
        for _, part in ipairs(liveParts) do liveKnown = liveKnown + math.max(tonumber(part.value) or 0, 0) end
        liveKnown = math.max(liveKnown, 1)
        if wealthLiveLabels.netWorth then wealthLiveLabels.netWorth:SetText(FormatWealthAmount(liveNetWorth)) end
        if wealthLiveLabels.allocationCenter then wealthLiveLabels.allocationCenter:SetText(FormatWholeGold(liveNetWorth)) end
        for _, part in ipairs(liveParts) do
            local valueLabel = wealthLiveLabels[part.key .. "Value"]
            local pctLabel = wealthLiveLabels[part.key .. "Pct"]
            if valueLabel then valueLabel:SetText(FormatWealthAmount(part.value)) end
            if pctLabel then pctLabel:SetText(math.floor(((tonumber(part.value) or 0) / liveKnown) * 100 + 0.5) .. "%") end
        end
        local allocationLive = wealthLiveLabels.allocation
        if allocationLive and allocationLive.apply then
            allocationLive.apply(liveParts)
        end
        -- Keep the pacing tower live as milestone progress changes.
        if wealthLiveLabels.goalRail and wealthLiveLabels.goalRail.fill and GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal then
            local liveGoal = GoldMint.Milestones:GetActiveGoal()
            local liveGoalPct = liveGoal and math.max(0, math.min(1, tonumber(liveGoal.progress) or 0)) or 0
            wealthLiveLabels.goalRail.fill:SetWidth(math.max(2, 305 * liveGoalPct))
            if wealthLiveLabels.goalPercent then
                wealthLiveLabels.goalPercent:SetText(string.format("%d%%", math.floor(liveGoalPct * 100 + 0.5)))
            end
        end
        -- Refresh the activity feed without rebuilding the Wealth page.
        if wealthLiveLabels.activityRows then
            local liveSession = GoldMint.Ledger and GoldMint.Ledger:GetSession() or nil
            local liveTx = liveSession and liveSession.transactions or {}
            local liveRows = {}
            for i=#liveTx,1,-1 do
                local t=liveTx[i]
                if type(t)=="table" and t.type~="transfer" then
                    liveRows[#liveRows+1]=t
                    if #liveRows>=#wealthLiveLabels.activityRows then break end
                end
            end
            for i,row in ipairs(wealthLiveLabels.activityRows) do
                local t=liveRows[i]
                if t then
                    local amount=tonumber(t.amount) or 0
                    local txTime=tonumber(t.time)
                    row.source:SetText(txTime and date("%b %d, %Y %I:%M %p",txTime) or "")
                    local source=tostring(t.source or "")
                    local typeText,typeColor
                    if string.find(source,"Auction House Sale",1,true) or string.find(source,"Vendor Sale",1,true) then typeText,typeColor="Sale",GREEN
                    elseif string.find(source,"Purchase",1,true) or t.type=="spending" then typeText,typeColor="Purchase",RED
                    elseif amount>0 and string.find(source,"Deposit",1,true) then typeText,typeColor="Deposit",CYAN
                    else typeText,typeColor=amount>=0 and "Income" or "Change",amount>=0 and GREEN or RED end
                    row.type:SetText(typeText); row.type:SetTextColor(unpack(typeColor))
                    local itemName=""; local icon=nil
                    if t.itemID and C_Item then
                        if C_Item.GetItemNameByID then local ok,n=pcall(C_Item.GetItemNameByID,t.itemID); if ok then itemName=n or "" end end
                        if C_Item.GetItemIconByID then local ok,v=pcall(C_Item.GetItemIconByID,t.itemID); if ok then icon=v end end
                    end
                    row.detail:SetText(itemName~="" and itemName or source)
                    if icon then row.icon:SetTexture(icon); row.icon:Show() else row.icon:Hide() end
                    row.amount:SetText((amount>=0 and "+" or "-")..FormatGold(math.abs(amount))); row.amount:SetTextColor(unpack(amount>=0 and GREEN or RED))
                    row.origin:SetText(source~="" and source or "Wallet")
                else
                    row.source:SetText(""); row.type:SetText(""); row.detail:SetText(""); row.amount:SetText(""); row.origin:SetText(""); row.icon:Hide()
                end
            end
        end
        -- Value Trend is event-driven: it only redraws after Ledger records
        -- a qualifying sale or looted-gold event. Ordinary PLAYER_MONEY changes
        -- and Warbank transfers are deliberately ignored.
        if wealthLiveLabels.sessionStart and panels.wealthPage and panels.wealthPage.RefreshSessionSummary then
            panels.wealthPage:RefreshSessionSummary()
        end

        local trendLive = wealthLiveLabels.trend
        if trendLive and trendLive.chart and GoldMint.Ledger and GoldMint.Ledger.GetTrendPoints then
            local points = GoldMint.Ledger:GetTrendPoints() or {}
            local count = #points
            if trendLive.lastTrendCount ~= count then
                trendLive.lastTrendCount = count
                local minV, maxV, pointCount = trendLive.draw(points)
                trendLive.lastRenderedCount = pointCount or 0
                if trendLive.maxLabel then trendLive.maxLabel:SetText(maxV and FormatWealthAmount(maxV) or "") end
                if trendLive.minLabel then trendLive.minLabel:SetText(minV and FormatWealthAmount(minV) or "") end
            end
        end
    end

    local goal = nil
    if GoldMint.Milestones and GoldMint.Milestones.GetGoals then
        local goals = GoldMint.Milestones:GetGoals() or {}
        for _, candidate in ipairs(goals) do
            if not candidate.completeAt and tonumber(candidate.progress or 0) < 1 then
                goal = candidate
                break
            end
        end
        if not goal and goals[1] and tonumber(goals[1].progress or 0) < 1 then
            goal = goals[1]
        end
    end
    RefreshGoal(goal)

    local dailyEconomics = GoldMint.Ledger and GoldMint.Ledger.GetDailyEconomics and GoldMint.Ledger:GetDailyEconomics() or {}
    local dailyVelocity = tonumber(dailyEconomics.velocityGoldPerHour) or 0
    local dailyProfitRate = tonumber(dailyEconomics.profitPerHour) or 0

    local weekSeries, weekTotal = GetWeeklyProfitSeries()
    -- Always normalize weekly dashboard values before numeric comparisons.
    -- This protects the refresh path if an older/partial data source returns nil.
    weekSeries = type(weekSeries) == "table" and weekSeries or {}
    weekTotal = tonumber(weekTotal) or 0
    SetText("momentumStatus", "This Week")
    SetText("momentumEarnedValue", (weekTotal >= 0 and "+" or "") .. FormatProfitGold(weekTotal))
    SetStatus(labels.momentumEarnedValue, weekTotal >= 0 and "profit" or "warning")
    SetText("momentumSpentValue", "Velocity: " .. ((dailyVelocity >= 0 and "+" or "") .. FormatRate(dailyVelocity) .. "/hr"))
    SetStatus(labels.momentumSpentValue, dailyProfitRate >= 0 and "profit" or "warning")
    SetText("momentumHint", "Today • since daily reset")
    SetText("momentumWeekTotal", "Total Week: " .. ((weekTotal >= 0 and "+" or "") .. FormatProfitGold(weekTotal)))

    local lines = labels.momentumGraphLines or {}
    local graphPoints = labels.momentumGraphPoints or {}
    local graphFill = labels.momentumGraphFill or {}
    local area = labels.momentumGraphArea
    if area and #weekSeries >= 2 then
        local minV, maxV = math.huge, -math.huge
        for _, point in ipairs(weekSeries) do
            minV = math.min(minV, tonumber(point[2]) or 0)
            maxV = math.max(maxV, tonumber(point[2]) or 0)
        end

        local span = maxV - minV
        if span < 1 then span = 1 end
        local points = {}
        for i, point in ipairs(weekSeries) do
            local value = tonumber(point[2]) or 0
            local normalized = (value - minV) / span
            -- In the WoW frame coordinate system, smaller Y is higher on
            -- screen. This keeps rising profit visually rising on the graph.
            local x = area.x + ((i - 1) / (#weekSeries - 1)) * area.w
            local y = area.y + ((1 - normalized) * area.h)
            points[#points + 1] = {x, y}
        end

        -- Draw the translucent filled area beneath the line. The strips are
        -- narrow enough to read as a continuous polygon at normal UI scale.
        local stripCount = #graphFill
        for i = 1, stripCount do
            local stripX = (i - 1) * 2
            local fraction = stripCount > 1 and ((i - 1) / (stripCount - 1)) or 0
            local pointPosition = fraction * (#points - 1) + 1
            local leftIndex = math.floor(pointPosition)
            local rightIndex = math.min(#points, leftIndex + 1)
            local localFraction = pointPosition - leftIndex
            local y = points[leftIndex][2]
            if points[rightIndex] and rightIndex ~= leftIndex then
                y = y + (points[rightIndex][2] - y) * localFraction
            end
            local fill = graphFill[i]
            fill:ClearAllPoints()
            fill:SetPoint("TOPLEFT", panels.momentum, "TOPLEFT", area.x + stripX, -(y))
            fill:SetHeight(math.max(1, area.y + area.h - y))
            fill:Show()
        end

        for i = 1, #lines do
            local line = lines[i]
            if points[i] and points[i + 1] then
                local x1, y1 = points[i][1], points[i][2]
                local x2, y2 = points[i + 1][1], points[i + 1][2]
                local dx, dy = x2 - x1, y2 - y1
                local length = math.sqrt(dx * dx + dy * dy)
                line:ClearAllPoints()
                line:SetSize(math.max(2, length), 2)
                line:SetPoint("CENTER", panels.momentum, "TOPLEFT", (x1 + x2) * 0.5, -((y1 + y2) * 0.5))
                line:SetRotation(math.atan2(-dy, dx))
                line:Show()
            else
                line:Hide()
            end
        end

        for i = 1, #graphPoints do
            local marker = graphPoints[i]
            local point = points[i]
            if point then
                marker.glow:ClearAllPoints()
                marker.glow:SetPoint("CENTER", panels.momentum, "TOPLEFT", point[1], -point[2])
                marker.glow:Show()
                marker.dot:ClearAllPoints()
                marker.dot:SetPoint("CENTER", panels.momentum, "TOPLEFT", point[1], -point[2])
                if i == #points then
                    marker.dot:SetColorTexture(0.25, 0.85, 0.95, 1.0)
                    marker.glow:SetColorTexture(0.25, 0.85, 0.95, 0.22)
                else
                    marker.dot:SetColorTexture(0.78, 0.90, 0.91, 0.98)
                    marker.glow:SetColorTexture(0.18, 0.72, 0.82, 0.16)
                end
                marker.dot:Show()
            else
                marker.glow:Hide()
                marker.dot:Hide()
            end
        end
    else
        for _, line in ipairs(lines) do line:Hide() end
        for _, marker in ipairs(graphPoints) do
            marker.glow:Hide()
            marker.dot:Hide()
        end
        for _, fill in ipairs(graphFill) do fill:Hide() end
    end

    local ready, active = 0, 0
    local homeEntries = {}
    if GoldMint.Cooldowns then
        if GoldMint.Cooldowns.GetSummary then
            local readyCount, activeCount = GoldMint.Cooldowns:GetSummary()
            ready = tonumber(readyCount) or 0
            active = tonumber(activeCount) or 0
        end
        if GoldMint.Cooldowns.GetHomeEntries then
            homeEntries = GoldMint.Cooldowns:GetHomeEntries(3) or {}
        end
    end

    SetText("cooldownsReady", string.format("%d Ready", ready))
    SetText("cooldownsActive", string.format("%d On Cooldown", active))
    if labels.cooldownsDetail then
        if #homeEntries > 0 then
            labels.cooldownsDetail:SetText("Live tracked cooldowns")
            labels.cooldownsDetail:Show()
        else
            labels.cooldownsDetail:SetText("")
            labels.cooldownsDetail:Hide()
        end
    end

    if labels.cooldownsRows then
        for _, row in ipairs(labels.cooldownsRows) do row:Hide() end
    else
        labels.cooldownsRows = {}
    end
    for i, entry in ipairs(homeEntries) do
        local row = labels.cooldownsRows[i]
        if not row then
            row = MakeLabel(panels.cooldowns, "GameFontNormalSmall", "", 220)
            row:SetPoint("TOPLEFT", 14, -103 - ((i - 1) * 16))
            row:SetWordWrap(false)
            labels.cooldownsRows[i] = row
        end
        local status = entry.ready and "READY" or tostring(entry.status or "")
        row:SetText(string.format("%s: %s", entry.professionName or "Profession", status))
        row:SetTextColor(unpack(entry.ready and GREEN or MUTED))
        row:Show()
    end

    if labels.cooldownsCraftNow and GoldMint.Cooldowns and GoldMint.Cooldowns.GetBestReadyProfitableCooldown then
        local bestCooldown = GoldMint.Cooldowns:GetBestReadyProfitableCooldown()
        if bestCooldown then
            labels.cooldownsCraftNow._recipeID = tonumber(bestCooldown.recipeID)
            labels.cooldownsCraftNow._recipeName = bestCooldown.name
            labels.cooldownsCraftNow._characterName = bestCooldown.characterName
            labels.cooldownsCraftNow._profit = bestCooldown.profit
            labels.cooldownsCraftNow.text:SetText("CRAFT NOW")
            labels.cooldownsCraftNow:Show()
        else
            labels.cooldownsCraftNow._recipeID = nil
            labels.cooldownsCraftNow._recipeName = nil
            labels.cooldownsCraftNow._characterName = nil
            labels.cooldownsCraftNow._profit = nil
            labels.cooldownsCraftNow:Hide()
        end
    end

    local mailCount = mail and tonumber(mail.attachmentCount) or 0
    if labels.homeQuickMail then
        labels.homeQuickMail:SetText("Mail")
    end
    if labels.homeQuickMailValue then
        labels.homeQuickMailValue:SetText(tostring(mailCount))
    end

    local profitable = crafting and tonumber(crafting.profitableRecipes) or 0
    if labels.homeQuickRecipes then
        labels.homeQuickRecipes:SetText("Recipes")
    end
    if labels.homeQuickRecipesValue then
        labels.homeQuickRecipesValue:SetText(tostring(profitable))
    end

    local routineAttention = 0
    if GoldMint.RoutineState and GoldMint.RoutineState.GetSummary then
        local rs = GoldMint.RoutineState:GetSummary() or {}
        routineAttention = tonumber(rs.ready or rs.incomplete or rs.attention) or 0
    end
    if labels.homeQuickRoutines then
        labels.homeQuickRoutines:SetText("Routines")
    end
    if labels.homeQuickRoutinesValue then
        labels.homeQuickRoutinesValue:SetText(tostring(routineAttention))
    end

    SetText("sessionStart", FormatGold(session and session.startingGold or 0))
    SetText("sessionEnd", FormatGold(session and session.endingGold or totalGold))
    SetText("sessionNet", (net >= 0 and "+" or "") .. FormatProfitGold(net))
    SetStatus(labels.sessionNet, net >= 0 and "profit" or "warning")
    SetText("sessionRate", (rate >= 0 and "+" or "") .. FormatRate(rate) .. "/hr")
    SetText("sessionStartName", "SESSION PROFIT")
    SetText("sessionEndName", "Current Hourly Rate")

    local top = {}
    if crafting and profitable > 0 then top[#top + 1] = "Crafting " .. tostring(profitable) end
    if market and tonumber(market.trackedItems) then top[#top + 1] = "Market " .. tostring(market.trackedItems) end
    if mailCount > 0 then top[#top + 1] = "Mail " .. tostring(mailCount) end
    SetText("sessionTopSources", #top > 0 and ("Sources: " .. table.concat(top, "  •  ")) or "Sources: —")
    SetText("sessionNetDetail", net >= 0 and "Current session is profitable" or "Current session is in investment")

    -- First-run flow: establish the data sources GoldMint relies on before
    -- asking the player to set a goal. Each setup action advances automatically
    -- once its corresponding data has actually been observed.
    local onboarding = GetOnboardingState()
    local setupStep = GetNextOnboardingStep()
    if setupStep then
        SetText("nextTitle", "GETTING STARTED")
        SetText("nextText", setupStep.title)
        local setupDone = 0
        local setupSteps = GetOnboardingSteps()
        for _, step in ipairs(setupSteps) do
            if step.done or onboarding.skipped[step.id] then setupDone = setupDone + 1 end
        end
        SetText("nextDetail", setupStep.detail .. "\n\nSetup: " .. tostring(setupDone) .. "/" .. tostring(#setupSteps) .. " complete")
        buttons.next:SetEnabled(true)
    elseif not goal then
        SetText("nextTitle", "YOUR NEXT STEP")
        SetText("nextText", "Create your first savings goal")
        SetText("nextDetail", "Set a target and optional checkpoint. After that, GoldMint will use your goal and routine activity to keep the next action current.")
        buttons.next:SetEnabled(true)
    else
        SetText("nextTitle", "YOUR NEXT STEP")
        local routineSummary = GoldMint.RoutineState and GoldMint.RoutineState.GetSummary and GoldMint.RoutineState:GetSummary() or nil
        local routineReady = routineSummary and tonumber(routineSummary.ready or 0) or 0
        if routineReady > 0 then
            SetText("nextText", "Review ready routines")
            SetText("nextDetail", string.format("%d routine item%s are ready. GoldMint will keep watching routine state after your goal is set.", routineReady, routineReady == 1 and " is" or "s are"))
        elseif (tonumber(goal.remaining) or 0) > 0 then
            SetText("nextText", "Watch your routines")
            local checkpointRemaining = goal.nextCheckpoint and (tonumber(goal.nextCheckpoint.remaining) or 0) or nil
            SetText("nextDetail", checkpointRemaining and (FormatGold(checkpointRemaining) .. " until the next checkpoint. GoldMint will keep watching Routines and surface ready work here.") or "Your active savings goal is set. GoldMint will keep watching Routines and surface the next actionable activity here.")
        else
            SetText("nextText", "Goal reached")
            SetText("nextDetail", "Your goal is complete. GoldMint will continue monitoring routines and new activity.")
        end
        buttons.next:SetEnabled(true)
    end

    local milestoneTarget = goal and (tonumber(goal.target) or 0) or 0
    if goal and goal.nextCheckpoint then
        SetText("milestone", FormatGold(goal.nextCheckpoint.amount))
        SetText("milestoneDetail", FormatGold(goal.nextCheckpoint.remaining) .. " to go")
    else
        SetText("milestone", goal and FormatGold(milestoneTarget) or "—")
        SetText("milestoneDetail", goal and "Current goal target" or "No active goal")
    end

    -- Only display the progress track when there is an actual target.
    -- A blank/no-goal milestone card must remain clean.
    if labels.milestoneTrack and labels.milestoneFill then
        if goal and milestoneTarget > 0 then
            local current = tonumber(goal.currentValue) or tonumber(goal.current) or 0
            local progress = math.max(0, math.min(1, current / milestoneTarget))
            labels.milestoneTrack:Show()
            labels.milestoneFill:SetSize(math.max(1, 228 * progress), 6)
            labels.milestoneFill:Show()
        else
            labels.milestoneTrack:Hide()
            labels.milestoneFill:Hide()
        end
    end

    local shield = goal and goal.weekly or nil
    if shield and shield.status == "ahead" then
        SetText("shield", "You're ahead")
        SetText("shieldDetail", "Based on your rolling 7-day pace.")
        SetStatus(labels.shield, "ahead")
    elseif shield and shield.status == "behind" then
        SetText("shield", "You're behind")
        SetText("shieldDetail", "Your 7-day pace is below target.")
        SetStatus(labels.shield, "behind")
    elseif shield and shield.status == "complete" then
        SetText("shield", "Goal complete")
        SetText("shieldDetail", "Time pressure is cleared.")
        SetStatus(labels.shield, "ahead")
    elseif shield and shield.status == "baseline" then
        SetText("shield", "7-day baseline")
        SetText("shieldDetail", "Tracking your actual weekly pace.")
        SetStatus(labels.shield, "normal")
    else
        SetText("shield", "Building baseline")
        SetText("shieldDetail", "More 7-day history is needed.")
        SetStatus(labels.shield, "normal")
    end

    -- Keep the header focused on liquid value; goal information belongs in the goal panel.

    -- Apply Home panel visibility last. Some panel refresh routines and OnShow
    -- callbacks can touch their frames while Refresh() is rebuilding content;
    -- the user's saved Options state is the final authority for the Home layout.
    if activeNavKey == "dashboard" then
        ApplyHomePanelVisibility()
    end
end

local function CreateFrameOnce()
    if initialized then return end
    initialized = true

    frame = CreateFrame("Frame", "GoldMintDashboard", UIParent, "BackdropTemplate")
    frame:SetSize(DASHBOARD_BASE_WIDTH, DASHBOARD_BASE_HEIGHT)
    -- Scale the complete dashboard canvas to the available UI space.  Because
    -- every page is a child of this frame, the same responsive treatment
    -- automatically applies to Home, Projects, Wealth, Inventory, Market,
    -- Recipes, Cooldowns, and Routines without individually redesigning each
    -- page around a particular monitor size or UI scale.
    UpdateResponsiveScale()
    -- Preserve the established default position, while allowing the new settings
    -- panel to remember a user-moved position.
    local savedX = GoldMintDB and GoldMintDB.settings and tonumber(GoldMintDB.settings.dashboardX)
    local savedY = GoldMintDB and GoldMintDB.settings and tonumber(GoldMintDB.settings.dashboardY)
    if savedX and savedY and savedX == savedX and savedY == savedY then
        -- Saved dashboard coordinates are CENTER offsets. Clamp them before
        -- restoring so an old/corrupt position can never put the window away.
        local uiW, uiH = UIParent:GetWidth(), UIParent:GetHeight()
        local responsiveScale = frame:GetScale() or 1
        local halfW = (frame:GetWidth() * responsiveScale) / 2
        local halfH = (frame:GetHeight() * responsiveScale) / 2
        local maxX = math.max(0, uiW / 2 - halfW - 24)
        local maxY = math.max(0, uiH / 2 - halfH - 22)
        savedX = math.max(-maxX, math.min(maxX, savedX))
        savedY = math.max(-maxY, math.min(maxY, savedY))
        frame:SetPoint("CENTER", UIParent, "CENTER", savedX, savedY)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", -150, 0)
    end
    -- Keep the GoldMint dashboard above unit frames and other game HUD elements.
    -- DIALOG is intentionally used instead of MEDIUM so stance/action/unit frames
    -- cannot visually bleed over the dashboard.
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(100)
    -- Treat Escape as the dashboard close key, matching normal Blizzard window behavior.
    if UISpecialFrames then
        tinsert(UISpecialFrames, "GoldMintDashboard")
    end
    -- Only the dedicated title-bar drag handle moves the dashboard.  The old
    -- implementation made the entire 1400x840 frame draggable, which allowed
    -- clicks/releases over child controls to interfere with the dashboard
    -- lifecycle and made the window appear to close after being moved.
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)

    local dragHandle = CreateFrame("Frame", "GoldMintDashboardDragHandle", frame)
    dragHandle:SetSize(1320, 82)
    dragHandle:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 18)
    dragHandle:SetFrameLevel(frame:GetFrameLevel() + 1)
    dragHandle:EnableMouse(true)
    dragHandle:RegisterForDrag("LeftButton")
    dragHandle:SetScript("OnDragStart", function()
        local locked = GoldMintDB and GoldMintDB.settings and GoldMintDB.settings.dashboardLocked
        if not locked then
            frame._goldMintDragging = true
            frame:StartMoving()
        end
    end)
    dragHandle:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        frame._goldMintDragging = false

        local centerX, centerY = frame:GetCenter()
        local uiCenterX, uiCenterY = UIParent:GetWidth() / 2, UIParent:GetHeight() / 2
        if GoldMintDB and GoldMintDB.settings and centerX and centerY then
            local x = centerX - uiCenterX
            local y = centerY - uiCenterY
            -- Never save invalid coordinates.
            if x == x and y == y then
                GoldMintDB.settings.dashboardX = x
                GoldMintDB.settings.dashboardY = y
            end
        end
    end)

    -- Keep the drag handle visually inert. It exists only to provide a safe,
    -- predictable place to move the dashboard without intercepting buttons.
    dragHandle:SetAlpha(0.001)
    panels.dashboardDragHandle = dragHandle

    -- Recalculate the canvas scale whenever WoW changes resolution or UI
    -- scale.  This makes the same addon layout adapt without requiring the
    -- user to manually resize the main window.
    frame:RegisterEvent("DISPLAY_SIZE_CHANGED")
    frame:RegisterEvent("UI_SCALE_CHANGED")
    frame:SetScript("OnEvent", function(self)
        UpdateResponsiveScale()
    end)

    frame:SetScript("OnHide", function(self)
        -- The lifecycle OnHide handler below is installed later in this
        -- function; this placeholder is intentionally replaced there.
    end)

    frame:SetBackdrop({
        -- Use the supplied Darkfiber artwork as the main dashboard background.
        -- The current Darkfiber.tga asset is the latest supplied background artwork.
        -- It is displayed behind all dashboard panels.
        bgFile = "Interface\\AddOns\\GoldMint\\Assets\\Darkfiber",
        tile = false,
    })
    frame:SetBackdropColor(1.0, 1.0, 1.0, 1.0)

    -- Custom metallic/cyan border supplied for the GoldMint main window.
    -- This replaces the old plain blue edge.
    local function AddWindowBorderTexture(name, width, height, point, x, y, texturePath)
        local t = frame:CreateTexture(name, "BORDER")
        t:SetTexture(texturePath or "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowBorder")
        t:SetSize(width, height)
        t:SetPoint(point, frame, point, x or 0, y or 0)
        t:SetTexCoord(0, 1, 0, 1)
        return t
    end
    -- Keep the main window edge at exactly 4 pixels.  The supplied horizontal
    -- artwork is used on the top/bottom, while the supplied vertical artwork
    -- is used on the left/right without rotating it.
    panels.windowBorderTop = AddWindowBorderTexture("GoldMintWindowBorderTop", DASHBOARD_BASE_WIDTH, 4, "TOPLEFT", 0, 0)
    panels.windowBorderBottom = AddWindowBorderTexture("GoldMintWindowBorderBottom", DASHBOARD_BASE_WIDTH, 4, "BOTTOMLEFT", 0, 0)
    panels.windowBorderLeft = AddWindowBorderTexture("GoldMintWindowBorderLeft", 4, DASHBOARD_BASE_HEIGHT, "TOPLEFT", 0, 0, "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowBorderVertical")
    panels.windowBorderRight = AddWindowBorderTexture("GoldMintWindowBorderRight", 4, DASHBOARD_BASE_HEIGHT, "TOPRIGHT", 0, 0, "Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowBorderVertical")

    -- Bottom-right decorative corner. Keep the same size and mirrored placement
    -- as the bottom-left corner artwork. This only replaces the artwork itself.
    local cornerRight = frame:CreateTexture("GoldMintWindowCornerRight", "OVERLAY")
    cornerRight:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowCornerRight")
    cornerRight:SetSize(90, 105)
    cornerRight:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", 11, 95)
    cornerRight:SetTexCoord(0, 1, 0, 1)
    panels.windowCornerRight = cornerRight

    -- Bottom-left decorative corner.  The bend of the supplied artwork is
    -- centered directly over the 4px main-window corner, so the artwork
    -- overlaps the border without changing the header or logo.
    local cornerLeft = frame:CreateTexture("GoldMintWindowCornerLeft", "OVERLAY")
    cornerLeft:SetTexture("Interface\\AddOns\\GoldMint\\Assets\\GoldMintWindowCornerLeft")
    cornerLeft:SetSize(90, 105)
    -- Source bend is approximately (305, 478) in the 521x606 artwork.
    -- Scale the decorative corner down while keeping its bend centered on the 4px frame corner.
    cornerLeft:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", -11, 95)
    cornerLeft:SetTexCoord(0, 1, 0, 1)
    panels.windowCornerLeft = cornerLeft

    BuildHeader()
    Dashboard:BuildMinimapButton()
    if GoldMint.FarmTracker and GoldMint.FarmTracker.Reanchor then
        GoldMint.FarmTracker:EnsureFrame()
        GoldMint.FarmTracker:Reanchor()
    end
    BuildNavigation()
    BuildGoalPanel()
    BuildMomentumPanel()
    BuildNextStepPanel()
    BuildSessionPanel()
    BuildBottomPanels()
    ApplyHomePanelVisibility()

    buttons.next:SetScript("OnClick", function()
        local setupStep = GetNextOnboardingStep()
        if setupStep then
            if setupStep.open then setupStep.open() end
            return
        end

        local activeGoal = GoldMint.Milestones and GoldMint.Milestones.GetActiveGoal and GoldMint.Milestones:GetActiveGoal() or nil
        if not activeGoal then
            OpenGoalEditor()
            return
        end

        local routineSummary = GoldMint.RoutineState and GoldMint.RoutineState.GetSummary and GoldMint.RoutineState:GetSummary() or nil
        if routineSummary and tonumber(routineSummary.ready or 0) > 0 then
            OpenOperations("routines")
            return
        end

        OpenOperations("routines")
    end)

    buttons.nextLater:SetScript("OnClick", function()
        local setupStep = GetNextOnboardingStep()
        if setupStep then
            local state = GetOnboardingState()
            state.skipped[setupStep.id] = true
            GoldMint.Print("Skipped setup step: " .. tostring(setupStep.title) .. ". GoldMint will continue to the next setup step.")
            Refresh()
            return
        end

        GoldMint.Print("Recommendation deferred. GoldMint will continue monitoring your goal and routines.")
        Refresh()
    end)

    -- Refresh state must be declared before the OnShow/OnHide handlers so
    -- those closures capture these locals rather than creating globals.
    local refreshPending = false
    local refreshGeneration = 0
    local refreshTicker
    local fallbackRefreshElapsed = 0

    frame:SetScript("OnShow", function(self)
        self._uiLifecycle = (self._uiLifecycle or 0) + 1
        self._refreshElapsed = 0
        fallbackRefreshElapsed = 0
        refreshPending = false
        refreshGeneration = refreshGeneration + 1
        Refresh()

        if not refreshTicker and C_Timer and C_Timer.NewTicker then
            refreshTicker = C_Timer.NewTicker(5, function()
                if not frame:IsShown() then return end
                if activeNavKey == "routines" then return end
                Refresh()
            end)
        end
    end)
    frame:SetScript("OnHide", function(self)
        self._uiLifecycle = (self._uiLifecycle or 0) + 1
        refreshPending = false
        refreshGeneration = refreshGeneration + 1
        self._refreshElapsed = 0
        fallbackRefreshElapsed = 0
        if refreshTicker then
            refreshTicker:Cancel()
            refreshTicker = nil
        end
    end)

    -- Keep the dashboard data fresh when the game changes the underlying
    -- economy state. The five-second ticker remains as a quiet fallback,
    -- while these events make visible changes appear immediately.
    local refreshEvents = CreateFrame("Frame", nil, frame)
    refreshEvents:RegisterEvent("PLAYER_MONEY")
        refreshEvents:RegisterEvent("PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED")
    refreshEvents:RegisterEvent("MAIL_SHOW")
    refreshEvents:RegisterEvent("MAIL_INBOX_UPDATE")
    refreshEvents:RegisterEvent("MAIL_CLOSED")
    refreshEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
    refreshEvents:SetScript("OnEvent", function(_, event)
        if not frame or not frame:IsShown() then return end
        if GoldMint:IsMerchantOpen() and event == "PLAYER_MONEY" then
            refreshPending = true
            refreshGeneration = refreshGeneration + 1
            return
        end
        -- Immediate events supersede any delayed bag repaint already queued.
        -- This keeps the visible UI converged on the newest Economy state.
        refreshGeneration = refreshGeneration + 1
        refreshPending = false
        Refresh()
    end)
    panels.refreshEvents = refreshEvents

    -- Create the frame hidden. Initialization should never consume the first
    -- /gm dashboard toggle by hiding a newly-created, automatically shown frame.
    frame:Hide()
end

function Dashboard:ApplyDisplayScale()
    if not frame then return end
    UpdateResponsiveScale()
end

function Dashboard:RefreshPanelVisibility()
    if not frame then return end
    ApplyHomePanelVisibility()
    if activeNavKey == "dashboard" then
        Refresh()
    end
end

function Dashboard:Initialize()
    -- Keep login lightweight. The full Dashboard is expensive to construct and
    -- is not needed until the player actually opens it. Build only the tiny
    -- minimap button here; CreateFrameOnce() remains lazy and is called by Show/Toggle.
    if self.BuildMinimapButton then
        self:BuildMinimapButton()
    end
    if frame then
        ApplyHomePanelVisibility()
    end
end

function Dashboard:IsShown()
    return frame ~= nil and frame.IsShown and frame:IsShown() == true
end

function Dashboard:GetActiveNavKey()
    return activeNavKey
end

function Dashboard:Refresh()
    if not initialized then
        return
    end
    Refresh()
end

function Dashboard:RefreshWealthView()
    if not initialized then
        return
    end
    if panels.operationsShow then
        panels.operationsShow("wealth")
    else
        Refresh()
    end
end

function Dashboard:Show()
    CreateFrameOnce()
    frame:Show()
    if activeNavKey == "projects" and OpenProjects then
        OpenProjects()
    elseif activeNavKey == "wealth" or activeNavKey == "cooldowns" or activeNavKey == "routines" then
        if OpenOperations then OpenOperations(activeNavKey) end
    else
        Dashboard:ShowHome()
    end
    Refresh()
end

function Dashboard:Hide()
    if frame then frame:Hide() end
end

function Dashboard:Toggle()
    CreateFrameOnce()
    if frame:IsShown() then self:Hide() else self:Show() end
end
