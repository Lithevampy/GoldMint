local ADDON_NAME, GoldMint = ...
GoldMint.ToDoPopout = GoldMint.ToDoPopout or {}
local ToDoUI = GoldMint.ToDoPopout
local Data = GoldMint.ToDoList

local frame, scroll, content, editor, screenButton
local scrollBar, scrollBarTrack
local headerDivider
local contentTopLine, contentBottomLine, contentLeftLine, contentRightLine
local rows = {}

local CYAN  = {0.20, 0.82, 1.00}
local GOLD  = {1.00, 0.78, 0.18}
local TEXT  = {0.92, 0.94, 0.98}
local MUTED = {0.62, 0.74, 0.84}
local GREEN = {0.25, 1.00, 0.15}
local RED   = {1.00, 0.30, 0.30}

local function L(parent, text, font, color)
    local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontNormal")
    fs:SetText(text or "")
    fs:SetTextColor(unpack(color or TEXT))
    return fs
end

local function Panel(parent, width, height, alpha)
    local f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    f:SetSize(width, height)
    f:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    f:SetBackdropColor(0.008, 0.018, 0.030, alpha or 0.94)
    f:SetBackdropBorderColor(0.08, 0.32, 0.46, 1)
    return f
end

local function Btn(parent, text, width, height, color)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height)
    b:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    b:SetBackdropColor(0.01, 0.035, 0.055, 0.96)
    b:SetBackdropBorderColor(0.10, 0.45, 0.62, 1)
    b.txt = L(b, text, "GameFontNormalSmall", color or MUTED)
    b.txt:SetPoint("CENTER")
    b:SetScript("OnEnter", function()
        b:SetBackdropColor(0.04, 0.12, 0.17, 1)
        b:SetBackdropBorderColor(1, 0.78, 0.20, 1)
    end)
    b:SetScript("OnLeave", function()
        b:SetBackdropColor(0.01, 0.035, 0.055, 0.96)
        b:SetBackdropBorderColor(0.10, 0.45, 0.62, 1)
    end)
    return b
end

local function Theme()
    local s = Data:GetSettings()
    local clear = s.theme == "clear"
    if clear then return {0.92, 0.94, 0.97, s.opacity} end
    return {0.012, 0.020, 0.032, s.opacity}
end

local function MenuDimensions(size)
    if size == "SMALL" then return 460, 500 end
    if size == "LARGE" then return 680, 720 end
    return 560, 620
end


local function UpdateToDoScrollBar()
    if not scroll or not scrollBar then return end
    local maxScroll = scroll:GetVerticalScrollRange() or 0
    if maxScroll <= 0 then
        scrollBar:Hide()
        if scrollBarTrack then scrollBarTrack:Hide() end
        return
    end

    scrollBar:Show()
    if scrollBarTrack then scrollBarTrack:Show() end
    scrollBar:SetMinMaxValues(0, maxScroll)
    scrollBar:SetValue(scroll:GetVerticalScroll() or 0)
end

local function BuildToDoScrollBar()
    if not frame or not scroll then return end

    if scrollBar then
        scrollBar:ClearAllPoints()
        scrollBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -142)
        scrollBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 24)
        UpdateToDoScrollBar()
        return
    end

    -- Mint-style scrollbar: narrow dark-teal rail with a thin cyan thumb.
    scrollBarTrack = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    scrollBarTrack:SetWidth(8)
    scrollBarTrack:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -142)
    scrollBarTrack:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 24)
    scrollBarTrack:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    scrollBarTrack:SetBackdropColor(0.016, 0.078, 0.095, 0.92)
    scrollBarTrack:SetBackdropBorderColor(0.035, 0.20, 0.30, 0.95)
    scrollBarTrack:SetFrameLevel(frame:GetFrameLevel() + 4)

    scrollBar = CreateFrame("Slider", nil, frame)
    scrollBar:SetOrientation("VERTICAL")
    scrollBar:SetWidth(8)
    scrollBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -142)
    scrollBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 24)
    scrollBar:SetMinMaxValues(0, 0)
    scrollBar:SetValueStep(1)
    scrollBar:SetObeyStepOnDrag(false)
    scrollBar:SetFrameLevel(frame:GetFrameLevel() + 5)

    local thumb = scrollBar:CreateTexture(nil, "ARTWORK")
    thumb:SetTexture("Interface\\Buttons\\WHITE8X8")
    thumb:SetWidth(2)
    thumb:SetHeight(34)
    thumb:SetVertexColor(0.19, 0.75, 0.98, 1)
    scrollBar:SetThumbTexture(thumb)

    scrollBar:SetScript("OnValueChanged", function(_, value)
        if scroll then
            scroll:SetVerticalScroll(value or 0)
        end
    end)
    scrollBar:SetScript("OnEnter", function()
        thumb:SetVertexColor(0.30, 0.86, 1.00, 1)
    end)
    scrollBar:SetScript("OnLeave", function()
        thumb:SetVertexColor(0.19, 0.75, 0.98, 1)
    end)

    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local maxScroll = self:GetVerticalScrollRange() or 0
        local current = self:GetVerticalScroll() or 0
        self:SetVerticalScroll(math.max(0, math.min(maxScroll, current - delta * 36)))
        UpdateToDoScrollBar()
    end)
    scroll:SetScript("OnVerticalScroll", function()
        UpdateToDoScrollBar()
    end)

    UpdateToDoScrollBar()
end

local function ContentWidth()
    if not frame then return 500 end
    return math.max(390, frame:GetWidth() - 54)
end

function ToDoUI:ApplyMenuSettings()
    if not frame then return end
    local s = Data:GetSettings()
    local w, h = MenuDimensions(s.menuSize)
    frame:SetSize(w, h)
    frame:SetFrameStrata(s.openBehavior == "LOW" and "LOW" or "DIALOG")
    frame:SetBackdropColor(unpack(Theme()))
    frame:SetScale(s.fontScale or 1)
    if frame.layout then frame:layout() end
end

local function ClearRows()
    for _, r in ipairs(rows) do r:Hide() end
    wipe(rows)
end

local function AddTaskDialog(catID, existing)
    if editor then editor:Hide() end

    editor = Panel(frame, 560, 390, 1)
    editor:SetPoint("CENTER")
    editor:SetFrameLevel(100)

    local title = L(editor, existing and "EDIT TASK" or "ADD TASK", "GameFontNormalLarge", GOLD)
    title:SetPoint("TOPLEFT", 22, -18)

    local hint = L(editor, existing and "Update the task details below." or "Create a new task for this category.", "GameFontNormalSmall", MUTED)
    hint:SetPoint("TOPLEFT", 22, -43)

    -- Task name
    L(editor, "TASK NAME", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 22, -72)
    local name = CreateFrame("EditBox", nil, editor, "InputBoxTemplate")
    name:SetSize(516, 30)
    name:SetPoint("TOPLEFT", 22, -88)
    name:SetAutoFocus(true)
    name:SetTextInsets(9, 9, 0, 0)
    name:SetText(existing and existing.title or "")

    -- Description
    L(editor, "DESCRIPTION", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 22, -128)
    local desc = CreateFrame("EditBox", nil, editor, "InputBoxTemplate")
    desc:SetSize(516, 66)
    desc:SetPoint("TOPLEFT", 22, -144)
    desc:SetMultiLine(true)
    desc:SetAutoFocus(false)
    desc:SetTextInsets(9, 9, 6, 6)
    desc:SetText(existing and existing.description or "")

    -- Options divider / heading
    local divider = editor:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(0.08, 0.32, 0.46, 0.9)
    divider:SetSize(516, 1)
    divider:SetPoint("TOPLEFT", 22, -224)

    L(editor, "TASK OPTIONS", "GameFontNormalSmall", GOLD):SetPoint("TOPLEFT", 22, -238)

    local resetModes = {"none", "daily", "weekly", "custom"}
    local mi = 1
    for i, v in ipairs(resetModes) do
        if existing and existing.reset == v then mi = i end
    end

    L(editor, "RESET", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 22, -267)
    local reset = Btn(editor, string.upper(resetModes[mi]), 92, 27, TEXT)
    reset:SetPoint("TOPLEFT", 78, -258)
    reset:SetScript("OnClick", function()
        mi = mi % #resetModes + 1
        reset.txt:SetText(string.upper(resetModes[mi]))
    end)

    local customHours = tonumber(existing and existing.resetHours) or 24
    local hoursLabel = L(editor, "HOURS", "GameFontNormalSmall", MUTED)
    hoursLabel:SetPoint("LEFT", reset, "RIGHT", 18, 0)
    local hours = CreateFrame("EditBox", nil, editor, "InputBoxTemplate")
    hours:SetSize(54, 27)
    hours:SetPoint("LEFT", hoursLabel, "RIGHT", 6, 0)
    hours:SetText(tostring(customHours))
    hours:SetTextInsets(6, 6, 0, 0)

    local favorite = existing and existing.favorite == true or false
    local fav = Btn(editor, favorite and "FAVORITE: ON" or "FAVORITE: OFF", 126, 27, MUTED)
    fav:SetPoint("TOPRIGHT", -22, -258)
    fav:SetScript("OnClick", function()
        favorite = not favorite
        fav.txt:SetText(favorite and "FAVORITE: ON" or "FAVORITE: OFF")
    end)

    L(editor, "NEW ITEMS", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 22, -308)
    local atTop = Data:GetSettings().addToTop == true
    local pos = Btn(editor, atTop and "ADD: TOP" or "ADD: BOTTOM", 126, 27, MUTED)
    pos:SetPoint("TOPLEFT", 92, -299)
    pos:SetScript("OnClick", function()
        atTop = not atTop
        pos.txt:SetText(atTop and "ADD: TOP" or "ADD: BOTTOM")
    end)

    local note = L(editor, "Reset and placement settings apply when the task is saved.", "GameFontNormalSmall", MUTED)
    note:SetPoint("TOPRIGHT", -22, -307)

    -- Footer
    local footer = editor:CreateTexture(nil, "ARTWORK")
    footer:SetColorTexture(0.08, 0.32, 0.46, 0.9)
    footer:SetSize(516, 1)
    footer:SetPoint("BOTTOMLEFT", 22, 56)

    local cancel = Btn(editor, "CANCEL", 92, 28, MUTED)
    cancel:SetPoint("BOTTOMRIGHT", -126, 18)
    cancel:SetScript("OnClick", function() editor:Hide() end)

    local save = Btn(editor, "SAVE TASK", 108, 28, GOLD)
    save:SetPoint("BOTTOMRIGHT", -22, 18)
    save:SetScript("OnClick", function()
        local titleText = strtrim(name:GetText() or "")
        if titleText == "" then return end
        local tab = Data:GetActiveTab()
        local opts = {
            description = desc:GetText(),
            reset = resetModes[mi],
            resetHours = math.max(1, tonumber(hours:GetText()) or 24),
            favorite = favorite,
        }
        if existing then
            Data:EditTask(tab.id, existing.id, {
                title = titleText,
                description = opts.description,
                reset = opts.reset,
                resetHours = opts.resetHours,
                favorite = opts.favorite,
            })
        else
            local task = Data:AddTask(tab.id, catID, titleText, opts)
            if atTop and task then Data:MoveTask(tab.id, task.id, "up") end
        end
        editor:Hide()
        ToDoUI:Refresh()
    end)

    editor:Show()
    name:SetFocus()
end

local function AddCategoryDialog(parentID)
    local d = Panel(frame, 380, 155, 1)
    d:SetPoint("CENTER")
    d:SetFrameLevel(110)
    L(d, "NEW CATEGORY", "GameFontNormalLarge", GOLD):SetPoint("TOPLEFT", 18, -16)
    L(d, "CATEGORY NAME", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 18, -48)
    local e = CreateFrame("EditBox", nil, d, "InputBoxTemplate")
    e:SetSize(344, 28)
    e:SetPoint("TOPLEFT", 18, -64)
    e:SetAutoFocus(true)
    e:SetTextInsets(8, 8, 0, 0)

    local cancel = Btn(d, "CANCEL", 82, 25, MUTED)
    cancel:SetPoint("BOTTOMLEFT", 18, 16)
    cancel:SetScript("OnClick", function() d:Hide() end)

    local ok = Btn(d, "ADD CATEGORY", 110, 25, GOLD)
    ok:SetPoint("LEFT", cancel, "RIGHT", 8, 0)
    ok:SetScript("OnClick", function()
        local n = strtrim(e:GetText() or "")
        if n ~= "" then
            local tab = Data:GetActiveTab()
            Data:AddCategory(tab.id, n, parentID)
            d:Hide()
            ToDoUI:Refresh()
        end
    end)
    e:SetScript("OnEnterPressed", function() ok:Click() end)
    d:Show()
end

local function EditCategoryDialog(tab, cat)
    local d = Panel(frame, 380, 185, 1)
    d:SetPoint("CENTER")
    d:SetFrameLevel(110)
    L(d, "EDIT CATEGORY", "GameFontNormalLarge", GOLD):SetPoint("TOPLEFT", 18, -16)
    L(d, "CATEGORY NAME", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 18, -48)
    local e = CreateFrame("EditBox", nil, d, "InputBoxTemplate")
    e:SetSize(344, 28)
    e:SetPoint("TOPLEFT", 18, -64)
    e:SetText(cat.name or "")
    e:SetTextInsets(8, 8, 0, 0)

    local del = Btn(d, "DELETE", 82, 25, RED)
    del:SetPoint("BOTTOMLEFT", 18, 16)
    del:SetScript("OnClick", function()
        Data:RemoveCategory(tab.id, cat.id)
        d:Hide()
        ToDoUI:Refresh()
    end)

    local cancel = Btn(d, "CANCEL", 82, 25, MUTED)
    cancel:SetPoint("LEFT", del, "RIGHT", 8, 0)
    cancel:SetScript("OnClick", function() d:Hide() end)

    local save = Btn(d, "SAVE", 82, 25, GOLD)
    save:SetPoint("LEFT", cancel, "RIGHT", 8, 0)
    save:SetScript("OnClick", function()
        Data:EditCategory(tab.id, cat.id, {name = e:GetText()})
        d:Hide()
        ToDoUI:Refresh()
    end)
    d:Show()
    e:SetFocus()
end

local function RenderCategory(tab, cat, depth, y)
    local width = ContentWidth()
    local indent = 8 + depth * 18
    local panelWidth = width - indent - 4

    local header = Panel(content, panelWidth, 36, 0.82)
    header:SetPoint("TOPLEFT", indent, y)
    header:SetBackdropBorderColor(0.10, 0.42, 0.58, 1)

    local titleColor = cat.color and {cat.color.r or 1, cat.color.g or 1, cat.color.b or 1} or CYAN
    local title = L(header, tostring(cat.name or "Category"), "GameFontNormal", titleColor)
    title:SetPoint("LEFT", 12, 0)

    local add = Btn(header, "+ TASK", 62, 24, GOLD)
    add:SetPoint("RIGHT", -8, 0)
    add:SetScript("OnClick", function() AddTaskDialog(cat.id) end)

    local edit = Btn(header, "EDIT", 48, 24, MUTED)
    edit:SetPoint("RIGHT", add, "LEFT", -5, 0)
    edit:SetScript("OnClick", function() EditCategoryDialog(tab, cat) end)

    rows[#rows + 1] = header
    y = y - 42

    for _, task in ipairs(cat.tasks or {}) do
        local hide = Data:GetSettings().hideCompleted and task.completed
        if not hide then
            local row = Panel(content, panelWidth, 44, 0.55)
            row:SetPoint("TOPLEFT", indent, y)

            local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            cb:SetSize(22, 22)
            cb:SetPoint("LEFT", 10, 0)
            cb:SetChecked(task.completed)
            cb:SetScript("OnClick", function()
                Data:ToggleTask(tab.id, task.id)
                ToDoUI:Refresh()
            end)

            local titleText = (task.favorite and "★ " or "") .. tostring(task.title or "Task")
            local fs = L(row, titleText, "GameFontNormal", task.completed and MUTED or (task.color and {task.color.r or 1, task.color.g or 1, task.color.b or 1} or TEXT))
            fs:SetPoint("LEFT", 40, 5)
            fs:SetWidth(math.max(160, panelWidth - 220))
            fs:SetJustifyH("LEFT")
            fs:SetWordWrap(true)

            if task.description and task.description ~= "" then
                local d = L(row, task.description, "GameFontNormalSmall", MUTED)
                d:SetPoint("LEFT", 40, -12)
                d:SetWidth(math.max(160, panelWidth - 220))
                d:SetWordWrap(true)
            end

            local del = Btn(row, "DELETE", 54, 22, MUTED)
            del:SetPoint("RIGHT", -8, 0)
            del:SetScript("OnClick", function()
                Data:RemoveTask(tab.id, task.id)
                ToDoUI:Refresh()
            end)

            local edit = Btn(row, "EDIT", 42, 22, MUTED)
            edit:SetPoint("RIGHT", del, "LEFT", -5, 0)
            edit:SetScript("OnClick", function() AddTaskDialog(cat.id, task) end)

            local up = Btn(row, "UP", 30, 22, MUTED)
            up:SetPoint("RIGHT", edit, "LEFT", -5, 0)
            up:SetScript("OnClick", function() Data:MoveTask(tab.id, task.id, "up"); ToDoUI:Refresh() end)

            local down = Btn(row, "DOWN", 42, 22, MUTED)
            down:SetPoint("RIGHT", up, "LEFT", -5, 0)
            down:SetScript("OnClick", function() Data:MoveTask(tab.id, task.id, "down"); ToDoUI:Refresh() end)

            row:SetScript("OnEnter", function()
                row:SetBackdropColor(0.03, 0.08, 0.12, 0.88)
                if task.description and task.description ~= "" then
                    GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
                    GameTooltip:SetText(task.title or "Task", 1, .78, .18)
                    GameTooltip:AddLine(task.description, .8, .85, .9, true)
                    GameTooltip:Show()
                end
            end)
            row:SetScript("OnLeave", function()
                row:SetBackdropColor(0.008, 0.018, 0.030, 0.55)
                GameTooltip_Hide()
            end)

            rows[#rows + 1] = row
            y = y - 50
        end
    end

    for _, child in ipairs(cat.children or {}) do
        y = RenderCategory(tab, child, depth + 1, y)
    end
    return y
end

function ToDoUI:Refresh()
    if not frame then return end
    ClearRows()
    local tab = Data:GetActiveTab()
    if not tab then return end

    local open, complete = Data:GetCounts(tab.id)
    frame.count:SetText(string.format("%d open  /  %d complete", open, complete))

    local y = -4
    for _, cat in ipairs(tab.categories or {}) do
        y = RenderCategory(tab, cat, 0, y)
    end

    if #tab.categories == 0 then
        frame.empty:Show()
    else
        frame.empty:Hide()
    end

    content:SetWidth(ContentWidth())
    content:SetHeight(math.max(80, -y + 10))
    scroll:UpdateScrollChildRect()
    UpdateToDoScrollBar()
end

local function AddTabDialog()
    local d = Panel(frame, 390, 205, 1)
    d:SetPoint("CENTER")
    d:SetFrameLevel(120)
    L(d, "NEW TAB", "GameFontNormalLarge", GOLD):SetPoint("TOPLEFT", 18, -16)
    L(d, "TAB NAME", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 18, -48)

    local e = CreateFrame("EditBox", nil, d, "InputBoxTemplate")
    e:SetSize(354, 28)
    e:SetPoint("TOPLEFT", 18, -64)
    e:SetAutoFocus(true)
    e:SetTextInsets(8, 8, 0, 0)

    local modes = {"none", "daily", "weekly", "custom"}
    local mi = 1
    local r = Btn(d, "RESET: NONE", 130, 25, MUTED)
    r:SetPoint("TOPLEFT", 18, -104)
    r:SetScript("OnClick", function()
        mi = mi % #modes + 1
        r.txt:SetText("RESET: " .. string.upper(modes[mi]))
    end)

    local hours = CreateFrame("EditBox", nil, d, "InputBoxTemplate")
    hours:SetSize(60, 25)
    hours:SetPoint("LEFT", r, "RIGHT", 8, 0)
    hours:SetText("24")
    hours:SetTextInsets(5, 5, 0, 0)

    local cancel = Btn(d, "CANCEL", 82, 25, MUTED)
    cancel:SetPoint("BOTTOMLEFT", 18, 16)
    cancel:SetScript("OnClick", function() d:Hide() end)

    local ok = Btn(d, "ADD TAB", 82, 25, GOLD)
    ok:SetPoint("LEFT", cancel, "RIGHT", 8, 0)
    ok:SetScript("OnClick", function()
        local n = strtrim(e:GetText() or "")
        if n ~= "" then
            local t = Data:AddTab(n, modes[mi])
            if t and modes[mi] == "custom" then
                t.resetSeconds = math.max(3600, (tonumber(hours:GetText()) or 24) * 3600)
            end
            d:Hide()
            ToDoUI:Refresh()
            if frame.refreshTabs then frame.refreshTabs() end
        end
    end)

    e:SetScript("OnEnterPressed", function() ok:Click() end)
    d:Show()
end

local function RegisterDataBroker()
    if ToDoUI._brokerRegistered then return end
    local LDB = _G.LibStub and _G.LibStub("LibDataBroker-1.1", true)
    if LDB then
        ToDoUI._broker = LDB:NewDataObject("GoldMint To-Do List", {
            type = "launcher",
            text = "GoldMint To-Do List",
            icon = "Interface\\Icons\\INV_Misc_Note_01",
            OnClick = function(_, button)
                if button == "LeftButton" then ToDoUI:Toggle() end
            end,
            OnTooltipShow = function(tt)
                tt:AddLine("GoldMint To-Do List")
                tt:AddLine("Left-click to open", .72, .84, .96)
            end,
        })
        ToDoUI._brokerRegistered = true
    end
end

local function Build()
    if frame then return end

    frame = CreateFrame("Frame", "GoldMintToDoPopout", UIParent, "BackdropTemplate")
    local sz = Data:GetSettings()
    local mw, mh = MenuDimensions(sz.menuSize)
    frame:SetSize(mw, mh)
    frame:SetResizable(true)
    frame:SetResizeBounds(420, 440, 900, 800)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata(sz.openBehavior == "LOW" and "LOW" or "DIALOG")
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        -- Decorative lines are direct children of this frame and are never
        -- re-anchored after a move. They travel with the frame automatically.
        UpdateToDoScrollBar()
    end)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    frame:SetBackdropColor(unpack(Theme()))
    frame:SetBackdropBorderColor(0.10, 0.42, 0.58, 1)

    local title = L(frame, "Mint's To-Do List", "GameFontNormalLarge", GOLD)
    title:SetPoint("TOPLEFT", 20, -16)

    local subtitle = L(frame, "Your checklist, organized by tab and category.", "GameFontNormalSmall", MUTED)
    subtitle:SetPoint("TOPLEFT", 21, -39)

    -- Dedicated title-bar drag area. Child controls (scroll frame, buttons, etc.)
    -- otherwise consume mouse input and make the window feel impossible to move.
    local dragBar = CreateFrame("Button", nil, frame)
    dragBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    dragBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -70, 0)
    dragBar:SetHeight(54)
    dragBar:SetFrameLevel(frame:GetFrameLevel() + 3)
    dragBar:RegisterForDrag("LeftButton")
    dragBar:SetScript("OnDragStart", function() frame:StartMoving() end)
    dragBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        -- Do not rebuild or re-anchor any decorative textures here.
        UpdateToDoScrollBar()
    end)
    frame.dragBar = dragBar

    local close = Btn(frame, "CLOSE", 52, 24, GOLD)
    close:SetFrameLevel(frame:GetFrameLevel() + 4)
    close:SetPoint("TOPRIGHT", -12, -12)
    close:SetScript("OnClick", function() frame:Hide() end)

    local tabs = {}
    local function RefreshTabs()
        for _, b in ipairs(tabs) do b:Hide() end
        wipe(tabs)
        local x = 16
        -- Reserve the fixed right-side action strip (+ CATEGORY / + TAB / SETTINGS)
        -- so tab buttons can never overlap it, regardless of window width or tab count.
        local actionStripWidth = 92 + 6 + 58 + 6 + 72
        local available = math.max(120, frame:GetWidth() - x - actionStripWidth - 24)
        local tabCount = math.max(1, #Data:GetTabs())
        local tabWidth = math.max(52, math.min(120, math.floor((available - ((tabCount - 1) * 6)) / tabCount)))
        for _, tab in ipairs(Data:GetTabs()) do
            local b = Btn(frame, string.upper(tab.name or "TAB"), tabWidth, 28, tab.id == Data:GetActiveTab().id and GOLD or MUTED)
            b:SetFrameLevel(frame:GetFrameLevel() + 4)
            b:SetPoint("TOPLEFT", x, -68)
            b:SetScript("OnClick", function()
                Data:SetActiveTab(tab.id)
                ToDoUI:Refresh()
                RefreshTabs()
            end)
            tabs[#tabs + 1] = b
            x = x + tabWidth + 6
        end
    end
    frame.refreshTabs = RefreshTabs

    -- Right-side action strip: keep all management buttons together on the fixed header bar.
    -- The buttons are anchored to the frame, not the scrolling content, so moving the window
    -- never changes their relationship to the header/divider.
    local settings = Btn(frame, "SETTINGS", 72, 28, MUTED)
    settings:SetFrameLevel(frame:GetFrameLevel() + 4)
    settings:SetPoint("TOPRIGHT", -14, -68)
    settings:SetScript("OnClick", function() ToDoUI:OpenSettings() end)

    local addTab = Btn(frame, "+ TAB", 58, 28, GOLD)
    addTab:SetFrameLevel(frame:GetFrameLevel() + 4)
    addTab:SetPoint("RIGHT", settings, "LEFT", -6, 0)
    addTab:SetScript("OnClick", AddTabDialog)

    local addCat = Btn(frame, "+ CATEGORY", 92, 28, CYAN)
    addCat:SetFrameLevel(frame:GetFrameLevel() + 4)
    addCat:SetPoint("RIGHT", addTab, "LEFT", -6, 0)
    addCat:SetScript("OnClick", function() AddCategoryDialog(nil) end)

    frame.count = L(frame, "0 open  /  0 complete", "GameFontNormalSmall", MUTED)
    frame.count:SetDrawLayer("OVERLAY", 7)
    frame.count:SetPoint("TOPLEFT", 18, -108)

    local contentTop = -140

    -- IMPORTANT: every decorative line is created directly on the moving
    -- To-Do window and anchored directly to that window. Nothing here is
    -- re-anchored when the window moves. This keeps the rules physically
    -- attached to the frame instead of chasing its position.
    headerDivider = frame:CreateTexture(nil, "ARTWORK")
    headerDivider:SetColorTexture(0.08, 0.35, 0.48, 0.85)
    headerDivider:SetHeight(1)
    headerDivider:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -56)
    headerDivider:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -14, -56)
    frame.headerDivider = headerDivider

    contentTopLine = frame:CreateTexture(nil, "ARTWORK")
    contentTopLine:SetColorTexture(0.08, 0.32, 0.46, 0.92)
    contentTopLine:SetHeight(1)
    contentTopLine:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, contentTop)
    contentTopLine:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -14, contentTop)
    frame.contentTopLine = contentTopLine

    contentBottomLine = frame:CreateTexture(nil, "ARTWORK")
    contentBottomLine:SetColorTexture(0.08, 0.32, 0.46, 0.92)
    contentBottomLine:SetHeight(1)
    contentBottomLine:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 14, 24)
    contentBottomLine:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -14, 24)
    frame.contentBottomLine = contentBottomLine

    contentLeftLine = frame:CreateTexture(nil, "ARTWORK")
    contentLeftLine:SetColorTexture(0.08, 0.32, 0.46, 0.92)
    contentLeftLine:SetWidth(1)
    contentLeftLine:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, contentTop)
    contentLeftLine:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 14, 24)
    frame.contentLeftLine = contentLeftLine

    contentRightLine = frame:CreateTexture(nil, "ARTWORK")
    contentRightLine:SetColorTexture(0.08, 0.32, 0.46, 0.92)
    contentRightLine:SetWidth(1)
    contentRightLine:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -14, contentTop)
    contentRightLine:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -14, 24)
    frame.contentRightLine = contentRightLine

    scroll = CreateFrame("ScrollFrame", "GoldMintToDoScrollFrame", frame)
    scroll:SetPoint("TOPLEFT", 22, contentTop - 8)
    scroll:SetPoint("BOTTOMRIGHT", -26, 24)
    scroll:SetClipsChildren(true)
    content = CreateFrame("Frame", nil, scroll)
    content:SetWidth(ContentWidth())
    content:SetHeight(80)
    scroll:SetScrollChild(content)
    scroll:SetFrameLevel(frame:GetFrameLevel() + 2)
    BuildToDoScrollBar()

    frame.empty = L(frame, "NO TASKS YET\n\nCreate a category, then add tasks to build your checklist.", "GameFontNormal", MUTED)
    frame.empty:SetDrawLayer("OVERLAY", 7)
    frame.empty:SetPoint("CENTER", 0, -22)
    frame.empty:SetWidth(380)
    frame.empty:SetJustifyH("CENTER")

    local grip = CreateFrame("Button", nil, frame)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:RegisterForDrag("LeftButton")
    grip:SetScript("OnDragStart", function() frame:StartSizing("BOTTOMRIGHT") end)
    grip:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        Data:GetSettings().width = frame:GetWidth()
        Data:GetSettings().height = frame:GetHeight()
        ToDoUI:Refresh()
    end)

    -- Only geometry that actually needs updating when the frame is resized is
    -- recalculated here. The decorative lines above are deliberately excluded.
    -- Moving the window therefore does not trigger any line repositioning.
    local function UpdateGeometry()
        if not frame or not scroll then return end

        scroll:ClearAllPoints()
        scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -148)
        scroll:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -26, 24)
        scroll:SetFrameLevel(frame:GetFrameLevel() + 2)
        content:SetWidth(ContentWidth())

        if scrollBar then
            scrollBar:ClearAllPoints()
            scrollBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -142)
            scrollBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 24)
            scrollBar:SetFrameLevel(frame:GetFrameLevel() + 5)
        end
        if scrollBarTrack then
            scrollBarTrack:ClearAllPoints()
            scrollBarTrack:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -142)
            scrollBarTrack:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 24)
            scrollBarTrack:SetFrameLevel(frame:GetFrameLevel() + 4)
        end

        RefreshTabs()
        UpdateToDoScrollBar()
    end

    frame.layout = UpdateGeometry

    frame:SetScript("OnSizeChanged", function()
        UpdateGeometry()
    end)

    frame:SetScript("OnShow", function()
        UpdateGeometry()
        ToDoUI:Refresh()
    end)

    UpdateGeometry()
end

function ToDoUI:OpenSettings()
    local d = Panel(frame, 430, 410, 1)
    d:SetPoint("CENTER")
    d:SetFrameLevel(120)

    L(d, "TO-DO SETTINGS", "GameFontNormalLarge", GOLD):SetPoint("TOPLEFT", 18, -16)
    L(d, "Presentation and behavior", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 19, -40)

    local s = Data:GetSettings()

    local theme = Btn(d, "THEME: " .. string.upper(s.theme), 170, 27, MUTED)
    theme:SetPoint("TOPLEFT", 18, -64)
    theme:SetScript("OnClick", function()
        s.theme = s.theme == "dark" and "clear" or "dark"
        theme.txt:SetText("THEME: " .. string.upper(s.theme))
        ToDoUI:ApplyMenuSettings()
    end)

    local hide = Btn(d, s.hideCompleted and "HIDE COMPLETED: ON" or "HIDE COMPLETED: OFF", 190, 27, MUTED)
    hide:SetPoint("TOPLEFT", 18, -98)
    hide:SetScript("OnClick", function()
        s.hideCompleted = not s.hideCompleted
        hide.txt:SetText(s.hideCompleted and "HIDE COMPLETED: ON" or "HIDE COMPLETED: OFF")
        ToDoUI:Refresh()
    end)

    local screen = Btn(d, s.screenButton and "SCREEN BUTTON: ON" or "SCREEN BUTTON: OFF", 190, 27, MUTED)
    screen:SetPoint("TOPLEFT", 18, -132)
    screen:SetScript("OnClick", function()
        s.screenButton = not s.screenButton
        screen.txt:SetText(s.screenButton and "SCREEN BUTTON: ON" or "SCREEN BUTTON: OFF")
        ToDoUI:UpdateScreenButton()
    end)

    local top = Btn(d, s.addToTop and "ADD NEW ITEMS: TOP" or "ADD NEW ITEMS: BOTTOM", 205, 27, MUTED)
    top:SetPoint("TOPLEFT", 18, -166)
    top:SetScript("OnClick", function()
        s.addToTop = not s.addToTop
        top.txt:SetText(s.addToTop and "ADD NEW ITEMS: TOP" or "ADD NEW ITEMS: BOTTOM")
    end)

    local behavior = Btn(d, "OPEN BEHAVIOR: " .. s.openBehavior, 190, 27, MUTED)
    behavior:SetPoint("TOPLEFT", 18, -200)
    behavior:SetScript("OnClick", function()
        s.openBehavior = s.openBehavior == "DIALOG" and "LOW" or "DIALOG"
        behavior.txt:SetText("OPEN BEHAVIOR: " .. s.openBehavior)
        ToDoUI:ApplyMenuSettings()
    end)

    local size = Btn(d, "MENU SIZE: " .. s.menuSize, 190, 27, MUTED)
    size:SetPoint("TOPLEFT", 18, -234)
    size:SetScript("OnClick", function()
        s.menuSize = s.menuSize == "SMALL" and "MEDIUM" or (s.menuSize == "MEDIUM" and "LARGE" or "SMALL")
        s.width, s.height = nil, nil
        size.txt:SetText("MENU SIZE: " .. s.menuSize)
        ToDoUI:ApplyMenuSettings()
        ToDoUI:Refresh()
    end)

    local fs = Btn(d, "FONT SIZE: " .. string.format("%.1f", s.fontScale), 150, 27, MUTED)
    fs:SetPoint("TOPLEFT", 18, -268)
    fs:SetScript("OnClick", function()
        s.fontScale = s.fontScale >= 1.4 and .8 or s.fontScale + .1
        fs.txt:SetText("FONT SIZE: " .. string.format("%.1f", s.fontScale))
        ToDoUI:ApplyFontScale()
    end)

    local op = Btn(d, "OPACITY: " .. math.floor((s.opacity or .96) * 100) .. "%", 150, 27, MUTED)
    op:SetPoint("TOPLEFT", 18, -302)
    op:SetScript("OnClick", function()
        s.opacity = (s.opacity or .96) - .1
        if s.opacity < .4 then s.opacity = .96 end
        op.txt:SetText("OPACITY: " .. math.floor(s.opacity * 100) .. "%")
        ToDoUI:ApplyMenuSettings()
    end)

    L(d, "These controls change the Mint-style To-Do List window immediately.", "GameFontNormalSmall", MUTED):SetPoint("TOPLEFT", 18, -342)

    local close = Btn(d, "CLOSE", 82, 25, GOLD)
    close:SetPoint("BOTTOMRIGHT", -18, 16)
    close:SetScript("OnClick", function() d:Hide() end)
    d:Show()
end

function ToDoUI:ApplyFontScale()
    if frame then
        frame:SetScale(Data:GetSettings().fontScale or 1)
        frame:SetFrameStrata(Data:GetSettings().openBehavior == "LOW" and "LOW" or "DIALOG")
    end
end

function ToDoUI:UpdateScreenButton()
    local s = Data:GetSettings()
    if not screenButton then
        screenButton = Btn(UIParent, "TO-DO", 54, 24, GOLD)
        screenButton:SetFrameStrata("MEDIUM")
        screenButton:SetMovable(true)
        screenButton:EnableMouse(true)
        screenButton:RegisterForDrag("LeftButton")
        screenButton:SetPoint("CENTER", UIParent, "CENTER", 260, 0)
        screenButton:SetScript("OnDragStart", screenButton.StartMoving)
        screenButton:SetScript("OnDragStop", screenButton.StopMovingOrSizing)
        screenButton:SetScript("OnClick", function() ToDoUI:Toggle() end)
    end
    screenButton:SetShown(s.screenButton == true)
end

function ToDoUI:Show()
    RegisterDataBroker()
    Build()
    self:ApplyMenuSettings()
    self:ApplyFontScale()
    self:UpdateScreenButton()
    self:Refresh()
    frame:Show()
    frame:Raise()
end

function ToDoUI:Hide()
    if frame then frame:Hide() end
end

function ToDoUI:Toggle()
    RegisterDataBroker()
    Build()
    if frame:IsShown() then
        frame:Hide()
    else
        self:Show()
    end
end

_G.TOGGLE_GOLDMINT_TODO = function() ToDoUI:Toggle() end
