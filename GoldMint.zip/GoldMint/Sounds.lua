local ADDON_NAME, GoldMint = ...

GoldMint.Sounds = {}
local Sounds = GoldMint.Sounds

local DEFAULTS = {
    alert = "RAID_WARNING",
    toast = "UI_BNET_TOAST",
    stretch = "READY_CHECK",
}

local CHOICES = {
    { key = "NONE", label = "None" },
    { key = "RAID_WARNING", label = "Raid Warning" },
    { key = "READY_CHECK", label = "Ready Check" },
    { key = "ALARM_CLOCK_WARNING_2", label = "Alarm Clock" },
    { key = "LEVELUPSOUND", label = "Level Up" },
    { key = "IG_MAINMENU_OPTION_CHECKBOX_ON", label = "Checkbox On" },
    { key = "UI_BNET_TOAST", label = "Battle.net Toast" },
}

local function EnsureStore()
    GoldMintDB.sounds = type(GoldMintDB.sounds) == "table" and GoldMintDB.sounds or {}
    local s = GoldMintDB.sounds
    for name, value in pairs(DEFAULTS) do
        if type(s[name]) ~= "string" then s[name] = value end
    end
    return s
end

local function Resolve(key)
    if not key or key == "NONE" then return nil end
    if SOUNDKIT and SOUNDKIT[key] then return SOUNDKIT[key] end
    return nil
end

function Sounds:GetSettings()
    return EnsureStore()
end

function Sounds:GetChoices()
    return CHOICES
end

function Sounds:GetLabel(key)
    for _, choice in ipairs(CHOICES) do
        if choice.key == key then return choice.label end
    end
    return "None"
end

function Sounds:Set(kind, key)
    local s = EnsureStore()
    if not DEFAULTS[kind] then return false end
    local valid = key == "NONE"
    if not valid then
        for _, choice in ipairs(CHOICES) do
            if choice.key == key then valid = true; break end
        end
    end
    if not valid then return false end
    s[kind] = key
    if GoldMintDB and type(GoldMintDB.settings) == "table" then
        GoldMintDB.settings[kind .. "Sound"] = key
    end
    return true
end

function Sounds:Play(kind)
    local s = EnsureStore()
    local key = s[kind]
    if GoldMintDB and type(GoldMintDB.settings) == "table" then
        key = GoldMintDB.settings[kind .. "Sound"] or key
    end
    local soundID = Resolve(key)
    if not soundID or type(PlaySound) ~= "function" then return false end
    local ok = pcall(PlaySound, soundID, "Master")
    return ok
end

function Sounds:Test(kind)
    return self:Play(kind)
end
