local ADDON_NAME, GoldMint = ...

-- GoldMint command-center Hub.
-- This is intentionally a read-only presentation layer for the current
-- WorkflowState + CharacterTracking backends. Mail and auction logistics can plug in
-- without changing this UI contract.

GoldMint.Hub = {}
local Hub = GoldMint.Hub

local frame
local labels = {}
local characterRows = {}

local function MakeLabel(parent, font, text)
    local label = parent:CreateFontString(nil, "OVERLAY", font)
    label:SetJustifyH("LEFT")
    label:SetText(text or "")
    return label
end

local function FormatGold(copper)
    if GoldMint.Ledger and GoldMint.Ledger.FormatGoldFull then
        return GoldMint.Ledger:FormatGoldFull(copper or 0)
    end
    return tostring(copper or 0)
end

local function FormatWhen(timestamp)
    timestamp = tonumber(timestamp) or 0
    if timestamp <= 0 then return "Never" end
    if date then return date("%Y-%m-%d %H:%M", timestamp) end
    return tostring(timestamp)
end

local function ClearRows()
    for _, row in ipairs(characterRows) do row:Hide() end
end

local function CreateCharacterRow(index)
    local row = CreateFrame("Frame", nil, frame)
    row:SetSize(500, 44)
    row:SetPoint("TOPLEFT", 22, -420 - ((index - 1) * 45))
    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, index % 2 == 0 and 0.025 or 0.01)
    row.text = MakeLabel(row, "GameFontNormal", "")
    row.text:SetPoint("TOPLEFT", 8, -5)
    row.text:SetWidth(360)
    row.detail = MakeLabel(row, "GameFontDisableSmall", "")
    row.detail:SetPoint("BOTTOMLEFT", 8, 5)
    row.detail:SetWidth(360)
    row.gold = MakeLabel(row, "GameFontNormal", "")
    row.gold:SetPoint("RIGHT", -8, 0)
    characterRows[index] = row
    return row
end

local function Refresh()
    if not frame or not frame:IsShown() then return end
    if not GoldMint.CharacterTracking then return end

    local snapshot = GoldMint.CharacterTracking:GetHubSnapshot()
    local current = snapshot.current
    if not current then return end

    labels.character:SetText(string.format("%s-%s  •  Level %d", current.name, current.realm, current.level))
    labels.gold:SetText("Known Account Gold: " .. FormatGold(snapshot.totalGold))
    labels.task:SetText("CURRENT TASK\n" .. ((current.task and current.task.title) or "No active task"))
    labels.next:SetText("NEXT ACTION\n" .. ((current.nextAction and current.nextAction.title) or "No next action set"))
    labels.activity:SetText("LAST ACTIVITY\n" .. ((current.lastActivity and current.lastActivity.label) or "No activity observed yet"))

    local reminders = 0
    if GoldMint.WorkflowState then
        local state = GoldMint.WorkflowState:GetWelcomeBackState()
        reminders = state and state.reminderCount or 0
    end
    labels.reminders:SetText("REMINDERS\n" .. tostring(reminders) .. " active")

    if GoldMint.MailTracking then
        local mail = GoldMint.MailTracking:GetSummary()
        local mailText = tostring(mail and mail.mailCount or 0) .. " message(s)"
        if mail and (mail.attachmentCount or 0) > 0 then
            mailText = mailText .. "  •  " .. tostring(mail.attachmentCount) .. " item(s)"
        end
        if mail and (mail.moneyTotal or 0) > 0 then
            mailText = mailText .. "  •  " .. FormatGold(mail.moneyTotal)
        end
        labels.mail:SetText("MAIL\n" .. mailText)
    else
        labels.mail:SetText("MAIL\nNot available")
    end

    labels.count:SetText(string.format("CHARACTERS  %d known  •  %d active this session", snapshot.characterCount, snapshot.activeCount))

    ClearRows()
    for index, character in ipairs(snapshot.characters) do
        local row = characterRows[index] or CreateCharacterRow(index)
        local marker = character.key == GoldMint.characterKey and "[CURRENT] " or ""
        local context = character.nextAction and ("Next: " .. character.nextAction.title)
            or (character.task and ("Task: " .. character.task.title) or "No active workflow")
        local reminderText = (character.reminderCount or 0) > 0 and (" • " .. character.reminderCount .. " reminder(s)") or ""
        row.text:SetText(string.format("%s%s  Lv.%d", marker, character.name, character.level))
        row.detail:SetText(context .. reminderText)
        row.gold:SetText(FormatGold(character.gold))
        row:Show()
    end

    frame:SetHeight(math.max(500, 445 + math.min(#snapshot.characters, 12) * 45))
end

function Hub:Initialize()
    if frame then return end

    frame = CreateFrame("Frame", "GoldMintHubFrame", UIParent, "BackdropTemplate")
    frame:SetSize(545, 500)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    frame:SetBackdropColor(0.025, 0.025, 0.03, 0.97)
    frame:SetBackdropBorderColor(0.65, 0.48, 0.12, 0.8)

    labels.title = MakeLabel(frame, "GameFontHighlightLarge", "GOLDMINT HUB")
    labels.title:SetPoint("TOPLEFT", 22, -18)
    labels.character = MakeLabel(frame, "GameFontNormal", "")
    labels.character:SetPoint("TOPLEFT", 22, -48)
    labels.gold = MakeLabel(frame, "GameFontNormal", "")
    labels.gold:SetPoint("TOPLEFT", 22, -70)

    labels.task = MakeLabel(frame, "GameFontHighlight", "")
    labels.task:SetPoint("TOPLEFT", 22, -100)
    labels.task:SetWidth(500)
    labels.task:SetHeight(42)

    labels.next = MakeLabel(frame, "GameFontHighlight", "")
    labels.next:SetPoint("TOPLEFT", 22, -145)
    labels.next:SetWidth(500)
    labels.next:SetHeight(42)

    labels.activity = MakeLabel(frame, "GameFontNormal", "")
    labels.activity:SetPoint("TOPLEFT", 22, -190)
    labels.activity:SetWidth(500)
    labels.activity:SetHeight(38)

    labels.reminders = MakeLabel(frame, "GameFontNormal", "")
    labels.reminders:SetPoint("TOPLEFT", 22, -235)
    labels.reminders:SetWidth(500)
    labels.reminders:SetHeight(35)

    labels.commands = MakeLabel(frame, "GameFontNormal", [[COMMANDS
/gm dashboard  —  Open Dashboard
/tdl  —  Open To-Do List
/gm farm  —  Open Farming Tracker]])
    labels.commands:SetPoint("TOPLEFT", 22, -318)
    labels.commands:SetWidth(500)
    labels.commands:SetHeight(62)

    labels.count = MakeLabel(frame, "GameFontHighlight", "CHARACTERS")
    labels.count:SetPoint("TOPLEFT", 22, -390)

    labels.mail = MakeLabel(frame, "GameFontNormal", "")
    labels.mail:SetPoint("TOPLEFT", 22, -270)
    labels.mail:SetWidth(500)
    labels.mail:SetHeight(35)

    local function MakeHubButton(text, width, height)
        local b = CreateFrame("Button", nil, frame, "BackdropTemplate")
        b:SetSize(width, height)
        b:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = true, tileSize = 8, edgeSize = 1,
            insets = {left = 1, right = 1, top = 1, bottom = 1},
        })
        b:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        b:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        b.text:SetPoint("CENTER")
        b.text:SetText(text)
        b.text:SetTextColor(0.60, 0.74, 0.88)
        b:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
            self:SetBackdropBorderColor(1.0, 0.78, 0.20, 1.0)
            self.text:SetTextColor(1.0, 0.86, 0.38)
        end)
        b:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
            self:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
            self.text:SetTextColor(0.60, 0.74, 0.88)
        end)
        return b
    end

    local close = MakeHubButton("×", 30, 30)
    close:SetPoint("TOPRIGHT", -10, -10)
    close.text:SetFont(close.text:GetFont(), 18, "")
    close:SetScript("OnClick", function() frame:Hide() end)

    local refresh = MakeHubButton("Refresh", 75, 24)
    refresh:SetPoint("TOPRIGHT", -48, -46)
    refresh:SetScript("OnClick", Refresh)

    frame:SetScript("OnShow", function(self)
        self._uiLifecycle = (self._uiLifecycle or 0) + 1
        Refresh()
    end)
    frame:SetScript("OnHide", function(self)
        self._uiLifecycle = (self._uiLifecycle or 0) + 1
    end)
    -- Initialization must never display the Hub automatically on login/reload.
    -- It should only appear when the user explicitly opens /gm hub.
    frame:Hide()
    self.frame = frame
end

function Hub:Show()
    if not frame then self:Initialize() end
    frame:Show()
    Refresh()
end

function Hub:Hide()
    if frame then frame:Hide() end
end

function Hub:Toggle()
    if not frame then self:Initialize() end
    if frame:IsShown() then self:Hide() else self:Show() end
end
