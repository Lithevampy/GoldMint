local ADDON_NAME, GoldMint = ...

GoldMint.Ledger = {}
local Ledger = GoldMint.Ledger

local MAX_TRANSACTIONS_PER_SESSION = 250
local MAX_SAVED_SESSIONS = 30
local MAX_DAILY_HISTORY = 14
local TRANSACTION_CONTEXT_WINDOW = 1.5

-- Negative wallet changes are only treated as real spending when GoldMint has
-- a concrete source for the charge.  A bare PLAYER_MONEY decrease can also be
-- caused by wallet/bank synchronization, stale baselines, or other Blizzard
-- bookkeeping that does not represent an economic purchase.  Never turn an
-- unidentified decrease into Daily Profit loss.
local CONFIRMED_SPENDING_SOURCES = {
    ["Vendor Purchase"] = true,
    ["Mail Payment / COD"] = true,
    ["Trade Payment"] = true,
    ["Auction House"] = true,
}

local function IsConfirmedSpendingSource(source)
    return type(source) == "string" and CONFIRMED_SPENDING_SOURCES[source] == true
end

local function IsFrameShown(frame)
    return frame and type(frame.IsShown) == "function" and frame:IsShown() or false
end

local function Now()
    if type(GetTimePreciseSec) == "function" then
        return GetTimePreciseSec()
    end
    return time()
end

local function WallTime()
    return time()
end

local function GetFaction()
    if UnitFactionGroup then
        local faction = UnitFactionGroup("player")
        if faction then
            return faction
        end
    end
    return "Unknown"
end

-- Daily economics are account-wide and survive /reload, logout, and a new
-- Ledger session.  The reset boundary is Blizzard's actual daily reset rather
-- than local midnight, so a late-night session does not get split incorrectly.
local function GetDailyResetEpoch()
    local remaining
    if C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset then
        remaining = tonumber(C_DateAndTime.GetSecondsUntilDailyReset())
    elseif GetQuestResetTime then
        remaining = tonumber(GetQuestResetTime())
    end

    if not remaining or remaining < 0 then
        remaining = 86400
    end

    local now = WallTime()
    return math.floor(now - math.max(0, 86400 - remaining))
end

local function EnsureDailyLedger()
    if type(GoldMintDB) ~= "table" then
        return nil
    end

    local store = GoldMintDB.dailyLedger
    if type(store) ~= "table" then
        store = {}
        GoldMintDB.dailyLedger = store
    end
    store.history = type(store.history) == "table" and store.history or {}

    local resetAt = GetDailyResetEpoch()
    local currentResetAt = tonumber(store.resetAt)

    if currentResetAt and currentResetAt ~= resetAt then
        -- Preserve the completed day before starting the new Blizzard reset
        -- period.  This history powers the seven-day dashboard trend.
        local entry = {
            resetAt = currentResetAt,
            income = tonumber(store.income) or 0,
            spending = tonumber(store.spending) or 0,
            net = tonumber(store.net) or 0,
        }
        if entry.income ~= 0 or entry.spending ~= 0 or entry.net ~= 0 then
            store.history[#store.history + 1] = entry
        end
        while #store.history > MAX_DAILY_HISTORY do
            table.remove(store.history, 1)
        end
        store.income = 0
        store.spending = 0
        store.net = 0
    elseif not currentResetAt then
        store.income = tonumber(store.income) or 0
        store.spending = tonumber(store.spending) or 0
        store.net = tonumber(store.net) or (store.income - store.spending)
    end

    store.resetAt = resetAt
    store.initialized = true
    store.updatedAt = WallTime()
    return store
end

function Ledger:EnsureDailyLedger()
    local store = EnsureDailyLedger()
    if not store then return nil end

    -- One-time migration: recover today's already-saved session transactions so
    -- upgrading to the persistent daily ledger does not erase today's work.
    -- Only confirmed spending sources are allowed into the spending side. Older
    -- builds could save an unexplained PLAYER_MONEY decrease as "Other Spending"
    -- and that must not become today's permanent Daily Profit loss.
    if store.migrated ~= true then
        local income, spending = 0, 0
        local resetAt = tonumber(store.resetAt) or GetDailyResetEpoch()
        local now = WallTime()
        for _, saved in ipairs(GoldMintDB.sessions or {}) do
            for _, tx in ipairs(saved.transactions or {}) do
                local txTime = tonumber(tx.time) or 0
                if txTime >= resetAt and txTime <= now then
                    local amount = tonumber(tx.amount) or 0
                    local source = tx.source
                    if amount > 0 then
                        income = income + amount
                    elseif amount < 0 and IsConfirmedSpendingSource(source) then
                        spending = spending + math.abs(amount)
                    end
                end
            end
        end
        store.income = income
        store.spending = spending
        store.net = income - spending
        store.migrated = true
        store.updatedAt = now
    end

    -- One-time cleanup for databases created by the earlier ledger logic.
    -- Rebuild today's economics from saved transactions while excluding any
    -- negative transaction that was recorded without a confirmed source. This
    -- removes false losses already written by previous builds.
    if store.sanitizedUnknownSpending ~= true then
        local income, spending = 0, 0
        local resetAt = tonumber(store.resetAt) or GetDailyResetEpoch()
        local now = WallTime()
        for _, saved in ipairs(GoldMintDB.sessions or {}) do
            for _, tx in ipairs(saved.transactions or {}) do
                local txTime = tonumber(tx.time) or 0
                if txTime >= resetAt and txTime <= now then
                    local amount = tonumber(tx.amount) or 0
                    local source = tx.source
                    if amount > 0 then
                        income = income + amount
                    elseif amount < 0 and IsConfirmedSpendingSource(source) then
                        spending = spending + math.abs(amount)
                    end
                end
            end
        end
        store.income = income
        store.spending = spending
        store.net = income - spending
        store.sanitizedUnknownSpending = true
        store.updatedAt = now
    end

    return store
end

function Ledger:RecordDailyTransaction(delta, confirmedSpending)
    delta = tonumber(delta) or 0
    if delta == 0 then return end

    -- Daily Profit is an economics ledger, not a raw wallet-delta ledger.
    -- Positive wallet changes are safe to count as income, but a negative
    -- PLAYER_MONEY change must have an explicitly confirmed spending source.
    -- Keep this guard here as the final safety net so no future caller can
    -- accidentally turn an unexplained wallet decrease into Daily Profit loss.
    if delta < 0 and not confirmedSpending then
        return false
    end

    local store = self:EnsureDailyLedger()
    if not store then return false end

    if delta > 0 then
        store.income = (tonumber(store.income) or 0) + delta
    else
        store.spending = (tonumber(store.spending) or 0) + math.abs(delta)
    end
    store.net = (tonumber(store.income) or 0) - (tonumber(store.spending) or 0)
    store.updatedAt = WallTime()
    return true
end

function Ledger:GetDailyEconomics()
    local store = self:EnsureDailyLedger() or {}
    local income = tonumber(store.income) or 0
    local spending = tonumber(store.spending) or 0
    local net = income - spending
    local elapsed = math.max(WallTime() - (tonumber(store.resetAt) or WallTime()), 1)
    local hours = elapsed / 3600

    return {
        resetAt = tonumber(store.resetAt) or GetDailyResetEpoch(),
        income = income,
        spending = spending,
        net = net,
        profitPerHour = net / hours,
        velocityGoldPerHour = income / hours,
    }
end

function Ledger:GetDailyHistory()
    local store = self:EnsureDailyLedger() or {}
    local history = {}
    for i, entry in ipairs(store.history or {}) do
        history[i] = {
            resetAt = tonumber(entry.resetAt) or 0,
            income = tonumber(entry.income) or 0,
            spending = tonumber(entry.spending) or 0,
            net = tonumber(entry.net) or ((tonumber(entry.income) or 0) - (tonumber(entry.spending) or 0)),
        }
    end
    return history
end

function Ledger:GetMoney()
    return type(GetMoney) == "function" and (tonumber(GetMoney()) or 0) or 0
end

local function GetAccountBankType()
    if Enum and Enum.BankType and Enum.BankType.Account then
        return Enum.BankType.Account
    end
    return 2
end

function Ledger:UpdateWarbandGold()
    if not C_Bank or not C_Bank.FetchDepositedMoney then
        return tonumber(GoldMintDB and GoldMintDB.warbandGold) or 0
    end

    local bankType = GetAccountBankType()

    -- FetchDepositedMoney is a read-only Blizzard API and can be queried without
    -- requiring the bank window to be open. Do not gate it behind CanViewBank:
    -- doing so left the dashboard stuck on an old Warband balance whenever the
    -- player was away from the bank. The dashboard must use the newest balance
    -- Blizzard has available and keep the last known value only if the API call
    -- itself fails.
    local ok, amount = pcall(C_Bank.FetchDepositedMoney, bankType)
    if ok and type(amount) == "number" and amount >= 0 then
        GoldMintDB.warbandGold = math.floor(amount)
        GoldMintDB.warbandGoldUpdatedAt = time()
        return GoldMintDB.warbandGold
    end

    return tonumber(GoldMintDB and GoldMintDB.warbandGold) or 0
end

function Ledger:GetWarbandGold()
    -- Warband gold is a single shared balance. Ordinary wallet/dashboard reads
    -- must use the last confirmed value instead of fetching Blizzard's bank
    -- balance again. Refresh it only from explicit bank lifecycle events.
    return tonumber(GoldMintDB and GoldMintDB.warbandGold) or 0
end

function Ledger:GetCharacterRecord()
    if not GoldMintDB or not GoldMint.characterKey then
        return nil
    end
    GoldMintDB.characters = type(GoldMintDB.characters) == "table" and GoldMintDB.characters or {}
    GoldMintDB.characters[GoldMint.characterKey] = GoldMintDB.characters[GoldMint.characterKey] or {}
    return GoldMintDB.characters[GoldMint.characterKey]
end

function Ledger:UpdateCharacterGold()
    local character = self:GetCharacterRecord()
    if not character then
        return
    end

    local money = self:GetMoney()
    local previous = self.session and self.session.lastGold or money
    local delta = money - previous

    -- If the character and Warbank balances changed by equal/opposite amounts,
    -- this is an internal transfer. It must not count as income, spending,
    -- profit, or loss.
    local warbandGold = self:GetWarbandGold()
    local previousWarband = self.lastObservedWarbandGold
    local warbandDelta = 0
    if previousWarband ~= nil then
        warbandDelta = warbandGold - previousWarband
    end
    local isInternalTransfer = delta ~= 0 and warbandDelta ~= 0 and (delta + warbandDelta) == 0

    if self.session and delta ~= 0 then
        if isInternalTransfer then
            local transfer = {
                time = WallTime(),
                elapsed = Now() - self.session.startedAt,
                amount = delta,
                type = "transfer",
                source = delta < 0 and "Character → Warbank" or "Warbank → Character",
                warbandDelta = warbandDelta,
            }
            table.insert(self.session.transactions, transfer)
            if delta < 0 then
                self.session.transferOut = (self.session.transferOut or 0) + math.abs(delta)
            else
                self.session.transferIn = (self.session.transferIn or 0) + delta
            end
            while #self.session.transactions > MAX_TRANSACTIONS_PER_SESSION do
                table.remove(self.session.transactions, 1)
            end
        else
            self:RecordTransaction(delta)
        end
    end

    if self.session then
        self.session.lastGold = money
        self.session.endingGold = money
        -- Economic net is based only on actual income and spending, so moving
        -- gold between a character and the shared Warbank leaves it unchanged.
        self.session.netGold = (tonumber(self.session.income) or 0) - (tonumber(self.session.spending) or 0)

        local elapsed = math.max(Now() - self.session.startedAt, 0.001)
        self.session.goldPerHour = self.session.netGold / (elapsed / 3600)
        -- Session Velocity is gross, realized gold income per hour.  Do not
        -- annualize the first few seconds/minutes of a session: one small
        -- loot payout immediately after login can otherwise become an absurd
        -- 20k+ gold/hour spike.  The five-minute floor is only a smoothing
        -- guard; after five minutes the rate uses the actual session elapsed
        -- time.  Item market value is never included here.
        local velocityElapsed = math.max(elapsed, 300)
        self.session.velocityGoldPerHour = (tonumber(self.session.income) or 0) / (velocityElapsed / 3600)
    end

    self.lastObservedWarbandGold = warbandGold
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.faction = GetFaction()
    character.gold = money
    character.lastSeen = WallTime()
end

function Ledger:SetTransactionContext(source, duration, data)
    self._transactionContext = {
        source = source,
        untilAt = Now() + (tonumber(duration) or TRANSACTION_CONTEXT_WINDOW),
        data = type(data) == "table" and data or nil,
    }
end

function Ledger:ClearTransactionContext(source)
    if not self._transactionContext then return end
    if not source or self._transactionContext.source == source then
        self._transactionContext = nil
    end
end

function Ledger:BeginTradeTracking()
    local snapshot = {
        startedAt = WallTime(),
        targetName = type(UnitName) == "function" and UnitName("NPC") or nil,
        playerMoney = type(GetPlayerTradeMoney) == "function" and (tonumber(GetPlayerTradeMoney()) or 0) or 0,
        targetMoney = type(GetTargetTradeMoney) == "function" and (tonumber(GetTargetTradeMoney()) or 0) or 0,
        playerItems = {},
        targetItems = {},
    }

    if type(GetTradePlayerItemInfo) == "function" and type(GetTradePlayerItemLink) == "function" then
        for i = 1, 7 do
            local name, texture, quantity = GetTradePlayerItemInfo(i)
            local link = GetTradePlayerItemLink(i)
            if name or link then
                snapshot.playerItems[#snapshot.playerItems + 1] = {
                    slot = i, name = name, link = link, quantity = tonumber(quantity) or 1,
                }
            end
        end
    end
    if type(GetTradeTargetItemInfo) == "function" and type(GetTradeTargetItemLink) == "function" then
        for i = 1, 7 do
            local name, texture, quantity = GetTradeTargetItemInfo(i)
            local link = GetTradeTargetItemLink(i)
            if name or link then
                snapshot.targetItems[#snapshot.targetItems + 1] = {
                    slot = i, name = name, link = link, quantity = tonumber(quantity) or 1,
                }
            end
        end
    end

    self._tradeSnapshot = snapshot
    return snapshot
end

function Ledger:EndTradeTracking()
    local snapshot = self._tradeSnapshot
    self._tradeSnapshot = nil
    return snapshot
end

function Ledger:GetTradeTransaction(delta)
    local snapshot = self._tradeSnapshot
    snapshot = snapshot or self._lastTradeSnapshot
    if type(snapshot) ~= "table" or delta == 0 then return nil end
    local target = snapshot.targetName
    local incoming = delta > 0
    return {
        targetName = target,
        playerMoney = snapshot.playerMoney,
        targetMoney = snapshot.targetMoney,
        playerItems = snapshot.playerItems,
        targetItems = snapshot.targetItems,
        direction = incoming and "received" or "paid",
    }
end

function Ledger:QueueAuctionSale(amount, itemID, quantity, auctionID)
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    self._pendingAuctionSales = self._pendingAuctionSales or {}
    self._pendingAuctionSales[#self._pendingAuctionSales + 1] = {
        amount = amount,
        itemID = tonumber(itemID),
        quantity = tonumber(quantity) or 1,
        auctionID = tonumber(auctionID),
        queuedAt = WallTime(),
    }
    while #self._pendingAuctionSales > 50 do table.remove(self._pendingAuctionSales, 1) end
    return true
end

function Ledger:ConsumePendingAuctionSales(delta)
    if delta <= 0 or type(self._pendingAuctionSales) ~= "table" then return nil end
    local now = WallTime()
    local candidates = {}
    for i, sale in ipairs(self._pendingAuctionSales) do
        local age = now - (tonumber(sale.queuedAt) or now)
        if age <= 7 * 86400 and (tonumber(sale.amount) or 0) > 0 then
            candidates[#candidates + 1] = { index = i, sale = sale }
        end
    end
    if #candidates == 0 then return nil end

    -- Prefer a single exact/near-exact sale first.
    local bestIndex, best, bestDifference = nil, nil, nil
    for _, candidate in ipairs(candidates) do
        local amount = tonumber(candidate.sale.amount) or 0
        local difference = math.abs(amount - delta)
        if not bestDifference or difference < bestDifference then
            bestIndex, best, bestDifference = candidate.index, candidate.sale, difference
        end
    end
    local tolerance = math.max(1, math.floor((tonumber(best.amount) or 0) * 0.10))
    if bestDifference <= tolerance then
        table.remove(self._pendingAuctionSales, bestIndex)
        best.matchedSales = { best }
        best.matchedAmount = best.amount
        best.matchConfidence = bestDifference == 0 and "exact" or "close"
        return best
    end

    -- Mailbox collection can combine several auction proceeds into one wallet
    -- change. Find a small combination whose gross proceeds are close to the
    -- observed delta (auction house cut explains a modest shortfall).
    table.sort(candidates, function(a, b)
        return (tonumber(a.sale.queuedAt) or 0) < (tonumber(b.sale.queuedAt) or 0)
    end)
    local chosen, sum = {}, 0
    for _, candidate in ipairs(candidates) do
        if #chosen >= 8 then break end
        local amount = tonumber(candidate.sale.amount) or 0
        if sum + amount <= delta * 1.15 or #chosen == 0 then
            chosen[#chosen + 1] = candidate
            sum = sum + amount
        end
        if sum >= delta * 0.90 then break end
    end
    if #chosen == 0 then return nil end
    local comboTolerance = math.max(1, math.floor(sum * 0.10))
    if math.abs(sum - delta) > comboTolerance then return nil end

    table.sort(chosen, function(a, b) return a.index > b.index end)
    local matched = {}
    for _, candidate in ipairs(chosen) do
        matched[#matched + 1] = candidate.sale
        table.remove(self._pendingAuctionSales, candidate.index)
    end
    return {
        amount = delta,
        itemID = (#matched == 1) and matched[1].itemID or nil,
        quantity = (#matched == 1) and matched[1].quantity or nil,
        auctionID = (#matched == 1) and matched[1].auctionID or nil,
        matchedSales = matched,
        matchedAmount = sum,
        matchConfidence = "combined",
    }
end

-- Backward-compatible singular helper for any existing callers.
function Ledger:ConsumePendingAuctionSale(delta)
    return self:ConsumePendingAuctionSales(delta)
end

function Ledger:GetTransactionSource(delta)
    delta = tonumber(delta) or 0
    local now = Now()

    local pendingSale = self:ConsumePendingAuctionSales(delta)
    if pendingSale then
        return "Auction House Sale", pendingSale
    end

    if IsFrameShown(MerchantFrame) then
        return delta > 0 and "Vendor Sale" or "Vendor Purchase"
    end

    if IsFrameShown(MailFrame) then
        -- Auction proceeds are often collected from mailbox after the sold
        -- auction was observed. Prefer the explicit auction classification when
        -- a pending sale exists; otherwise identify ordinary incoming mail.
        local mailState = GoldMint.MailTracking and GoldMint.MailTracking.GetState
            and GoldMint.MailTracking:GetState() or nil
        if mailState and delta > 0 and type(mailState.messages) == "table" then
            local best, bestDiff
            for _, message in ipairs(mailState.messages) do
                local amount = tonumber(message.money) or 0
                if amount > 0 then
                    local diff = math.abs(amount - delta)
                    if not bestDiff or diff < bestDiff then
                        best, bestDiff = message, diff
                    end
                end
            end
            if best then
                local tolerance = math.max(1, math.floor((tonumber(best.money) or 0) * 0.05))
                if bestDiff <= tolerance then
                    return best.auctionHouse and "Auction House Mail" or "Mail Received", {
                        mailID = best.id, sender = best.sender, subject = best.subject,
                        invoiceType = best.invoiceType, confidence = bestDiff == 0 and "exact" or "close",
                    }
                end
            end
        end
        if mailState and (tonumber(mailState.auctionMoneyTotal) or 0) > 0 and delta > 0 then
            return "Auction House Mail"
        end
        if delta > 0 then return "Mail Received" end
        return "Mail Payment / COD"
    end

    if IsFrameShown(TradeFrame) or IsFrameShown(TradeFrameManager) or self._tradeSnapshot then
        local tradeData = self:GetTradeTransaction(delta)
        if tradeData then
            return delta > 0 and "Trade Received" or "Trade Payment", tradeData
        end
        return delta > 0 and "Trade Received" or "Trade Payment"
    end

    if C_AuctionHouse and type(C_AuctionHouse.IsSellItem) == "function" then
        -- No reliable public API identifies every AH fee/purchase transaction,
        -- so use the known AH lifecycle below instead of guessing here.
    end

    local context = self._transactionContext
    if context and now <= (tonumber(context.untilAt) or 0) then
        return context.source, context.data
    end
    if context then self._transactionContext = nil end

    -- The loot window can still be open when PLAYER_MONEY fires. This is more
    -- reliable than relying solely on LOOT_OPENED ordering.
    if delta > 0 and GetNumLootItems and GetLootSlotType and LOOT_SLOT_MONEY then
        local slots = tonumber(GetNumLootItems()) or 0
        for i = 1, slots do
            if GetLootSlotType(i) == LOOT_SLOT_MONEY then
                return "Looted Gold"
            end
        end
    end

    -- A positive unclassified wallet change can still be useful as income.
    -- A negative unclassified change is deliberately kept out of economics;
    -- it is a wallet-change diagnostic rather than confirmed spending.
    return delta > 0 and "Other Income" or "Unclassified Wallet Change"
end

function Ledger:BeginSession()
    local now = Now()
    local money = self:GetMoney()

    local goldMakingGuild = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
    local inGoldMakingGuild = goldMakingGuild and GoldMint.IsCharacterInGoldMakingGuild
        and GoldMint:IsCharacterInGoldMakingGuild(GoldMint.characterKey) or false

    self.session = {
        startedAt = now,
        startedAtWall = WallTime(),
        startingGold = money,
        lastGold = money,
        endingGold = money,
        netGold = 0,
        income = 0,
        spending = 0,
        goldPerHour = 0,
        velocityGoldPerHour = 0,
        transactions = {},
        trendPoints = {},
        transferIn = 0,
        transferOut = 0,
        sourceTotals = {},
        goldMakingGuild = goldMakingGuild,
        goldMakingGuildActive = inGoldMakingGuild,
    }
    self._transactionContext = nil
    self._pendingAuctionSales = self._pendingAuctionSales or {}
    self:EnsureDailyLedger()

    -- Baseline the shared Warbank so character <-> Warbank moves can be
    -- recognized as internal transfers instead of income or spending.
    self.lastObservedWarbandGold = self:GetWarbandGold()
    self:UpdateCharacterGold()
end


function Ledger:RecordTrendEvent(reason, gold)
    if not self.session then
        return false
    end

    gold = math.floor(tonumber(gold) or self:GetMoney())
    local points = self.session.trendPoints
    if type(points) ~= "table" then
        points = {}
        self.session.trendPoints = points
    end

    local last = points[#points]
    if last and tonumber(last.gold) == gold and (Now() - (tonumber(last.time) or 0)) < 0.5 then
        return false
    end

    points[#points + 1] = {
        time = Now(),
        wallTime = WallTime(),
        gold = gold,
        reason = reason or "gold income",
    }

    while #points > 100 do
        table.remove(points, 1)
    end
    return true
end

function Ledger:GetTrendPoints()
    if not self.session then
        return {}
    end
    return self.session.trendPoints or {}
end

function Ledger:BeginMerchantTrendContext()
    self._merchantTrendGold = self:GetMoney()
end

function Ledger:EndMerchantTrendContext()
    local before = self._merchantTrendGold
    self._merchantTrendGold = nil
    if before == nil then
        return false
    end
    local nowGold = self:GetMoney()
    if nowGold > before then
        return self:RecordTrendEvent("Sold to vendor", nowGold)
    end
    return false
end

function Ledger:RecordLootGoldTrend()
    local ok = self:RecordTrendEvent("Looted gold", self:GetMoney())
    return ok
end

function Ledger:RecordTransaction(delta)
    if not self.session or delta == 0 then
        return
    end

    local source, sourceData = self:GetTransactionSource(delta)
    local confirmedSpending = delta >= 0 or IsConfirmedSpendingSource(source)
    local transaction = {
        time = WallTime(),
        elapsed = Now() - self.session.startedAt,
        amount = delta,
        type = delta > 0 and "income" or (confirmedSpending and "spending" or "unclassified"),
        source = source or (delta > 0 and "Other Income" or "Unclassified Wallet Change"),
        itemID = sourceData and sourceData.itemID or nil,
        quantity = sourceData and sourceData.quantity or nil,
        auctionID = sourceData and sourceData.auctionID or nil,
        targetName = sourceData and sourceData.targetName or nil,
        playerMoney = sourceData and sourceData.playerMoney or nil,
        targetMoney = sourceData and sourceData.targetMoney or nil,
        playerItems = sourceData and sourceData.playerItems or nil,
        targetItems = sourceData and sourceData.targetItems or nil,
    }

    table.insert(self.session.transactions, transaction)

    -- Keep source-level economics alongside the session totals.  This makes
    -- Session Velocity traceable to real classified transactions instead of
    -- relying on a generic wallet delta for the visual trend.
    local sourceKey = transaction.source or (delta > 0 and "Other Income" or "Unclassified Wallet Change")
    self.session.sourceTotals = self.session.sourceTotals or {}
    local bucket = self.session.sourceTotals[sourceKey]
    if type(bucket) ~= "table" then
        bucket = { income = 0, spending = 0, net = 0, count = 0 }
        self.session.sourceTotals[sourceKey] = bucket
    end
    bucket.count = (tonumber(bucket.count) or 0) + 1
    if delta > 0 then
        self.session.income = self.session.income + delta
        bucket.income = (tonumber(bucket.income) or 0) + delta
        bucket.net = (tonumber(bucket.net) or 0) + delta
    elseif confirmedSpending then
        local spend = math.abs(delta)
        self.session.spending = self.session.spending + spend
        bucket.spending = (tonumber(bucket.spending) or 0) + spend
        bucket.net = (tonumber(bucket.net) or 0) - spend
    end

    -- Persist only confirmed economics. An unidentified negative PLAYER_MONEY
    -- change remains visible in the session transaction log for diagnosis but
    -- cannot reduce Daily Profit.
    if delta > 0 or confirmedSpending then
        self:RecordDailyTransaction(delta, confirmedSpending)
    end

    while #self.session.transactions > MAX_TRANSACTIONS_PER_SESSION do
        table.remove(self.session.transactions, 1)
    end
end

function Ledger:GetSessionSourceTotals()
    if not self.session then return {} end
    return self.session.sourceTotals or {}
end

function Ledger:GetSessionSourceRate(source)
    if not self.session then return 0 end
    local bucket = (self.session.sourceTotals or {})[source]
    if type(bucket) ~= "table" then return 0 end
    local elapsed = math.max(Now() - (tonumber(self.session.startedAt) or Now()), 0.001)
    return ((tonumber(bucket.net) or 0) / (elapsed / 3600))
end

function Ledger:GetSession()
    self:UpdateCharacterGold()
    return self.session
end

function Ledger:GetKnownAccountGold()
    return self:GetAccountWallet().totalGold
end

-- Returns only the characters that belong to the user-selected Gold-Making Guild.
-- Warbank gold is intentionally excluded because it is account-wide and cannot
-- be attributed to a single guild without inventing ownership.
function Ledger:GetGoldMakingGuildWallet()
    local selected = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil
    local result = {
        selected = selected,
        characterCount = 0,
        personalGold = 0,
        characters = {},
        updatedAt = WallTime(),
    }

    if not selected or not GoldMintDB or type(GoldMintDB.characters) ~= "table" then
        return result
    end

    for key, character in pairs(GoldMintDB.characters) do
        if type(character) == "table" and (character.name or character.realm) and GoldMint.IsCharacterInGoldMakingGuild
            and GoldMint:IsCharacterInGoldMakingGuild(key) then
            local gold = tonumber(character.gold) or 0
            result.characterCount = result.characterCount + 1
            result.personalGold = result.personalGold + gold
            result.characters[#result.characters + 1] = {
                key = key,
                name = character.name or key,
                realm = character.realm or "Unknown",
                faction = character.faction or "Unknown",
                gold = gold,
                lastSeen = tonumber(character.lastSeen) or 0,
            }
        end
    end

    table.sort(result.characters, function(a, b)
        if a.gold ~= b.gold then return a.gold > b.gold end
        return string.lower(a.name) < string.lower(b.name)
    end)

    return result
end

function Ledger:GetAccountWallet()
    local characters = {}
    local personalTotal = 0

    for key, character in pairs(GoldMintDB.characters or {}) do
        local gold = tonumber(character.gold) or 0
        personalTotal = personalTotal + gold

        characters[#characters + 1] = {
            key = key,
            name = character.name or key,
            realm = character.realm or "Unknown",
            faction = character.faction or "Unknown",
            gold = gold,
            lastSeen = tonumber(character.lastSeen) or 0,
        }
    end

    table.sort(characters, function(a, b)
        if a.gold ~= b.gold then
            return a.gold > b.gold
        end
        return a.name < b.name
    end)

    -- Warband bank gold is shared. It is therefore added exactly once to the
    -- account total rather than being attached to every character record.
    -- The Warband balance is shared across the account and already cached by
    -- UpdateWarbandGold(). Never trigger another bank fetch while building the
    -- wallet; this keeps repeated dashboard refreshes from double-counting or
    -- observing transitional bank values.
    local warbandGold = tonumber(GoldMintDB and GoldMintDB.warbandGold) or 0
    local total = personalTotal + warbandGold

    return {
        totalGold = total,
        personalGold = personalTotal,
        warbandGold = warbandGold,
        characters = characters,
        updatedAt = WallTime(),
    }
end

function Ledger:FormatGold(copper)
    copper = tonumber(copper) or 0
    if copper ~= copper then copper = 0 end

    local sign = copper < 0 and "-" or ""
    copper = math.floor(math.abs(copper) + 0.5)

    local gold = math.floor(copper / 10000)
    local silver = math.floor((copper % 10000) / 100)
    local c = copper % 100

    if gold > 0 then
        if silver > 0 or c > 0 then
            return string.format("%s%dg %02ds %02dc", sign, gold, silver, c)
        end
        return string.format("%s%dg", sign, gold)
    elseif silver > 0 then
        if c > 0 then
            return string.format("%s%ds %02dc", sign, silver, c)
        end
        return string.format("%s%ds", sign, silver)
    end

    return string.format("%s%dc", sign, c)
end

function Ledger:FormatRate(copperPerHour)
    copperPerHour = tonumber(copperPerHour) or 0
    if copperPerHour ~= copperPerHour then copperPerHour = 0 end

    local sign = copperPerHour < 0 and "-" or ""
    local amount = math.floor(math.abs(copperPerHour) + 0.5)

    if amount >= 10000 then
        return sign .. self:FormatGold(amount)
    elseif amount >= 100 then
        return string.format("%s%ds %02dc", sign, math.floor(amount / 100), amount % 100)
    end

    return string.format("%s%dc", sign, amount)
end

function Ledger:FormatGoldFull(copper)
    return GetMoneyString(math.floor(tonumber(copper) or 0), true)
end

function Ledger:EndSession()
    if not self.session then
        return
    end

    self:UpdateCharacterGold()

    GoldMintDB.sessions = type(GoldMintDB.sessions) == "table" and GoldMintDB.sessions or {}
    table.insert(GoldMintDB.sessions, {
        startedAt = self.session.startedAt,
        startedAtWall = self.session.startedAtWall,
        endedAt = WallTime(),
        startingGold = self.session.startingGold,
        endingGold = self.session.endingGold,
        netGold = self.session.netGold,
        income = self.session.income,
        spending = self.session.spending,
        goldPerHour = self.session.goldPerHour,
        velocityGoldPerHour = self.session.velocityGoldPerHour or 0,
        transferIn = self.session.transferIn or 0,
        transferOut = self.session.transferOut or 0,
        goldMakingGuild = self.session.goldMakingGuild,
        goldMakingGuildActive = self.session.goldMakingGuildActive == true,
        transactions = self.session.transactions,
        sourceTotals = self.session.sourceTotals or {},
        trendPoints = self.session.trendPoints or {},
    })

    while #GoldMintDB.sessions > MAX_SAVED_SESSIONS do
        table.remove(GoldMintDB.sessions, 1)
    end

    self.session = nil
end
