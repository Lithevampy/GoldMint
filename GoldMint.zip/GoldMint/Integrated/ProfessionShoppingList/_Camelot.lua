local appName = "GoldMint"
local app = _G.GoldMint

app.Retail = false
app.Forever = true
