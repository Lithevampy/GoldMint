----------------------------------------
-- Profession Shopping List: esMX.lua --
----------------------------------------
-- Spanish (Mexico) localisation
-- Translator(s): Ferran Carril

if GetLocale() ~= "esMX" then return end
local appName = "GoldMint"
local app = _G.GoldMint
local L = app.locales

-- Main window
-- L.WINDOW_BUTTON_CLOSE =                  "Close the window"
-- L.WINDOW_BUTTON_LOCK =                   "Lock the window"
-- L.WINDOW_BUTTON_UNLOCK =                 "Unlock the window"
-- L.WINDOW_BUTTON_SETTINGS =               "Open the settings"
-- L.WINDOW_BUTTON_CLEAR =                  "Clear all tracked recipes"
-- L.WINDOW_BUTTON_AUCTIONATOR =            "Update the Auctionator shopping list\n" ..
--                                          "The shopping list is automatically generated when opening the Auction House"
-- L.WINDOW_BUTTON_CORNER =                 "Double " .. app.IconLMB .. "|cffFFFFFF: Autosize to fit the window|r"

-- L.WINDOW_HEADER_RECIPES =                PROFESSIONS_RECIPES_TAB -- "Recipes"
-- L.WINDOW_HEADER_ITEMS =                  ITEMS -- "Items"
-- L.WINDOW_HEADER_REAGENTS =               PROFESSIONS_COLUMN_HEADER_REAGENTS -- "Reagents"
-- L.WINDOW_HEADER_COSTS =                  "Costs"
-- L.WINDOW_HEADER_COOLDOWNS =              "Cooldowns"

-- L.WINDOW_TOOLTIP_RECIPES =               "Shift " .. app.IconLMB .. "|cffFFFFFF: Link the recipe\n|r" ..
--                                          "Ctrl " .. app.IconLMB .. "|cffFFFFFF: Open the recipe (if known)\n|r" ..
--                                          "Alt " .. app.IconLMB .. "|cffFFFFFF: Attempt to craft this recipe\n\n|r" ..
--                                          app.IconRMB .. "|cffFFFFFF: Untrack 1 of the selected recipe\n|r" ..
--                                          "Ctrl " .. app.IconRMB .. "|cffFFFFFF: Untrack all of the selected recipe"
-- L.WINDOW_TOOLTIP_REAGENTS =              "Shift " .. app.IconLMB .. "|cffFFFFFF: Link the reagent\n|r" ..
--                                          "Ctrl " .. app.IconLMB .. "|cffFFFFFF: Add recipe for the selected subreagent, if it exists and is cached"
-- L.WINDOW_TOOLTIP_COOLDOWNS =             "Shift " .. app.IconRMB .. "|cffFFFFFF: Remove this specific cooldown reminder\n|r" ..
--                                          "Ctrl " .. app.IconLMB .. "|cffFFFFFF: Open the recipe (if known)\n|r" ..
--                                          "Alt " .. app.IconLMB .. "|cffFFFFFF: Attempt to craft this recipe"

-- L.CLEAR_CONFIRMATION =                   "This will clear all recipes."
-- L.CONFIRMATION =                         "Do you wish to proceed?"
-- L.SUBREAGENTS1 =                         "There are multiple recipes that can create" -- Followed by an item link
-- L.SUBREAGENTS2 =                         "Please select one of the following"
-- L.GOLD =                                 BONUS_ROLL_REWARD_MONEY -- "Gold"
-- L.MERCHANT_BUY =                         "Let " .. app.NameShort .. " buy the tracked " .. L.WINDOW_HEADER_REAGENTS .. " and " .. L.WINDOW_HEADER_COSTS .. "\nyou need from this merchant, if available."

-- Cooldowns
-- L.RECHARGED =                            "Fully recharged"
-- L.READY =                                "Ready"
-- L.DAYS =                                 "d"
-- L.HOURS =                                "h"
-- L.MINUTES =                              "m"
-- L.READY_TO_CRAFT =                       "is ready to craft again on" -- Preceded by a recipe name, followed by a character name

-- -- Recipe tracking
-- L.TRACK =                                "Track"
-- L.UNTRACK =                              "Untrack"
-- L.RANK =                                 RANK -- "Rank"
-- L.RECRAFT_TOOLTIP =                      "Select an item with a cached recipe to track it.\n" ..
--                                          "To cache a recipe, open the profession the recipe belongs to on any character\nor view the item as a regular crafting order."
-- L.QUICKORDER =                           "Quick Order"
-- L.QUICKORDER_TOOLTIP =                   "|cffFF0000Instantly|r create a crafting order for the specified recipient.\n\n" ..
--                                          "Use |cffFFFFFFGUILD|r (all uppercase) to place a " .. PROFESSIONS_CRAFTING_FORM_ORDER_RECIPIENT_GUILD .. ".\n" .. -- "Guild Order". Don't translate "|cffFFFFFFGUILD|r" as this is hardcoded
--                                          "Use a character name to place a " .. PROFESSIONS_CRAFTING_FORM_ORDER_RECIPIENT_PRIVATE .. ".\n" .. -- "Personal Order"
--                                          "Recipients are saved per recipe."
-- L.LOCALREAGENTS_LABEL =                  "Use local reagents"
-- L.LOCALREAGENTS_TOOLTIP =                "Use (the lowest quality) available local reagents. Which reagents are used |cffFF0000cannot|r be customised."
-- L.QUICKORDER_REPEAT_TOOLTIP =            "Repeat the last " .. L.QUICKORDER .. " done on this character"
-- L.RECIPIENT =                            "Recipient"

-- Profession window
-- L.MILLING_INFO =                         "Milling Information"
-- L.THAUMATURGY_INFO =                     "Thaumaturgy Information"
-- L.FROM =                                 "from" -- I will convert this whole section to item links, then this is the only localisation needed. I recommend skipping the rest of this section. :)

-- L.MILLING_CLASSIC =                      "Sapphire Pigment: 25% from Golden Sansam, Dreamfoil, Mountain Silversage, Sorrowmoss, Icecap\n" ..
--                                          "Silvery Pigment: 75% from Golden Sansam, Dreamfoil, Mountain Silversage, Sorrowmoss, Icecap\n\n" ..
--                                          "Ruby Pigment: 25% from Firebloom, Purple Lotus, Arthas' Tears, Sungrass, Blindweed,\n      Ghost Mushroom, Gromsblood\n" ..
--                                          "Violet Pigment: 75% from Firebloom, Purple Lotus, Arthas' Tears, Sungrass, Blindweed,\n      Ghost Mushroom, Gromsblood\n\n" ..
--                                          "Indigo Pigment: 25% from Fadeleaf, Goldthorn, Khadgar's Whisker, Dragon's Teeth\n" ..
--                                          "Emerald Pigment: 75% from Fadeleaf, Goldthorn, Khadgar's Whisker, Dragon's Teeth\n\n" ..
--                                          "Burnt Pigment: 25% from Wild Steelbloom, Grave Moss, Kingsblood, Liferoot\n" ..
--                                          "Golden Pigment: 75% from Wild Steelbloom, Grave Moss, Kingsblood, Liferoot\n\n" ..
--                                          "Verdant Pigment: 25% from Mageroyal, Briarthorn, Swiftthistle, Bruiseweed, Stranglekelp\n" ..
--                                          "Dusky Pigment: 75% from Mageroyal, Briarthorn, Swiftthistle, Bruiseweed, Stranglekelp\n\n" ..
--                                          "Alabaster Pigment: 100% from Peacebloom, Silverleaf, Earthroot"
-- L.MILLING_TBC =                          "Ebon Pigment: 25%\n" ..
--                                          "Nether Pigment: 100%"
-- L.MILLING_WOTLK =                        "Icy Pigment: 25%\n" ..
--                                          "Azure Pigment: 100%"
-- L.MILLING_CATA =                         "Burning Embers: 25%, 50% from Twilight Jasmine, Whiptail\n" ..
--                                          "Ashen Pigment: 100%"
-- L.MILLING_MOP =                          "Misty Pigment: 25%, 50% from Fool's Cap\n" ..
--                                          "Shadow Pigment: 100%"
-- L.MILLING_WOD =                          "Cerulean Pigment: 100%"
-- L.MILLING_LEGION =                       "Sallow Pigment: 10%, 80% from Felwort\n" ..
--                                          "Roseate Pigment: 90%"
-- L.MILLING_BFA =                          "Viridescent Pigment: 10%, 30% from Anchor Weed\n" ..
--                                          "Crimson Pigment: 25%\n" ..
--                                          "Ultramarine Pigment: 75%"
-- L.MILLING_SL =                           "Tranquil Pigment: Nightshade\n" ..
--                                          "Luminous Pigment: Death Blossom, Rising Glory, Vigil's Torch\n" ..
--                                          "Umbral Pigment: Death's Blossom, Marrowroot, Widowbloom"
-- L.MILLING_DF =                           "Blazing Pigment: Saxifrage\n" ..
--                                          "Flourishing Pigment: Writhebark\n" ..
--                                          "Serene Pigment: Bubble Poppy\n" ..
--                                          "Shimmering Pigment: Hochenblume"
-- L.MILLING_TWW =                          "Blossom Pigment: Blessing Blossom\n" ..
--                                          "Luredrop Pigment: Luredrop\n" ..
--                                          "Orbinid Pigment: Orbinid\n" ..
--                                          "Nacreous Pigment: Mycobloom"
-- L.THAUMATURGY_TWW =                      "Mercurial Transmutagen: Aqirite, Gloom Chitin, Luredrop, Orbinid\n" ..
--                                          "Ominous Transmutagen: Bismuth, Mycobloom, Storm Dust, Weavercloth\n" ..
--                                          "Volatile Transmutagen: Arathor's Spear, Blessing Blossom, Ironclaw Ore, Stormcharged Leather"

-- L.BUTTON_COOKINGFIRE =                   app.IconLMB .. ": " .. BINDING_NAME_TARGETSELF .. "\n" .. -- "Target Self"
--                                          app.IconRMB .. ": " .. STATUS_TEXT_TARGET -- "Target"
-- L.BUTTON_COOKINGPET =                    app.IconLMB .. ": Summon this pet\n" ..
--                                          app.IconRMB .. ": Switch between available pets"
-- L.BUTTON_CHEFSHAT =                      app.IconLMB .. ": Use the"
-- L.BUTTON_THERMALANVIL =                  app.IconLMB .. ": Use a"
-- L.BUTTON_ALVIN =                         app.IconLMB .. ": Summon this pet"
-- L.BUTTON_LIGHTFORGE =                    app.IconLMB .. ": Cast"

-- Track new mogs
-- L.BUTTON_TRACKNEW =                      "Track New Mogs"
-- L.CURRENT_SETTING =                      "Current setting:"
-- L.MODE_APPEARANCES =                     "new appearances"
-- L.MODE_SOURCES =                         "new appearances and sources"
-- L.ADDED_RECIPES =                        "Checked %d visible recipes for %s. Tracked %d recipes." -- %d becomes a number, %s becomes L.MODE_APPEARANCES or L.MODE_SOURCES

-- Tooltip info
-- L.MORE_NEEDED =                          "more needed" -- Preceded by a number
-- L.MADE_WITH =                            "Made with" -- Followed by a profession name such as "Blacksmithing" or "Leatherworking"
-- L.RECIPE_LEARNED =                       "recipe learned"
-- L.RECIPE_UNLEARNED =                     "recipe not learned"
-- L.CRAFTING_COST =                        "Crafting Cost"

-- Profession knowledge
-- L.PERKS_UNLOCKED =                       "perks unlocked"
-- L.PROFESSION_KNOWLEDGE =                 "knowledge"
-- L.VENDORS =                              "Vendors"
-- L.RENOWN =                               COVENANT_SANCTUM_TAB_RENOWN -- "Renown "
-- L.WORLD =                                "World"
-- L.HIDDEN_PROFESSION_MASTER =             "Hidden Profession Master"
-- L.WEEKLY =                               WEEKLY -- "Weekly"
-- L.TREASURE =                             "Treasure"
-- L.DROP =                                 BATTLE_PET_SOURCE_1 -- "Drop"
-- L.CATCHUP_KNOWLEDGE =                    "Available catch-up knowledge:"
-- L.LOADING =                              SEARCH_LOADING_TEXT -- "Loading..."

-- Order adjustments
-- L.AUCTION_ADDONS =                       "Auctionator, Oribos Exchange, or TradeSkillMaster"
-- L.ORDERS_PRICING_MISSING =               "Missing"
-- L.ORDERS_PRICING_UPDATE =                "Update or scan with %s." -- %s becomes a list of addon names
-- L.ORDERS_SET_CRITERIA =                  "Set the criteria to track orders."
-- L.ORDERS_COST_NEED =                     "Cost settings only work with: %s." -- %s becomes a list of addon names
-- L.ORDERS_MAX_COST_KNOWLEDGE =            "Maximum cost per knowledge point:"
-- L.ORDERS_MAX_COST_ARTISAN =              "Maximum cost per artisan currency:" -- This refers to Artisan's Mettle, Artisan's Acuity, and Artisan's Moxie
-- L.ORDERS_MAX_COST_PAYOUT =               "Maximum cost per reward bag:" -- This refers to Artisan's Payout bag
-- L.ORDERS_TRACK_AFTER_RESET =             "Track orders available after weekly reset"
-- L.ORDERS_TRACK_CONCENTRATION =           "Track orders costing concentration:"
-- L.ORDERS_TRACK_ON =                      "Track on %s:"  -- %s becomes a character name

-- L.ORDERSQUEUE_QUEUE =                    "Queue"
-- L.ORDERSQUEUE_QUEUE =                    "Orders in queue:"
-- L.ORDERSQUEUE_NEXT =                     "Next Order"
-- L.ORDERSQUEUE_CLAIM =                    "Claim Order"
-- L.ORDERSQUEUE_CRAFT =                    "Craft Order"
-- L.ORDERSQUEUE_CRAFTING =                 "Crafting..."
-- L.ORDERSQUEUE_COMPLETE =                 PROFESSIONS_COMPLETE_ORDER -- "Complete Order"
-- L.ORDERSQUEUE_WARNING_QUEST =            "You have not picked up %s." -- %s becomes a quest name
-- L.ORDERSQUEUE_WARNING_REAGENTS =         "You do not have enough reagents for all tracked recipes."

-- L.PROFTOOL_AUTOEQUIP =                   "Automatically equip this tool" -- Followed by one of the two following phrases
-- L.PROFTOOL_DEFAULT =                     "for |cffFFFFFFregular crafting|R."
-- L.PROFTOOL_ORDERS =                      "while |cffFFFFFFdoing orders|R."
-- L.PROFTOOL_DRAG =                        "Drag a tool here."
-- L.PROFTOOL_MOUSE =                       app.IconLMB .. ": Equip this tool.\n" ..
--                                          app.IconRMB .. ": Remove this tool."

-- Chat feedback
-- L.INVALID_PARAMETERS =                   "Invalid parameters."
-- L.INVALID_RECIPEQUANTITY =               L.INVALID_PARAMETERS .. " Please enter a valid recipe quantity."
-- L.INVALID_RECIPEID =                     L.INVALID_PARAMETERS .. " Please enter a cached recipeID."
-- L.INVALID_RECIPE_TRACKED =               L.INVALID_PARAMETERS .. " Please enter a tracked recipeID."
-- L.INVALID_ACHIEVEMENT =                  L.INVALID_PARAMETERS .. " This is not a crafting achievement. No recipes were added."
-- L.INVALID_RESET_ARG =                    L.INVALID_PARAMETERS .. " You can use the following arguments:"
-- L.INVALID_COMMAND =                      "Invalid command. See " .. app:Colour("/psl settings") .. " for more info."
-- L.DEBUG_ENABLED =                        "Debug mode enabled."
-- L.DEBUG_DISABLED =                       "Debug mode disabled."
-- L.RESET_DONE =                           "Data reset performed successfully."
-- L.REQUIRES_RELOAD =                      "|cffFF0000" .. REQUIRES_RELOAD .. ".|r Use |cffFFFFFF/reload|r or relog." -- "Requires Reload"

-- L.FALSE =                                "false"
-- L.TRUE =                                 "true"
-- L.NOLASTORDER =                          "No last " .. L.QUICKORDER .. " found"
-- L.ERROR =                                "Error"
-- L.ERROR_CRAFTSIM =                       L.ERROR .. ": Could not read the information from CraftSim."
-- L.ERROR_QUICKORDER =                     L.ERROR .. ": " .. L.QUICKORDER .. " failed. Sorry. :("
-- L.ERROR_REAGENTS =                       L.ERROR .. ": Can't create a " .. L.QUICKORDER .. " for items with mandatory reagents. Sorry. :("
-- L.ERROR_WARBANK =                        L.ERROR .. ": Can't create a " .. L.QUICKORDER .. " with items in the Warbank."
-- L.ERROR_GUILD =                          L.ERROR .. ": Can't create a " .. PROFESSIONS_CRAFTING_FORM_ORDER_RECIPIENT_GUILD .. " while not in a guild." -- "Guild Order"
-- L.ERROR_RECIPIENT =                      L.ERROR .. ": Target recipient cannot craft that item. Please enter a valid recipient name."
-- L.ERROR_MULTISIM =                       L.ERROR .. ": No simulated reagents have been used. Please only enable one of the following supported addons:"

-- L.NEW_VERSION_AVAILABLE =                "There is a newer version of " .. app.NameLong .. " available:"

-- Settings
-- L.SETTINGS_TOOLTIP =                     app.NameLong .. "\n|cffFFFFFF" ..
--                                          app.IconLMB .. ": Toggle the window\n" ..
--                                          app.IconRMB .. ": " .. L.WINDOW_BUTTON_SETTINGS

L.SETTINGS_VERSION =                     GAME_VERSION_LABEL .. ":" -- "Version"
L.SETTINGS_SUPPORT_TEXTLONG =            "Desarrollar este addon requiere una cantidad significativa de tiempo y esfuerzo.\nPor favor, considera apoyar financieramente al desarrollador."
L.SETTINGS_SUPPORT_TEXT =                "Apoyar"
L.SETTINGS_SUPPORT_BUTTON =              "Buy Me a Coffee" -- Brand name, if there isn't a localised version, keep it the way it is
L.SETTINGS_SUPPORT_DESC =                "¡Gracias!"
L.SETTINGS_HELP_TEXT =                   "Comentarios y Ayuda"
L.SETTINGS_HELP_BUTTON =                 "Discord" -- Brand name, if there isn't a localised version, keep it the way it is
L.SETTINGS_HELP_DESC =                   "Únete al servidor de Discord."
L.SETTINGS_URL_COPY =                    "Ctrl+C para copiar:"
L.SETTINGS_URL_COPIED =                  "Enlace copiado al portapapeles"

-- L.SETTINGS_KEYSLASH_TITLE =              SETTINGS_KEYBINDINGS_LABEL .. " & Slash Commands" -- "Keybindings"
-- _G["BINDING_NAME_PSL_TOGGLEWINDOW"] =    app.NameShort .. ": Toggle Window"
-- L.SETTINGS_SLASH_TOGGLE =                "Toggle the tracking window"
-- L.SETTINGS_SLASH_RESETPOS =              "Reset the tracking window position"
-- L.SETTINGS_SLASH_RESET =                 "Reset saved data"
-- L.SETTINGS_SLASH_TRACK =                 "Track a recipe"
-- L.SETTINGS_SLASH_UNTRACK =               "Untrack a recipe"
-- L.SETTINGS_SLASH_UNTRACKALL =            "Untrack all of a recipe"
-- L.SETTINGS_SLASH_TRACKACHIE =            "Track the recipes needed for the linked achievement"
-- L.SETTINGS_SLASH_CRAFTINGACHIE =         "crafting achievement"
-- L.SETTINGS_SLASH_RECIPEID =              "recipeID"
-- L.SETTINGS_SLASH_QUANTITY =              "quantity"
-- L.SETTINGS_SLASH_REAGENT =               "itemLink or itemID"
-- L.SETTINGS_SLASH_TRACKREAGENT =          "Track all recipes using this reagent"

-- L.GENERAL =                              GENERAL -- "General"
-- L.SETTINGS_MINIMAP_TITLE =               "Show Minimap Icon"
-- L.SETTINGS_MINIMAP_DESC =                "Show the minimap icon. If you disable this, " .. app.NameShort .. " is still available from the Addon Compartment."
-- L.SETTINGS_COOLDOWNS_TITLE =             "Track Recipe Cooldowns"
-- L.SETTINGS_COOLDOWNS_DESC =              "Enable the tracking of recipe cooldowns. These will show in the tracking window, and in chat upon login if ready."
-- L.SETTINGS_COOLDOWNSWINDOW_TITLE =       "Show Window When Ready"
-- L.SETTINGS_COOLDOWNSWINDOW_DESC =        "Open the tracking window on login when a cooldown is ready, in addition to the reminder via chat message."
-- L.SETTINGS_TOOLTIP_TITLE =               "Show Tooltip Information"
-- L.SETTINGS_TOOLTIP_DESC =                "Show how many of a reagent you have/need on the item's tooltip."
-- L.SETTINGS_CRAFTTOOLTIP_TITLE =          "Show Crafting Information"
-- L.SETTINGS_CRAFTTOOLTIP_DESC =           "Show with which profession a piece of gear is made, and if the recipe is known on your account."
-- L.SETTINGS_CRAFTCOSTTOOLTIP_TITLE =      "Show Crafting Cost"
-- L.SETTINGS_CRAFTCOSTTOOLTIP_DESC =       "Show how much an item costs to craft, if that information is available."
-- L.SETTINGS_REAGENTQUALITY_TITLE =        "Minimum Reagent Quality"
-- L.SETTINGS_REAGENTQUALITY_DESC =         "Set the minimum quality reagents need to be before " .. app.NameShort .. " includes them in the item count. Simulated results will still override this."
-- L.SETTINGS_INCLUDEHIGHER_TITLE =         "Include Higher Quality"
-- L.SETTINGS_INCLUDEHIGHER_DESC =          "Whether or not to count higher quality reagents. (I.e. include owned tier 2 reagents when counting tier 1 reagents.)"
-- L.SETTINGS_COLLECTMODE_TITLE =           "Collection Mode"
-- L.SETTINGS_COLLECTMODE_DESC =            "Set which items are included when using the " .. app:Colour(L.BUTTON_TRACKNEW) .. " button."

-- L.PROFESSION_WINDOW =                    "Profession Window"
-- L.SETTINGS_FILTER_OPTREAGENTS =          "Filter Optional Reagents"
-- L.SETTINGS_FILTER_OPTREAGENTS_DESC =     "When %s is checked for optional reagents, hide combinable items." -- %s becomes "Hide Unavailable"
-- L.SETTINGS_SPENDTOPERK_TITLE =           "Spend to Next Perk"
-- L.SETTINGS_SPENDTOPERK_DESC =            "Shift+clicking a profession knowledge node spends points until the next perk."
-- L.SETTINGS_ENHANCEDORDERS_TITLE =        "Enhanced Orders"
-- L.SETTINGS_ENHANCEDORDERS_DESC =         "Enhance the preview of order rewards and commission, and add icons for first crafts, unlearned recipes, and tracked recipes.\n\n" .. L.REQUIRES_RELOAD
-- L.SETTINGS_QUICKORDER_TITLE =            "Quick Order Duration"
-- L.SETTINGS_QUICKORDER_DESC =             "Set the duration for placing quick orders with " .. app.NameShort .. "."

-- L.LOW =                                  LOW -- "Low"
-- L.HIGH =                                 HIGH -- "High"
-- L.SETTINGS_INCLUDE =                     "Include higher qualities"
-- L.SETTINGS_DONT_INCLUDE =                "Don't include higher qualities"
-- L.SETTINGS_APPEARANCES_TITLE =           WARDROBE -- "Appearances"
-- L.SETTINGS_APPEARANCES_TEXT =            "Include items only if they have a new appearance."
-- L.SETTINGS_SOURCES_TITLE =               "Sources"
-- L.SETTINGS_SOURCES_TEXT =                "Include items if they are a new source, including for known appearances."
-- L.SETTINGS_DURATION_SHORT =              "Short (12 hours)"
-- L.SETTINGS_DURATION_MEDIUM =             "Medium (24 hours)"
-- L.SETTINGS_DURATION_LONG =               "Long (48 hours)"

-- L.SETTINGS_HEADER_TRACK =                "Tracking Window"
-- L.SETTINGS_HELPTOOLTIP_TITLE =           "Show Help Tooltips"
-- L.SETTINGS_HELPTOOLTIP_DESC =            "Display what mouse actions exist when hovering over entries in the tracking window."
-- L.SETTINGS_PERSONALWINDOWS_TITLE =       "Window Position per Character"
-- L.SETTINGS_PERSONALWINDOWS_DESC =        "Save the window position per character, instead of account wide."
-- L.SETTINGS_PERSONALRECIPES_TITLE =       "Track Recipes per Character"
-- L.SETTINGS_PERSONALRECIPES_DESC =        "Track recipes per character, instead of account wide."
-- L.SETTINGS_SHOWREMAINING_TITLE =         "Show Remaining Reagents"
-- L.SETTINGS_SHOWREMAINING_DESC =          "Only show how many reagents you still need in the tracking window, instead of have/need."
-- L.SETTINGS_REMOVECRAFT_TITLE =           "Untrack on Craft"
-- L.SETTINGS_REMOVECRAFT_DESC =            "Remove one of a tracked recipe when you successfully craft it."
-- L.SETTINGS_CLOSEWHENDONE_TITLE =         "Close Window When Done"
-- L.SETTINGS_CLOSEWHENDONE_DESC =          "Close the tracking window after crafting the last tracked recipe."
