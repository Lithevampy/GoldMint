----------------------------------------
-- Profession Shopping List: frFR.lua --
----------------------------------------
-- French (France) localisation
-- Translator(s): Klep-Ysondre

if GetLocale() ~= "frFR" then return end
local appName = "GoldMint"
local app = _G.GoldMint
local L = app.locales

-- Main window
L.WINDOW_BUTTON_CLOSE =                  "Fermer la fenêtre"
L.WINDOW_BUTTON_LOCK =                   "Verrouiller la fenêtre"
L.WINDOW_BUTTON_UNLOCK =                 "Déverrouiller la fenêtre"
L.WINDOW_BUTTON_SETTINGS =               "Ouvrir les paramètres"
L.WINDOW_BUTTON_CLEAR =                  "Effacer toutes les recettes suivies"
L.WINDOW_BUTTON_AUCTIONATOR =            "Mettre à jour la liste d’achats dans Auctionator\n" ..
                                         "La liste d’achats sera générée automatiquement lors de l’ouverture de l’Hôtel des ventes"
L.WINDOW_BUTTON_CORNER =                 "Double " .. app.IconLMB .. "|cffFFFFFF : dimensionner automatiquement pour s’adapter à la fenêtre|r"

L.WINDOW_HEADER_RECIPES =                PROFESSIONS_RECIPES_TAB -- "Recettes"
L.WINDOW_HEADER_ITEMS =                  ITEMS -- "Objets"
L.WINDOW_HEADER_REAGENTS =               PROFESSIONS_COLUMN_HEADER_REAGENTS -- "Composants"
L.WINDOW_HEADER_COSTS =                  "Coûts"
L.WINDOW_HEADER_COOLDOWNS =              "Temps de recharge"

L.WINDOW_TOOLTIP_RECIPES =               "Maj " .. app.IconLMB .. "|cffFFFFFF : poster la recette\n|r" ..
                                         "Ctrl " .. app.IconLMB .. "|cffFFFFFF : ouvrir la recette (si connue)\n|r" ..
                                         "Alt " .. app.IconLMB .. "|cffFFFFFF : essayer de créer cette recette\n\n|r" ..
                                         app.IconRMB .. "|cffFFFFFF : annuler le suivi d’1 unité de la recette\n|r" ..
                                         "Ctrl " .. app.IconRMB .. "|cffFFFFFF : annuler le suivi de toutes les unités de la recette sélectionnée"
L.WINDOW_TOOLTIP_REAGENTS =              "Maj " .. app.IconLMB .. "|cffFFFFFF : poster le composant\n|r" ..
                                         "Ctrl " .. app.IconLMB .. "|cffFFFFFF : ajouter une recette pour le sous-composant sélectionné, s’il existe et est mis en cache"
L.WINDOW_TOOLTIP_COOLDOWNS =             "Maj " .. app.IconRMB .. "|cffFFFFFF : supprimer le rappel de temps de recharge\n|r" ..
                                         "Ctrl " .. app.IconLMB .. "|cffFFFFFF : ouvrir la recette (si connue)\n|r" ..
                                         "Alt " .. app.IconLMB .. "|cffFFFFFF : essayer de créer cette recette"

L.CLEAR_CONFIRMATION =                   "Cela effacera toutes les recettes."
L.CONFIRMATION =                         "Souhaitez-vous poursuivre ?"
L.SUBREAGENTS1 =                         "Il existe plusieurs recettes qui permettent de créer" -- Followed by an item link
L.SUBREAGENTS2 =                         "Veuillez sélectionner l’un des éléments suivants"
L.GOLD =                                 BONUS_ROLL_REWARD_MONEY -- "Or"
L.MERCHANT_BUY =                         "Laissez " .. app.NameShort .. " acheter les " .. L.WINDOW_HEADER_REAGENTS .. " et " .. L.WINDOW_HEADER_COSTS .. " dont vous avez besoin auprès de ce marchand, si disponibles."

-- Cooldowns
L.RECHARGED =                            "Entièrement rechargé"
L.READY =                                "Prêt"
L.DAYS =                                 "j"
L.HOURS =                                "h"
L.MINUTES =                              "m"
L.READY_TO_CRAFT =                       "est de nouveau prête pour" -- Preceded by a recipe name, followed by a character name

-- Recipe tracking
L.TRACK =                                "Suivre"
L.UNTRACK =                              "Annuler le suivi"
L.RANK =                                 "Rang"
L.RECRAFT_TOOLTIP =                      "Sélectionnez un objet dont la recette a été mise en cache pour en assurer le suivi.\n" ..
                                         "Pour mettre en cache une recette, ouvrez le métier correspondant (sur n’importe quel personnage)\nou visualisez l’objet comme une commande d’artisanat normale."
L.QUICKORDER =                           "Commande rapide"
L.QUICKORDER_TOOLTIP =                   "|cffFF0000Créer instantanément|r une commande d’artisanat pour le destinataire spécifié.\n\n" ..
                                         "Utiliser |cffFFFFFFGUILD|r (tout en majuscules) pour placer une " .. PROFESSIONS_CRAFTING_FORM_ORDER_RECIPIENT_GUILD .. ".\n" .. -- "Guild Order". Don't translate "|cffFFFFFFGUILD|r" as this is hardcoded
                                         "Utiliser un nom de personnage pour placer une " .. PROFESSIONS_CRAFTING_FORM_ORDER_RECIPIENT_PRIVATE .. ".\n" .. -- "Personal Order"
                                         "Les destinataires sont mémorisés par recette. "
L.LOCALREAGENTS_LABEL =                  "Utiliser des composants dans les sacs"
L.LOCALREAGENTS_TOOLTIP =                "Utiliser les composants disponibles dans les sacs (de la plus basse qualité). Les composants utilisés |cffFF0000ne peuvent pas|r être personnalisés."
L.QUICKORDER_REPEAT_TOOLTIP =            "Répéter la dernière " .. L.QUICKORDER .. " effectuée sur ce personnage"
L.RECIPIENT =                            "Destinataire"

-- Profession window
L.MILLING_INFO =                         "Informations sur le broyage"
L.THAUMATURGY_INFO =                     "Informations sur la thaumaturgie"
L.FROM =                                 "depuis" -- I will convert this whole section to item links, then this is the only localisation needed. I recommend skipping this section, other than the two headers. :)

L.MILLING_CLASSIC =                      "Pigment saphir : 25% depuis Sansam doré, Feuillerêve, Sauge-argent des montagnes, Chagrinelle, Chapeglace\n" ..
                                         "Pigment argenté : 75% depuis Sansam doré, Feuillerêve, Sauge-argent des montagnes, Chagrinelle, Chapeglace\n\n" ..
                                         "Pigment rubis : 25% depuis Fleur de feu, Lotus pourpre, Larmes d’Arthas, Soleillette, Aveuglette,\n      Champignon fantôme, Gromsang\n" ..
                                         "Pigment violet : 75% depuis Fleur de feu, Lotus pourpre, Larmes d’Arthas, Soleillette, Aveuglette,\n      Champignon fantôme, Gromsang\n\n" ..
                                         "Pigment indigo : 25% depuis Pâlerette, Dorépine, Moustache de Khadgar, Dents de dragon\n" ..
                                         "Pigment émeraude : 75% depuis Pâlerette, Dorépine, Moustache de Khadgar, Dents de dragon\n\n" ..
                                         "Pigment brûlé : 25% depuis Aciérite sauvage, Tombeline, Sang-royal, Vietérule\n" ..
                                         "Pigment doré : 75% depuis Aciérite sauvage, Tombeline, Sang-royal, Vietérule\n\n" ..
                                         "Pigment verdoyant : 25% depuis Mage royal, Eglantine, Chardonnier, Doulourante, Etouffante\n" ..
                                         "Pigment crépusculaire : 75% depuis Mage royal, Eglantine, Chardonnier, Doulourante, Etouffante\n\n" ..
                                         "Pigment albâtre : 100% depuis Pacifique, Feuillargent, Terrestrine"
L.MILLING_TBC =                          "Pigment ébène : 25%\n" ..
                                         "Pigment néantin : 100%"
L.MILLING_WOTLK =                        "Pigment glacé : 25%\n" ..
                                         "Pigment azur : 100%"
L.MILLING_CATA =                         "Braises ardentes : 25%, 50% depuis Jasmin crépusculaire, Fouettine\n" ..
                                         "Pigment cendreux : 100%"
L.MILLING_MOP =                          "Pigment brumeux : 25%, 50% depuis Berluette\n" ..
                                         "Pigment ombreux : 100%"
L.MILLING_WOD =                          "Pigment céruléen : 100%"
L.MILLING_LEGION =                       "Pigment jaunâtre : 10%, 80% depuis Gangrèche\n" ..
                                         "Pigment rosé : 90%"
L.MILLING_BFA =                          "Pigment smaragdin : 10%, 30% depuis Ancoracée\n" ..
                                         "Pigment cramoisi : 25%\n" ..
                                         "Pigment bleu outremer : 75%"
L.MILLING_SL =                           "Pigment paisible : Belladone\n" ..
                                         "Pigment lumineux : Fatalée, Belle-de-l’aube, Plante-torche du veilleur\n" ..
                                         "Pigment ombreux : Fatalée, Courgineuse, Endeuillée"
L.MILLING_DF =                           "Pigment flamboyant : Saxifrage\n" ..
                                         "Pigment florissant : Écorce tordue\n" ..
                                         "Pigment serein : Pavot à bulle\n" ..
                                         "Pigment chatoyant : Hochenblume"
L.MILLING_TWW =                          "Pigment de la floraison : Floraison bénie\n" ..
                                         "Pigment de pose-appât : Pose-appât\n" ..
                                         "Pigment d’orbinide : Orbinide\n" ..
                                         "Pigment nacré : Champifleur"
L.THAUMATURGY_TWW =                      "Transmutagène mercurien : Aqirite, Chitine sinistre, Pose-appât, Orbinide\n" ..
                                         "Transmutagène sinistre : Bismuth, Champifleur, Poussière de tempête, Tissétoffe\n" ..
                                         "Transmutagène instable : Lance d’Arathor, Floraison bénie, Minerai de griffefer, Cuir chargé par la tempête"

L.BUTTON_COOKINGFIRE =                   app.IconLMB .. " : " .. BINDING_NAME_TARGETSELF .. "\n" .. -- "Target Self"
                                         app.IconRMB .. " : " .. STATUS_TEXT_TARGET -- "Target"
L.BUTTON_COOKINGPET =                    app.IconLMB .. " : invoquer cette mascotte\n" ..
                                         app.IconRMB .. " : passer d’une mascotte à l’autre"
L.BUTTON_CHEFSHAT =                      app.IconLMB .. " : utiliser l’"
L.BUTTON_THERMALANVIL =                  app.IconLMB .. " : utiliser une"
L.BUTTON_ALVIN =                         app.IconLMB .. " : invoquer cette mascotte"
L.BUTTON_LIGHTFORGE =                    app.IconLMB .. " : lancer"

-- Track new mogs
L.BUTTON_TRACKNEW =                      "Suivre les apparences inconnues"
L.CURRENT_SETTING =                      "Paramètre actuel :"
L.MODE_APPEARANCES =                     "nouvelles apparences"
L.MODE_SOURCES =                         "nouvelles apparences et sources"
-- L.ADDED_RECIPES =                        "Checked %d visible recipes for %s. Tracked %d recipes." -- %d becomes a number, %s becomes L.MODE_APPEARANCES or L.MODE_SOURCES

-- Tooltip info
L.MORE_NEEDED =                          "de plus sont nécessaires" -- Preceded by a number
L.MADE_WITH =                            "Fabriqué par" -- Followed by a profession name such as "Blacksmithing" or "Leatherworking"
L.RECIPE_LEARNED =                       "recette apprise"
L.RECIPE_UNLEARNED =                     "recette non apprise"
-- L.CRAFTING_COST =                        "Crafting Cost"

-- Profession knowledge
L.PERKS_UNLOCKED =                       "avantages débloqués"
L.PROFESSION_KNOWLEDGE =                 "connaissance"
L.VENDORS =                              "Vendeurs"
L.RENOWN =                               COVENANT_SANCTUM_TAB_RENOWN --"Renown "
L.WORLD =                                "Monde"
L.HIDDEN_PROFESSION_MASTER =             "Maître de métier caché"
-- L.WEEKLY =                               WEEKLY -- "Weekly"
-- L.TREASURE =                             "Treasure"
-- L.DROP =                                 BATTLE_PET_SOURCE_1 -- "Drop"
L.CATCHUP_KNOWLEDGE =                    "Connaissances de rattrapage disponibles :"
L.LOADING =                              SEARCH_LOADING_TEXT -- "Loading..."

-- Order adjustments
-- L.AUCTION_ADDONS =                       "Auctionator, Oribos Exchange, or TradeSkillMaster"
-- L.ORDERS_PRICING_MISSING =               "Missing"
-- L.ORDERS_PRICING_UPDATE =                "Update or scan with %s." -- %s becomes a list of addon names
L.ORDERS_SET_CRITERIA =                  "Définir les critères de suivi des commandes."
-- L.ORDERS_COST_NEED =                     "Cost settings only work with: %s." -- %s becomes a list of addon names
L.ORDERS_MAX_COST_KNOWLEDGE =            "Coût maximal par point de connaissance :"
L.ORDERS_MAX_COST_ARTISAN =              "Coût maximal par unité de monnaie d'artisan :" -- This refers to Artisan's Mettle, Artisan's Acuity, and Artisan's Moxie
L.ORDERS_MAX_COST_PAYOUT =               "Coût maximal par sac de récompense :" -- This refers to Artisan's Payout bag
L.ORDERS_TRACK_AFTER_RESET =             "Suivi des commandes disponible après la réinitialisation hebdomadaire"
L.ORDERS_TRACK_CONCENTRATION =           "Suivre les commandes par coûts en concentration :"
-- L.ORDERS_TRACK_ON =                      "Track on %s:"  -- %s becomes a character name

L.ORDERSQUEUE_QUEUE =                    "File d'attente"
L.ORDERSQUEUE_QUEUED =                   "Commandes en attente :"
L.ORDERSQUEUE_NEXT =                     "Prochaine commande"
L.ORDERSQUEUE_CLAIM =                    "Commencer la commande"
L.ORDERSQUEUE_CRAFT =                    "Lancer la commande"
L.ORDERSQUEUE_CRAFTING =                 "En cours..."
L.ORDERSQUEUE_COMPLETE =                 PROFESSIONS_COMPLETE_ORDER -- "Complete Order"
-- L.ORDERSQUEUE_WARNING_QUEST =            "You have not picked up %s." -- %s becomes a quest name
-- L.ORDERSQUEUE_WARNING_REAGENTS =         "You do not have enough reagents for all tracked recipes."

-- L.PROFTOOL_AUTOEQUIP =                   "Automatically equip this tool" -- Followed by one of the two following phrases
-- L.PROFTOOL_DEFAULT =                     "for |cffFFFFFFregular crafting|R."
-- L.PROFTOOL_ORDERS =                      "while |cffFFFFFFdoing orders|R."
-- L.PROFTOOL_DRAG =                        "Drag a tool here."
-- L.PROFTOOL_MOUSE =                       app.IconLMB .. ": Equip this tool.\n" ..
--                                          app.IconRMB .. ": Remove this tool."

-- Chat feedback
L.INVALID_PARAMETERS =                   "Paramètres non valides"
L.INVALID_RECIPEQUANTITY =               L.INVALID_PARAMETERS .. " : veuillez saisir une quantité valide pour la recette."
L.INVALID_RECIPEID =                     L.INVALID_PARAMETERS .. " : veuillez saisir un identifiant de recette (recipeID) mis en cache."
L.INVALID_RECIPE_TRACKED =               L.INVALID_PARAMETERS .. " : veuillez saisir un identifiant de recette suivie (recipeID)"
L.INVALID_ACHIEVEMENT =                  L.INVALID_PARAMETERS .. " : il ne s’agit pas d’un haut fait de métier. Aucune recette n’a été ajoutée."
L.INVALID_RESET_ARG =                    L.INVALID_PARAMETERS .. " : vous pouvez utiliser les arguments suivants :"
L.INVALID_COMMAND =                      "Commande non valide. Voir " .. app:Colour("/psl settings") .. " pour plus d’informations."
L.DEBUG_ENABLED =                        "Mode débogage activé"
L.DEBUG_DISABLED =                       "Mode débogage désactivé"
L.RESET_DONE =                           "La réinitialisation des données a été effectuée avec succès."
L.REQUIRES_RELOAD =                      "|cffFF0000" .. REQUIRES_RELOAD .. ".|r Faites |cffFFFFFF/reload|r ou |cffFFFFFF/rl|r ou reconnectez-vous."

L.FALSE =                                "faux"
L.TRUE =                                 "vrai"
L.NOLASTORDER =                          "Aucune dernière " .. L.QUICKORDER .. " trouvée"
L.ERROR =                                "Erreur"
L.ERROR_CRAFTSIM =                       L.ERROR .. " : impossible de lire les informations provenant de CraftSim"
L.ERROR_QUICKORDER =                     L.ERROR .. " : la " .. L.QUICKORDER .. " a échoué. Désolé. :("
L.ERROR_REAGENTS =                       L.ERROR .. " : impossible de créer une " .. L.QUICKORDER .. " pour les objets comportant des composants obligatoires. Désolé. :("
L.ERROR_WARBANK =                        L.ERROR .. " : impossible de créer une " .. L.QUICKORDER .. " avec des objets provenant de la Banque de bataillon"
L.ERROR_GUILD =                          L.ERROR .. " : impossible de créer une " .. PROFESSIONS_CRAFTING_FORM_ORDER_RECIPIENT_GUILD .. " en dehors d’une guilde" -- "Guild Order"
L.ERROR_RECIPIENT =                      L.ERROR .. " : le destinataire cible ne peut pas fabriquer cet objet. Veuillez saisir un nom de destinataire valide"
L.ERROR_MULTISIM =                       L.ERROR .. " : aucun composant simulé n’a été utilisé. Veuillez n’activer que l’un des addons suivants :"

L.NEW_VERSION_AVAILABLE =                "Une nouvelle version de " .. app.NameLong .. " est disponible :"

-- Settings
L.SETTINGS_TOOLTIP =                     app.NameLong .. "\n|cffFFFFFF" ..
                                         app.IconLMB .. " : Afficher / masquer la fenêtre\n" ..
                                         app.IconRMB .. " : " .. L.WINDOW_BUTTON_SETTINGS

L.SETTINGS_VERSION =                     GAME_VERSION_LABEL .. ":"    -- "Version"
L.SETTINGS_SUPPORT_TEXTLONG =            "Le développement de ce module complémentaire demande beaucoup de temps et d’efforts.\nVeuillez envisager de soutenir financièrement le développeur."
L.SETTINGS_SUPPORT_TEXT =                "Soutien"
L.SETTINGS_SUPPORT_BUTTON =              "Buy Me a Coffee"    -- Brand name, if there isn't a localised version, keep it the way it is
L.SETTINGS_SUPPORT_DESC =                "Merci !"
L.SETTINGS_HELP_TEXT =                   "Commentaires et aide"
L.SETTINGS_HELP_BUTTON =                 "Discord"    -- Brand name, if there isn't a localised version, keep it the way it is
L.SETTINGS_HELP_DESC =                   "Rejoignez le serveur Discord."
L.SETTINGS_URL_COPY =                    "Ctrl + C pour copier :"
L.SETTINGS_URL_COPIED =                  "lien a été copié dans le presse-papiers"

L.SETTINGS_KEYSLASH_TITLE =              SETTINGS_KEYBINDINGS_LABEL .. " & Commandes « Slash »"    -- "Keybindings"
_G["BINDING_NAME_PSL_TOGGLEWINDOW"] =    app.NameShort .. " : afficher / masquer la fenêtre"
L.SETTINGS_SLASH_TOGGLE =                "Afficher / masquer la fenêtre de suivi"
L.SETTINGS_SLASH_RESETPOS =              "Réinitialiser la position de la fenêtre de suivi"
L.SETTINGS_SLASH_RESET =                 "Réinitialiser les données enregistrées"
L.SETTINGS_SLASH_TRACK =                 "Suivre une recette"
L.SETTINGS_SLASH_UNTRACK =               "Annuler le suivi d’une recette"
L.SETTINGS_SLASH_UNTRACKALL =            "Annuler le suivi de toutes les unités d’une recette"
L.SETTINGS_SLASH_TRACKACHIE =            "Suivre les recettes nécessaires pour le haut fait sélectionné"
L.SETTINGS_SLASH_CRAFTINGACHIE =         "haut fait de métier"
L.SETTINGS_SLASH_RECIPEID =              "recipeID"
L.SETTINGS_SLASH_QUANTITY =              "quantité"
-- L.SETTINGS_SLASH_REAGENT =               "itemLink or itemID"
-- L.SETTINGS_SLASH_TRACKREAGENT =          "Track all recipes using this reagent"

L.GENERAL =                              GENERAL    -- "General"
L.SETTINGS_MINIMAP_TITLE =               "Afficher le bouton de la mini-carte"
L.SETTINGS_MINIMAP_DESC =                "Afficher le bouton de la mini-carte. Si vous désactivez cette fonction, " .. app.NameShort .. " sera toujours disponible dans le panneau des addons."
L.SETTINGS_COOLDOWNS_TITLE =             "Suivre le temps de recharge des recettes"
L.SETTINGS_COOLDOWNS_DESC =              "Activer le suivi des temps de recharge des recettes. Ceux-ci s’afficheront dans la fenêtre de suivi, et dans le chat à la connexion s’ils sont prêts."
L.SETTINGS_COOLDOWNSWINDOW_TITLE =       "Afficher la fenêtre lorsque « Prêt »"
L.SETTINGS_COOLDOWNSWINDOW_DESC =        "Ouvrir la fenêtre de suivi lors de la connexion lorsqu’un temps de recharge est prêt, en plus du rappel par message de chat."
L.SETTINGS_TOOLTIP_TITLE =               "Afficher les informations de l’infobulle"
L.SETTINGS_TOOLTIP_DESC =                "Afficher la quantité de composants que vous possédez / avez besoin dans l’infobulle de l’objet."
L.SETTINGS_CRAFTTOOLTIP_TITLE =          "Afficher les informations d’artisanat"
L.SETTINGS_CRAFTTOOLTIP_DESC =           "Afficher avec quel métier une pièce d’équipement est fabriquée et si la recette est connue sur votre compte."
-- L.SETTINGS_CRAFTCOSTTOOLTIP_TITLE =      "Show Crafting Cost"
-- L.SETTINGS_CRAFTCOSTTOOLTIP_DESC =       "Show how much an item costs to craft, if that information is available."
L.SETTINGS_REAGENTQUALITY_TITLE =        "Qualité minimale de composant"
L.SETTINGS_REAGENTQUALITY_DESC =         "Définissez la qualité minimale requise pour les réactifs avant que " .. app.NameShort .. " ne les inclue dans le décompte des objets. Les résultats simulés prévaudront toutefois sur cette valeur."
L.SETTINGS_INCLUDEHIGHER_TITLE =         "Inclure une qualité supérieure"
L.SETTINGS_INCLUDEHIGHER_DESC =          "Faut-il inclure ou non les réactifs de qualité supérieure ? (Par exemple, faut-il inclure les réactifs de niveau 2 détenus lors du décompte des réactifs de niveau 1 ?)"
L.SETTINGS_COLLECTMODE_TITLE =           "Mode de collection"
L.SETTINGS_COLLECTMODE_DESC =            "Définir les objets à inclure lors de l’utilisation du bouton " .. app:Colour(L.BUTTON_TRACKNEW) .. "."

-- L.PROFESSION_WINDOW =                    "Profession Window"
-- L.SETTINGS_FILTER_OPTREAGENTS =          "Filter Optional Reagents"
-- L.SETTINGS_FILTER_OPTREAGENTS_DESC =     "When %s is checked for optional reagents, hide combinable items." -- %s becomes "Hide Unavailable"
L.SETTINGS_SPENDTOPERK_TITLE =           "Dépenser jusqu’au prochain palier"
L.SETTINGS_SPENDTOPERK_DESC =            "Maj + Clic sur une spécialisation de métier dépense tous les points de connaissance jusqu’au prochain palier."
L.SETTINGS_ENHANCEDORDERS_TITLE =        "Commandes améliorées"
L.SETTINGS_ENHANCEDORDERS_DESC =         "Améliore l’aperçu des récompenses et commissions de commande et ajoute des icônes pour les premières fabrications, les recettes non apprises et les recettes suivies.\n\n" .. L.REQUIRES_RELOAD
L.SETTINGS_QUICKORDER_TITLE =            "Durée de la commande rapide"
L.SETTINGS_QUICKORDER_DESC =             "Définir la durée pour passer des commandes rapides avec " .. app.NameShort .. "."

L.LOW =                                  LOW -- "Low"
L.HIGH =                                 HIGH -- "High"
L.SETTINGS_INCLUDE =                     "Inclure les qualités supérieures"
L.SETTINGS_DONT_INCLUDE =                "Ne pas inclure les qualités supérieures"
L.SETTINGS_APPEARANCES_TITLE =            WARDROBE -- "Appearances"
L.SETTINGS_APPEARANCES_TEXT =            "Inclure les objets uniquement s’ils ont une nouvelle apparence."
L.SETTINGS_SOURCES_TITLE =               "Sources"
L.SETTINGS_SOURCES_TEXT =                "Inclure les objets s’ils proviennent d’une nouvelle source, y compris pour les apparences connues."
L.SETTINGS_DURATION_SHORT =              "Court (12 heures)"
L.SETTINGS_DURATION_MEDIUM =             "Moyen (24 heures)"
L.SETTINGS_DURATION_LONG =               "Long (48 heures)"

L.SETTINGS_HEADER_TRACK =                "Fenêtre de suivi"
L.SETTINGS_HELPTOOLTIP_TITLE =           "Afficher les infobulles d’aide"
L.SETTINGS_HELPTOOLTIP_DESC =            "Afficher les actions disponibles à la souris lorsque vous survolez des éléments dans la fenêtre de suivi."
L.SETTINGS_PERSONALWINDOWS_TITLE =       "Position de la fenêtre par personnage"
L.SETTINGS_PERSONALWINDOWS_DESC =        "Enregistrer la position de la fenêtre pour chaque personnage, au lieu de l’appliquer à tout le compte."
L.SETTINGS_PERSONALRECIPES_TITLE =       "Suivre les recettes par personnage"
L.SETTINGS_PERSONALRECIPES_DESC =        "Suivre les recettes pour chaque personnage, au lieu de les partager à tout le compte."
L.SETTINGS_SHOWREMAINING_TITLE =         "Afficher les composants restants"
L.SETTINGS_SHOWREMAINING_DESC =          "Afficher uniquement le nombre de composants qu’il reste à obtenir dans la fenêtre de suivi, au lieu d’afficher ceux possédés / requis."
L.SETTINGS_REMOVECRAFT_TITLE =           "Arrêt du suivi après fabrication"
L.SETTINGS_REMOVECRAFT_DESC =            "Arrêter de suivre une recette lorsque vous la fabriquez avec succès."
L.SETTINGS_CLOSEWHENDONE_TITLE =         "Fermer la fenêtre une fois terminé"
L.SETTINGS_CLOSEWHENDONE_DESC =          "Fermer la fenêtre de suivi après avoir fabriqué la dernière recette suivie."
