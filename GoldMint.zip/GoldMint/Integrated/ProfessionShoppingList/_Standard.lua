local appName = "GoldMint"
local app = _G.GoldMint

app.Retail = true
app.Forever = false
