local ADDON_NAME = "GoldMint"
local GoldMint = _G.GoldMint
local app = GoldMint
app.__integratedPSL = true
app.CreateWindow = function() end
app.ShowWindow = function() end
app.UpdateNumbers = function() end
app.UpdateAssets = function() end
