local ADDON_NAME = "GoldMint"
local GoldMint = _G.GoldMint
local app = GoldMint
local api = app.api

-- GoldMint owns the visible shopping-list UI. Keep PSL's tracking/data engine,
-- but never open its original standalone window.
app.CreateWindow = function() end
app.ShowWindow = function(self)
    if GoldMint.CraftingIntegration and GoldMint.CraftingIntegration.RefreshShoppingList then
        GoldMint.CraftingIntegration:RefreshShoppingList()
    end
end

local originalUpdateRecipes = app.UpdateRecipes
app.UpdateRecipes = function(self)
    if originalUpdateRecipes and self.Window and self.Window.Recipes then
        return originalUpdateRecipes(self)
    end
    self.ReagentQuantities = {}
    if self.Data and self.Data.Recipes and self.GetReagents then
        for recipeID, recipeInfo in pairs(self.Data.Recipes) do
            if type(recipeID) == "number" and recipeInfo and recipeInfo.quantity then
                pcall(self.GetReagents, self, self.ReagentQuantities, recipeID, recipeInfo.quantity, recipeInfo.recraft)
            end
        end
    end
    if GoldMint.CraftingIntegration and GoldMint.CraftingIntegration.RefreshShoppingList then
        GoldMint.CraftingIntegration:RefreshShoppingList()
    end
end

app.Clear = function(self)
    if self.Data then self.Data.Recipes = {} end
    if self.Cache then
        self.Cache.Reagents = {}
        self.Cache.FakeRecipes = {}
        self.Cache.SimulatedRecipes = {}
    end
    self.ReagentQuantities = {}
    if GoldMint.CraftingIntegration and GoldMint.CraftingIntegration.RefreshShoppingList then
        GoldMint.CraftingIntegration:RefreshShoppingList()
    end
    if self.FireTrackedRecipesChanged then self:FireTrackedRecipesChanged(nil, nil) end
end

api.ToggleWindow = function()
    if GoldMint.CraftingIntegration and GoldMint.CraftingIntegration.RefreshShoppingList then
        GoldMint.CraftingIntegration:RefreshShoppingList()
    end
end
