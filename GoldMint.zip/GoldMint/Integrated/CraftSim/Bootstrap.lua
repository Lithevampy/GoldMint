local ADDON_NAME = "GoldMint"
local GoldMint = _G.GoldMint

if not GoldMint then return end

GoldMint.CraftSim = GoldMint.CraftSim or {}
local CraftSim = GoldMint.CraftSim
CraftSim.__integrated = true
CraftSim.__hostAddon = ADDON_NAME
CraftSim.OPTIONS = CraftSim.OPTIONS or { lastOpenRecipeID = {} }
CraftSim.SLASH = CraftSim.SLASH or { Init = function() end }
