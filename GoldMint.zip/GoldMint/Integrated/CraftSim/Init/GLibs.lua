---@class CraftSim
local CraftSim = _G.GoldMint and _G.GoldMint.CraftSim
if not CraftSim then return end

---@source ../Libs/GGUI/GGUI.lua
---@type GGUI-2.1
CraftSim.GGUI = LibStub:GetLibrary("GGUI-2.1")

---@source ../Libs/GUTIL/GUTIL.lua
---@type GUTIL-2.0
CraftSim.GUTIL = LibStub:GetLibrary("GUTIL-2.0")

---@source ../Libs/LibGraph-2.0/LibGraph-2.0/LibGraph-2.0.lua
---@class LibGraph-2.0
CraftSim.LibGraph = LibStub:GetLibrary("LibGraph-2.0")

---@class AceSerializer-3.0
CraftSim.AceSerializer = LibStub:GetLibrary("AceSerializer-3.0")

---@class LibCompress
CraftSim.LibCompress = LibStub:GetLibrary("LibCompress")

---@class LibDBIcon
CraftSim.LibIcon = LibStub("LibDBIcon-1.0")

---@source ../Libs/LibLog-1.0/LibLog-1.0.lua
---@class LibLog-1.0
CraftSim.LibLog = LibStub:GetLibrary("LibLog-1.0")
CraftSim.LibLog:DisableSink("BuiltIn") -- Disable printing logs to chat
