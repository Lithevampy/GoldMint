GoldMint Integrated Crafting Backend

This directory contains integrated source derived from CraftSim and Profession Shopping List.
The original addon UI is not loaded; GoldMint owns the Crafting page UI.
CraftSim source is MIT licensed; see Integrated/CraftSim/LICENSE.
Profession Shopping List source is GPLv3 licensed; see Integrated/ProfessionShoppingList/LICENSE.
GoldMint includes the corresponding source files so the integrated functionality does not require either addon to be installed separately.
