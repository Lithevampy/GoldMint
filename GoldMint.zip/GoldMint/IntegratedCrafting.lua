local ADDON_NAME, GoldMint = ...
GoldMint.CraftingIntegration = GoldMint.CraftingIntegration or {}
local I = GoldMint.CraftingIntegration

local function safe(fn, ...)
    local ok, a,b,c,d = pcall(fn, ...)
    if ok then return a,b,c,d end
    return nil
end

function I:IsCraftSimReady()
    return GoldMint.CraftSim and GoldMint.CraftSim.__integratedInitialized == true and CraftSimAPI ~= nil
end

function I:GetRecipeData(recipeID)
    if not self:IsCraftSimReady() or not recipeID then return nil end
    return safe(CraftSimAPI.GetRecipeData, CraftSimAPI, {recipeID=tonumber(recipeID)})
end

function I:CalculateRecipe(recipeID)
    local rd = self:GetRecipeData(recipeID)
    if not rd then return nil end
    -- Refresh core calculations when possible. CraftSim's RecipeData constructor
    -- already initializes result, prices, profession stats, concentration and costs.
    safe(rd.Update, rd)
    local averageProfit, probability = safe(rd.GetAverageProfit, rd)
    local priceData = rd.priceData or {}
    local craftingCost = tonumber(priceData.craftingCosts or priceData.craftingCost) or 0
    local resultValue = tonumber(rd.resultData and (rd.resultData.averageItemValue or rd.resultData.averageValue)) or 0
    local concentration = tonumber(rd.concentrationCost) or 0
    local skill = tonumber(rd.professionStats and rd.professionStats.skill and rd.professionStats.skill.value)
    local quality = safe(rd.GetResultQuality, rd)
    local outputID = tonumber(rd.recipeInfo and rd.recipeInfo.outputItemID) or tonumber(rd.outputItemID)
    local name = rd.recipeInfo and rd.recipeInfo.name or rd.recipeName
    return {
        recipeData = rd,
        recipeID = tonumber(recipeID),
        name = name,
        profit = tonumber(averageProfit) or 0,
        craftingCost = craftingCost,
        resultValue = resultValue,
        concentrationCost = concentration,
        skill = skill,
        quality = quality,
        probability = probability,
        outputItemID = outputID,
        profession = rd.professionData and rd.professionData.professionInfo and rd.professionData.professionInfo.profession,
    }
end

function I:GetShoppingEntries()
    local entries = {}
    local psl = GoldMint.api
    if not psl or not psl.Data or not psl.Data.Recipes then return entries end
    local quantities = psl.ReagentQuantities or {}
    for itemID, amount in pairs(quantities) do
        if type(itemID) == "number" and tonumber(amount) and amount > 0 then
            local name, link, icon = C_Item.GetItemInfo(itemID)
            local owned = C_Item.GetItemCount(itemID, true, false, true, true) or 0
            entries[#entries+1] = {
                itemID = itemID,
                name = name or ("Item "..itemID),
                link = link,
                icon = icon,
                needed = tonumber(amount) or 0,
                owned = owned,
                missing = math.max((tonumber(amount) or 0) - owned, 0),
            }
        end
    end
    table.sort(entries, function(a,b)
        if a.missing ~= b.missing then return a.missing > b.missing end
        return tostring(a.name) < tostring(b.name)
    end)
    return entries
end

function I:RefreshShoppingList()
    self.shoppingEntries = self:GetShoppingEntries()
    if GoldMint.Dashboard and GoldMint.Dashboard.RefreshCraftingPage then
        GoldMint.Dashboard:RefreshCraftingPage()
    end
end

function I:TrackRecipe(recipeID, quantity)
    if not recipeID then return false end
    if ProfessionShoppingList and ProfessionShoppingList.TrackRecipe then
        local ok = pcall(ProfessionShoppingList.TrackRecipe, ProfessionShoppingList, tonumber(recipeID), tonumber(quantity) or 1, false)
        if ok then self:RefreshShoppingList(); return true end
    end
    return false
end

function I:UntrackRecipe(recipeID, quantity)
    if ProfessionShoppingList and ProfessionShoppingList.UntrackRecipe then
        local ok = pcall(ProfessionShoppingList.UntrackRecipe, ProfessionShoppingList, tonumber(recipeID), tonumber(quantity) or 0)
        if ok then self:RefreshShoppingList(); return true end
    end
    return false
end

function I:GetSelectedRecipeCalculation(recipeID)
    return self:CalculateRecipe(recipeID)
end
