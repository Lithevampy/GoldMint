local ADDON_NAME, GoldMint = ...

-- GoldMint Mail & Auction Logistics
--
-- This module connects observed mail, outgoing mail intent, bag inventory and
-- owned-auction data to Cognitive Accessibility. It never auto-loots mail,
-- sends mail, or posts auctions. It only creates persistent, evidence-based
-- work items that the player can review and act on.

GoldMint.Logistics = {}
local Logistics = GoldMint.Logistics

local STORE_VERSION = 1
local MAX_OUTGOING = 100
local MAX_AUCTION_CANDIDATES = 100
local CANDIDATE_MIN_VALUE = 10000 -- 1g; deliberately conservative
local SCAN_INTERVAL = 5

local function Now()
    return time()
end

local function CurrentKey()
    return GoldMint.characterKey
end

local function EnsureStore()
    GoldMintDB.logistics = type(GoldMintDB.logistics) == "table" and GoldMintDB.logistics or {}
    local store = GoldMintDB.logistics
    store.version = math.max(tonumber(store.version) or 0, STORE_VERSION)
    store.outgoing = type(store.outgoing) == "table" and store.outgoing or {}
    store.auctionCandidates = type(store.auctionCandidates) == "table" and store.auctionCandidates or {}
    store.lastScanAt = tonumber(store.lastScanAt) or 0
    store.lastScanReason = store.lastScanReason
    return store
end

local function NormalizeName(name)
    name = tostring(name or "")
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    local base, realm = name:match("^([^%-]+)%-(.+)$")
    if base then
        return base:lower(), realm:lower()
    end
    return name:lower(), nil
end

local function FindCharacterKey(name)
    local base, realm = NormalizeName(name)
    if base == "" then return nil end
    if type(GoldMintDB.characters) ~= "table" then return nil end

    local fallback
    for key, character in pairs(GoldMintDB.characters) do
        if type(character) == "table" and character.name then
            local cname, crealm = NormalizeName(character.name)
            if cname == base then
                if realm and crealm == realm then return key end
                fallback = fallback or key
            end
        end
    end
    return fallback
end

local function IsCurrentCharacterName(name)
    local a = NormalizeName(name)
    local b = NormalizeName(GoldMint.characterName)
    return a ~= "" and a == b
end

local function SafeItemInfo(bag, slot)
    if not C_Container or type(C_Container.GetContainerItemInfo) ~= "function" then return nil end
    local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
    if ok and type(info) == "table" then return info end
    return nil
end

local function IsQuestItem(bag, slot)
    if not C_Container or type(C_Container.GetContainerItemQuestInfo) ~= "function" then return false end
    local ok, info = pcall(C_Container.GetContainerItemQuestInfo, bag, slot)
    return ok and type(info) == "table" and info.isQuestItem == true
end

local function IsBound(info)
    return info and info.isBound == true
end

-- Warbound-until-equipped items are not Auction House sell candidates.
-- They can look exactly like normal Bind-on-Equip items through C_Item.GetItemInfo,
-- so candidate generation must inspect the actual item location / tooltip binding state.
local function IsWarboundUntilEquipped(bag, slot, itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end

    local function TooltipSaysWuE(data)
        if type(data) ~= "table" or type(data.lines) ~= "table" then return false end
        for _, line in ipairs(data.lines) do
            if type(line) == "table" then
                local bonding = tonumber(line.bonding)
                if bonding == 9 or bonding == 10 then return true end
                if Enum and Enum.TooltipDataLineType and line.type == Enum.TooltipDataLineType.ItemBinding then
                    if bonding == 9 or bonding == 10 then return true end
                end
            end
        end
        return false
    end

    -- The live bag tooltip is the authoritative per-item source.
    if bag ~= nil and slot ~= nil and C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
        if ok and TooltipSaysWuE(data) then return true end
    end

    -- This API specifically answers the WuE state for an actual inventory item.
    if bag ~= nil and slot ~= nil and ItemLocation and ItemLocation.CreateFromBagAndSlot and C_Item and C_Item.IsBoundToAccountUntilEquip then
        local okLoc, itemLocation = pcall(ItemLocation.CreateFromBagAndSlot, bag, slot)
        if okLoc and itemLocation then
            local ok, result = pcall(C_Item.IsBoundToAccountUntilEquip, itemLocation)
            if ok and result == true then return true end
        end
    end

    -- Item-level API covers cached item data when no live location is available.
    if C_Item and C_Item.IsItemBindToAccountUntilEquip then
        local ok, result = pcall(C_Item.IsItemBindToAccountUntilEquip, itemID)
        if ok and result == true then return true end
    end
    if C_TooltipInfo and C_TooltipInfo.GetItemByID then
        local ok, data = pcall(C_TooltipInfo.GetItemByID, itemID)
        if ok and TooltipSaysWuE(data) then return true end
    end

    return false
end

local function IsAuctionSellable(bag, slot, itemID)
    if IsWarboundUntilEquipped(bag, slot, itemID) then return false end

    -- Blizzard's own Auction House validation is the final live-item guard.
    -- If the item location is not valid for posting, never surface it as a
    -- GoldMint auction candidate.
    if bag ~= nil and slot ~= nil and C_AuctionHouse and C_AuctionHouse.IsSellItemValid
        and ItemLocation and ItemLocation.CreateFromBagAndSlot then
        local okLoc, itemLocation = pcall(ItemLocation.CreateFromBagAndSlot, bag, slot)
        if okLoc and itemLocation then
            local ok, valid = pcall(C_AuctionHouse.IsSellItemValid, itemLocation, false)
            if ok and valid == false then return false end
        end
    end

    return true
end

local function IsCraftingReagent(itemID)
    if GoldMint.Market and GoldMint.Market.IsMaterial then
        return GoldMint.Market:IsMaterial(itemID)
    end
    return false
end

local function GetUnitValue(itemID)
    if GoldMint.Market and GoldMint.Market.GetUnitValue then
        local value, source = GoldMint.Market:GetUnitValue(itemID)
        return tonumber(value), source
    end
    return nil, nil
end

local function ActiveAuctionQuantities()
    local quantities = {}
    if not GoldMint.Market or not GoldMint.Market.GetActiveOwnedAuctionsForCharacter then
        return quantities
    end
    for _, auction in ipairs(GoldMint.Market:GetActiveOwnedAuctionsForCharacter() or {}) do
        local itemID = tonumber(auction.itemID or (auction.itemKey and auction.itemKey.itemID))
        if itemID then
            quantities[itemID] = (quantities[itemID] or 0) + (tonumber(auction.quantity) or 1)
        end
    end
    return quantities
end

function Logistics:Initialize()
    if self._initialized then return true end
    self._initialized = true
    EnsureStore()

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("AUCTION_HOUSE_SHOW")
    frame:RegisterEvent("OWNED_AUCTIONS_UPDATED")
    frame:RegisterEvent("MAIL_INBOX_UPDATE")
    frame:RegisterEvent("MAIL_SHOW")

    frame:SetScript("OnEvent", function(_, event, ...)
        if event == "PLAYER_ENTERING_WORLD" then
            GoldMint:ScheduleGuardedCallback(Logistics, "logistics world refresh", 2, function()
                Logistics:Refresh("world")
            end, function() return Logistics._initialized end)
        elseif event == "AUCTION_HOUSE_SHOW" or event == "OWNED_AUCTIONS_UPDATED" then
            GoldMint:ScheduleGuardedCallback(Logistics, "logistics auction refresh", 0.5, function()
                if not GoldMint:IsMerchantOpen() then Logistics:Refresh("auction_house") end
            end, function() return Logistics._initialized end)
        elseif event == "MAIL_INBOX_UPDATE" or event == "MAIL_SHOW" then
            GoldMint:ScheduleGuardedCallback(Logistics, "logistics mail refresh", 0.4, function()
                if not GoldMint:IsMerchantOpen() then Logistics:Refresh("mail") end
            end, function() return Logistics._initialized end)
        end
    end)

    -- Capture player-initiated outgoing mail intent. The hook records only the
    -- recipient/subject/money that the UI submitted; it does not send anything.
    if type(hooksecurefunc) == "function" and type(SendMail) == "function" then
        hooksecurefunc("SendMail", function(recipient, subject, money, cod)
            Logistics:RecordOutgoingMail(recipient, subject, money, cod)
        end)
    end

    GoldMint:ScheduleGuardedCallback(self, "logistics initial refresh", 3, function()
        Logistics:Refresh("initialize")
    end, function() return Logistics._initialized end)
    return true
end

function Logistics:RecordOutgoingMail(recipient, subject, money, cod)
    recipient = tostring(recipient or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if recipient == "" or IsCurrentCharacterName(recipient) then return false end

    local store = EnsureStore()
    local targetKey = FindCharacterKey(recipient)
    local record = {
        id = string.format("mail-%d-%d", Now(), math.random(1000, 9999)),
        senderKey = CurrentKey(),
        senderName = GoldMint.characterName,
        senderRealm = GoldMint.characterRealm,
        recipient = recipient,
        recipientKey = targetKey,
        subject = tostring(subject or ""),
        money = tonumber(money) or 0,
        cod = tonumber(cod) or 0,
        sentAt = Now(),
        deliveredAt = nil,
        status = "sent",
    }
    store.outgoing[#store.outgoing + 1] = record
    while #store.outgoing > MAX_OUTGOING do table.remove(store.outgoing, 1) end
    return record
end

local function MarkObservedDeliveries()
    local store = EnsureStore()
    local currentKey = CurrentKey()
    if not currentKey then return 0 end
    if not GoldMint.MailTracking or not GoldMint.MailTracking.GetMessages then return 0 end

    local delivered = 0
    local messages = GoldMint.MailTracking:GetMessages(currentKey)
    for _, message in ipairs(messages or {}) do
        if message.internal and message.sender and not IsCurrentCharacterName(message.sender) then
            local senderKey = FindCharacterKey(message.sender)
            for _, outgoing in ipairs(store.outgoing) do
                if outgoing.status == "sent"
                    and outgoing.senderKey == senderKey
                    and outgoing.recipientKey == currentKey
                    and outgoing.deliveredAt == nil then
                    outgoing.deliveredAt = Now()
                    outgoing.status = "delivered"
                    outgoing.observedMessageID = message.id
                    delivered = delivered + 1
                    break
                end
            end
        end
    end
    return delivered
end

function Logistics:ScanAuctionCandidates()
    local store = EnsureStore()
    local candidates = {}
    local active = ActiveAuctionQuantities()
    local aggregated = {}

    if not C_Container or type(C_Container.GetContainerNumSlots) ~= "function" then
        return candidates
    end

    -- Aggregate stacks first so split bag stacks are not mistaken for separate
    -- decisions and active-auction quantities are subtracted from the total.
    for bag = BACKPACK_CONTAINER, NUM_BAG_SLOTS do
        local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, bag)
        local slots = okSlots and (tonumber(rawSlots) or 0) or 0
        for slot = 1, slots do
            local info = SafeItemInfo(bag, slot)
            local itemID = info and tonumber(info.itemID)
            if itemID then
                local entry = aggregated[itemID]
                if not entry then
                    entry = {
                        itemID = itemID,
                        itemName = info.itemName,
                        itemLink = info.hyperlink,
                        quantity = 0,
                        bag = bag,
                        slot = slot,
                        sellable = true,
                        unitValue = nil,
                        valueSource = nil,
                    }
                    aggregated[itemID] = entry
                end

                local quantity = tonumber(info.stackCount) or 1
                entry.quantity = entry.quantity + quantity
                if not entry.itemLink and info.hyperlink then entry.itemLink = info.hyperlink end
                if IsBound(info) or not IsAuctionSellable(bag, slot, itemID) or IsQuestItem(bag, slot) or IsCraftingReagent(itemID) then
                    entry.sellable = false
                end
            end
        end
    end

    for itemID, entry in pairs(aggregated) do
        if entry.sellable then
            local value, source = GetUnitValue(itemID)
            local activeQuantity = tonumber(active[itemID]) or 0
            local remaining = math.max((tonumber(entry.quantity) or 0) - activeQuantity, 0)
            if value and value >= CANDIDATE_MIN_VALUE and remaining > 0 then
                local name = entry.itemName
                if not name and C_Item and C_Item.GetItemInfo then
                    local ok, itemName = pcall(C_Item.GetItemInfo, itemID)
                    if ok then name = itemName end
                end
                candidates[#candidates + 1] = {
                    itemID = itemID,
                    itemName = tostring(name or ("Item " .. itemID)),
                    itemLink = entry.itemLink,
                    bag = entry.bag,
                    slot = entry.slot,
                    quantity = remaining,
                    unitValue = value,
                    totalValue = value * remaining,
                    valueSource = source,
                    activeQuantity = activeQuantity,
                    observedAt = Now(),
                    characterKey = CurrentKey(),
                }
            end
        end
    end

    table.sort(candidates, function(a, b)
        return (a.totalValue or 0) > (b.totalValue or 0)
    end)
    while #candidates > MAX_AUCTION_CANDIDATES do table.remove(candidates) end
    store.auctionCandidates = candidates
    return candidates
end

function Logistics:Refresh(reason)
    local store = EnsureStore()
    MarkObservedDeliveries()
    self:ScanAuctionCandidates()
    store.lastScanAt = Now()
    store.lastScanReason = tostring(reason or "refresh")
    self:UpdateWorkflow()
    if GoldMint.Alerts then
        GoldMint.Alerts:Evaluate("logistics")
    end
    return self:GetSummary()
end

function Logistics:GetOutgoing(includeDelivered)
    local result = {}
    for _, record in ipairs(EnsureStore().outgoing) do
        if includeDelivered == true or record.status ~= "delivered" then
            result[#result + 1] = record
        end
    end
    table.sort(result, function(a, b) return (a.sentAt or 0) > (b.sentAt or 0) end)
    return result
end

function Logistics:GetAuctionCandidates()
    return EnsureStore().auctionCandidates
end

function Logistics:GetPendingMailCount()
    local count = 0
    for _, record in ipairs(EnsureStore().outgoing) do
        if record.status == "sent" then count = count + 1 end
    end
    return count
end

function Logistics:GetSummary()
    local candidates = EnsureStore().auctionCandidates
    local auctionCount, auctionValue = 0, 0
    for _, candidate in ipairs(candidates) do
        auctionCount = auctionCount + (tonumber(candidate.quantity) or 0)
        auctionValue = auctionValue + (tonumber(candidate.totalValue) or 0)
    end
    return {
        pendingMail = self:GetPendingMailCount(),
        auctionItemCount = auctionCount,
        auctionCandidateCount = #candidates,
        auctionCandidateValue = auctionValue,
        lastScanAt = EnsureStore().lastScanAt,
    }
end

function Logistics:UpdateWorkflow()
    if not GoldMint.WorkflowState then return false end

    local pendingMail = self:GetPendingMailCount()
    local candidates = EnsureStore().auctionCandidates
    local auctionUnits = 0
    local auctionValue = 0
    for _, candidate in ipairs(candidates) do
        auctionUnits = auctionUnits + (tonumber(candidate.quantity) or 0)
        auctionValue = auctionValue + (tonumber(candidate.totalValue) or 0)
    end

    local title, details, id
    if pendingMail > 0 then
        title = string.format("Check mail delivery to %d character(s)", pendingMail)
        details = "GoldMint is waiting for the destination character to show the mail in an observed mailbox scan."
        id = "logistics-mail-delivery"
    elseif auctionUnits > 0 then
        title = string.format("Post %d auction item(s)", auctionUnits)
        details = string.format("Observed sellable bag items worth about %s at current tracked values.", GoldMint.Ledger and GoldMint.Ledger:FormatGoldFull(auctionValue) or tostring(auctionValue))
        id = "logistics-auction-posting"
    else
        -- Do not erase a player-authored next action. Only clear a previous
        -- logistics action when the evidence that created it is gone.
        local current = GoldMint.WorkflowState:GetNextAction()
        if current and current.source == "logistics" then
            GoldMint.WorkflowState:ClearNextAction()
        end
        return true
    end

    local current = GoldMint.WorkflowState:GetNextAction()
    if current and current.source ~= "logistics" then
        return true
    end
    if current and current.id == id and current.details == details then
        return true
    end
    GoldMint.WorkflowState:SetSystemNextAction(title, id, details, "logistics")
    return true
end
