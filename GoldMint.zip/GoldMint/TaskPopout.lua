local ADDON_NAME, GoldMint = ...

-- GoldMint Current Tasks popout.
-- A compact, movable on-screen companion for the player's current workflow.
GoldMint.TaskPopout = {}
local TaskPopout = GoldMint.TaskPopout

local frame
local labels = {}
local todoRows = {}

local CYAN = {0.20, 0.78, 1.00}
local GOLD = {1.00, 0.78, 0.20}
local MUTED = {0.60, 0.74, 0.88}
local WHITE = {0.90, 0.94, 1.00}
local GREEN = {0.20, 1.00, 0.40}

local function EnsureSettings()
    GoldMintDB.settings = type(GoldMintDB.settings) == "table" and GoldMintDB.settings or {}
    local s = GoldMintDB.settings
    if s.taskPopoutX == nil then s.taskPopoutX = nil end
    if s.taskPopoutY == nil then s.taskPopoutY = nil end
    return s
end

local function MakeLabel(parent, font, text, color)
    local label = parent:CreateFontString(nil, "OVERLAY", font)
    label:SetJustifyH("LEFT")
    label:SetText(text or "")
    if color then label:SetTextColor(unpack(color)) end
    return label
end

local function MakeButton(parent, text, width, height)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height)
    b:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true, tileSize = 8, edgeSize = 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    b:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
    b:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
    b.text = MakeLabel(b, "GameFontNormal", text, MUTED)
    b.text:SetPoint("CENTER")
    b:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.055, 0.11, 0.16, 1.0)
        self:SetBackdropBorderColor(unpack(GOLD))
        self.text:SetTextColor(unpack(GOLD))
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0.018, 0.055, 0.090, 0.98)
        self:SetBackdropBorderColor(0.10, 0.34, 0.52, 1.0)
        self.text:SetTextColor(unpack(MUTED))
    end)
    return b
end

local function SavePosition()
    if not frame then return end
    local s = EnsureSettings()
    local point, _, _, x, y = frame:GetPoint(1)
    if point then
        s.taskPopoutPoint = point
        s.taskPopoutX = x
        s.taskPopoutY = y
    end
end

local function RestorePosition()
    if not frame then return end
    local s = EnsureSettings()
    frame:ClearAllPoints()
    if s.taskPopoutPoint and s.taskPopoutX and s.taskPopoutY then
        frame:SetPoint(s.taskPopoutPoint, UIParent, s.taskPopoutPoint, s.taskPopoutX, s.taskPopoutY)
    else
        frame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -32, -150)
    end
end

local function ClearTodoRows()
    for _, row in ipairs(todoRows) do row:Hide() end
end

local function Refresh()
    if not frame or not frame:IsShown() then return end

    local workflow = GoldMint.WorkflowState
    local task = workflow and workflow.GetCurrentTask and workflow:GetCurrentTask() or nil
    local nextAction = workflow and workflow.GetNextAction and workflow:GetNextAction() or nil

    labels.task:SetText(task and tostring(task.title or "Current task") or "No current task")
    labels.task:SetTextColor(unpack(task and WHITE or MUTED))
    labels.taskDetail:SetText(task and tostring(task.details or "") or "Set a task from Projects, Routines, or /gm workflow task.")

    labels.next:SetText(nextAction and tostring(nextAction.title or "Next suggestion") or "No next suggestion")
    labels.next:SetTextColor(unpack(nextAction and GOLD or MUTED))
    labels.nextDetail:SetText(nextAction and tostring(nextAction.details or "") or "GoldMint will show the next recorded workflow action here.")

    ClearTodoRows()
    local todos = workflow and workflow.GetManualTodos and workflow:GetManualTodos() or {}
    local shown = 0
    for _, todo in ipairs(todos) do
        if shown >= 4 then break end
        if not todo.completed then
            shown = shown + 1
            local row = todoRows[shown]
            if not row then
                row = CreateFrame("Button", nil, frame, "BackdropTemplate")
                row:SetSize(270, 26)
                row.check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
                row.check:SetSize(22, 22)
                row.check:SetPoint("LEFT", 0, 0)
                if row.check.GetCheckedTexture and row.check:GetCheckedTexture() then
                    row.check:GetCheckedTexture():SetVertexColor(unpack(GREEN))
                end
                row.text = MakeLabel(row, "GameFontNormalSmall", "", MUTED)
                row.text:SetPoint("LEFT", 26, 0)
                row.text:SetPoint("RIGHT", -4, 0)
                row.text:SetWordWrap(false)
                row.check:SetScript("OnClick", function(self)
                    local id = row.todoID
                    if id and GoldMint.WorkflowState then
                        GoldMint.WorkflowState:ToggleManualTodo(id)
                        Refresh()
                    end
                end)
                todoRows[shown] = row
            end
            row.todoID = todo.id
            row.text:SetText(todo.title or "Task")
            row.check:SetChecked(false)
            row:SetPoint("TOPLEFT", 26, -238 - ((shown - 1) * 27))
            row:Show()
        end
    end

    if shown > 0 then
        labels.todoHeader:Show()
    else
        labels.todoHeader:Hide()
    end
end

function TaskPopout:Initialize()
    if frame then return end

    frame = CreateFrame("Frame", "GoldMintTaskPopoutFrame", UIParent, "BackdropTemplate")
    frame:SetSize(310, 345)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); SavePosition() end)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = {left = 4, right = 4, top = 4, bottom = 4},
    })
    frame:SetBackdropColor(0.008, 0.018, 0.026, 0.97)
    frame:SetBackdropBorderColor(0.10, 0.40, 0.62, 0.95)

    labels.title = MakeLabel(frame, "GameFontHighlightLarge", "GOLDMINT", CYAN)
    labels.title:SetPoint("TOPLEFT", 18, -14)
    labels.subtitle = MakeLabel(frame, "GameFontNormalSmall", "CURRENT TASKS", MUTED)
    labels.subtitle:SetPoint("TOPLEFT", 19, -36)

    local close = MakeButton(frame, "×", 24, 24)
    close:SetPoint("TOPRIGHT", -8, -8)
    close.text:SetFont(close.text:GetFont(), 16, "")
    close:SetScript("OnClick", function() frame:Hide() end)

    local refreshButton = MakeButton(frame, "Refresh", 66, 22)
    refreshButton:SetPoint("TOPRIGHT", -38, -42)
    refreshButton:SetScript("OnClick", Refresh)

    labels.taskHeader = MakeLabel(frame, "GameFontHighlight", "CURRENT TASK", CYAN)
    labels.taskHeader:SetPoint("TOPLEFT", 18, -66)
    labels.task = MakeLabel(frame, "GameFontNormal", "No current task", WHITE)
    labels.task:SetPoint("TOPLEFT", 18, -88)
    labels.task:SetWidth(274)
    labels.taskDetail = MakeLabel(frame, "GameFontNormalSmall", "", MUTED)
    labels.taskDetail:SetPoint("TOPLEFT", 18, -111)
    labels.taskDetail:SetWidth(274)
    labels.taskDetail:SetHeight(34)
    labels.taskDetail:SetWordWrap(true)

    labels.nextHeader = MakeLabel(frame, "GameFontHighlight", "NEXT SUGGESTION", CYAN)
    labels.nextHeader:SetPoint("TOPLEFT", 18, -154)
    labels.next = MakeLabel(frame, "GameFontNormal", "No next suggestion", GOLD)
    labels.next:SetPoint("TOPLEFT", 18, -176)
    labels.next:SetWidth(274)
    labels.nextDetail = MakeLabel(frame, "GameFontNormalSmall", "", MUTED)
    labels.nextDetail:SetPoint("TOPLEFT", 18, -199)
    labels.nextDetail:SetWidth(274)
    labels.nextDetail:SetHeight(34)
    labels.nextDetail:SetWordWrap(true)

    labels.todoHeader = MakeLabel(frame, "GameFontHighlight", "OPEN TASKS", CYAN)
    labels.todoHeader:SetPoint("TOPLEFT", 18, -226)

    local options = MakeButton(frame, "TASK OPTIONS", 112, 24)
    options:SetPoint("BOTTOMLEFT", 18, 12)
    options:SetScript("OnClick", function()
        if GoldMint.OpenOptions then GoldMint:OpenOptions("Accessibility") end
    end)

    RestorePosition()
    frame:SetScript("OnShow", Refresh)
    frame:Hide()
    self.frame = frame
end

function TaskPopout:Show()
    if not frame then self:Initialize() end
    frame:Show()
    frame:Raise()
    Refresh()
end

function TaskPopout:Hide()
    if frame then frame:Hide() end
end

function TaskPopout:Toggle()
    if not frame then self:Initialize() end
    if frame:IsShown() then self:Hide() else self:Show() end
end

function TaskPopout:Refresh()
    if frame and frame:IsShown() then Refresh() end
end
