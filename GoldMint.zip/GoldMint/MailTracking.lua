local ADDON_NAME, GoldMint = ...

-- GoldMint Mail Tracking
--
-- Mail is only considered "known" after the WoW mailbox data has been queried.
-- This module records the last observed inbox for each character and exposes a
-- small read model for the Hub/alert system. It never invents outgoing mail or
-- expected transfers that the game API has not established.

GoldMint.MailTracking = {}
local Mail = GoldMint.MailTracking

local STORE_VERSION = 1
local MAX_MESSAGES = 100
local scanPending = false
local mailboxOpen = false
local lastScanAt = 0
local pendingMailPrimed = false
local mailboxSessionActive = false
local suppressNextPendingMailEvent = false
local lastPendingMailAlertAt = 0

local function Now()
    return time()
end

local function CurrentCharacterKey()
    return GoldMint.characterKey
end

local function EnsureStore()
    GoldMintDB.mailTracking = type(GoldMintDB.mailTracking) == "table" and GoldMintDB.mailTracking or {}
    local store = GoldMintDB.mailTracking
    store.version = math.max(tonumber(store.version) or 0, STORE_VERSION)
    store.characters = type(store.characters) == "table" and store.characters or {}
    return store
end

local function EnsureCharacterStore(characterKey)
    local store = EnsureStore()
    characterKey = characterKey or CurrentCharacterKey()
    if not characterKey then return nil end

    store.characters[characterKey] = type(store.characters[characterKey]) == "table" and store.characters[characterKey] or {}
    local character = store.characters[characterKey]
    character.messages = type(character.messages) == "table" and character.messages or {}
    character.lastScanAt = tonumber(character.lastScanAt) or 0
    character.mailCount = tonumber(character.mailCount) or 0
    character.attachmentCount = tonumber(character.attachmentCount) or 0
    character.moneyTotal = tonumber(character.moneyTotal) or 0
    character.externalMoneyTotal = tonumber(character.externalMoneyTotal) or 0
    character.auctionMoneyTotal = tonumber(character.auctionMoneyTotal) or 0
    character.unreadCount = tonumber(character.unreadCount) or 0
    character.internalCount = tonumber(character.internalCount) or 0
    return character
end

local function IsKnownCharacterSender(sender)
    if not sender or sender == "" or type(GoldMintDB.characters) ~= "table" then
        return false
    end

    local senderName = tostring(sender):lower()
    for key, character in pairs(GoldMintDB.characters) do
        if type(character) == "table" and character.name and tostring(character.name):lower() == senderName then
            if key ~= CurrentCharacterKey() then
                return true
            end
        end
    end
    return false
end

local function SafeHeader(index)
    if not GetInboxHeaderInfo then return nil end
    return GetInboxHeaderInfo(index)
end

local function BuildMessage(index)
    local packageIcon, stationeryIcon, sender, subject, money, codAmount, daysLeft, hasItem, wasRead, wasReturned, textCreated, canReply, isGM = SafeHeader(index)
    if not sender and not subject and not hasItem and not money then
        return nil
    end

    -- Auction House mail is real mailbox money, but it is intentionally kept
    -- out of Wealth's "Mail Value" because GoldMint tracks auction proceeds
    -- separately. GetInboxInvoiceInfo is the authoritative way to identify
    -- Auction House invoices, including the temporary "Sale Pending" mail
    -- whose header money is correctly reported as zero.
    local invoiceType, invoiceItemName, invoicePlayerName
    if type(GetInboxInvoiceInfo) == "function" then
        local ok, a, b, c = pcall(GetInboxInvoiceInfo, index)
        if ok then
            invoiceType, invoiceItemName, invoicePlayerName = a, b, c
        end
    end
    local auctionHouse = invoiceType ~= nil

    local attachments = {}
    local attachmentTotal = 0
    local maxAttachments = tonumber(ATTACHMENTS_MAX_RECEIVE) or 12

    if hasItem then
        for attachmentIndex = 1, maxAttachments do
            local name, itemID, texture, count, quality, canUse
            if GetInboxItem then
                name, itemID, texture, count, quality, canUse = GetInboxItem(index, attachmentIndex)
            end
            if name then
                attachments[#attachments + 1] = {
                    name = tostring(name),
                    itemID = tonumber(itemID) or 0,
                    texture = texture,
                    count = tonumber(count) or 1,
                    quality = tonumber(quality),
                    canUse = canUse and true or false,
                }
                attachmentTotal = attachmentTotal + (tonumber(count) or 1)
            end
        end
    end

    local internal = IsKnownCharacterSender(sender)
    local id = table.concat({
        tostring(sender or ""),
        tostring(subject or ""),
        tostring(money or 0),
        tostring(codAmount or 0),
        tostring(daysLeft or 0),
    }, "|")

    return {
        id = id,
        index = index,
        sender = tostring(sender or "Unknown"),
        subject = tostring(subject or ""),
        money = tonumber(money) or 0,
        codAmount = tonumber(codAmount) or 0,
        daysLeft = tonumber(daysLeft) or 0,
        hasItem = hasItem and true or false,
        attachmentCount = #attachments,
        attachmentTotal = attachmentTotal,
        attachments = attachments,
        wasRead = wasRead and true or false,
        wasReturned = wasReturned and true or false,
        canReply = canReply and true or false,
        isGM = isGM and true or false,
        internal = internal,
        auctionHouse = auctionHouse,
        invoiceType = invoiceType,
        observedAt = Now(),
    }
end

local function SortMessages(messages)
    table.sort(messages, function(a, b)
        local ad = tonumber(a.daysLeft) or math.huge
        local bd = tonumber(b.daysLeft) or math.huge
        if ad ~= bd then return ad < bd end
        if a.wasRead ~= b.wasRead then return not a.wasRead end
        return (tonumber(a.observedAt) or 0) > (tonumber(b.observedAt) or 0)
    end)
end

function Mail:Initialize()
    scanPending = false
    mailboxSessionActive = false
    suppressNextPendingMailEvent = false
    pendingMailPrimed = false
    lastPendingMailAlertAt = 0
    EnsureStore()
    EnsureCharacterStore()

    -- UPDATE_PENDING_MAIL also fires when the player enters the world with
    -- mail already waiting. Prime the state first so logging in does not
    -- masquerade as a newly received message.
    if C_Timer and C_Timer.After then
        C_Timer.After(1.5, function()
            if GoldMint.MailTracking ~= Mail then return end
            pendingMailPrimed = true
            -- UPDATE_PENDING_MAIL can fire before the addon has finished
            -- initializing. Check once after priming so mail already waiting
            -- on login is still announced instead of being missed forever.
            Mail:TryAnnouncePendingMail("login")
        end)
    else
        pendingMailPrimed = true
        Mail:TryAnnouncePendingMail("login")
    end
    return true
end

function Mail:IsMailboxOpen()
    if MailFrame and MailFrame.IsShown then
        return MailFrame:IsShown()
    end
    return mailboxOpen
end

function Mail:Scan(reason)
    if not GetInboxNumItems or not self:IsMailboxOpen() then
        return false
    end

    local character = EnsureCharacterStore()
    if not character then return false end

    local count, totalItems = GetInboxNumItems()
    count = tonumber(count) or 0
    totalItems = tonumber(totalItems) or count

    local messages = {}
    local moneyTotal = 0
    local externalMoneyTotal = 0
    local unreadCount = 0
    local attachmentCount = 0
    local internalCount = 0
    local auctionMoneyTotal = 0

    for index = 1, count do
        local message = BuildMessage(index)
        if message then
            messages[#messages + 1] = message
            local messageMoney = tonumber(message.money) or 0
            moneyTotal = moneyTotal + messageMoney
            if message.auctionHouse then
                auctionMoneyTotal = auctionMoneyTotal + messageMoney
            elseif not message.internal then
                externalMoneyTotal = externalMoneyTotal + messageMoney
            end
            attachmentCount = attachmentCount + (tonumber(message.attachmentCount) or 0)
            if not message.wasRead then unreadCount = unreadCount + 1 end
            if message.internal then internalCount = internalCount + 1 end
        end
    end

    SortMessages(messages)
    while #messages > MAX_MESSAGES do
        table.remove(messages)
    end

    character.messages = messages
    character.lastScanAt = Now()
    character.mailCount = count
    character.totalItems = totalItems
    character.attachmentCount = attachmentCount
    character.moneyTotal = moneyTotal
    character.externalMoneyTotal = externalMoneyTotal
    character.auctionMoneyTotal = auctionMoneyTotal
    character.unreadCount = unreadCount
    character.internalCount = internalCount
    character.lastReason = reason and tostring(reason) or nil
    lastScanAt = character.lastScanAt

    return true
end

function Mail:RequestScan(reason, delay)
    if scanPending then return false end
    if not self:IsMailboxOpen() then return false end

    scanPending = true
    GoldMint:ScheduleGuardedCallback(self, "mail-scan", tonumber(delay) or 0.2, function()
        scanPending = false
        if GoldMint.MailTracking and GoldMint.MailTracking:IsMailboxOpen() then
            GoldMint.MailTracking:Scan(reason)
            if GoldMint.Economy then
                GoldMint.Economy:ScheduleRefresh("mail:" .. tostring(reason or "scan"))
            end
            if GoldMint.WorkflowState then
                GoldMint.WorkflowState:TouchActivity("mail", "Managing mail")
            end
        end
    end)
    return true
end

function Mail:OnMailShow()
    mailboxOpen = true
    mailboxSessionActive = true
    suppressNextPendingMailEvent = false
    self:RequestScan("mail_show", 0.25)
end

function Mail:OnMailInboxUpdate()
    if self:IsMailboxOpen() then
        self:RequestScan("mail_update", 0.15)
    end
end

function Mail:OnMailClosed()
    mailboxOpen = false
    -- UPDATE_PENDING_MAIL can fire when a mailbox closes after its inbox count
    -- changed. That is a mailbox-management event, not proof that new mail
    -- arrived, so suppress the next pending-mail notification from this session.
    if mailboxSessionActive then
        suppressNextPendingMailEvent = true
        if C_Timer and C_Timer.After then
            C_Timer.After(1.0, function()
                suppressNextPendingMailEvent = false
            end)
        end
    end
    mailboxSessionActive = false
end

function Mail:TryAnnouncePendingMail(reason)
    if not pendingMailPrimed then return false end

    if suppressNextPendingMailEvent then
        suppressNextPendingMailEvent = false
        return false
    end

    if type(HasNewMail) ~= "function" or not HasNewMail() then
        return false
    end

    local now = Now()
    if now - (lastPendingMailAlertAt or 0) < 3 then
        return false
    end
    lastPendingMailAlertAt = now

    if GoldMint.Alerts and GoldMint.Alerts.Push then
        return GoldMint.Alerts:Push("NEW MAIL", "You have mail waiting in your mailbox.", {
            id = "mail-arrival-" .. tostring(now),
            dedupeKey = "mail-arrival",
            priority = 90,
            ttl = 18,
            category = "mail",
        }) and true or false
    end
    return false
end

function Mail:OnPendingMailUpdate()
    -- The first pending-mail event can arrive before the delayed startup
    -- priming completes. Recheck after priming rather than losing the event.
    if not pendingMailPrimed then
        if C_Timer and C_Timer.After then
            C_Timer.After(1.6, function()
                if GoldMint.MailTracking == Mail then
                    pendingMailPrimed = true
                    Mail:TryAnnouncePendingMail("delayed_pending_mail")
                end
            end)
        end
        return false
    end
    return self:TryAnnouncePendingMail("pending_mail_update")
end

function Mail:GetState(characterKey)
    local character = EnsureCharacterStore(characterKey or CurrentCharacterKey())
    if not character then return nil end

    local messages = {}
    for _, message in ipairs(character.messages or {}) do
        messages[#messages + 1] = message
    end
    SortMessages(messages)

    return {
        characterKey = characterKey or CurrentCharacterKey(),
        mailCount = tonumber(character.mailCount) or 0,
        totalItems = tonumber(character.totalItems) or 0,
        attachmentCount = tonumber(character.attachmentCount) or 0,
        moneyTotal = tonumber(character.moneyTotal) or 0,
        externalMoneyTotal = tonumber(character.externalMoneyTotal) or 0,
        auctionMoneyTotal = tonumber(character.auctionMoneyTotal) or 0,
        messages = messages,
        unreadCount = tonumber(character.unreadCount) or 0,
        internalCount = tonumber(character.internalCount) or 0,
        lastScanAt = tonumber(character.lastScanAt) or 0,
        lastReason = character.lastReason,
        messages = messages,
        mailboxOpen = self:IsMailboxOpen(),
    }
end

function Mail:GetAccountExternalMoneyTotal()
    local store = EnsureStore()
    local total = 0
    for _, character in pairs(store.characters or {}) do
        if type(character) == "table" then
            total = total + (tonumber(character.externalMoneyTotal) or 0)
        end
    end
    return total
end

function Mail:GetSummary(characterKey)
    local state = self:GetState(characterKey)
    if not state then return nil end
    return {
        characterKey = state.characterKey,
        mailCount = state.mailCount,
        totalItems = state.totalItems,
        attachmentCount = state.attachmentCount,
        moneyTotal = state.moneyTotal,
        unreadCount = state.unreadCount,
        internalCount = state.internalCount,
        lastScanAt = state.lastScanAt,
        mailboxOpen = state.mailboxOpen,
    }
end

function Mail:GetMessages(characterKey)
    local state = self:GetState(characterKey)
    return state and state.messages or {}
end

function Mail:HasPendingMail(characterKey)
    local state = self:GetState(characterKey)
    return state and ((state.mailCount or 0) > 0 or (state.attachmentCount or 0) > 0) or false
end

function Mail:ClearCharacter(characterKey)
    local store = EnsureStore()
    characterKey = characterKey or CurrentCharacterKey()
    if not characterKey then return false end
    store.characters[characterKey] = nil
    return true
end

function Mail:GetStatus()
    local state = self:GetState()
    if not state then return nil end
    return {
        version = STORE_VERSION,
        characterKey = state.characterKey,
        mailCount = state.mailCount,
        attachmentCount = state.attachmentCount,
        moneyTotal = state.moneyTotal,
        unreadCount = state.unreadCount,
        internalCount = state.internalCount,
        lastScanAt = state.lastScanAt,
        mailboxOpen = state.mailboxOpen,
        messageCount = #state.messages,
    }
end
