local ADDON_NAME, GoldMint = ...

-- ============================================================================
-- GOLDMINT ROUTINES
-- ============================================================================
--
-- Passive daily/weekly routine tracking. A built-in catalog identifies
-- important repeatable activities without requiring the player to visit every
-- hub. Each character is synchronized automatically when they log in. The
-- live quest log is also observed so GoldMint can learn additional repeatable
-- activities without manual scans or commands.
--
-- The eventual UI can read this database to present:
--   Current Expansion
--   Legacy Content -> expansion sections
--   Daily / Weekly
--   Ready / Completed
--   Character assignment
--
-- Nothing is printed during automatic observation.
-- ============================================================================

GoldMint.Routines = {}
local Routines = GoldMint.Routines

local STORE_VERSION = 7
local SCAN_INTERVAL = 10
local STATE_REFRESH_INTERVAL = 30
local FREQUENCY_DAILY = 1
local FREQUENCY_WEEKLY = 2
local FREQUENCY_SCHEDULED = 3

local function Now()
    return time()
end

local function EnsureStore()
    GoldMintDB.routines = type(GoldMintDB.routines) == "table" and GoldMintDB.routines or {}
    local savedVersion = tonumber(GoldMintDB.routines.version) or 0
    GoldMintDB.routines.version = math.max(savedVersion, STORE_VERSION)
    GoldMintDB.routines.quests = type(GoldMintDB.routines.quests) == "table" and GoldMintDB.routines.quests or {}
    GoldMintDB.routines.characters = type(GoldMintDB.routines.characters) == "table" and GoldMintDB.routines.characters or {}
    return GoldMintDB.routines
end

local function GetCharacterKey()
    return GoldMint.characterKey
end

local function GetCatalogQuest(questID)
    if GoldMint.RoutineCatalog and GoldMint.RoutineCatalog.Get then
        return GoldMint.RoutineCatalog:Get(questID)
    end
    return nil
end

local function GetCatalogExpansion(expansionID)
    if GoldMint.RoutineCatalog and GoldMint.RoutineCatalog.GetExpansion then
        return GoldMint.RoutineCatalog:GetExpansion(expansionID)
    end
    return nil
end

local function CharacterHasQuestInLog(questID)
    if not C_QuestLog or not C_QuestLog.GetLogIndexForQuestID then
        return false
    end
    local index = C_QuestLog.GetLogIndexForQuestID(questID)
    if not index or not C_QuestLog.GetInfo then
        return false
    end
    local info = C_QuestLog.GetInfo(index)
    return info ~= nil and not info.isHeader
end

local function GetExpansionName(expansionID)
    expansionID = tonumber(expansionID)
    if not expansionID then
        return "Unknown"
    end

    if type(_G["EXPANSION_NAME" .. expansionID]) == "string" then
        return _G["EXPANSION_NAME" .. expansionID]
    end

    if GetExpansionDisplayInfo then
        local info = GetExpansionDisplayInfo(expansionID)
        if info and info.name then
            return info.name
        end
    end

    return "Expansion " .. tostring(expansionID)
end

local function GetQuestFrequency(info, questID)
    if info and info.frequency ~= nil then
        return tonumber(info.frequency)
    end

    -- A quest can be observed after it leaves the quest log.  The stored
    -- frequency is retained in that case; never guess from the quest name.
    return nil
end

local function GetQuestExpansion(questID)
    if GetQuestExpansion then
        local ok, expansionID = pcall(GetQuestExpansion, questID)
        if ok and expansionID ~= nil then
            return tonumber(expansionID)
        end
    end

    return nil
end

local function GetQuestInfoByID(questID)
    if not C_QuestLog then
        return nil
    end

    local index = C_QuestLog.GetLogIndexForQuestID and C_QuestLog.GetLogIndexForQuestID(questID)
    if index then
        local info = C_QuestLog.GetInfo and C_QuestLog.GetInfo(index)
        if info then
            return info
        end
    end

    return nil
end

local function UpsertQuest(questID, info)
    if not questID or questID <= 0 then
        return nil
    end

    local store = EnsureStore()
    local record = store.quests[questID]
    if not record then
        record = {
            questID = questID,
            firstSeen = Now(),
            characters = {},
        }
        store.quests[questID] = record
    end

    local catalog = GetCatalogQuest(questID)

    local title = (info and info.title) or (catalog and catalog.title)
    if not title and C_QuestLog and C_QuestLog.GetTitleForQuestID then
        title = C_QuestLog.GetTitleForQuestID(questID)
    end
    if title and title ~= "" then
        record.title = title
    end

    -- Quest level is captured when Blizzard exposes it. This lets GoldMint
    -- avoid surfacing quests above the current character's level without
    -- maintaining a hand-written level table.
    if info and tonumber(info.level) then
        record.questLevel = tonumber(info.level)
    elseif info and tonumber(info.suggestedLevel) then
        record.questLevel = tonumber(info.suggestedLevel)
    end

    local frequency = GetQuestFrequency(info, questID) or (catalog and catalog.frequency)
    if frequency and frequency > 0 then
        record.frequency = frequency
    end

    local expansionID = GetQuestExpansion(questID)
    if expansionID == nil and catalog then
        expansionID = tonumber(catalog.expansionID)
    end
    if expansionID ~= nil then
        record.expansionID = expansionID
        local expansion = GetCatalogExpansion(expansionID)
        record.expansionName = (catalog and catalog.expansionName) or (expansion and expansion.name) or GetExpansionName(expansionID)
        record.era = (catalog and catalog.era) or (expansion and expansion.era) or "Legacy"
    end

    if catalog then
        record.category = catalog.category
        record.activity = catalog.activity
        record.catalogVersion = GoldMint.RoutineCatalog and GoldMint.RoutineCatalog.version or 1
    end

    record.lastSeen = Now()
    record.characters = type(record.characters) == "table" and record.characters or {}

    local characterKey = GetCharacterKey()
    local character = record.characters[characterKey]
    if not character then
        character = {}
        record.characters[characterKey] = character
    end

    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.lastSeen = Now()
    character.level = UnitLevel("player") or character.level or 0
    if frequency and frequency > 0 then
        character.frequency = frequency
    end

    -- Capture current completion state while the quest is still available in
    -- the log.  We do not infer completion for quests we have never observed.
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
        local completed = C_QuestLog.IsQuestFlaggedCompleted(questID)
        if completed then
            character.lastCompleted = character.lastCompleted or Now()
        end
    end

    if GoldMint.ContentProgression then
        GoldMint.ContentProgression:ObserveQuestRecord(record, characterKey)
    end

    return record
end

function Routines:SyncCatalogForCurrentCharacter()
    local catalog = GoldMint.RoutineCatalog
    if not catalog or type(catalog.quests) ~= "table" then
        return 0
    end

    local synced = 0
    for questID, entry in pairs(catalog.quests) do
        local id = tonumber(questID)
        if id then
            local completed = false
            if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
                completed = C_QuestLog.IsQuestFlaggedCompleted(id) == true
            end

            -- A false completion result is ambiguous: the character may simply
            -- have never unlocked the activity. Only create a character record
            -- when the game gives us positive evidence (completed or currently
            -- present in the quest log). This prevents GoldMint from claiming
            -- that every alt has an available quest they may not have unlocked.
            if completed or CharacterHasQuestInLog(id) then
                local info = GetQuestInfoByID(id)
                if not info then
                    info = {
                        questID = id,
                        title = entry.title,
                        frequency = entry.frequency,
                    }
                end
                local record = UpsertQuest(id, info)
                if record then
                    local characterKey = GetCharacterKey()
                    local character = record.characters[characterKey] or {}
                    character.name = GoldMint.characterName
                    character.realm = GoldMint.characterRealm
                    character.lastSeen = Now()
                    character.catalogSeen = true
                    character.knownToCharacter = true
                    character.frequency = record.frequency or entry.frequency
                    if completed then
                        character.lastCompleted = character.lastCompleted or Now()
                        character.completedState = true
                    else
                        character.completedState = false
                    end
                    record.characters[characterKey] = character
                    record.lastSeen = Now()
                    synced = synced + 1
                end
            end
        end
    end

    return synced
end

function Routines:SyncCurrentCharacter()
    local scanned = self:ScanQuestLog()
    local catalog = self:SyncCatalogForCurrentCharacter()
    local character = EnsureStore().characters[GetCharacterKey()] or {}
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.level = UnitLevel("player") or character.level or 0
    character.lastLoginSync = character.lastLoginSync or Now()
    character.lastScan = Now()
    character.lastQuestLogCount = scanned
    character.currentExpansion = (GetExpansionLevel and tonumber(GetExpansionLevel())) or character.currentExpansion
    character.lastStateCheck = Now()
    EnsureStore().characters[GetCharacterKey()] = character
    return scanned, catalog
end

function Routines:ScanQuestLog()
    if not C_QuestLog or not C_QuestLog.GetNumQuestLogEntries or not C_QuestLog.GetInfo then
        return 0
    end

    local store = EnsureStore()
    local scanned = 0
    local count = select(2, C_QuestLog.GetNumQuestLogEntries()) or 0

    for index = 1, count do
        local info = C_QuestLog.GetInfo(index)
        if info and not info.isHeader and info.questID then
            local frequency = tonumber(info.frequency)
            -- The routine database is intentionally limited to repeatable
            -- daily/weekly/scheduled quests. Normal story/side quests do not
            -- become routine clutter.
            if frequency == FREQUENCY_DAILY or frequency == FREQUENCY_WEEKLY or frequency == FREQUENCY_SCHEDULED then
                local record = UpsertQuest(info.questID, info)
                if record then
                    local characterKey = GetCharacterKey()
                    local character = record.characters[characterKey] or {}
                    character.name = GoldMint.characterName
                    character.realm = GoldMint.characterRealm
                    character.level = UnitLevel("player") or character.level or 0
                    character.lastSeen = Now()
                    character.knownToCharacter = true
                    character.completedState = self:GetStatus(record, characterKey) == "completed"
                    record.characters[characterKey] = character
                    scanned = scanned + 1
                end
            end
        end
    end

    local character = store.characters[GetCharacterKey()] or {}
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.lastScan = Now()
    store.characters[GetCharacterKey()] = character

    return scanned
end

function Routines:RecordTurnIn(questID)
    if not questID then
        return
    end

    local store = EnsureStore()
    local record = store.quests[questID]
    local info = GetQuestInfoByID(questID)

    -- If the quest was already observed, preserve its known frequency and
    -- expansion even if WoW has already removed it from the quest log.
    if not record then
        record = UpsertQuest(questID, info)
    end
    if not record then
        return
    end

    local catalog = GetCatalogQuest(questID)
    local frequency = record.frequency or GetQuestFrequency(info, questID) or (catalog and catalog.frequency)
    if frequency ~= FREQUENCY_DAILY and frequency ~= FREQUENCY_WEEKLY and frequency ~= FREQUENCY_SCHEDULED then
        return
    end

    local characterKey = GetCharacterKey()
    record.characters = record.characters or {}
    local character = record.characters[characterKey] or {}
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.level = UnitLevel("player") or character.level or 0
    character.knownToCharacter = true
    character.completedState = true
    character.lastCompleted = Now()
    character.lastSeen = Now()
    record.characters[characterKey] = character
    record.lastCompleted = Now()
    record.lastCompletedBy = characterKey
end

function Routines:RecordAccepted(questID)
    if not questID then
        return
    end

    local info = GetQuestInfoByID(questID)
    local frequency = GetQuestFrequency(info, questID)
    if frequency == FREQUENCY_DAILY or frequency == FREQUENCY_WEEKLY or frequency == FREQUENCY_SCHEDULED then
        local record = UpsertQuest(questID, info)
        if record then
            local characterKey = GetCharacterKey()
            local character = record.characters[characterKey] or {}
            character.name = GoldMint.characterName
            character.realm = GoldMint.characterRealm
            character.level = UnitLevel("player") or character.level or 0
            character.knownToCharacter = true
            character.lastSeen = Now()
            record.characters[characterKey] = character
        end
    end
end


local function RefreshStoredCharacterStates(characterKey)
    characterKey = characterKey or GetCharacterKey()
    local store = EnsureStore()
    local changed = 0

    -- Keep persisted state synchronized with the time-based resolver. This is
    -- silent and automatic, so relogs, reloads, and reset boundaries do not
    -- require a manual routine command.
    for _, record in pairs(store.quests) do
        local character = record.characters and record.characters[characterKey]
        if character and character.knownToCharacter == true then
            local status = Routines:GetStatus(record, characterKey)
            local completed = (status == "completed")
            if character.completedState ~= completed then
                character.completedState = completed
                changed = changed + 1
            end
            character.lastStateCheck = Now()
        end
    end

    local characterRecord = store.characters[characterKey]
    if characterRecord then
        characterRecord.lastStateCheck = Now()
        characterRecord.level = UnitLevel("player") or characterRecord.level or 0
        characterRecord.name = GoldMint.characterName
        characterRecord.realm = GoldMint.characterRealm
        characterRecord.currentExpansion = (GetExpansionLevel and tonumber(GetExpansionLevel())) or characterRecord.currentExpansion
    end

    store.lastStateRefresh = Now()
    return changed
end

local RefreshResetEpochs
local GetLastDailyReset
local GetLastWeeklyReset

function Routines:RefreshState()
    local dailyChanged, weeklyChanged = RefreshResetEpochs()
    if GoldMint.ContentProgression then
        GoldMint.ContentProgression:Refresh()
    end
    local scanned, catalog = self:SyncCurrentCharacter()
    RefreshStoredCharacterStates(GetCharacterKey())
    if GoldMint.RoutineState then
        GoldMint.RoutineState:SyncCharacter()
    end

    -- Automation layer: surface meaningful routine changes once, rather than
    -- repeatedly notifying on every background refresh.
    local store = EnsureStore()
    store.automation = type(store.automation) == "table" and store.automation or {}
    local summary = self:GetSummary()
    local readyCount = tonumber(summary.ready) or 0
    local previousReady = tonumber(store.automation.lastReadyCount)
    if previousReady ~= nil and previousReady >= 0 and readyCount > previousReady and GoldMint.Alerts then
        local delta = readyCount - previousReady
        GoldMint.Alerts:Push("ROUTINES READY", string.format("%d new routine %s ready to complete.", delta, delta == 1 and "is" or "are"), {
            id = "routine-ready-" .. tostring(time()),
            dedupeKey = "routine-ready-" .. tostring(time()),
            priority = 70,
            category = "routine",
        })
    end
    if previousReady ~= nil and previousReady > 0 and readyCount == 0 and GoldMint.Alerts then
        -- Do not notify when the list merely becomes empty; a completed routine
        -- already has its own transaction/event trail.
    end
    if dailyChanged and GoldMint.Alerts then
        GoldMint.Alerts:Push("DAILY RESET", "Daily routines have reset and are ready to review.", {
            id = "routine-daily-reset-" .. tostring(math.floor(GetLastDailyReset())),
            dedupeKey = "routine-daily-reset-" .. tostring(math.floor(GetLastDailyReset())),
            priority = 60,
            category = "routine",
        })
    end
    if weeklyChanged and GoldMint.Alerts then
        GoldMint.Alerts:Push("WEEKLY RESET", "Weekly routines have reset and are ready to review.", {
            id = "routine-weekly-reset-" .. tostring(math.floor(GetLastWeeklyReset())),
            dedupeKey = "routine-weekly-reset-" .. tostring(math.floor(GetLastWeeklyReset())),
            priority = 65,
            category = "routine",
        })
    end
    -- Account-wide automation: keep tracked alts current and surface a new
    -- ready routine on another character without requiring that character to
    -- be logged in right now.
    local accountSummary = self:GetAccountSummary()
    store.automation.accountReadyByCharacter = type(store.automation.accountReadyByCharacter) == "table" and store.automation.accountReadyByCharacter or {}
    for _, characterInfo in ipairs(accountSummary.characters) do
        local key = characterInfo.characterKey
        local previous = tonumber(store.automation.accountReadyByCharacter[key])
        if previous ~= nil and characterInfo.ready > previous and key ~= GetCharacterKey() and GoldMint.Alerts then
            local delta = characterInfo.ready - previous
            local label = characterInfo.name or key
            GoldMint.Alerts:Push("ALT ROUTINES READY", string.format("%s has %d new routine %s ready to complete.", label, delta, delta == 1 and "is" or "are"), {
                id = "routine-alt-ready-" .. tostring(key) .. "-" .. tostring(time()),
                dedupeKey = "routine-alt-ready-" .. tostring(key) .. "-" .. tostring(time()),
                priority = 55,
                category = "routine",
            })
        end
        store.automation.accountReadyByCharacter[key] = characterInfo.ready
    end
    store.automation.accountReadyTotal = accountSummary.ready
    store.automation.lastReadyCount = readyCount
    store.automation.initialized = true
    return scanned, catalog
end

local function GetSecondsUntilDailyReset()
    if C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset then
        local remaining = tonumber(C_DateAndTime.GetSecondsUntilDailyReset())
        if remaining and remaining >= 0 then
            return remaining
        end
    end

    if GetQuestResetTime then
        local remaining = tonumber(GetQuestResetTime())
        if remaining and remaining >= 0 then
            return remaining
        end
    end

    return 24 * 60 * 60
end

local function GetSecondsUntilWeeklyReset()
    if C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset then
        local remaining = tonumber(C_DateAndTime.GetSecondsUntilWeeklyReset())
        if remaining and remaining >= 0 then
            return remaining
        end
    end

    if C_DateAndTime and C_DateAndTime.GetWeeklyResetStartTime then
        local start = tonumber(C_DateAndTime.GetWeeklyResetStartTime())
        if start then
            local reset = start + (7 * 24 * 60 * 60)
            while reset <= Now() do
                reset = reset + (7 * 24 * 60 * 60)
            end
            return math.max(0, reset - Now())
        end
    end

    return 7 * 24 * 60 * 60
end

GetLastDailyReset = function()
    return Now() - (24 * 60 * 60 - GetSecondsUntilDailyReset())
end

GetLastWeeklyReset = function()
    return Now() - (7 * 24 * 60 * 60 - GetSecondsUntilWeeklyReset())
end

RefreshResetEpochs = function()
    local store = EnsureStore()
    local now = Now()
    local dailyReset = now - (24 * 60 * 60 - GetSecondsUntilDailyReset())
    local weeklyReset = now - (7 * 24 * 60 * 60 - GetSecondsUntilWeeklyReset())

    store.resetEpochs = type(store.resetEpochs) == "table" and store.resetEpochs or {}
    store.automation = type(store.automation) == "table" and store.automation or {}
    store.automation.lastReadyCount = tonumber(store.automation.lastReadyCount) or -1
    store.automation.initialized = store.automation.initialized == true
    local dailyChanged = tonumber(store.resetEpochs.daily) ~= tonumber(dailyReset)
    local weeklyChanged = tonumber(store.resetEpochs.weekly) ~= tonumber(weeklyReset)

    if dailyChanged or weeklyChanged then
        local characterKey = GetCharacterKey()
        for _, record in pairs(store.quests) do
            local character = record.characters and record.characters[characterKey]
            if character and character.knownToCharacter == true then
                local frequency = tonumber(record.frequency or character.frequency)
                if (dailyChanged and frequency == FREQUENCY_DAILY)
                    or (weeklyChanged and frequency == FREQUENCY_WEEKLY) then
                    -- The time-based resolver is authoritative, but clearing the
                    -- persisted completion flag keeps the saved database truthful
                    -- across reloads and makes reset transitions explicit.
                    character.completedState = false
                    character.lastStateCheck = now
                end
            end
        end
    end

    store.resetEpochs.daily = dailyReset
    store.resetEpochs.weekly = weeklyReset
    store.lastResetCheck = now
    return dailyChanged, weeklyChanged
end

local function IsRelevantForCharacter(record, characterKey)
    if not record then
        return false
    end

    local store = EnsureStore()
    local character = store.characters[characterKey]
    if not character then
        return false
    end

    local level = tonumber(character.level) or 0
    if level <= 0 then
        return true
    end

    local questLevel = tonumber(record.questLevel)
    if questLevel and questLevel > level then
        return false
    end

    return true
end

function Routines:GetCharacterLevel(characterKey)
    characterKey = characterKey or GetCharacterKey()
    local character = EnsureStore().characters[characterKey]
    return character and tonumber(character.level) or 0
end

function Routines:IsRelevantForCharacter(record, characterKey)
    return IsRelevantForCharacter(record, characterKey or GetCharacterKey())
end

function Routines:GetStatus(record, characterKey)
    if not record then
        return "unknown"
    end

    characterKey = characterKey or GetCharacterKey()
    local character = record.characters and record.characters[characterKey]
    if not character or character.knownToCharacter ~= true then
        return "unknown"
    end

    local completedAt = tonumber(character.lastCompleted)
    local frequency = tonumber(record.frequency or character.frequency)

    if frequency == FREQUENCY_DAILY then
        if not completedAt or completedAt < GetLastDailyReset() then
            return "ready"
        end
        return "completed"
    elseif frequency == FREQUENCY_WEEKLY then
        if not completedAt or completedAt < GetLastWeeklyReset() then
            return "ready"
        end
        return "completed"
    elseif frequency == FREQUENCY_SCHEDULED then
        return completedAt and "scheduled" or "ready"
    end

    return "unknown"
end

function Routines:GetCharacterQuests(characterKey)
    characterKey = characterKey or GetCharacterKey()
    local result = {}
    local store = EnsureStore()

    for _, record in pairs(store.quests) do
        local character = record.characters and record.characters[characterKey]
        if character and IsRelevantForCharacter(record, characterKey) then
            result[#result + 1] = {
                questID = record.questID,
                title = record.title,
                frequency = record.frequency or character.frequency,
                expansionID = record.expansionID,
                expansionName = record.expansionName,
                era = record.era or "Legacy",
                status = self:GetStatus(record, characterKey),
                category = record.category,
                activity = record.activity,
                catalog = record.catalogVersion ~= nil,
                knownToCharacter = character.knownToCharacter == true,
                characterLevel = tonumber(character.level) or self:GetCharacterLevel(characterKey),
                questLevel = record.questLevel,
                lastCompleted = character.lastCompleted,
                lastSeen = character.lastSeen,
            }
        end
    end

    table.sort(result, function(a, b)
        local af = tonumber(a.frequency) or 99
        local bf = tonumber(b.frequency) or 99
        if af ~= bf then
            return af < bf
        end
        return (a.title or "") < (b.title or "")
    end)

    return result
end

function Routines:GetAllQuests()
    local result = {}
    local store = EnsureStore()

    for _, record in pairs(store.quests) do
        result[#result + 1] = record
    end

    table.sort(result, function(a, b)
        local ae = tonumber(a.expansionID) or -1
        local be = tonumber(b.expansionID) or -1
        if ae ~= be then
            return ae > be
        end
        return (a.title or "") < (b.title or "")
    end)

    return result
end

function Routines:GetAccountSummary()
    local store = EnsureStore()
    local result = {
        ready = 0,
        completed = 0,
        known = 0,
        characters = {},
    }

    local characterKeys = {}
    for characterKey, character in pairs(store.characters) do
        if type(character) == "table" then
            characterKeys[characterKey] = true
        end
    end
    for _, record in pairs(store.quests) do
        if type(record) == "table" and type(record.characters) == "table" then
            for characterKey in pairs(record.characters) do
                characterKeys[characterKey] = true
            end
        end
    end

    for characterKey in pairs(characterKeys) do
        local characterInfo = store.characters[characterKey] or {}
        local entry = {
            characterKey = characterKey,
            name = characterInfo.name or characterKey,
            realm = characterInfo.realm or "",
            ready = 0,
            completed = 0,
            known = 0,
        }

        for _, record in pairs(store.quests) do
            local character = record.characters and record.characters[characterKey]
            if character and character.knownToCharacter == true and IsRelevantForCharacter(record, characterKey) then
                entry.known = entry.known + 1
                local status = self:GetStatus(record, characterKey)
                if status == "ready" then
                    entry.ready = entry.ready + 1
                elseif status == "completed" then
                    entry.completed = entry.completed + 1
                end
            end
        end

        if entry.known > 0 then
            result.characters[#result.characters + 1] = entry
            result.ready = result.ready + entry.ready
            result.completed = result.completed + entry.completed
            result.known = result.known + entry.known
        end
    end

    table.sort(result.characters, function(a, b)
        if a.ready ~= b.ready then
            return a.ready > b.ready
        end
        return (a.name or "") < (b.name or "")
    end)

    return result
end

function Routines:GetSummary()
    local currentExpansion = (GetExpansionLevel and tonumber(GetExpansionLevel())) or nil
    local summary = {
        current = { daily = 0, weekly = 0, scheduled = 0 },
        legacy = { daily = 0, weekly = 0, scheduled = 0 },
        ready = 0,
        completed = 0,
        known = 0,
    }

    local store = EnsureStore()
    local characterKey = GetCharacterKey()

    for _, record in pairs(store.quests) do
        local character = record.characters and record.characters[characterKey]
        if character and IsRelevantForCharacter(record, characterKey) then
            local frequency = tonumber(record.frequency or character.frequency)
            local bucket = (currentExpansion and tonumber(record.expansionID) == currentExpansion) and summary.current or summary.legacy
            if frequency == FREQUENCY_DAILY then
                bucket.daily = bucket.daily + 1
            elseif frequency == FREQUENCY_WEEKLY then
                bucket.weekly = bucket.weekly + 1
            elseif frequency == FREQUENCY_SCHEDULED then
                bucket.scheduled = bucket.scheduled + 1
            end

            local status = self:GetStatus(record, characterKey)
            summary.known = summary.known + 1
            if status == "ready" then
                summary.ready = summary.ready + 1
            elseif status == "completed" then
                summary.completed = summary.completed + 1
            end
        end
    end

    return summary
end

function Routines:Initialize()
    if self._initialized then
        return
    end

    self._initialized = true
    EnsureStore()

    local frame = CreateFrame("Frame")
    self._eventFrame = frame

    -- Quest/routine maintenance does not need frame-rate polling. Use a
    -- lightweight timer so the routine system wakes only when work is due.
    local stateTick = 0
    self._ticker = C_Timer.NewTicker(SCAN_INTERVAL, function()
        self:ScanQuestLog()
        stateTick = stateTick + SCAN_INTERVAL
        if stateTick >= STATE_REFRESH_INTERVAL then
            stateTick = 0
            self:RefreshState()
        end
    end)

    frame:RegisterEvent("QUEST_LOG_UPDATE")
    frame:RegisterEvent("QUEST_TURNED_IN")
    frame:RegisterEvent("QUEST_ACCEPTED")
    frame:RegisterEvent("QUEST_AUTOCOMPLETE")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("PLAYER_LEVEL_CHANGED")

    frame:SetScript("OnEvent", function(_, event, questID)
        questID = tonumber(questID)
        if event == "QUEST_TURNED_IN" or event == "QUEST_AUTOCOMPLETE" then
            if questID then self:RecordTurnIn(questID) end
        elseif event == "QUEST_ACCEPTED" then
            if questID then self:RecordAccepted(questID) end
        elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_LEVEL_CHANGED" then
            self:RefreshState()
        else
            self:ScanQuestLog()
            RefreshStoredCharacterStates(GetCharacterKey())
        end
    end)

    C_Timer.After(2, function()
        self:RefreshState()
    end)
end
