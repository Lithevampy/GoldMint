local ADDON_NAME, GoldMint = ...

-- ============================================================================
-- GOLDMINT MILESTONES / PACING BACKEND
-- ============================================================================
-- Persistent long-term gold goals. This module is backend-only: controls and
-- presentation can be layered on later without changing the stored model.
-- It tracks account liquid wealth snapshots, target checkpoints, weekly pace,
-- and a rolling seven-day comparison.
-- ============================================================================

GoldMint.Milestones = {}
local Milestones = GoldMint.Milestones

local STORE_VERSION = 4
local SNAPSHOT_INTERVAL = 6 * 60 * 60
local ROLLING_WINDOW = 7 * 24 * 60 * 60
local MAX_SNAPSHOTS = 180

local function Now()
    return time()
end

local function EnsureStore()
    GoldMintDB.milestones = type(GoldMintDB.milestones) == "table" and GoldMintDB.milestones or {}
    GoldMintDB.milestones.version = math.max(tonumber(GoldMintDB.milestones.version) or 0, STORE_VERSION)
    GoldMintDB.milestones.goals = type(GoldMintDB.milestones.goals) == "table" and GoldMintDB.milestones.goals or {}
    GoldMintDB.milestones.snapshots = type(GoldMintDB.milestones.snapshots) == "table" and GoldMintDB.milestones.snapshots or {}
    GoldMintDB.milestones.history = type(GoldMintDB.milestones.history) == "table" and GoldMintDB.milestones.history or {}
    return GoldMintDB.milestones
end

local function GetAccountValue()
    if GoldMint.Valuation and GoldMint.Valuation.GetAccountLiquidValue then
        local value = GoldMint.Valuation:GetAccountLiquidValue()
        if value and value.total then
            return tonumber(value.total) or 0
        end
    end
    if GoldMint.Ledger then
        return tonumber(GoldMint.Ledger:GetAccountWallet().totalGold) or 0
    end
    return 0
end

local function GetAccountGold()
    if GoldMint.Ledger then
        return tonumber(GoldMint.Ledger:GetAccountWallet().totalGold) or 0
    end
    return 0
end

local function GetGoalCurrentValue(goal)
    if type(goal) == "table" and (goal.type or "gold") == "gold" then
        return GetAccountGold()
    end
    return GetAccountValue()
end

local function GetGoalSnapshotValue(goal, snapshot)
    if type(goal) == "table" and (goal.type or "gold") == "gold" then
        return tonumber(snapshot and snapshot.gold) or 0
    end
    return tonumber(snapshot and snapshot.value) or 0
end

local function PruneSnapshots(store)
    local snapshots = store.snapshots
    table.sort(snapshots, function(a, b)
        return (tonumber(a.time) or 0) < (tonumber(b.time) or 0)
    end)
    while #snapshots > MAX_SNAPSHOTS do
        table.remove(snapshots, 1)
    end
end

function Milestones:CaptureSnapshot(force)
    local store = EnsureStore()
    local now = Now()
    local value = GetAccountValue()
    local gold = GetAccountGold()
    local last = store.snapshots[#store.snapshots]

    if not force and last and now - (tonumber(last.time) or 0) < SNAPSHOT_INTERVAL then
        return last
    end

    local snapshot = {
        time = now,
        gold = gold,
        value = value,
    }
    store.snapshots[#store.snapshots + 1] = snapshot
    PruneSnapshots(store)
    store.lastSnapshot = now
    return snapshot
end

local function FindSnapshotAtOrBefore(targetTime)
    local snapshots = EnsureStore().snapshots
    local best
    for i = #snapshots, 1, -1 do
        local snapshot = snapshots[i]
        if (tonumber(snapshot.time) or 0) <= targetTime then
            best = snapshot
            break
        end
    end
    return best
end

local function CountGoalCheckpoints(goal)
    local count = 0
    for _, checkpoint in ipairs(goal.checkpoints or {}) do
        if type(checkpoint) == "table" and tonumber(checkpoint.amount) then
            count = count + 1
        end
    end
    return count
end

local function NormalizeCheckpoints(goal)
    goal.checkpoints = type(goal.checkpoints) == "table" and goal.checkpoints or {}
    table.sort(goal.checkpoints, function(a, b)
        return (tonumber(a.amount) or 0) < (tonumber(b.amount) or 0)
    end)
end

local function GetItemName(itemID)
    if not itemID then return nil end
    local name
    if C_Item and C_Item.GetItemNameByID then
        local okName, value = pcall(C_Item.GetItemNameByID, itemID)
        if okName then name = value end
    end
    return name
end

local function GetItemIcon(itemID)
    if not itemID then return nil end
    if C_Item and C_Item.GetItemIconByID then
        local okIcon, value = pcall(C_Item.GetItemIconByID, itemID)
        if okIcon then return value end
    end
    return nil
end

local function IsItemCollected(itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end

    -- Mount items are consumed when learned, so inventory count is not enough.
    if C_MountJournal and C_MountJournal.GetMountFromItem and C_MountJournal.GetMountInfoByID then
        local mountID = C_MountJournal.GetMountFromItem(itemID)
        if mountID then
            local _, _, _, _, _, _, _, _, _, _, isCollected = C_MountJournal.GetMountInfoByID(mountID)
            if isCollected ~= nil then
                return isCollected == true
            end
        end
    end

    if C_Item and C_Item.GetItemCount then
        local okCount, rawCount = pcall(C_Item.GetItemCount, itemID, true, false, true, true)
        return okCount and (tonumber(rawCount) or 0) > 0 or false
    end
    return false
end

local function GetGoalCompletion(goal)
    if goal.completeAt then
        return true, goal.completeReason or "completed"
    end
    if goal.completeWhenCollected and goal.itemID and IsItemCollected(goal.itemID) then
        return true, "collected"
    end
    return false, nil
end

local function ArchiveGoal(goal, reason)
    if not goal then return end
    local store = EnsureStore()
    store.history[#store.history + 1] = {
        id = goal.id,
        name = goal.name,
        itemID = goal.itemID,
        target = goal.target,
        startValue = goal.startValue,
        completedAt = goal.completeAt or Now(),
        reason = reason or goal.completeReason or "completed",
        createdAt = goal.createdAt,
        projectType = goal.projectType,
        budget = goal.budget,
        expectedRevenue = goal.expectedRevenue,
        expectedCost = goal.expectedCost,
        status = goal.status,
        nextAction = goal.nextAction,
        materials = goal.materials,
    }
    while #store.history > 100 do
        table.remove(store.history, 1)
    end
end

local function BuildGoalStatus(goal, currentValue, now)
    local startValue = tonumber(goal.startValue)
    if not startValue then
        startValue = currentValue
        goal.startValue = startValue
    end

    local target = tonumber(goal.target) or 0
    local collected, collectionReason = GetGoalCompletion(goal)
    local remaining = math.max(target - currentValue, 0)
    -- Goal progress is the character/account gold currently held toward the
    -- target.  startValue is retained for pacing/history, but it must not be
    -- used as the progress baseline: if a player creates a 900,000g goal while
    -- already holding 810,000g, the tracker must show 90%, not 0%.
    local progress = target > 0 and math.max(0, math.min(1, currentValue / target)) or 0

    local checkpoint = nil
    for _, candidate in ipairs(goal.checkpoints or {}) do
        if tonumber(candidate.amount) and candidate.amount > currentValue then
            checkpoint = candidate
            break
        end
    end

    local status = (currentValue >= target or collected) and "complete" or "in_progress"
    if status == "complete" and not goal.completeAt then
        goal.completeAt = Now()
        goal.completeReason = collectionReason or "gold_target"
        ArchiveGoal(goal, goal.completeReason)
    end
    local weekly = {
        actual = 0,
        expected = 0,
        aheadBehind = 0,
        status = "unknown",
        hasBaseline = false,
    }

    local weekAgo = FindSnapshotAtOrBefore(now - ROLLING_WINDOW)
    if weekAgo then
        weekly.hasBaseline = true
        weekly.actual = currentValue - GetGoalSnapshotValue(goal, weekAgo)
        local deadline = tonumber(goal.deadline)
        if deadline and deadline > now and target > currentValue then
            local weeksRemaining = math.max((deadline - now) / ROLLING_WINDOW, 1 / 7)
            weekly.expected = remaining / weeksRemaining
            weekly.aheadBehind = weekly.actual - weekly.expected
            weekly.status = weekly.aheadBehind >= 0 and "ahead" or "behind"
        elseif target <= currentValue then
            weekly.status = "complete"
        else
            -- We have a real 7-day baseline, but no deadline to compare against.
            -- Report the measured pace rather than pretending the goal is on track.
            weekly.status = "baseline"
        end
    end

    return {
        id = goal.id,
        name = goal.name,
        purpose = goal.purpose,
        type = goal.type or "gold",
        itemID = goal.itemID,
        itemName = goal.itemName or GetItemName(goal.itemID),
        itemIcon = goal.itemIcon or GetItemIcon(goal.itemID),
        completeWhenCollected = goal.completeWhenCollected == true,
        collected = collected,
        completionReason = goal.completeReason,
        target = target,
        startValue = startValue,
        currentValue = currentValue,
        gained = gained,
        remaining = remaining,
        progress = progress,
        deadline = goal.deadline,
        checkpointCount = CountGoalCheckpoints(goal),
        nextCheckpoint = checkpoint and {
            name = checkpoint.name,
            amount = checkpoint.amount,
            remaining = math.max((tonumber(checkpoint.amount) or 0) - currentValue, 0),
        } or nil,
        weekly = weekly,
        createdAt = goal.createdAt,
        updatedAt = now,
        projectType = goal.projectType or "Gold Target",
        budget = tonumber(goal.budget) or 0,
        expectedRevenue = tonumber(goal.expectedRevenue) or 0,
        expectedCost = tonumber(goal.expectedCost) or 0,
        expectedProfit = (tonumber(goal.expectedRevenue) or 0) - (tonumber(goal.expectedCost) or 0),
        status = goal.status or "active",
        nextAction = goal.nextAction,
        materials = type(goal.materials) == "table" and goal.materials or {},
    }
end

function Milestones:CreateGoal(name, target, options)
    local store = EnsureStore()
    options = options or {}
    name = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
    target = tonumber(target)
    if name == "" or not target or target <= 0 then
        return nil, "invalid_goal"
    end

    local id = options.id or (string.lower(name):gsub("[^%w]+", "_") .. "_" .. tostring(Now()))
    if store.goals[id] then
        return nil, "goal_exists"
    end

    local goal = {
        id = id,
        name = name,
        purpose = options.purpose,
        type = options.type or (options.itemID and "item" or "gold"),
        itemID = tonumber(options.itemID),
        itemName = options.itemName or GetItemName(options.itemID),
        itemIcon = options.itemIcon or GetItemIcon(options.itemID),
        completeWhenCollected = options.completeWhenCollected == true,
        target = target,
        startValue = tonumber(options.startValue) or GetGoalCurrentValue({ type = options.type or (options.itemID and "item" or "gold") }),
        deadline = tonumber(options.deadline),
        checkpoints = type(options.checkpoints) == "table" and options.checkpoints or {},
        projectType = options.projectType or "Gold Target",
        budget = tonumber(options.budget) or 0,
        expectedRevenue = tonumber(options.expectedRevenue) or 0,
        expectedCost = tonumber(options.expectedCost) or 0,
        status = options.status or "active",
        nextAction = options.nextAction,
        materials = type(options.materials) == "table" and options.materials or {},
        createdAt = Now(),
    }
    NormalizeCheckpoints(goal)
    store.goals[id] = goal
    self:CaptureSnapshot(true)
    return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
end

function Milestones:UpdateGoal(id, changes)
    local store = EnsureStore()
    local goal = store.goals[id]
    if not goal or type(changes) ~= "table" then
        return nil, "goal_not_found"
    end

    for _, key in ipairs({ "name", "purpose", "type", "itemID", "itemName", "itemIcon", "completeWhenCollected", "target", "startValue", "deadline", "checkpoints", "projectType", "budget", "expectedRevenue", "expectedCost", "status", "nextAction", "materials" }) do
        if changes[key] ~= nil then
            goal[key] = changes[key]
        end
    end
    goal.target = tonumber(goal.target) or 0
    goal.startValue = tonumber(goal.startValue) or GetGoalCurrentValue(goal)
    NormalizeCheckpoints(goal)
    goal.budget = tonumber(goal.budget) or 0
    goal.expectedRevenue = tonumber(goal.expectedRevenue) or 0
    goal.expectedCost = tonumber(goal.expectedCost) or 0
    goal.projectType = goal.projectType or "Gold Target"
    goal.status = goal.status or "active"
    goal.updatedAt = Now()
    return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
end

function Milestones:CreateItemGoal(itemID, target, options)
    options = options or {}
    options.itemID = tonumber(itemID)
    options.type = options.type or "item"
    options.itemName = options.itemName or GetItemName(options.itemID)
    return self:CreateGoal(options.name or options.itemName or ("Item " .. tostring(itemID)), target, options)
end

function Milestones:SetGoalTarget(id, name, target, options)
    local store = EnsureStore()
    local goal = store.goals[id]
    if not goal then return nil, "goal_not_found" end
    options = options or {}

    -- Preserve the completed target as history, then turn the same slot into
    -- the user's next target. This is what the future UI's "Set New Goal"
    -- control will use; no slash command is required.
    if goal.completeAt or options.archivePrevious ~= false then
        ArchiveGoal(goal, goal.completeReason or "replaced")
    end

    goal.name = tostring(name or goal.name or "Goal")
    goal.target = tonumber(target) or 0
    goal.type = options.type or (options.itemID and "item" or "gold")
    goal.itemID = tonumber(options.itemID)
    goal.itemName = options.itemName or GetItemName(goal.itemID)
    goal.itemIcon = options.itemIcon or GetItemIcon(goal.itemID)
    goal.completeWhenCollected = options.completeWhenCollected == true
    goal.purpose = options.purpose
    goal.startValue = tonumber(options.startValue) or GetGoalCurrentValue(goal)
    goal.deadline = tonumber(options.deadline)
    goal.checkpoints = type(options.checkpoints) == "table" and options.checkpoints or {}
    goal.projectType = options.projectType or goal.projectType or "Gold Target"
    goal.budget = tonumber(options.budget) or 0
    goal.expectedRevenue = tonumber(options.expectedRevenue) or 0
    goal.expectedCost = tonumber(options.expectedCost) or 0
    goal.status = options.status or "active"
    goal.nextAction = options.nextAction
    goal.materials = type(options.materials) == "table" and options.materials or {}
    goal.completeAt = nil
    goal.completeReason = nil
    goal.updatedAt = Now()
    NormalizeCheckpoints(goal)
    self:CaptureSnapshot(true)
    return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
end

function Milestones:ReplaceGoal(id, name, target, options)
    return self:SetGoalTarget(id, name, target, options)
end

function Milestones:CompleteGoal(id, reason)
    local store = EnsureStore()
    local goal = store.goals[id]
    if not goal then return nil, "goal_not_found" end
    if not goal.completeAt then
        goal.completeAt = Now()
        goal.completeReason = reason or "manual"
        ArchiveGoal(goal, goal.completeReason)
    end
    return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
end

function Milestones:GetHistory()
    local result = {}
    for i = #EnsureStore().history, 1, -1 do
        result[#result + 1] = EnsureStore().history[i]
    end
    return result
end

function Milestones:DeleteGoal(id)
    local store = EnsureStore()
    if not store.goals[id] then
        return false
    end
    store.goals[id] = nil
    return true
end

function Milestones:GetGoal(id)
    local goal = EnsureStore().goals[id]
    if not goal then return nil end
    return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
end

function Milestones:GetGoals()
    local result = {}
    local now = Now()
    for _, goal in pairs(EnsureStore().goals) do
        result[#result + 1] = BuildGoalStatus(goal, GetGoalCurrentValue(goal), now)
    end
    table.sort(result, function(a, b)
        if a.remaining ~= b.remaining then
            return a.remaining < b.remaining
        end
        return (a.name or "") < (b.name or "")
    end)
    return result
end

function Milestones:GetSummary()
    local goals = self:GetGoals()
    local complete, active, ahead, behind = 0, 0, 0, 0
    for _, goal in ipairs(goals) do
        if goal.progress >= 1 then
            complete = complete + 1
        else
            active = active + 1
            if goal.weekly.status == "ahead" then ahead = ahead + 1 end
            if goal.weekly.status == "behind" then behind = behind + 1 end
        end
    end
    return {
        accountValue = GetAccountValue(),
        accountGold = GetAccountGold(),
        goals = #goals,
        active = active,
        complete = complete,
        ahead = ahead,
        behind = behind,
        updatedAt = Now(),
    }
end

function Milestones:GetActiveGoal()
    local goals = self:GetGoals()
    for _, goal in ipairs(goals) do
        if not goal.completeAt and goal.progress < 1 then
            return goal
        end
    end
    return nil
end

function Milestones:SetCheckpoint(id, amount, name)
    local store = EnsureStore()
    local goal = store.goals[id]
    amount = tonumber(amount)
    if not goal or not amount or amount <= 0 then
        return nil, "invalid_checkpoint"
    end

    local target = tonumber(goal.target) or 0
    if target > 0 and amount >= target then
        return nil, "checkpoint_must_be_below_goal"
    end

    goal.checkpoints = type(goal.checkpoints) == "table" and goal.checkpoints or {}
    local checkpointName = strtrim(tostring(name or ""))
    if checkpointName == "" then
        checkpointName = "Checkpoint"
    end

    -- Replace a checkpoint at the same gold amount instead of creating duplicates.
    for _, checkpoint in ipairs(goal.checkpoints) do
        if type(checkpoint) == "table" and tonumber(checkpoint.amount) == amount then
            checkpoint.name = checkpointName
            goal.updatedAt = Now()
            NormalizeCheckpoints(goal)
            return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
        end
    end

    goal.checkpoints[#goal.checkpoints + 1] = {
        amount = amount,
        name = checkpointName,
    }
    NormalizeCheckpoints(goal)
    goal.updatedAt = Now()
    return BuildGoalStatus(goal, GetGoalCurrentValue(goal), Now())
end

function Milestones:ClearCheckpoints(id)
    local store = EnsureStore()
    local goal = store.goals[id]
    if not goal then return false end
    goal.checkpoints = {}
    goal.updatedAt = Now()
    return true
end

function Milestones:Initialize()
    if self._initialized then return end
    self._initialized = true
    EnsureStore()
    self:CaptureSnapshot(true)

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("PLAYER_MONEY")
    frame:RegisterEvent("BANKFRAME_OPENED")
    frame:RegisterEvent("PLAYERBANKSLOTS_CHANGED")
    frame:RegisterEvent("PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED")

    frame:SetScript("OnEvent", function()
        -- Merchant UI can emit bag/money events while it is opening or while an
        -- item sale is settling. CaptureSnapshot walks the account valuation, so
        -- never do that work on the merchant's frame-critical path.
        if GoldMint:IsMerchantOpen() then
            self._snapshotPending = true
            return
        end
        self:CaptureSnapshot(false)
    end)

    self._ticker = C_Timer.NewTicker(15 * 60, function()
        if self._initialized and not GoldMint:IsMerchantOpen() then
            self:CaptureSnapshot(false)
        else
            self._snapshotPending = true
        end
    end)
end
