local ADDON_NAME, GoldMint = ...

GoldMint.FarmTracker = GoldMint.FarmTracker or {}
local Tracker = GoldMint.FarmTracker

local TRACKER_WIDTH = 720
local TRACKER_HEIGHT = 380
local UPDATE_INTERVAL = 1.0
local INTELLIGENCE_REFRESH_INTERVAL = 5
local PERFORMANCE_REFRESH_INTERVAL = 5
local PATH_SAMPLE_INTERVAL = 5
local MAX_PATH_POINTS = 120
local MAX_LOOT_ROWS = 5
local DEFAULT_LOOT_MIN_VALUE = 10 * 10000 -- 10 gold

local GOLD = {1.0, 0.82, 0.25}
local CYAN = {0.20, 0.78, 1.0}
local GREEN = {0.25, 1.0, 0.55}
local RED = {1.0, 0.35, 0.35}
local MUTED = {0.60, 0.74, 0.88}
local DARK = {0.006, 0.028, 0.050, 0.98}

local function EnsureDB()
    GoldMintDB.farmTracker = type(GoldMintDB.farmTracker) == "table" and GoldMintDB.farmTracker or {}
    local db = GoldMintDB.farmTracker
    if db.x == nil then db.x = -20 end
    if db.y == nil then db.y = -260 end
    -- The tracker is anchored to GoldMint's external minimap button.
    -- Keep the saved point relative to that button so the tracker follows it.
    if db.point == nil then db.point = "BOTTOMRIGHT" end
    if db.relativePoint == nil then db.relativePoint = "TOPLEFT" end
    if db.offsetX == nil then db.offsetX = -8 end
    if db.offsetY == nil then db.offsetY = 8 end
    if db.recentLootEnabled == nil then db.recentLootEnabled = true end
    if db.recentLootMinValue == nil then db.recentLootMinValue = DEFAULT_LOOT_MIN_VALUE end
    if db.activeSession ~= nil and type(db.activeSession) ~= "table" then db.activeSession = nil end
    return db
end

function Tracker:GetRecentLootSettings()
    local db = EnsureDB()
    return {
        enabled = db.recentLootEnabled ~= false,
        minValue = math.max(0, tonumber(db.recentLootMinValue) or DEFAULT_LOOT_MIN_VALUE),
    }
end

function Tracker:SetRecentLootEnabled(enabled)
    local db = EnsureDB()
    db.recentLootEnabled = enabled == true
    if self.frame then self:Refresh() end
end

function Tracker:SetRecentLootMinValue(copper)
    local db = EnsureDB()
    db.recentLootMinValue = math.max(0, math.floor(tonumber(copper) or DEFAULT_LOOT_MIN_VALUE))
    if self.frame then self:Refresh() end
end

local function CopperText(copper)
    copper = math.floor(tonumber(copper) or 0)
    local sign = copper < 0 and "-" or ""
    copper = math.abs(copper)
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100
    if g > 0 then return string.format("%s%dg %02ds", sign, g, s) end
    if s > 0 then return string.format("%s%ds %02dc", sign, s, c) end
    return string.format("%s%dc", sign, c)
end

local function GoldText(copper)
    copper = math.floor(tonumber(copper) or 0)
    local sign = copper < 0 and "-" or ""
    copper = math.abs(copper)
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    if g > 0 then
        local formatted = tostring(g)
        local changed
        repeat
            formatted, changed = formatted:gsub("^(%d+)(%d%d%d)", "%1,%2")
        until changed == 0
        if s > 0 then return string.format("%s%sg %02ds", sign, formatted, s) end
        return string.format("%s%sg", sign, formatted)
    end
    return CopperText(copper)
end

local function AddText(parent, size, color, justify)
    local t = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t:SetFont("Fonts\\FRIZQT__.TTF", size or 12, "")
    t:SetTextColor(color[1], color[2], color[3], color[4] or 1)
    t:SetJustifyH(justify or "LEFT")
    return t
end

local function MakePanel(parent, width, height)
    local f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    f:SetSize(width, height)
    f:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = {left=1,right=1,top=1,bottom=1},
    })
    f:SetBackdropColor(DARK[1], DARK[2], DARK[3], DARK[4])
    f:SetBackdropBorderColor(CYAN[1], CYAN[2], CYAN[3], 0.75)
    return f
end

local function Button(parent, text, width, height)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, height)
    b:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    b:SetBackdropColor(0.015, 0.055, 0.085, 1)
    b:SetBackdropBorderColor(CYAN[1], CYAN[2], CYAN[3], 0.65)
    local t = AddText(b, 11, CYAN, "CENTER")
    t:SetPoint("CENTER")
    t:SetText(text)
    b.text = t
    b:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.025, 0.09, 0.13, 1)
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0.015, 0.055, 0.085, 1)
    end)
    return b
end

local function PersistActiveSession(session)
    local db = EnsureDB()
    if session then
        db.activeSession = session
    else
        db.activeSession = nil
    end
end

function Tracker:SaveActiveSession(force)
    if not self.session or not self.session.active then return end
    local now = time()
    local last = tonumber(self._lastSessionPersistAt) or 0
    -- Do not rewrite SavedVariables when nothing in the active session has
    -- changed. Live HUD refreshes may call this method frequently, but only
    -- dirty sessions need persistence. Force-save remains the explicit
    -- lifecycle boundary used by pause/resume/logout.
    if not force and not self._sessionDirty then return end
    -- Active sessions can change every second. Throttle SavedVariables writes
    -- while still keeping a recent recovery point for reloads/disconnects.
    if force or last == 0 or (now - last) >= 10 then
        PersistActiveSession(self.session)
        self._lastSessionPersistAt = now
        self._sessionDirty = false
    end
end

function Tracker:RestoreActiveSession()
    local db = EnsureDB()
    local saved = db.activeSession
    if type(saved) ~= "table" or saved.active ~= true then
        return false
    end

    local nowWall = time()
    local startedWall = tonumber(saved.startedAtWall)
    if not startedWall then
        return false
    end

    local pausedDuration = tonumber(saved.pausedDuration) or 0
    local paused = saved.paused == true
    local pausedAtWall = tonumber(saved.pausedAtWall)
    if paused and pausedAtWall then
        pausedDuration = pausedDuration + math.max(nowWall - pausedAtWall, 0)
    end

    local elapsedWall = math.max(nowWall - startedWall - pausedDuration, 0)
    local restored = {}
    for k, v in pairs(saved) do
        restored[k] = v
    end
    restored.startedAt = GetTime() - elapsedWall
    restored.pausedDuration = pausedDuration
    if paused and pausedAtWall then
        restored.pausedAt = GetTime() - math.max(nowWall - pausedAtWall, 0)
    else
        restored.pausedAt = nil
    end
    restored.active = true
    self.session = restored
    self._sessionDirty = false
    self._lastSessionPersistAt = nowWall
    self.routeItemID = tonumber(restored.routeItemID)
    self.routeItemName = restored.routeItemName
    self.routeZone = restored.routeZone
    self.routeArea = restored.routeArea
    self.routeID = restored.routeKey
    self.routeMapID = tonumber(restored.routeMapID)
    self.routeWaypoints = restored.routeWaypoints
    self.routeLength = tonumber(restored.routeLength)
    self.routeTargetItemIDs = restored.routeTargetItemIDs
    return true
end

function Tracker:RecordRoutePosition(force)
    if not self:IsActive() or self.session.paused or not self.session.routeKey then return end
    local now = GetTime()
    if not force and now - (tonumber(self.session.lastPathSampleAt) or 0) < PATH_SAMPLE_INTERVAL then return end
    if not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition then return end
    local mapID = C_Map.GetBestMapForUnit("player")
    if not mapID then return end
    local ok, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
    if not ok or not pos or not pos.GetXY then return end
    local x, y = pos:GetXY()
    if not x or not y or x <= 0 or y <= 0 then return end
    local routeMap = tonumber(self.session.routeMapID)
    if routeMap and routeMap ~= tonumber(mapID) then return end
    self.session.routeMapID = tonumber(mapID)
    self.session.routePath = self.session.routePath or {}
    local path = self.session.routePath
    local last = path[#path]
    -- Ignore tiny movement jitter; retain meaningful route geometry.
    if last then
        local dx, dy = x - last.x, y - last.y
        if (dx * dx + dy * dy) < 0.000004 and not force then
            self.session.lastPathSampleAt = now
            return
        end
    end
    path[#path + 1] = {x = x, y = y, t = now}
    self._sessionDirty = true
    while #path > MAX_PATH_POINTS do table.remove(path, 1) end
    self.session.lastPathSampleAt = now
end

function Tracker:StartTicker()
    if self._ticker then return end
    if C_Timer and C_Timer.NewTicker then
        self._ticker = C_Timer.NewTicker(UPDATE_INTERVAL, function()
            if Tracker.session and Tracker.session.active then
                GoldMint:SafeCall("farm tracker tick", function()
                    Tracker:RecordRoutePosition(false)
                    Tracker:SaveActiveSession(false)
                    Tracker:Refresh()
                end)
            end
        end)
    end
end

function Tracker:StopTicker()
    self._hudIntelligenceCache = nil
    self._hudQualityCache = nil
    self._routePerformanceCache = nil
    if self._ticker and self._ticker.Cancel then
        self._ticker:Cancel()
    end
    self._ticker = nil
end

function Tracker:IsActive()
    return type(self.session) == "table" and self.session.active == true
end

function Tracker:EnsureFrame()
    if self.frame then return self.frame end

    local f = MakePanel(UIParent, TRACKER_WIDTH, TRACKER_HEIGHT)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(80)
    f:SetClampedToScreen(true)
    -- The tracker is a movable floating utility.  StartMoving() requires
    -- the frame itself to be explicitly marked movable; anchoring it to the
    -- minimap button does not make it movable automatically.
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:Hide()
    self.frame = f

    local db = EnsureDB()
    self:RestoreActiveSession()
    local anchor = (GoldMint.Dashboard and GoldMint.Dashboard.panels and GoldMint.Dashboard.panels.minimapButton) or Minimap
    f:SetPoint(db.point, anchor, db.relativePoint, db.offsetX, db.offsetY)

    local title = AddText(f, 15, GOLD, "LEFT")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("GOLD PER HOUR")
    self.title = title

    local status = AddText(f, 10, MUTED, "RIGHT")
    status:SetPoint("TOPRIGHT", -38, -14)
    status:SetText("READY")
    self.status = status

    local route = AddText(f, 10, CYAN, "RIGHT")
    route:SetPoint("TOPRIGHT", -40, -28)
    route:SetText("NO FARM TARGET")
    self.routeLabel = route

    local close = Button(f, "X", 24, 24)
    close:SetPoint("TOPRIGHT", -8, -7)
    close:SetScript("OnClick", function()
        if Tracker.frame then
            Tracker.frame:Hide()
        end
    end)
    self.closeButton = close

    local divider = f:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 0.30)
    divider:SetPoint("TOPLEFT", 12, -36)
    divider:SetPoint("TOPRIGHT", -12, -36)
    divider:SetHeight(1)

    -- Wide layout: keep the live money metrics on the left, give Recent Loot
    -- a clean dedicated column on the right, and move the farm intelligence
    -- into the lower information band so nothing feels cramped.
    local LEFT_X = 18
    local RIGHT_X = 330
    local RIGHT_W = 370

    local timeLabel = AddText(f, 10, MUTED)
    timeLabel:SetPoint("TOPLEFT", LEFT_X, -50)
    timeLabel:SetText("SESSION TIME")
    self.timeLabel = timeLabel

    local timeValue = AddText(f, 13, CYAN, "RIGHT")
    timeValue:SetPoint("TOPLEFT", 142, -48)
    timeValue:SetWidth(112)
    self.timeValue = timeValue

    local rows = {
        {"Raw Gold", "rawGold", GOLD},
        {"Loot Value", "lootValue", CYAN},
        {"Vendor Value", "vendorValue", MUTED},
        {"Market Value", "marketValue", GREEN},
        {"Expenses", "expenses", RED},
    }
    self.valueLabels = {}
    for i, row in ipairs(rows) do
        local y = -78 - ((i - 1) * 25)
        local label = AddText(f, 11, MUTED)
        label:SetPoint("TOPLEFT", LEFT_X, y)
        label:SetText(row[1])
        local value = AddText(f, 11, row[3], "RIGHT")
        value:SetPoint("TOPLEFT", 142, y)
        value:SetWidth(112)
        self.valueLabels[row[2]] = value
    end

    local recentHeader = AddText(f, 10, CYAN, "LEFT")
    recentHeader:SetPoint("TOPLEFT", RIGHT_X, -50)
    recentHeader:SetText("RECENT LOOT")
    self.recentLootHeader = recentHeader

    local recentRows = {}
    for i = 1, MAX_LOOT_ROWS do
        local row = CreateFrame("Frame", nil, f)
        row:SetSize(RIGHT_W, 30)
        row:SetPoint("TOPLEFT", RIGHT_X, -70 - ((i - 1) * 30))

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(24, 24)
        icon:SetPoint("LEFT", 0, 0)

        local nameText = AddText(row, 10, MUTED, "LEFT")
        nameText:SetPoint("LEFT", icon, "RIGHT", 8, 0)
        nameText:SetPoint("RIGHT", -92, 0)
        nameText:SetWordWrap(false)

        local valueText = AddText(row, 10, GOLD, "RIGHT")
        valueText:SetPoint("RIGHT", 0, 0)
        valueText:SetWidth(86)

        row.icon = icon
        row.name = nameText
        row.value = valueText
        row:Hide()
        recentRows[i] = row
    end
    self.recentLootRows = recentRows

    local vertical = f:CreateTexture(nil, "ARTWORK")
    vertical:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 0.22)
    vertical:SetPoint("TOPLEFT", 306, -46)
    vertical:SetPoint("BOTTOMLEFT", 306, 52)
    vertical:SetWidth(1)

    local sep = f:CreateTexture(nil, "ARTWORK")
    sep:SetColorTexture(CYAN[1], CYAN[2], CYAN[3], 0.22)
    sep:SetPoint("TOPLEFT", 14, -218)
    sep:SetPoint("TOPRIGHT", -14, -218)
    sep:SetHeight(1)

    local netLabel = AddText(f, 11, MUTED)
    netLabel:SetPoint("TOPLEFT", LEFT_X, -233)
    netLabel:SetText("NET PROFIT")
    local net = AddText(f, 17, GREEN, "RIGHT")
    net:SetPoint("TOPLEFT", 142, -231)
    net:SetWidth(112)
    self.net = net

    local rateLabel = AddText(f, 11, MUTED)
    rateLabel:SetPoint("TOPLEFT", LEFT_X, -262)
    rateLabel:SetText("GOLD / HOUR")
    local rate = AddText(f, 17, GOLD, "RIGHT")
    rate:SetPoint("TOPLEFT", 142, -260)
    rate:SetWidth(112)
    self.rate = rate

    local estimateLabel = AddText(f, 10, MUTED, "LEFT")
    estimateLabel:SetPoint("TOPLEFT", RIGHT_X, -233)
    estimateLabel:SetPoint("TOPRIGHT", -16, -233)
    estimateLabel:SetHeight(16)
    self.estimateLabel = estimateLabel

    local lootLabel = AddText(f, 10, MUTED, "LEFT")
    lootLabel:SetPoint("TOPLEFT", RIGHT_X, -252)
    lootLabel:SetPoint("TOPRIGHT", -16, -252)
    lootLabel:SetHeight(16)
    self.lootLabel = lootLabel

    local intelligenceLabel = AddText(f, 10, CYAN, "LEFT")
    intelligenceLabel:SetPoint("TOPLEFT", RIGHT_X, -272)
    intelligenceLabel:SetPoint("TOPRIGHT", -16, -272)
    intelligenceLabel:SetHeight(16)
    self.intelligenceLabel = intelligenceLabel

    local evidenceLabel = AddText(f, 9, MUTED, "LEFT")
    evidenceLabel:SetPoint("TOPLEFT", RIGHT_X, -291)
    evidenceLabel:SetPoint("TOPRIGHT", -16, -291)
    evidenceLabel:SetHeight(16)
    self.evidenceLabel = evidenceLabel

    local start = Button(f, "START FARM", 90, 28)
    start:SetPoint("BOTTOMLEFT", 14, 10)
    start:SetScript("OnClick", function() Tracker:Start() end)
    self.startButton = start

    local pause = Button(f, "PAUSE", 72, 28)
    pause:SetPoint("LEFT", start, "RIGHT", 10, 0)
    pause:SetScript("OnClick", function() Tracker:TogglePause() end)
    self.pauseButton = pause

    local reset = Button(f, "RESET", 72, 28)
    reset:SetPoint("LEFT", pause, "RIGHT", 10, 0)
    reset:SetScript("OnClick", function() Tracker:Reset() end)
    self.resetButton = reset

    local finish = Button(f, "END", 72, 28)
    finish:SetPoint("LEFT", reset, "RIGHT", 10, 0)
    finish:SetScript("OnClick", function() Tracker:End() end)
    self.endButton = finish

    f:SetScript("OnDragStart", function(self)
        if Tracker._dragging then return end
        Tracker._dragging = true
        self:StartMoving()
    end)
    f:SetScript("OnDragStop", function(self)
        if not Tracker._dragging then return end
        Tracker._dragging = false
        self:StopMovingOrSizing()
        Tracker:SavePosition()
        Tracker:Reanchor()
    end)

    -- HUD updates are driven by the single session ticker above.  Avoid a
    -- second frame OnUpdate loop so the tracker does not perform duplicate
    -- refresh work every frame.

    if self.session and self.session.active then
        self:StartTicker()
    end
    self:Refresh()
    return f
end

function Tracker:SavePosition()
    if not self.frame then return end
    local db = EnsureDB()
    local anchor = (GoldMint.Dashboard and GoldMint.Dashboard.panels and GoldMint.Dashboard.panels.minimapButton) or Minimap

    -- Keep the saved position relative to the GoldMint minimap button.
    -- StartMoving/StopMovingOrSizing may change the frame's actual anchor,
    -- so reading GetPoint() here can otherwise save a UIParent-relative
    -- position and cause the tracker to jump when it is reopened.
    if anchor then
        local frameX, frameY = self.frame:GetCenter()
        local anchorX, anchorY = anchor:GetCenter()
        if frameX and frameY and anchorX and anchorY then
            db.point = "CENTER"
            db.relativePoint = "CENTER"
            db.offsetX = frameX - anchorX
            db.offsetY = frameY - anchorY
            return
        end
    end

    local point, _, relativePoint, x, y = self.frame:GetPoint(1)
    if point then
        db.point = point
        db.relativePoint = relativePoint or "TOPLEFT"
        db.offsetX = x or 0
        db.offsetY = y or 0
    end
end

function Tracker:Reanchor()
    if not self.frame then return end
    local db = EnsureDB()
    local anchor = (GoldMint.Dashboard and GoldMint.Dashboard.panels and GoldMint.Dashboard.panels.minimapButton) or Minimap
    if not anchor then return end
    self.frame:ClearAllPoints()
    self.frame:SetPoint(db.point or "BOTTOMRIGHT", anchor, db.relativePoint or "TOPLEFT", db.offsetX or -8, db.offsetY or 8)
end

function Tracker:Toggle()
    self:EnsureFrame()
    if self.frame:IsShown() then
        self.frame:Hide()
    else
        self:Reanchor()
        self.frame:Show()
        self:Refresh()
    end
end

function Tracker:SetRoute(route)
    if type(route) ~= "table" then
        self.routeItemID, self.routeItemName, self.routeZone, self.routeArea = nil, nil, nil, nil
        if self.session and self.session.active then
            self.session.routeItemID = nil
            self.session.routeItemName = nil
            self.session.routeZone = nil
            self.session.routeArea = nil
        self.session.routeKey = nil
        end
        self:Refresh()
        return
    end
    self.routeItemID = tonumber(route.itemID)
    self.routeItemName = route.itemName or route.name
    self.routeZone = route.zone
    self.routeArea = route.start or route.name
    self.routeKey = route.routeID or route.id or ((route.zone or "") .. "|" .. (route.start or "") .. "|" .. tostring(route.mapID or ""))
    self.routeID = self.routeKey
    self.routeMapID = tonumber(route.mapID)
    self.routeWaypoints = route.waypoints
    self.routeLength = tonumber(route.length)
    self.routeTargetItemIDs = route.targetItemIDs
    if self.session and self.session.active then
        self.session.routeItemID = self.routeItemID
        self.session.routeItemName = self.routeItemName
        self.session.routeZone = self.routeZone
        self.session.routeArea = self.routeArea
        self.session.routeKey = self.routeKey
        self.session.routeMapID = tonumber(route.mapID)
        self.session.routeWaypoints = route.waypoints
        self.session.routeLength = tonumber(route.length)
        self.session.routeTargetItemIDs = route.targetItemIDs
        self.session.routePath = {}
        self.session.lastPathSampleAt = 0
        self.session.routeValue = 0
        self.session.routeItems = 0
    end
    self:Refresh()
end

function Tracker:GetBuiltInRoute(routeID)
    if GoldMint.FarmRoutes and GoldMint.FarmRoutes.Get then
        return GoldMint.FarmRoutes:Get(routeID)
    end
    return nil
end

function Tracker:GetCurrentRoute()
    local id = self.session and self.session.routeKey or self.routeKey
    return id and self:GetBuiltInRoute(id) or nil
end

function Tracker:GetCurrentWaypoint()
    local route = self:GetCurrentRoute()
    if not route or not route.mapID or not C_Map or not C_Map.GetPlayerMapPosition then return nil end
    local mapID = C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player") or route.mapID
    if tonumber(mapID) ~= tonumber(route.mapID) then return nil end
    local ok, pos = pcall(C_Map.GetPlayerMapPosition, route.mapID, "player")
    if not ok or not pos or not pos.GetXY then return nil end
    local x, y = pos:GetXY()
    local index, distance = GoldMint.FarmRoutes:GetNearestWaypoint(route.id, x, y)
    return index, distance, #route.waypoints
end

function Tracker:GetBuiltInRoutesForMap(mapID)
    if GoldMint.FarmRoutes and GoldMint.FarmRoutes.GetRoutesForMap then
        return GoldMint.FarmRoutes:GetRoutesForMap(mapID)
    end
    return {}
end

function Tracker:GetHistoricalGPH()
    local db = EnsureDB()
    local id = self.session and self.session.routeItemID or self.routeItemID
    if not id or type(db.routeStats) ~= "table" then return nil end
    local routeKey = self.session and self.session.routeKey or self.routeKey
    local key = tostring(id) .. "|" .. tostring(routeKey or "")
    local stat = db.routeStats[key] or db.routeStats[tostring(id)]
    if type(stat) ~= "table" or (tonumber(stat.seconds) or 0) <= 0 then return nil end
    return (tonumber(stat.value) or 0) / (tonumber(stat.seconds) / 3600), stat
end

function Tracker:GetRouteQualityWeight(session)
    if type(session) ~= "table" then return 0 end
    local quality = tostring(session.quality or "")
    local confidence = tonumber(session.qualityConfidence)
    if confidence == nil then
        confidence = (quality == "STRONG" and 85) or (quality == "USABLE" and 60) or (quality == "LOW_QUALITY" and 25) or 0
    end
    if quality == "INSUFFICIENT" or quality == "LOW_QUALITY" or confidence <= 0 then
        return 0
    end
    local seconds = tonumber(session.seconds) or 0
    if seconds <= 0 then return 0 end
    local durationWeight = math.min(math.max(seconds / 600, 0.5), 3)

    -- When a measured route path exists, scale the evidence contribution by
    -- how much of that route was actually covered. This keeps a short/partial
    -- traversal from contributing as though the entire route was completed.
    -- Legacy sessions without route geometry retain their prior weighting.
    local completionWeight = 1
    local completion = session.routeCompletion
    if type(completion) == "table" then
        local coverage = tonumber(completion.coverage)
        if coverage ~= nil then
            completionWeight = math.min(1, math.max(0.10, coverage / 100))
        end
    end

    return (confidence / 100) * durationWeight * completionWeight
end

function Tracker:GetRouteEvidenceHalfLife(profile)
    if type(profile) ~= "table" then return 7 end

    -- Stable routes retain historical evidence longer; volatile routes adapt
    -- faster. This is intentionally bounded so a single noisy session cannot
    -- erase a useful history, while genuinely unstable routes remain responsive.
    local stability = tonumber(profile.gphStability) or 100
    local geometry = tonumber(profile.geometryConsistency) or 100
    local loops = tonumber(profile.loopRate) or 100
    local volatility = math.max(0, math.min(100,
        (100 - stability) * 0.55 +
        (100 - geometry) * 0.30 +
        (100 - loops) * 0.15))

    local halfLifeDays = 14 - (volatility / 100) * 11
    halfLifeDays = math.max(3, math.min(14, halfLifeDays))
    profile.volatility = volatility
    profile.evidenceHalfLifeDays = halfLifeDays
    return halfLifeDays
end

function Tracker:ApplyRouteEvidenceDecay(profile, nowAt)
    if type(profile) ~= "table" then return profile end
    nowAt = tonumber(nowAt) or time()
    local lastAt = tonumber(profile.lastEvidenceAt or profile.lastAt)
    if not lastAt or lastAt <= 0 then
        profile.lastEvidenceAt = nowAt
        profile.recencyWeight = tonumber(profile.effectiveSessions) or 0
        return profile
    end

    local elapsedDays = math.max(0, (nowAt - lastAt) / 86400)
    local halfLifeDays = self:GetRouteEvidenceHalfLife(profile)
    if elapsedDays > 0 then
        local decay = math.exp(-math.log(2) * elapsedDays / halfLifeDays)
        local effective = tonumber(profile.effectiveSessions)
        if effective ~= nil then
            profile.effectiveSessions = effective * decay
        end
        local recency = tonumber(profile.recencyWeight)
        if recency ~= nil then
            profile.recencyWeight = recency * decay
        end
    end
    profile.evidenceAgeDays = elapsedDays
    return profile
end

function Tracker:ApplyBaselineConfidenceAging(profile, nowAt)
    if type(profile) ~= "table" then return profile end
    nowAt = tonumber(nowAt) or time()
    local baseline = type(profile.baselineSnapshot) == "table" and profile.baselineSnapshot or nil
    if not baseline then
        profile.baselineAgeDays = 0
        profile.baselineRecencyFactor = 0
        profile.baselineConfidence = 0
        profile.baselineAgeState = "NONE"
        return profile
    end

    local capturedAt = tonumber(baseline.revisedAt or baseline.capturedAt or profile.baselineRevisionAt) or 0
    if capturedAt <= 0 then
        profile.baselineAgeDays = 0
        profile.baselineRecencyFactor = 1
        profile.baselineConfidence = tonumber(baseline.confidence) or tonumber(profile.averageConfidence) or 0
        profile.baselineAgeState = "FRESH"
        return profile
    end

    local ageDays = math.max(0, (nowAt - capturedAt) / 86400)
    local halfLifeDays = self:GetRouteEvidenceHalfLife(profile)
    local factor = math.exp(-math.log(2) * ageDays / math.max(1, halfLifeDays))
    factor = math.max(0.35, math.min(1, factor))

    local baselineConfidence = tonumber(baseline.confidence) or tonumber(profile.averageConfidence) or 0
    local state
    if ageDays >= halfLifeDays * 2.5 then
        state = "REVALIDATE"
    elseif ageDays >= halfLifeDays * 1.5 then
        state = "STALE"
    elseif ageDays >= halfLifeDays * 0.5 then
        state = "AGING"
    else
        state = "FRESH"
    end

    profile.baselineAgeDays = ageDays
    profile.baselineHalfLifeDays = halfLifeDays
    profile.baselineRecencyFactor = factor
    profile.baselineConfidence = math.max(0, math.min(100, baselineConfidence * factor))
    profile.baselineAgeState = state
    profile.baselineLastValidatedAt = capturedAt
    return profile
end

function Tracker:BuildRouteBaselineSnapshot(itemID, routeKey, fallbackProfile, nowAt)
    local db = EnsureDB()
    local id = tonumber(itemID)
    if not id then return nil end
    nowAt = tonumber(nowAt) or time()
    fallbackProfile = type(fallbackProfile) == "table" and fallbackProfile or {}

    local history = type(db.routeSessions) == "table" and db.routeSessions[tostring(id)] or nil
    local eligible = {}
    if type(history) == "table" then
        for _, entry in ipairs(history) do
            if type(entry) == "table" and tostring(entry.routeKey or "") == tostring(routeKey or "") then
                local quality = tostring(entry.quality or "INSUFFICIENT")
                local confidence = tonumber(entry.qualityConfidence) or 0
                local seconds = tonumber(entry.seconds) or 0
                if (quality == "STRONG" or quality == "USABLE") and confidence > 0 and seconds > 0 then
                    eligible[#eligible + 1] = entry
                end
            end
        end
    end

    -- Keep the most recent sessions separate from the established historical
    -- baseline. Five sessions is deliberately small enough to react to drift
    -- while preserving a meaningful established reference.
    local recentCount = math.min(5, #eligible)
    local established = {}
    if #eligible > recentCount then
        for i = 1, #eligible - recentCount do established[#established + 1] = eligible[i] end
    else
        for i = 1, #eligible do established[#established + 1] = eligible[i] end
    end

    local gphTotal, gphWeight = 0, 0
    local completionTotal, completionWeight = 0, 0
    local loopTotal, loopCount = 0, 0
    for _, entry in ipairs(established) do
        local seconds = tonumber(entry.seconds) or 0
        local value = tonumber(entry.value) or 0
        local confidence = math.max(1, math.min(100, tonumber(entry.qualityConfidence) or 0))
        local weight = (confidence / 100) * math.min(3, math.max(0.5, seconds / 600))
        local gph = seconds > 0 and value / (seconds / 3600) or 0
        gphTotal = gphTotal + gph * weight
        gphWeight = gphWeight + weight
        local completion = type(entry.routeCompletion) == "table" and tonumber(entry.routeCompletion.coverage) or nil
        if completion ~= nil then
            completionTotal = completionTotal + completion * weight
            completionWeight = completionWeight + weight
        end
        local metrics = type(entry.pathMetrics) == "table" and entry.pathMetrics or nil
        if metrics and metrics.loop ~= nil then
            loopTotal = loopTotal + (metrics.loop and 100 or 0)
            loopCount = loopCount + 1
        end
    end

    local baselineGPH = gphWeight > 0 and gphTotal / gphWeight or tonumber(fallbackProfile.averageGPH) or 0
    local baselineCompletion = completionWeight > 0 and completionTotal / completionWeight or tonumber(fallbackProfile.averageCompletion) or 100
    local baselineLoops = loopCount > 0 and loopTotal / loopCount or tonumber(fallbackProfile.loopRate) or 0
    local baselineGeometry = tonumber(fallbackProfile.geometryConsistency) or 0
    local baselineConfidence = tonumber(fallbackProfile.averageConfidence) or 0

    if #established == 0 and not (baselineGPH > 0 or baselineConfidence > 0) then
        return nil
    end

    local first = established[1]
    local last = established[#established]
    return {
        version = 1,
        source = #eligible > recentCount and "ESTABLISHED_HISTORY" or "INITIAL_HISTORY",
        sessions = #established,
        eligibleSessions = #eligible,
        recentExcluded = recentCount,
        gph = baselineGPH,
        completion = baselineCompletion,
        geometryConsistency = baselineGeometry,
        loopRate = baselineLoops,
        confidence = baselineConfidence,
        capturedAt = nowAt,
        windowStart = first and tonumber(first.endedAt) or nil,
        windowEnd = last and tonumber(last.endedAt) or nil,
    }
end

function Tracker:BuildRollingRouteBaselineSnapshot(itemID, routeKey, fallbackProfile, nowAt)
    local db = EnsureDB()
    local id = tonumber(itemID)
    if not id then return nil end
    nowAt = tonumber(nowAt) or time()
    fallbackProfile = type(fallbackProfile) == "table" and fallbackProfile or {}

    local history = type(db.routeSessions) == "table" and db.routeSessions[tostring(id)] or nil
    local eligible = {}
    if type(history) == "table" then
        for i = #history, 1, -1 do
            local entry = history[i]
            if type(entry) == "table" and tostring(entry.routeKey or "") == tostring(routeKey or "") then
                local quality = tostring(entry.quality or "INSUFFICIENT")
                local confidence = tonumber(entry.qualityConfidence) or 0
                local seconds = tonumber(entry.seconds) or 0
                if (quality == "STRONG" or quality == "USABLE") and confidence > 0 and seconds > 0 then
                    eligible[#eligible + 1] = entry
                    if #eligible >= 5 then break end
                end
            end
        end
    end

    if #eligible == 0 then return nil end
    local gphTotal, gphWeight = 0, 0
    local completionTotal, completionWeight = 0, 0
    local geometryTotal, geometryWeight = 0, 0
    local loopTotal, loopWeight = 0, 0
    local confidenceTotal, confidenceWeight = 0, 0

    for _, entry in ipairs(eligible) do
        local seconds = tonumber(entry.seconds) or 0
        local confidence = math.max(1, math.min(100, tonumber(entry.qualityConfidence) or 0))
        local weight = (confidence / 100) * math.min(3, math.max(0.5, seconds / 600))
        local value = tonumber(entry.value) or tonumber(entry.routeValue) or 0
        local gph = seconds > 0 and value / (seconds / 3600) or 0
        gphTotal = gphTotal + gph * weight
        gphWeight = gphWeight + weight
        confidenceTotal = confidenceTotal + confidence * weight
        confidenceWeight = confidenceWeight + weight

        local completion = type(entry.routeCompletion) == "table" and tonumber(entry.routeCompletion.coverage) or nil
        if completion ~= nil then
            completionTotal = completionTotal + completion * weight
            completionWeight = completionWeight + weight
        end
        local metrics = type(entry.pathMetrics) == "table" and entry.pathMetrics or nil
        if metrics then
            local geometry = tonumber(entry.geometryConsistency) or tonumber(metrics.consistency)
            if geometry ~= nil then
                geometryTotal = geometryTotal + geometry * weight
                geometryWeight = geometryWeight + weight
            end
            if metrics.loop ~= nil then
                loopTotal = loopTotal + (metrics.loop and 100 or 0) * weight
                loopWeight = loopWeight + weight
            end
        end
    end

    local latestFirst = eligible[#eligible]
    local latestLast = eligible[1]
    return {
        version = 1,
        source = "ROLLING_RECENT",
        sessions = #eligible,
        gph = gphWeight > 0 and gphTotal / gphWeight or tonumber(fallbackProfile.averageGPH) or 0,
        completion = completionWeight > 0 and completionTotal / completionWeight or tonumber(fallbackProfile.averageCompletion) or 100,
        geometryConsistency = geometryWeight > 0 and geometryTotal / geometryWeight or tonumber(fallbackProfile.geometryConsistency) or 0,
        loopRate = loopWeight > 0 and loopTotal / loopWeight or tonumber(fallbackProfile.loopRate) or 0,
        confidence = confidenceWeight > 0 and confidenceTotal / confidenceWeight or tonumber(fallbackProfile.averageConfidence) or 0,
        capturedAt = nowAt,
        windowStart = latestFirst and tonumber(latestFirst.endedAt) or nil,
        windowEnd = latestLast and tonumber(latestLast.endedAt) or nil,
    }
end

function Tracker:CompareRouteBaselines(established, rolling)
    if type(established) ~= "table" or type(rolling) ~= "table" then return nil end
    local function pct(current, base)
        if not base or base <= 0 or not current then return 0 end
        return (current - base) / base * 100
    end
    local gph = pct(rolling.gph, established.gph)
    local completion = pct(rolling.completion, established.completion)
    local geometry = pct(rolling.geometryConsistency, established.geometryConsistency)
    local loop = pct(rolling.loopRate, established.loopRate)
    local signals = 0
    if math.abs(gph) >= 20 then signals = signals + 1 end
    if math.abs(completion) >= 20 then signals = signals + 1 end
    if math.abs(geometry) >= 20 then signals = signals + 1 end
    if math.abs(loop) >= 20 then signals = signals + 1 end
    return {
        gph = gph,
        completion = completion,
        geometry = geometry,
        loop = loop,
        signalCount = signals,
        gradualDrift = signals >= 2,
    }
end

function Tracker:ClassifyRouteDrift(profile)
    if type(profile) ~= "table" then
        return {state = "STABLE", observations = 0, anomalous = 0, corroborated = 0, confidence = 0}
    end
    local timeline = type(profile.stateTimeline) == "table" and profile.stateTimeline or {}
    local total = #timeline
    if total == 0 then
        return {state = "STABLE", observations = 0, anomalous = 0, corroborated = 0, confidence = 0}
    end

    local start = math.max(1, total - 5)
    local observations, anomalous, corroborated = 0, 0, 0
    local recent = {}
    for i = start, total do
        local entry = timeline[i]
        if type(entry) == "table" then
            observations = observations + 1
            local signals = tonumber(entry.signalCount) or 0
            local gradual = entry.baselineDrift == true
            local isAnomaly = signals >= 1 or gradual
            local isCorroborated = signals >= 2 or gradual
            if isAnomaly then anomalous = anomalous + 1 end
            if isCorroborated then corroborated = corroborated + 1 end
            recent[#recent + 1] = {anomaly = isAnomaly, corroborated = isCorroborated}
        end
    end

    local last3Anomaly, last3Corroborated = 0, 0
    local n3 = math.max(1, #recent - 2)
    for i = n3, #recent do
        if recent[i].anomaly then last3Anomaly = last3Anomaly + 1 end
        if recent[i].corroborated then last3Corroborated = last3Corroborated + 1 end
    end

    local state = "STABLE"
    if observations >= 3 and last3Anomaly >= 2 and last3Corroborated >= 1 then
        state = "SUSTAINED"
    elseif observations >= 5 and anomalous >= 3 and corroborated >= 2 then
        state = "SUSTAINED"
    elseif anomalous >= 2 then
        state = "EMERGING"
    elseif anomalous == 1 then
        local latest = recent[#recent]
        state = latest and latest.anomaly and "EMERGING" or "TRANSIENT"
    end

    if state == "STABLE" and total >= 2 then
        local latest = recent[#recent]
        local prior = recent[#recent - 1]
        if latest and not latest.anomaly and prior and prior.anomaly then
            state = "TRANSIENT"
        end
    end

    local confidence = 0
    if observations > 0 then
        local persistence = anomalous / observations
        local corroboration = corroborated / observations
        confidence = math.max(0, math.min(100, persistence * 60 + corroboration * 40))
        if state == "SUSTAINED" then
            confidence = math.max(confidence, 70)
        elseif state == "TRANSIENT" then
            confidence = math.min(confidence, 45)
        end
    end

    return {
        version = 1,
        state = state,
        observations = observations,
        anomalous = anomalous,
        corroborated = corroborated,
        last3Anomalous = last3Anomaly,
        last3Corroborated = last3Corroborated,
        confidence = confidence,
        updatedAt = time(),
    }
end

function Tracker:MaybeReviseRouteBaseline(profile, rollingSnapshot, driftClassification, nowAt)
    if type(profile) ~= "table" or type(rollingSnapshot) ~= "table" or type(driftClassification) ~= "table" then
        return nil
    end
    nowAt = tonumber(nowAt) or time()

    local sustained = tostring(driftClassification.state or "") == "SUSTAINED"
    local sessions = tonumber(rollingSnapshot.sessions) or 0
    local drift = type(profile.baselineDrift) == "table" and profile.baselineDrift or nil
    local signals = tonumber(drift and drift.signalCount) or 0
    if not sustained or sessions < 3 or signals < 2 then return nil end

    local prior = type(profile.baselineSnapshot) == "table" and profile.baselineSnapshot or nil
    if not prior then return nil end

    local function delta(current, base)
        if current == nil or base == nil or base == 0 then return nil end
        return math.abs(current - base) / math.abs(base) * 100
    end

    -- Baseline revision is now a two-stage process. Sustained drift creates a
    -- candidate, but the candidate must remain stable across several later
    -- observations before becoming the long-term reference.
    local pending = type(profile.pendingBaselineRevision) == "table" and profile.pendingBaselineRevision or nil
    local candidate = pending and pending.snapshot or nil
    if not candidate then
        local material = 0
        if (delta(rollingSnapshot.gph, prior.gph) or 0) >= 15 then material = material + 1 end
        if (delta(rollingSnapshot.completion, prior.completion) or 0) >= 15 then material = material + 1 end
        if (delta(rollingSnapshot.geometryConsistency, prior.geometryConsistency) or 0) >= 15 then material = material + 1 end
        if (delta(rollingSnapshot.loopRate, prior.loopRate) or 0) >= 15 then material = material + 1 end
        if material < 2 then return nil end

        profile.baselineRevisionDiagnostics = {status = "CANDIDATE_CREATED", at = nowAt, failedSignals = {}, message = "Sustained drift created a baseline candidate"}
        local copy = {}
        for k, v in pairs(rollingSnapshot) do copy[k] = v end
        profile.pendingBaselineRevision = {
            snapshot = copy,
            startedAt = nowAt,
            validationStreak = 1,
            validationObservations = 1,
            lastValidatedAt = nowAt,
            status = "PENDING_VALIDATION",
        }
        profile.baselineRevisionReason = "Sustained drift candidate awaiting validation"
        return nil
    end

    -- The candidate must be reproducible, not merely sustained relative to the
    -- obsolete baseline. Allow modest movement between rolling windows.
    local checks, passed = 0, 0
    local failedSignals, signalDeltas = {}, {}
    local function check(name, current, base, threshold)
        if current == nil or base == nil or base == 0 then return end
        local d = delta(current, base) or 999
        checks = checks + 1
        signalDeltas[name] = d
        if d <= threshold then passed = passed + 1 else failedSignals[#failedSignals + 1] = name end
    end
    check("gph", rollingSnapshot.gph, candidate.gph, 15)
    check("completion", rollingSnapshot.completion, candidate.completion, 15)
    check("geometry", rollingSnapshot.geometryConsistency, candidate.geometryConsistency, 15)
    check("loop", rollingSnapshot.loopRate, candidate.loopRate, 15)

    local corroborated = checks > 0 and passed / checks >= 0.75
    pending.validationObservations = (tonumber(pending.validationObservations) or 1) + 1
    if corroborated then
        pending.validationStreak = (tonumber(pending.validationStreak) or 1) + 1
        pending.lastValidatedAt = nowAt
    else
        -- A failed validation does not rewrite the baseline. It restarts the
        -- candidate only when the route is still classified as sustained.
        pending.validationStreak = 0
        pending.status = "REJECTED"
        pending.lastFailedAt = nowAt
        pending.lastFailedSignals = failedSignals
        pending.lastSignalDeltas = signalDeltas
        profile.baselineRevisionDiagnostics = {status = "REJECTED", at = nowAt, failedSignals = failedSignals, signalDeltas = signalDeltas, checks = checks, passed = passed, message = "Baseline candidate failed stability validation"}
        pending.snapshot = nil
        profile.pendingBaselineRevision = pending
        profile.baselineRevisionReason = "Baseline candidate failed stability validation"
        return nil
    end

    pending.status = "VALIDATED"
    profile.pendingBaselineRevision = pending

    -- Require three consecutive validated rolling observations. This gives the
    -- new state time to prove it is stable and prevents an abrupt market/event
    -- effect from permanently redefining the route baseline.
    if (tonumber(pending.validationStreak) or 0) < 3 then
        profile.baselineRevisionReason = "Baseline candidate validating"
        return nil
    end

    local lastRevision = tonumber(profile.baselineRevisionAt) or 0
    if lastRevision > 0 and nowAt - lastRevision < 86400 then return nil end

    local history = type(profile.baselineRevisionHistory) == "table" and profile.baselineRevisionHistory or {}
    history[#history + 1] = {
        at = nowAt,
        fromCapturedAt = tonumber(prior.capturedAt),
        toCapturedAt = tonumber(rollingSnapshot.capturedAt),
        sessions = sessions,
        driftSignals = signals,
        driftConfidence = tonumber(driftClassification.confidence) or 0,
        validationStreak = tonumber(pending.validationStreak) or 0,
        validationObservations = tonumber(pending.validationObservations) or 0,
        priorGPH = tonumber(prior.gph) or 0,
        newGPH = tonumber(rollingSnapshot.gph) or 0,
        priorCompletion = tonumber(prior.completion) or 0,
        newCompletion = tonumber(rollingSnapshot.completion) or 0,
        priorGeometry = tonumber(prior.geometryConsistency) or 0,
        newGeometry = tonumber(rollingSnapshot.geometryConsistency) or 0,
        priorLoopRate = tonumber(prior.loopRate) or 0,
        newLoopRate = tonumber(rollingSnapshot.loopRate) or 0,
    }
    while #history > 10 do table.remove(history, 1) end

    local revised = {}
    for k, v in pairs(rollingSnapshot) do revised[k] = v end
    revised.version = 3
    revised.source = "REVISED_FROM_VALIDATED_DRIFT"
    revised.revision = (tonumber(profile.baselineRevision) or 0) + 1
    revised.capturedAt = nowAt
    revised.revisedAt = nowAt
    revised.previousCapturedAt = tonumber(prior.capturedAt)
    revised.validationStreak = tonumber(pending.validationStreak) or 0

    profile.baselineSnapshot = revised
    profile.baselineRevision = revised.revision
    profile.baselineRevisionAt = nowAt
    profile.baselineRevisionHistory = history
    profile.baselineRevisionReason = "Validated sustained multi-signal route drift"
    profile.baselineRevisionDiagnostics = {status = "ESTABLISHED", at = nowAt, failedSignals = {}, checks = checks, passed = passed, message = "Baseline candidate passed stability validation"}
    profile.pendingBaselineRevision = nil
    return revised
end

function Tracker:UpdateRouteEvidenceProfile(stat, session, geometry)
    if type(stat) ~= "table" or type(session) ~= "table" then return nil end
    local profile = type(stat.routeEvidence) == "table" and stat.routeEvidence or {}
    local quality = session.sessionQuality or {}
    local baselineSnapshot = type(profile.baselineSnapshot) == "table" and profile.baselineSnapshot or nil
    if not baselineSnapshot then
        baselineSnapshot = self:BuildRouteBaselineSnapshot(session.routeItemID, session.routeKey, profile, tonumber(session.endedAt) or time())
        if baselineSnapshot then
            profile.baselineSnapshot = baselineSnapshot
        end
    end
    local rollingSnapshot = self:BuildRollingRouteBaselineSnapshot(session.routeItemID, session.routeKey, profile, tonumber(session.endedAt) or time())
    if rollingSnapshot then
        profile.rollingBaselineSnapshot = rollingSnapshot
        profile.baselineDrift = self:CompareRouteBaselines(baselineSnapshot, rollingSnapshot)
    end
    self:ApplyRouteEvidenceDecay(profile, tonumber(session.endedAt) or time())
    self:ApplyBaselineConfidenceAging(profile, tonumber(session.endedAt) or time())
    local status = tostring(quality.status or "INSUFFICIENT")
    local confidence = math.max(0, math.min(100, tonumber(quality.confidence) or 0))
    -- Preserve the prior evidence baseline for multi-signal state detection.
    profile.preUpdateAverageGPH = tonumber(profile.averageGPH)
    profile.preUpdateAverageCompletion = tonumber(profile.averageCompletion)
    profile.preUpdateGeometryConsistency = tonumber(profile.geometryConsistency)
    profile.preUpdateLoopRate = tonumber(profile.loopRate)
    local seconds = math.max(0, tonumber(session.seconds) or 0)
    local value = tonumber(session.routeValue) or 0
    local gph = seconds > 0 and value / (seconds / 3600) or 0
    local eligible = (status == "STRONG" or status == "USABLE") and confidence > 0 and seconds > 0

    profile.sessions = (tonumber(profile.sessions) or 0) + 1
    profile.lastAt = tonumber(session.endedAt) or time()
    profile.lastEvidenceAt = profile.lastAt
    profile.lastStatus = status
    profile.lastConfidence = confidence
    profile.totalSeconds = (tonumber(profile.totalSeconds) or 0) + seconds
    if eligible then
        profile.usableSessions = (tonumber(profile.usableSessions) or 0) + 1
        if status == "STRONG" then profile.strongSessions = (tonumber(profile.strongSessions) or 0) + 1 end

        -- Recency-weighted evidence: the effective sample size decays using
        -- an adaptive half-life, so stable routes retain useful history while
        -- volatile routes respond more quickly to changing performance.
        local effective = tonumber(profile.effectiveSessions) or 0
        local sampleWeight = 1
        local alpha = sampleWeight / (effective + sampleWeight)
        local oldGPH = tonumber(profile.averageGPH) or 0
        if effective <= 0 then
            profile.averageGPH = gph
            profile.gphVariance = 0
            profile.averageConfidence = confidence
        else
            profile.averageGPH = oldGPH + (gph - oldGPH) * alpha
            local oldVariance = tonumber(profile.gphVariance) or 0
            profile.gphVariance = math.max(0, (1 - alpha) * (oldVariance + alpha * (gph - oldGPH) * (gph - oldGPH)))
            profile.averageConfidence = (tonumber(profile.averageConfidence) or 0) + (confidence - (tonumber(profile.averageConfidence) or 0)) * alpha
        end
        profile.effectiveSessions = effective + sampleWeight
        profile.recencyWeight = profile.effectiveSessions

        local completion = type(quality.routeCompletion) == "table" and tonumber(quality.routeCompletion.coverage) or nil
        if completion ~= nil then
            local oldCompletion = tonumber(profile.averageCompletion) or completion
            profile.averageCompletion = effective <= 0 and completion or oldCompletion + (completion - oldCompletion) * alpha
        elseif profile.averageCompletion == nil then
            profile.averageCompletion = 100
        end
        profile.gphStdDev = math.sqrt(math.max(0, tonumber(profile.gphVariance) or 0))
        profile.gphStability = math.max(0, math.min(100, 100 - ((profile.gphStdDev / math.max(profile.averageGPH, 1)) * 100)))
    end

    if type(geometry) == "table" and (tonumber(geometry.usableSessions) or 0) > 0 then
        profile.geometryConsistency = tonumber(geometry.consistency) or 0
        profile.geometrySessions = tonumber(geometry.usableSessions) or 0
        profile.loopRate = tonumber(geometry.loopRate) or 0
        profile.averageCoverage = tonumber(geometry.averageCoverage) or 0
    end

    local n = tonumber(profile.usableSessions) or 0
    if n > 1 then
        profile.gphStdDev = math.sqrt(math.max(0, (tonumber(profile.gphDeviation) or 0) / (n - 1)))
        profile.gphStability = math.max(0, math.min(100, 100 - ((profile.gphStdDev / math.max(profile.averageGPH, 1)) * 100)))
    elseif n == 1 then
        profile.gphStdDev = 0
        profile.gphStability = 100
    end

    -- Detect route state changes from multiple independent signals. Economic
    -- noise alone should not redefine a route: a change requires repeated
    -- evidence across GPH, completion, geometry, and/or loop behavior.
    -- Capture the prior profile values before replacing them with the latest
    -- aggregate so the comparison is genuinely against established history.
    local snapshot = type(profile.baselineSnapshot) == "table" and profile.baselineSnapshot or nil
    local baselineGPH = tonumber(snapshot and snapshot.gph) or tonumber(profile.preUpdateAverageGPH or profile.averageGPH) or 0
    local baselineCompletion = tonumber(snapshot and snapshot.completion) or tonumber(profile.preUpdateAverageCompletion or profile.averageCompletion)
    local baselineGeometry = tonumber(snapshot and snapshot.geometryConsistency) or tonumber(profile.preUpdateGeometryConsistency or profile.geometryConsistency)
    local baselineLoops = tonumber(snapshot and snapshot.loopRate) or tonumber(profile.preUpdateLoopRate or profile.loopRate)
    local gphDeviation = 0
    local completionDeviation = 0
    local geometryDeviation = 0
    local loopDeviation = 0
    local gphChanged, completionChanged, geometryChanged, loopChanged = false, false, false, false

    if eligible and baselineGPH > 0 and gph > 0 then
        gphDeviation = math.abs(gph - baselineGPH) / baselineGPH * 100
        gphChanged = gphDeviation >= 30
    end
    local latestCompletion = type(quality.routeCompletion) == "table" and tonumber(quality.routeCompletion.coverage) or nil
    if eligible and latestCompletion ~= nil and baselineCompletion and baselineCompletion > 0 then
        completionDeviation = math.max(0, baselineCompletion - latestCompletion) / baselineCompletion * 100
        completionChanged = completionDeviation >= 25
    end
    local latestGeometry = type(geometry) == "table" and tonumber(geometry.consistency) or nil
    local latestLoops = type(geometry) == "table" and tonumber(geometry.loopRate) or nil
    if eligible and latestGeometry ~= nil and baselineGeometry and baselineGeometry > 0 then
        geometryDeviation = math.max(0, baselineGeometry - latestGeometry)
        geometryChanged = geometryDeviation >= 25
    end
    if eligible and latestLoops ~= nil and baselineLoops and baselineLoops > 0 then
        loopDeviation = math.max(0, baselineLoops - latestLoops)
        loopChanged = loopDeviation >= 25
    end

    -- A rolling-vs-established divergence identifies gradual drift. It is a
    -- corroborating signal rather than a replacement for the per-session
    -- checks, so a slowly changing route does not flip state on one anomaly.
    local baselineDrift = type(profile.baselineDrift) == "table" and profile.baselineDrift or nil
    local driftSignal = baselineDrift and baselineDrift.gradualDrift == true
    local signalCount = 0
    if gphChanged then signalCount = signalCount + 1 end
    if completionChanged then signalCount = signalCount + 1 end
    if geometryChanged then signalCount = signalCount + 1 end
    if loopChanged then signalCount = signalCount + 1 end

    local state = tostring(profile.state or "STABLE")
    local previousState = state
    local anomalyStreak = tonumber(profile.anomalyStreak) or 0
    local recoveryStreak = tonumber(profile.recoveryStreak) or 0
    local priorSignalCount = tonumber(profile.lastSignalCount) or 0
    local driftCorroborated = eligible and driftSignal and signalCount >= 1
    local materiallyChanged = eligible and (signalCount >= 2 or driftCorroborated)
    local corroborated = materiallyChanged and (priorSignalCount >= 2 or driftCorroborated)
    if corroborated then
        anomalyStreak = anomalyStreak + 1
    elseif materiallyChanged then
        anomalyStreak = 1
    elseif eligible and signalCount == 0 then
        anomalyStreak = 0
    elseif eligible then
        -- A single isolated signal is worth watching, but is not enough to
        -- establish a new route state.
        anomalyStreak = 0
    end

    if anomalyStreak >= 2 then
        state = "CHANGED"
        recoveryStreak = 0
    elseif materiallyChanged or (eligible and signalCount == 1) then
        state = "WATCH"
        recoveryStreak = 0
    elseif eligible and signalCount == 0 then
        if previousState == "CHANGED" then
            -- Recovery is deliberately staged: two clean observations move
            -- CHANGED -> WATCH -> STABLE, allowing confidence to recover
            -- without snapping back after one good run.
            recoveryStreak = math.min(3, recoveryStreak + 1)
            state = recoveryStreak >= 2 and "STABLE" or "WATCH"
        elseif previousState == "WATCH" then
            recoveryStreak = math.min(3, recoveryStreak + 1)
            state = recoveryStreak >= 1 and "STABLE" or "WATCH"
        else
            recoveryStreak = 0
            state = "STABLE"
        end
    else
        recoveryStreak = 0
        state = "STABLE"
    end

    profile.recoveryStreak = recoveryStreak
    profile.recoveryFactor = math.min(1, 0.70 + (recoveryStreak * 0.15))
    if state == "STABLE" and previousState == "CHANGED" then
        profile.recoveryFactor = 0.95
    end

    profile.anomalyStreak = anomalyStreak
    profile.lastSignalCount = signalCount
    profile.lastSignals = {
        gph = gphChanged,
        completion = completionChanged,
        geometry = geometryChanged,
        loop = loopChanged,
        gradualDrift = driftSignal,
    }
    profile.lastDeviationPct = gphDeviation
    profile.lastCompletionDeviationPct = completionDeviation
    profile.lastGeometryDeviation = geometryDeviation
    profile.lastLoopDeviation = loopDeviation
    profile.state = state
    profile.stateChangedAt = (state ~= tostring(profile.previousState or state)) and (tonumber(session.endedAt) or time()) or profile.stateChangedAt
    profile.previousState = state

    -- Preserve a compact route-state history so GoldMint can distinguish a
    -- transient anomaly from a sustained baseline shift. Keep this separate
    -- from routeSessions: the timeline stores state evidence, not raw paths or
    -- loot payloads. Newest entries are appended and the history is bounded.
    local timeline = type(profile.stateTimeline) == "table" and profile.stateTimeline or {}
    if eligible then
        timeline[#timeline + 1] = {
            at = tonumber(session.endedAt) or time(),
            state = state,
            previousState = previousState,
            signalCount = signalCount,
            signals = {
                gph = gphChanged,
                completion = completionChanged,
                geometry = geometryChanged,
                loop = loopChanged,
                gradualDrift = driftSignal,
            },
            gphDeviation = gphDeviation,
            completionDeviation = completionDeviation,
            geometryDeviation = geometryDeviation,
            loopDeviation = loopDeviation,
            recoveryStreak = recoveryStreak,
            baselineDrift = driftSignal,
        }
        while #timeline > 20 do table.remove(timeline, 1) end
    end
    profile.stateTimeline = timeline
    profile.stateTimelineVersion = 1
    profile.driftClassification = self:ClassifyRouteDrift(profile)

    -- Sustained drift can establish a new long-term reference. Keep the prior
    -- baseline and a compact revision history so the change remains auditable.
    local revisedBaseline = self:MaybeReviseRouteBaseline(profile, rollingSnapshot, profile.driftClassification, tonumber(session.endedAt) or time())
    if revisedBaseline then
        profile.baselineDrift = self:CompareRouteBaselines(revisedBaseline, rollingSnapshot)
        self:ApplyBaselineConfidenceAging(profile, tonumber(session.endedAt) or time())
        profile.driftClassification.baselineRevised = true
        profile.driftClassification.baselineRevision = tonumber(profile.baselineRevision) or 0
    else
        profile.driftClassification.baselineRevised = false
    end

    local recencySessions = tonumber(profile.effectiveSessions) or 0
    local recencyFactor = math.max(0.45, math.min(1, recencySessions / 3))
    profile.recencyFactor = recencyFactor
    self:GetRouteEvidenceHalfLife(profile)
    profile.evidenceAgeDays = math.max(0, (time() - (tonumber(profile.lastEvidenceAt) or time())) / 86400)
    profile.evidenceConfidence = math.max(0, math.min(100,
        ((tonumber(profile.averageConfidence) or 0) * 0.55 +
        (tonumber(profile.gphStability) or 0) * 0.20 +
        (tonumber(profile.geometryConsistency) or 0) * 0.15 +
        (tonumber(profile.loopRate) or 0) * 0.10) * recencyFactor))
    stat.routeEvidence = profile
    return profile
end

function Tracker:GetRoutePathMetrics(path)
    if type(path) ~= "table" or #path < 2 then
        return {points = 0, distance = 0, duration = 0, closure = 0, coverage = 0, loop = false}
    end

    local distance, duration = 0, 0
    local minX, maxX, minY, maxY = path[1].x, path[1].x, path[1].y, path[1].y
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local dx = (tonumber(b.x) or 0) - (tonumber(a.x) or 0)
        local dy = (tonumber(b.y) or 0) - (tonumber(a.y) or 0)
        distance = distance + math.sqrt(dx * dx + dy * dy)
        if a.t and b.t then duration = duration + math.max((tonumber(b.t) or 0) - (tonumber(a.t) or 0), 0) end
        local x, y = tonumber(b.x) or 0, tonumber(b.y) or 0
        minX, maxX = math.min(minX, x), math.max(maxX, x)
        minY, maxY = math.min(minY, y), math.max(maxY, y)
    end

    local first, last = path[1], path[#path]
    local closeDx = (tonumber(last.x) or 0) - (tonumber(first.x) or 0)
    local closeDy = (tonumber(last.y) or 0) - (tonumber(first.y) or 0)
    local closure = distance > 0 and (1 - math.min(math.sqrt(closeDx * closeDx + closeDy * closeDy) / distance, 1)) or 0
    local bboxArea = math.max(maxX - minX, 0) * math.max(maxY - minY, 0)
    local travelArea = math.max(distance * math.max(math.min(maxX - minX, maxY - minY), 0), 0)
    local coverage = distance > 0 and math.min(100, math.max(0, (travelArea > 0 and math.sqrt(travelArea) or 0) * 100)) or 0
    -- Coverage is deliberately a geometry/consistency signal, not a map-area percentage.
    -- Closure rewards completed loops; path length and footprint prevent a short walk from
    -- looking like a full route. Keep it bounded and stable for SavedVariables/UI use.
    coverage = math.min(100, math.max(0, (math.min(distance * 100, 60) + closure * 40)))

    return {
        points = #path,
        distance = distance,
        duration = duration,
        closure = closure,
        coverage = coverage,
        loop = closure >= 0.80 and #path >= 4,
        minX = minX, maxX = maxX, minY = minY, maxY = maxY,
    }
end

function Tracker:ResampleRoutePath(path, samples)
    samples = math.max(4, math.floor(tonumber(samples) or 20))
    if type(path) ~= "table" or #path < 2 then return {} end

    local points = {}
    local cumulative = {0}
    local total = 0
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local dx = (tonumber(b.x) or 0) - (tonumber(a.x) or 0)
        local dy = (tonumber(b.y) or 0) - (tonumber(a.y) or 0)
        total = total + math.sqrt(dx * dx + dy * dy)
        cumulative[i] = total
    end
    if total <= 0 then return {} end

    local cursor = 2
    for n = 0, samples - 1 do
        local target = total * (n / (samples - 1))
        while cursor < #path and (cumulative[cursor] or 0) < target do cursor = cursor + 1 end
        local prev = math.max(cursor - 1, 1)
        local span = (cumulative[cursor] or total) - (cumulative[prev] or 0)
        local alpha = span > 0 and (target - (cumulative[prev] or 0)) / span or 0
        local a, b = path[prev], path[cursor]
        points[#points + 1] = {
            x = (tonumber(a.x) or 0) + ((tonumber(b.x) or 0) - (tonumber(a.x) or 0)) * alpha,
            y = (tonumber(a.y) or 0) + ((tonumber(b.y) or 0) - (tonumber(a.y) or 0)) * alpha,
        }
    end
    return points
end

function Tracker:GetRouteGeometryConsistency(itemID, routeKey)
    local db = EnsureDB()
    local id = tonumber(itemID) or (self.session and self.session.routeItemID) or self.routeItemID
    local key = routeKey or (self.session and self.session.routeKey) or self.routeKey
    if not id or type(db.routeSessions) ~= "table" then
        return {sessions = 0, usableSessions = 0, consistency = 0, averageCoverage = 0, loopRate = 0}
    end

    local history = db.routeSessions[tostring(id)]
    if type(history) ~= "table" then
        return {sessions = 0, usableSessions = 0, consistency = 0, averageCoverage = 0, loopRate = 0}
    end

    local traces = {}
    local coverageSum, loopCount = 0, 0
    for i = 1, #history do
        local row = history[i]
        if type(row) == "table" and (not key or tostring(row.routeKey or "") == tostring(key)) then
            local q = tostring(row.quality or "")
            local confidence = tonumber(row.qualityConfidence) or 0
            if (q == "STRONG" or q == "USABLE" or q == "") and confidence > 0 and type(row.path) == "table" and #row.path >= 4 then
                local trace = self:ResampleRoutePath(row.path, 20)
                if #trace >= 4 then
                    traces[#traces + 1] = trace
                    local m = type(row.pathMetrics) == "table" and row.pathMetrics or self:GetRoutePathMetrics(row.path)
                    coverageSum = coverageSum + (tonumber(m.coverage) or 0)
                    if m.loop then loopCount = loopCount + 1 end
                end
            end
        end
    end

    local count = #traces
    if count == 0 then
        return {sessions = 0, usableSessions = 0, consistency = 0, averageCoverage = 0, loopRate = 0}
    end

    -- Compare each session against the current consensus trace. Start with the
    -- first trace, then repeatedly average aligned points. This is intentionally
    -- lightweight: it provides a stable route-shape signal without storing a
    -- second full-resolution copy of every historical path.
    local consensus = {}
    for j = 1, #traces[1] do consensus[j] = {x = traces[1][j].x, y = traces[1][j].y} end
    local deviationSum, comparisons = 0, 0
    for i = 2, count do
        local trace = traces[i]
        local scale = 1
        local total = 0
        for j = 1, #consensus do
            local dx = trace[j].x - consensus[j].x
            local dy = trace[j].y - consensus[j].y
            total = total + math.sqrt(dx * dx + dy * dy)
        end
        local meanDeviation = total / #consensus
        deviationSum = deviationSum + meanDeviation
        comparisons = comparisons + 1
        for j = 1, #consensus do
            consensus[j].x = (consensus[j].x + trace[j].x) * 0.5
            consensus[j].y = (consensus[j].y + trace[j].y) * 0.5
        end
    end

    -- Route coordinates are map-normalized (0..1). A 0.03 mean deviation is
    -- already a visibly different route; clamp the score for stable UI use.
    local meanDeviation = comparisons > 0 and deviationSum / comparisons or 0
    local consistency = math.max(0, math.min(100, 100 - (meanDeviation / 0.03 * 100)))
    return {
        sessions = #history,
        usableSessions = count,
        consistency = consistency,
        meanDeviation = meanDeviation,
        averageCoverage = coverageSum / count,
        loopRate = loopCount / count * 100,
        consensus = consensus,
    }
end

function Tracker:GetRouteVisualization(itemID, routeKey)
    local path, mapID = self:GetRoutePath(itemID, routeKey)
    local metrics = self:GetRoutePathMetrics(path)
    local trace = {}
    if type(path) == "table" then
        local lastX, lastY
        for _, point in ipairs(path) do
            local x, y = tonumber(point.x), tonumber(point.y)
            if x and y and (not lastX or math.abs(x - lastX) >= 0.003 or math.abs(y - lastY) >= 0.003) then
                trace[#trace + 1] = {x = x, y = y}
                lastX, lastY = x, y
            end
        end
    end
    return {mapID = tonumber(mapID), trace = trace, metrics = metrics}
end

function Tracker:GetRoutePath(itemID, routeKey)
    local db = EnsureDB()
    local id = tonumber(itemID) or (self.session and self.session.routeItemID) or self.routeItemID
    local key = routeKey or (self.session and self.session.routeKey) or self.routeKey
    if self.session and self.session.routeItemID == id and self.session.routeKey == key and type(self.session.routePath) == "table" and #self.session.routePath > 1 then
        return self.session.routePath, self.session.routeMapID
    end
    if id and type(db.routeStats) == "table" then
        local stat = db.routeStats[tostring(id) .. "|" .. tostring(key or "")]
        if type(stat) == "table" and type(stat.latestPath) == "table" and #stat.latestPath > 1 then
            return stat.latestPath, stat.mapID
        end
    end
    return {}, nil
end

function Tracker:GetRoutePerformances(itemID)
    local db = EnsureDB()
    local id = tonumber(itemID) or (self.session and self.session.routeItemID) or self.routeItemID
    if not id or type(db.routeStats) ~= "table" then return {} end

    -- Route performance rows are derived from persisted route aggregates and
    -- can be relatively expensive when several routes/history profiles exist.
    -- Cache them briefly for dashboard/comparison consumers; mutations such as
    -- End() invalidate the cache so completed-session data is immediately seen.
    local now = GetTime and GetTime() or 0
    local cache = self._routePerformanceCache
    if cache and cache.itemID == id and (now - (cache.at or 0)) < PERFORMANCE_REFRESH_INTERVAL then
        return cache.data
    end

    local prefix = tostring(id) .. "|"
    local rows = {}
    local seen = {}
    for key, stat in pairs(db.routeStats) do
        if type(stat) == "table" and (tostring(key):sub(1, #prefix) == prefix or tostring(key) == tostring(id)) then
            local seconds = tonumber(stat.seconds) or 0
            local sessions = tonumber(stat.sessions) or 0
            local items = tonumber(stat.items) or 0
            local value = tonumber(stat.value) or 0
            if seconds > 0 and sessions > 0 and not seen[tostring(key)] then
                seen[tostring(key)] = true
                rows[#rows + 1] = {
                    routeKey = stat.routeKey or tostring(key):sub(#prefix + 1),
                    sessions = sessions,
                    seconds = seconds,
                    value = value,
                    items = items,
                    valuePerHour = (tonumber(stat.qualityWeightTotal) or 0) > 0 and (tonumber(stat.qualityWeightedGPH) or 0) / (tonumber(stat.qualityWeightTotal) or 1) or ((tonumber(stat.qualityWeightedValue) or value) / ((tonumber(stat.qualityWeightedSeconds) or seconds) / 3600)),
                    itemsPerHour = (tonumber(stat.qualityWeightTotal) or 0) > 0 and (tonumber(stat.qualityWeightedItemsPerHour) or 0) / (tonumber(stat.qualityWeightTotal) or 1) or ((tonumber(stat.qualityWeightedItems) or items) / ((tonumber(stat.qualityWeightedSeconds) or seconds) / 3600)),
                    valuePerItem = (tonumber(stat.qualityWeightedItems) or items) > 0 and (tonumber(stat.qualityWeightedValue) or value) / (tonumber(stat.qualityWeightedItems) or items) or 0,
                    qualityWeighted = (tonumber(stat.qualityWeightTotal) or tonumber(stat.qualityWeightedSeconds) or 0) > 0,
                    qualitySessions = tonumber(stat.qualitySessions) or 0,
                    averageConfidence = tonumber(stat.qualityConfidenceTotal) and (tonumber(stat.qualityConfidenceTotal) / math.max(tonumber(stat.qualitySessions) or 1, 1)) or 0,
                    averageCompletion = tonumber(stat.qualityCompletionWeightTotal) and (tonumber(stat.qualityCompletionWeightTotal) / math.max(tonumber(stat.qualitySessions) or 1, 1)) or 1,
                    geometryConsistency = type(stat.geometryConsistency) == "table" and tonumber(stat.geometryConsistency.consistency) or 0,
                    geometrySessions = type(stat.geometryConsistency) == "table" and tonumber(stat.geometryConsistency.usableSessions) or 0,
                    loopRate = type(stat.geometryConsistency) == "table" and tonumber(stat.geometryConsistency.loopRate) or 0,
                    routeEvidence = type(stat.routeEvidence) == "table" and stat.routeEvidence or nil,
                    routeBaseline = type(stat.routeEvidence) == "table" and stat.routeEvidence.baselineSnapshot or nil,
                    baselineRevision = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineRevision) or 0,
                    baselineRevisionAt = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineRevisionAt) or nil,
                    baselineRevisionHistory = type(stat.routeEvidence) == "table" and stat.routeEvidence.baselineRevisionHistory or nil,
                    pendingBaselineRevision = type(stat.routeEvidence) == "table" and stat.routeEvidence.pendingBaselineRevision or nil,
                    baselineRevisionReason = type(stat.routeEvidence) == "table" and stat.routeEvidence.baselineRevisionReason or nil,
                    baselineRevisionDiagnostics = type(stat.routeEvidence) == "table" and stat.routeEvidence.baselineRevisionDiagnostics or nil,
                    baselineAgeDays = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineAgeDays) or 0,
                    baselineHalfLifeDays = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineHalfLifeDays) or nil,
                    baselineRecencyFactor = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineRecencyFactor) or 1,
                    baselineConfidence = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineConfidence) or 0,
                    baselineAgeState = type(stat.routeEvidence) == "table" and stat.routeEvidence.baselineAgeState or "NONE",
                    baselineLastValidatedAt = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.baselineLastValidatedAt) or nil,
                    routeState = type(stat.routeEvidence) == "table" and stat.routeEvidence.state or "STABLE",
                    routeStateDeviation = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.lastDeviationPct) or 0,
                    routeStateSignals = type(stat.routeEvidence) == "table" and tonumber(stat.routeEvidence.lastSignalCount) or 0,
                    routeStateTimeline = type(stat.routeEvidence) == "table" and stat.routeEvidence.stateTimeline or nil,
                    driftClassification = type(stat.routeEvidence) == "table" and stat.routeEvidence.driftClassification or nil,
                    itemName = stat.itemName,
                    zone = stat.zone,
                    area = stat.area,
                }
            end
        end
    end

    table.sort(rows, function(a, b)
        if a.valuePerHour == b.valuePerHour then
            if a.sessions == b.sessions then
                return tostring(a.routeKey or "") < tostring(b.routeKey or "")
            end
            return a.sessions > b.sessions
        end
        return a.valuePerHour > b.valuePerHour
    end)
    self._routePerformanceCache = {itemID = id, at = now, data = rows}
    return rows
end

function Tracker:GetRecommendedRoute(itemID, routes)
    routes = type(routes) == "table" and routes or {}
    local intelligence = self:GetRouteIntelligence(itemID)
    local key = intelligence and intelligence.recommendedRouteKey
    if key then
        for _, route in ipairs(routes) do
            if tostring(route.routeID or "") == tostring(key) then
                return route, "MEASURED"
            end
        end
    end

    -- Fallback order is deterministic: current configured route, then the
    -- first known route. This keeps the Dashboard useful before enough
    -- evidence exists to recommend a measured alternate.
    local currentKey = self.session and self.session.routeKey or self.routeKey
    if currentKey then
        for _, route in ipairs(routes) do
            if tostring(route.routeID or "") == tostring(currentKey) then
                return route, "CURRENT"
            end
        end
    end
    if routes[1] then return routes[1], "FALLBACK" end
    return nil, "NONE"
end

function Tracker:GetRouteIntelligence(itemID)
    local id = tonumber(itemID) or (self.session and self.session.routeItemID) or self.routeItemID
    local performances = self:GetRoutePerformances(id)
    local currentKey = self.session and self.session.routeKey or self.routeKey
    if not id or #performances == 0 then
        return {status = "NO_DATA", eligible = false, sessions = 0, seconds = 0, routeCount = 0}
    end

    local current
    for _, row in ipairs(performances) do
        if currentKey and tostring(row.routeKey or "") == tostring(currentKey) then
            current = row
            break
        end
    end
    current = current or performances[1]

    local sessions = tonumber(current.sessions) or 0
    local seconds = tonumber(current.seconds) or 0
    local minimumSessions = 3
    local minimumSeconds = 30 * 60
    local matureSessions = 5
    local matureSeconds = 2 * 3600

    local status = "BUILDING_DATA"
    if sessions >= matureSessions and seconds >= matureSeconds then
        status = "ESTABLISHED"
    elseif sessions >= minimumSessions and seconds >= minimumSeconds then
        status = "VERIFIED"
    end

    -- Quality-aware recommendation candidate. A route is only considered
    -- established enough to recommend when it has usable quality evidence.
    -- Legacy rows remain eligible through the existing raw-history fallback.
    local candidates = {}
    for _, row in ipairs(performances) do
        local qualitySessions = tonumber(row.qualitySessions) or 0
        local confidence = tonumber(row.averageConfidence) or 0
        local measuredSeconds = tonumber(row.seconds) or 0
        local eligible = (qualitySessions >= minimumSessions and measuredSeconds >= minimumSeconds)
            or (not row.qualityWeighted and (tonumber(row.sessions) or 0) >= minimumSessions and measuredSeconds >= minimumSeconds)
        if eligible then
            candidates[#candidates + 1] = row
        end
    end

    -- Geometry is a repeatability signal, not a replacement for GPH.
    -- Blend it into recommendation confidence and only use a modest score
    -- adjustment so a proven high-value route is not discarded solely for
    -- imperfect path recording. Legacy rows retain full geometry confidence.
    local function enrichRecommendation(row)
        local evidence = type(row.routeEvidence) == "table" and row.routeEvidence or nil
        local baseConfidence = math.min(100, math.max(0, evidence and tonumber(evidence.evidenceConfidence) or tonumber(row.averageConfidence) or 0))
        local evidenceAgeDays = evidence and tonumber(evidence.evidenceAgeDays) or 0
        local recencyFactor = evidence and tonumber(evidence.recencyFactor) or 1
        local geometrySessions = tonumber(row.geometrySessions) or 0
        local consistency = tonumber(row.geometryConsistency) or 0
        local loopRate = tonumber(row.loopRate) or 0
        local completion = tonumber(row.averageCompletion) or 100
        local geometryConfidence
        local geometryWeight = 0
        local reasons = {}

        if geometrySessions >= 2 then
            geometryConfidence = math.max(0, math.min(100, consistency * 0.60 + loopRate * 0.25 + completion * 0.15))
            geometryWeight = math.min(0.25, geometrySessions / 12)
            if consistency < 50 then reasons[#reasons + 1] = "Inconsistent route geometry" end
            if loopRate < 50 then reasons[#reasons + 1] = "Low loop repeatability" end
            if completion < 60 then reasons[#reasons + 1] = "Partial route completion" end
        else
            geometryConfidence = baseConfidence
            geometryWeight = 0
            reasons[#reasons + 1] = "Limited geometry history"
        end

        if evidenceAgeDays >= 7 then reasons[#reasons + 1] = "Evidence is aging" end
        if recencyFactor < 0.75 then reasons[#reasons + 1] = "Limited recent evidence" end
        local halfLifeDays = evidence and tonumber(evidence.evidenceHalfLifeDays) or 7
        local volatility = evidence and tonumber(evidence.volatility) or 0
        if volatility >= 60 then reasons[#reasons + 1] = "Route performance is volatile" end
        local routeState = tostring(evidence and evidence.state or row.routeState or "STABLE")
        local driftClassification = type(evidence and evidence.driftClassification) == "table" and evidence.driftClassification or nil
        if driftClassification then
            if driftClassification.state == "SUSTAINED" then
                reasons[#reasons + 1] = "Sustained route drift detected"
            elseif driftClassification.state == "TRANSIENT" then
                reasons[#reasons + 1] = "Recent route drift appears transient"
            elseif driftClassification.state == "EMERGING" then
                reasons[#reasons + 1] = "Route drift is emerging"
            end
        end
        local baseline = type(row.routeBaseline) == "table" and row.routeBaseline or nil
        local baselineAgeState = tostring(evidence and evidence.baselineAgeState or "NONE")
        local baselineRecencyFactor = evidence and tonumber(evidence.baselineRecencyFactor) or 1
        if baseline and (tonumber(baseline.sessions) or 0) >= 3 then
            reasons[#reasons + 1] = "Established historical baseline available"
        elseif baseline then
            reasons[#reasons + 1] = "Baseline still maturing"
        end
        local rollingBaseline = type(evidence and evidence.rollingBaselineSnapshot) == "table" and evidence.rollingBaselineSnapshot or nil
        local baselineDrift = type(evidence and evidence.baselineDrift) == "table" and evidence.baselineDrift or nil
        if rollingBaseline then
            reasons[#reasons + 1] = "Recent rolling baseline available"
        end
        if baselineDrift and baselineDrift.gradualDrift then
            reasons[#reasons + 1] = "Recent performance differs from established baseline"
        end
        if baselineAgeState == "AGING" then
            reasons[#reasons + 1] = "Established baseline is aging"
        elseif baselineAgeState == "STALE" then
            reasons[#reasons + 1] = "Established baseline is stale"
        elseif baselineAgeState == "REVALIDATE" then
            reasons[#reasons + 1] = "Established baseline needs revalidation"
        end
        local stateConfidenceFactor = 1
        local recoveryFactor = evidence and tonumber(evidence.recoveryFactor) or 1
        if routeState == "WATCH" then
            stateConfidenceFactor = 0.90
            reasons[#reasons + 1] = "Possible route state change"
            if recoveryFactor < 1 then
                reasons[#reasons + 1] = "Route recovery is still being confirmed"
            end
        elseif routeState == "CHANGED" then
            stateConfidenceFactor = 0.75
            reasons[#reasons + 1] = "Recent route state change detected"
        elseif recoveryFactor < 1 then
            reasons[#reasons + 1] = "Recommendation confidence recovering"
        end
        local baselineAgingFactor = baseline and baselineAgeState ~= "NONE" and baselineRecencyFactor or 1
        local recommendationConfidence = (baseConfidence * (1 - geometryWeight) + geometryConfidence * geometryWeight) * recencyFactor * stateConfidenceFactor * recoveryFactor * baselineAgingFactor
        local gph = tonumber(row.valuePerHour) or 0
        -- Small geometry modifier for selection: at full weight it ranges from
        -- -10% to +5%, keeping economic performance as the dominant signal.
        local geometryModifier = geometryWeight > 0 and ((geometryConfidence - 60) / 100 * 0.15) or 0
        local recommendationScore = gph * (1 + geometryModifier)

        row.recommendationConfidence = recommendationConfidence
        row.geometryConfidence = geometryConfidence
        row.geometryWeight = geometryWeight
        row.recommendationScore = recommendationScore
        row.recommendationReasons = reasons
        return row
    end

    for _, row in ipairs(candidates) do enrichRecommendation(row) end

    local recommended = nil
    if #candidates > 0 then
        table.sort(candidates, function(a, b)
            if (a.recommendationScore or 0) == (b.recommendationScore or 0) then
                if (a.recommendationConfidence or 0) == (b.recommendationConfidence or 0) then
                    return (a.qualitySessions or a.sessions or 0) > (b.qualitySessions or b.sessions or 0)
                end
                return (a.recommendationConfidence or 0) > (b.recommendationConfidence or 0)
            end
            return (a.recommendationScore or 0) > (b.recommendationScore or 0)
        end)
        recommended = candidates[1]
    end

    return {
        status = status,
        eligible = status ~= "BUILDING_DATA",
        sessions = sessions,
        seconds = seconds,
        routeCount = #performances,
        minimumSessions = minimumSessions,
        minimumSeconds = minimumSeconds,
        valuePerHour = current.valuePerHour or 0,
        itemsPerHour = current.itemsPerHour or 0,
        routeKey = current.routeKey,
        zone = current.zone,
        area = current.area,
        recommended = recommended,
        recommendedRouteKey = recommended and recommended.routeKey or nil,
        recommendedValuePerHour = recommended and recommended.valuePerHour or 0,
        recommendedConfidence = recommended and recommended.recommendationConfidence or 0,
        recommendationScore = recommended and recommended.recommendationScore or 0,
        geometryConfidence = recommended and recommended.geometryConfidence or 0,
        geometryConsistency = recommended and recommended.geometryConsistency or 0,
        loopRate = recommended and recommended.loopRate or 0,
        geometrySessions = recommended and recommended.geometrySessions or 0,
        recommendationReasons = recommended and recommended.recommendationReasons or {},
        recommendationReady = recommended ~= nil,
        routeEvidence = recommended and recommended.routeEvidence or nil,
        routeBaseline = recommended and recommended.routeBaseline or nil,
        baselineRevision = recommended and recommended.baselineRevision or 0,
        baselineRevisionAt = recommended and recommended.baselineRevisionAt or nil,
        baselineRevisionHistory = recommended and recommended.baselineRevisionHistory or nil,
        pendingBaselineRevision = recommended and recommended.pendingBaselineRevision or nil,
        baselineRevisionReason = recommended and recommended.baselineRevisionReason or nil,
        baselineRevisionDiagnostics = recommended and recommended.baselineRevisionDiagnostics or nil,
        baselineAgeDays = recommended and recommended.baselineAgeDays or 0,
        baselineHalfLifeDays = recommended and recommended.baselineHalfLifeDays or nil,
        baselineRecencyFactor = recommended and recommended.baselineRecencyFactor or 1,
        baselineConfidence = recommended and recommended.baselineConfidence or 0,
        baselineAgeState = recommended and recommended.baselineAgeState or "NONE",
        baselineLastValidatedAt = recommended and recommended.baselineLastValidatedAt or nil,
        rollingBaseline = recommended and recommended.routeEvidence and recommended.routeEvidence.rollingBaselineSnapshot or nil,
        baselineDrift = recommended and recommended.routeEvidence and recommended.routeEvidence.baselineDrift or nil,
        evidenceAgeDays = recommended and recommended.routeEvidence and recommended.routeEvidence.evidenceAgeDays or 0,
        recencyFactor = recommended and recommended.routeEvidence and recommended.routeEvidence.recencyFactor or 1,
        evidenceHalfLifeDays = recommended and recommended.routeEvidence and recommended.routeEvidence.evidenceHalfLifeDays or 7,
        routeVolatility = recommended and recommended.routeEvidence and recommended.routeEvidence.volatility or 0,
        routeState = recommended and (recommended.routeState or (recommended.routeEvidence and recommended.routeEvidence.state)) or "STABLE",
        routeStateDeviation = recommended and (recommended.routeStateDeviation or (recommended.routeEvidence and recommended.routeEvidence.lastDeviationPct) or 0) or 0,
        routeStateSignals = recommended and (recommended.routeStateSignals or (recommended.routeEvidence and recommended.routeEvidence.lastSignalCount) or 0) or 0,
        recoveryStreak = recommended and recommended.routeEvidence and recommended.routeEvidence.recoveryStreak or 0,
        recoveryFactor = recommended and recommended.routeEvidence and recommended.routeEvidence.recoveryFactor or 1,
        routeStateTimeline = recommended and recommended.routeEvidence and recommended.routeEvidence.stateTimeline or nil,
        driftClassification = recommended and recommended.routeEvidence and recommended.routeEvidence.driftClassification or nil,
    }
end

function Tracker:AnalyzeSessionQuality(session)
    session = session or self.session
    if type(session) ~= "table" then
        return {status = "INSUFFICIENT", usable = false, confidence = 0, reasons = {"No session data"}}
    end

    local started = tonumber(session.startedAt) or 0
    local now = GetTime and GetTime() or 0
    local seconds = tonumber(session.seconds) or 0
    if seconds <= 0 and started > 0 then
        seconds = math.max((session.endedAt and 0 or now) - started - (tonumber(session.pausedDuration) or 0), 0)
    end

    local paused = tonumber(session.pausedDuration) or 0
    local wallSeconds = tonumber(session.wallSeconds) or seconds + paused
    if wallSeconds <= 0 then wallSeconds = seconds end
    local pauseRatio = wallSeconds > 0 and math.min(paused / wallSeconds, 1) or 0

    local targetItems = tonumber(session.routeItems) or 0
    local targetValue = tonumber(session.routeValue) or 0
    local totalItems = tonumber(session.items) or 0
    local lootValue = tonumber(session.lootValue) or 0
    local targetShare = lootValue > 0 and math.min(targetValue / lootValue, 1) or 0
    local targetItemShare = totalItems > 0 and math.min(targetItems / totalItems, 1) or 0
    local hours = seconds > 0 and seconds / 3600 or 0
    local gph = hours > 0 and targetValue / hours or 0
    local itemsPerHour = hours > 0 and targetItems / hours or 0

    local reasons = {}
    local confidence = 0
    local status = "INSUFFICIENT"

    -- Route completion is a separate evidence dimension from loot/value.
    -- A session can be long and profitable while only covering a small part
    -- of the configured route, so use the recorded geometry when available.
    local routeCompletion = nil
    if session.routeItemID and type(session.routePath) == "table" and #session.routePath >= 2 then
        local metrics = self:GetRoutePathMetrics(session.routePath)
        local coverage = tonumber(metrics.coverage) or 0
        local closure = tonumber(metrics.closure) or 0
        local completionConfidence = math.min(100, math.max(0, coverage * 0.65 + closure * 100 * 0.35))
        routeCompletion = {
            coverage = coverage,
            closure = closure,
            loop = metrics.loop == true,
            distance = tonumber(metrics.distance) or 0,
            points = tonumber(metrics.points) or 0,
            confidence = completionConfidence,
        }
        if metrics.loop and coverage >= 65 then
            confidence = confidence + 20
        elseif coverage >= 45 then
            confidence = confidence + 10
            reasons[#reasons + 1] = "Partial route coverage"
        elseif coverage > 0 then
            confidence = confidence - 10
            reasons[#reasons + 1] = "Low route coverage"
        else
            reasons[#reasons + 1] = "No route movement evidence"
        end
    elseif session.routeItemID then
        reasons[#reasons + 1] = "No recorded route path"
    end

    if seconds < 120 then
        reasons[#reasons + 1] = "Session shorter than 2 minutes"
    elseif seconds < 600 then
        reasons[#reasons + 1] = "Short sample"
        confidence = confidence + 15
    else
        confidence = confidence + 30
    end

    if pauseRatio >= 0.35 then
        reasons[#reasons + 1] = "High pause ratio"
        confidence = confidence - 25
    elseif pauseRatio >= 0.15 then
        reasons[#reasons + 1] = "Moderate pause ratio"
        confidence = confidence - 10
    else
        confidence = confidence + 15
    end

    if session.routeItemID then
        if targetItems <= 0 or targetValue <= 0 then
            reasons[#reasons + 1] = "No target farming evidence"
        elseif targetItemShare >= 0.50 or targetShare >= 0.50 then
            confidence = confidence + 25
        elseif targetItemShare >= 0.25 or targetShare >= 0.25 then
            confidence = confidence + 15
            reasons[#reasons + 1] = "Mixed target activity"
        else
            reasons[#reasons + 1] = "Low target activity"
        end
    else
        if totalItems > 0 or lootValue > 0 then
            confidence = confidence + 15
        else
            reasons[#reasons + 1] = "No loot evidence"
        end
    end

    if gph <= 0 then
        reasons[#reasons + 1] = "No measurable farming value"
        confidence = confidence - 20
    end

    confidence = math.max(0, math.min(100, confidence))

    local routeCoverageOK = not session.routeItemID or not routeCompletion or (routeCompletion.coverage >= 35)
    if seconds >= 600 and pauseRatio < 0.35 and (not session.routeItemID or targetItems > 0) and confidence >= 65 and routeCoverageOK then
        status = "STRONG"
    elseif seconds >= 300 and pauseRatio < 0.50 and (not session.routeItemID or targetItems > 0) and confidence >= 40 and routeCoverageOK then
        status = "USABLE"
    elseif seconds >= 120 and confidence >= 20 then
        status = "LOW_QUALITY"
    end

    return {
        status = status,
        usable = status == "USABLE" or status == "STRONG",
        confidence = confidence,
        seconds = seconds,
        wallSeconds = wallSeconds,
        pausedSeconds = paused,
        pauseRatio = pauseRatio,
        targetItems = targetItems,
        targetValue = targetValue,
        targetItemShare = targetItemShare,
        targetValueShare = targetShare,
        totalItems = totalItems,
        lootValue = lootValue,
        gph = gph,
        itemsPerHour = itemsPerHour,
        routeCompletion = routeCompletion,
        reasons = reasons,
    }
end

function Tracker:GetRouteTrend(itemID)
    local db = EnsureDB()
    local id = tonumber(itemID) or (self.session and self.session.routeItemID) or self.routeItemID
    if not id then
        return {status = "NO_DATA", sessions = 0, usableSessions = 0}
    end

    db.routeSessions = type(db.routeSessions) == "table" and db.routeSessions or {}
    local all = db.routeSessions[tostring(id)]
    if type(all) ~= "table" or #all == 0 then
        return {status = "NO_DATA", sessions = 0, usableSessions = 0}
    end

    local routeKey = self.session and self.session.routeKey or self.routeKey
    local rows = {}
    local rawCount = 0
    local excluded = 0
    for i = 1, #all do
        local row = all[i]
        if type(row) == "table" and (not routeKey or tostring(row.routeKey or "") == tostring(routeKey)) then
            rawCount = rawCount + 1
            local seconds = tonumber(row.seconds) or 0
            local value = tonumber(row.value) or 0
            local quality = tostring(row.quality or "")
            local confidence = tonumber(row.qualityConfidence)
            if confidence == nil then
                confidence = (quality == "STRONG" and 85) or (quality == "USABLE" and 60) or (quality == "LOW_QUALITY" and 25) or 0
            end
            -- Only usable/strong sessions are evidence for trend direction. Older
            -- history without quality metadata remains usable via its legacy rows.
            local usable = quality == "STRONG" or quality == "USABLE" or quality == ""
            if seconds > 0 and value > 0 and usable and confidence > 0 then
                local gph = value / (seconds / 3600)
                -- Confidence is the evidence weight; duration adds a small guard
                -- against a 2-minute sample dominating a long, clean session.
                local durationWeight = math.min(math.max(seconds / 600, 0.5), 3)
                local completionWeight = type(row.routeCompletion) == "table" and math.min(1, math.max(0.10, (tonumber(row.routeCompletion.coverage) or 100) / 100)) or 1
                local weight = math.max(confidence, 1) * durationWeight * completionWeight
                rows[#rows + 1] = {
                    seconds = seconds,
                    value = value,
                    gph = gph,
                    weight = weight,
                    confidence = confidence,
                    quality = quality ~= "" and quality or "LEGACY",
                    completionWeight = type(row.routeCompletion) == "table" and math.min(1, math.max(0.10, (tonumber(row.routeCompletion.coverage) or 100) / 100)) or 1,
                    endedAt = tonumber(row.endedAt) or 0,
                }
            else
                excluded = excluded + 1
            end
        end
    end

    local count = #rows
    if count == 0 then
        return {status = "NO_DATA", sessions = rawCount, usableSessions = 0, excludedSessions = excluded}
    end
    if count < 4 then
        return {status = "NEED_MORE_HISTORY", sessions = rawCount, usableSessions = count, excludedSessions = excluded}
    end

    local recentCount = math.min(3, count)
    local function WeightedAverage(firstIndex, lastIndex)
        local sum, weight = 0, 0
        for i = firstIndex, lastIndex do
            local row = rows[i]
            sum = sum + row.gph * row.weight
            weight = weight + row.weight
        end
        return weight > 0 and sum / weight or 0, weight
    end

    local recentAvg, recentWeight = WeightedAverage(count - recentCount + 1, count)
    local priorAvg, priorWeight = WeightedAverage(1, count - recentCount)
    if priorWeight <= 0 then
        return {status = "NEED_MORE_HISTORY", sessions = rawCount, usableSessions = count, excludedSessions = excluded}
    end

    local changePct = priorAvg > 0 and ((recentAvg - priorAvg) / priorAvg) * 100 or 0

    local variance = 0
    local varianceWeight = 0
    for i = 1, count do
        local row = rows[i]
        variance = variance + row.weight * (row.gph - priorAvg) ^ 2
        varianceWeight = varianceWeight + row.weight
    end
    variance = varianceWeight > 0 and variance / varianceWeight or 0
    local deviation = math.sqrt(math.max(variance, 0))
    local consistencyPct = priorAvg > 0 and math.max(0, 100 - (deviation / priorAvg * 100)) or 0

    local latest = rows[count].gph
    local outlier = false
    if recentCount >= 3 and priorAvg > 0 then
        -- Do not let a low-confidence final run create the route outlier signal.
        local latestConfidence = tonumber(rows[count].confidence) or 0
        if latestConfidence >= 40 then
            outlier = latest > priorAvg * 1.75 or latest < priorAvg * 0.45
        end
    end

    local status = "STABLE"
    if changePct >= 10 then
        status = "RISING"
    elseif changePct <= -10 then
        status = "FALLING"
    end

    local qualitySum, strongCount = 0, 0
    for _, row in ipairs(rows) do
        qualitySum = qualitySum + row.confidence
        if row.quality == "STRONG" then strongCount = strongCount + 1 end
    end

    return {
        status = status,
        sessions = rawCount,
        usableSessions = count,
        excludedSessions = excluded,
        recentSessions = recentCount,
        recentGPH = recentAvg,
        priorGPH = priorAvg,
        changePct = changePct,
        consistencyPct = consistencyPct,
        latestGPH = latest,
        latestOutlier = outlier,
        averageConfidence = count > 0 and qualitySum / count or 0,
        strongSessions = strongCount,
        qualityAware = true,
    }
end

function Tracker:GetRoutePerformance()
    local _, stat = self:GetHistoricalGPH()
    if type(stat) ~= "table" then return nil end
    local rawSeconds = tonumber(stat.seconds) or 0
    if rawSeconds <= 0 then return nil end
    local weightedSeconds = tonumber(stat.qualityWeightedSeconds) or 0
    local weightedValue = tonumber(stat.qualityWeightedValue) or 0
    local weightedItems = tonumber(stat.qualityWeightedItems) or 0
    local qualityWeightTotal = tonumber(stat.qualityWeightTotal) or 0
    local qualityWeighted = qualityWeightTotal > 0 or weightedSeconds > 0
    local valuePerHour, itemsPerHour, seconds, value, items
    if qualityWeightTotal > 0 then
        -- Use a weighted average of each session's GPH. Unlike weighted
        -- value/seconds totals, this does NOT allow the completion factor to
        -- cancel out. A 30% route traversal therefore contributes roughly
        -- 30% as much evidence as a full traversal.
        valuePerHour = (tonumber(stat.qualityWeightedGPH) or 0) / qualityWeightTotal
        itemsPerHour = (tonumber(stat.qualityWeightedItemsPerHour) or 0) / qualityWeightTotal
        seconds = weightedSeconds
        value = weightedValue
        items = weightedItems
    else
        seconds = rawSeconds
        value = tonumber(stat.value) or 0
        items = tonumber(stat.items) or 0
        local hours = seconds / 3600
        valuePerHour = hours > 0 and value / hours or 0
        itemsPerHour = hours > 0 and items / hours or 0
    end
    return {
        sessions = tonumber(stat.sessions) or 0,
        seconds = seconds,
        rawSeconds = rawSeconds,
        value = value,
        items = items,
        valuePerHour = valuePerHour,
        itemsPerHour = itemsPerHour,
        valuePerItem = items > 0 and value / items or 0,
        qualityWeighted = qualityWeighted,
        qualitySessions = tonumber(stat.qualitySessions) or 0,
        averageConfidence = tonumber(stat.qualityConfidenceTotal) and (tonumber(stat.qualityConfidenceTotal) / math.max(tonumber(stat.qualitySessions) or 1, 1)) or 0,
        geometryConsistency = type(stat.geometryConsistency) == "table" and tonumber(stat.geometryConsistency.consistency) or 0,
        geometrySessions = type(stat.geometryConsistency) == "table" and tonumber(stat.geometryConsistency.usableSessions) or 0,
        loopRate = type(stat.geometryConsistency) == "table" and tonumber(stat.geometryConsistency.loopRate) or 0,
        itemName = stat.itemName,
        zone = stat.zone,
        area = stat.area,
    }
end

function Tracker:Start()
    local now = GetTime()
    local money = (GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney()) or (GetMoney and GetMoney()) or 0
    self.session = {
        active = true,
        paused = false,
        startedAt = now,
        startedAtWall = time(),
        pausedAt = nil,
        pausedAtWall = nil,
        pausedDuration = 0,
        wallSeconds = 0,
        startingGold = money,
        lastGold = money,
        routeItemID = self.routeItemID,
        routeItemName = self.routeItemName,
        routeZone = self.routeZone,
        routeArea = self.routeArea,
        routeKey = self.routeKey,
        routeMapID = tonumber(self.routeMapID),
        routeWaypoints = self.routeWaypoints,
        routeLength = tonumber(self.routeLength),
        routeTargetItemIDs = self.routeTargetItemIDs,
        routePath = {},
        lastPathSampleAt = 0,
        routeValue = 0,
        routeItems = 0,
        materials = {},
        rawGold = 0,
        lootValue = 0,
        vendorValue = 0,
        marketValue = 0,
        expenses = 0,
        items = 0,
        recentLoot = {},
    }
    self._sessionDirty = true
    self._lastSessionPersistAt = 0
    self._hudIntelligenceCache = nil
    self._hudQualityCache = nil
    self:SaveActiveSession(true)
    self:RecordRoutePosition(true)
    self:StartTicker()
    self:EnsureFrame():Show()
    self:Refresh()
end

function Tracker:TogglePause()
    if not self:IsActive() then return end
    local now = GetTime()
    if self.session.paused then
        self.session.pausedDuration = (self.session.pausedDuration or 0) + math.max(now - (self.session.pausedAt or now), 0)
        self.session.paused = false
        self.session.pausedAt = nil
        self.session.pausedAtWall = nil
    else
        self.session.paused = true
        self.session.pausedAt = now
        self.session.pausedAtWall = time()
    end
    self:SaveActiveSession(true)
    self._hudQualityCache = nil
    self:Refresh()
end

function Tracker:GetElapsed()
    if not self.session then return 0 end
    local now = GetTime()
    local endTime = now
    if self.session.paused and self.session.pausedAt then endTime = self.session.pausedAt end
    return math.max(endTime - self.session.startedAt - (self.session.pausedDuration or 0), 0)
end

function Tracker:End()
    self._routePerformanceCache = nil
    if not self:IsActive() then
        if self.frame then self.frame:Hide() end
        return
    end
    if self.session.paused then
        local now = GetTime()
        self.session.pausedDuration = (self.session.pausedDuration or 0) + math.max(now - (self.session.pausedAt or now), 0)
        self.session.paused = false
        self.session.pausedAt = nil
        self.session.pausedAtWall = nil
    end
    self:Refresh()
    local ended = self.session
    ended.active = false
    ended.endedAt = time()
    ended.seconds = self:GetElapsed()
    ended.wallSeconds = math.max((tonumber(ended.endedAt) or time()) - (tonumber(ended.startedAtWall) or tonumber(ended.endedAt) or time()), 0)
    ended.sessionQuality = self:AnalyzeSessionQuality(ended)
    GoldMintDB.farmTracker.lastSession = ended
    if GoldMint.Ledger and GoldMint.Ledger.GetSession then
        local ledger = GoldMint.Ledger:GetSession()
        if ledger then
            ended.ledgerIncome = ledger.income or 0
            ended.ledgerSpending = ledger.spending or 0
        end
    end
    -- Preserve real farming results so future route recommendations can show
    -- an evidence-based Gold Per Hour estimate instead of inventing one.
    if ended.routeItemID and ended.routeItemName and (ended.routeValue or 0) > 0 then
        local db = EnsureDB()
        db.routeStats = type(db.routeStats) == "table" and db.routeStats or {}
        local routeKey = ended.routeKey or ((ended.routeZone or "") .. "|" .. (ended.routeArea or ""))
        local key = tostring(ended.routeItemID) .. "|" .. tostring(routeKey)
        local stat = db.routeStats[key] or {sessions = 0, seconds = 0, value = 0, items = 0}
        stat.sessions = (stat.sessions or 0) + 1
        stat.seconds = (stat.seconds or 0) + (ended.seconds or 0)
        stat.value = (stat.value or 0) + (ended.routeValue or 0)
        stat.items = (stat.items or 0) + (ended.routeItems or 0)

        -- Maintain a quality-weighted route aggregate. Raw totals remain intact
        -- for backwards compatibility, while performance APIs prefer evidence
        -- from usable/strong sessions.
        local quality = ended.sessionQuality or {}
        local qualityWeight = self:GetRouteQualityWeight({
            quality = quality.status,
            qualityConfidence = quality.confidence,
            seconds = ended.seconds,
            routeCompletion = quality.routeCompletion,
        })
        if qualityWeight > 0 then
            local sessionSeconds = tonumber(ended.seconds) or 0
            local sessionValue = tonumber(ended.routeValue) or 0
            local sessionItems = tonumber(ended.routeItems) or 0
            local sessionHours = sessionSeconds / 3600
            local sessionGPH = sessionHours > 0 and sessionValue / sessionHours or 0
            local sessionItemsPerHour = sessionHours > 0 and sessionItems / sessionHours or 0
            stat.qualityWeightedValue = (stat.qualityWeightedValue or 0) + sessionValue * qualityWeight
            stat.qualityWeightedItems = (stat.qualityWeightedItems or 0) + sessionItems * qualityWeight
            stat.qualityWeightedSeconds = (stat.qualityWeightedSeconds or 0) + sessionSeconds * qualityWeight
            stat.qualityWeightedGPH = (stat.qualityWeightedGPH or 0) + sessionGPH * qualityWeight
            stat.qualityWeightedItemsPerHour = (stat.qualityWeightedItemsPerHour or 0) + sessionItemsPerHour * qualityWeight
            stat.qualityWeightTotal = (stat.qualityWeightTotal or 0) + qualityWeight
            stat.qualitySessions = (stat.qualitySessions or 0) + 1
            stat.qualityConfidenceTotal = (stat.qualityConfidenceTotal or 0) + (tonumber(quality.confidence) or 0)
            stat.qualityCompletionWeightTotal = (stat.qualityCompletionWeightTotal or 0) + (type(quality.routeCompletion) == "table" and math.min(1, math.max(0.10, (tonumber(quality.routeCompletion.coverage) or 100) / 100)) or 1)
        end
        stat.itemName = ended.routeItemName
        stat.zone = ended.routeZone
        stat.area = ended.routeArea
        stat.routeKey = routeKey
        stat.mapID = tonumber(ended.routeMapID) or stat.mapID
        if type(ended.routePath) == "table" and #ended.routePath >= 2 then
            stat.latestPath = ended.routePath
            stat.latestPathAt = tonumber(ended.endedAt) or time()
            stat.latestPathMetrics = self:GetRoutePathMetrics(ended.routePath)
        end
        stat.geometryConsistency = self:GetRouteGeometryConsistency(ended.routeItemID, routeKey)
        stat.routeEvidence = self:UpdateRouteEvidenceProfile(stat, ended, stat.geometryConsistency)
        stat.valuePerItem = stat.items > 0 and stat.value / stat.items or 0
        stat.itemsPerHour = stat.seconds > 0 and stat.items / (stat.seconds / 3600) or 0
        stat.valuePerHour = stat.seconds > 0 and stat.value / (stat.seconds / 3600) or 0
        db.routeStats[key] = stat

        -- Keep a small per-route session history so Farming Intelligence can
        -- distinguish a real trend from a single unusually good or bad run.
        db.routeSessions = type(db.routeSessions) == "table" and db.routeSessions or {}
        local historyKey = tostring(ended.routeItemID)
        db.routeSessions[historyKey] = type(db.routeSessions[historyKey]) == "table"
            and db.routeSessions[historyKey] or {}
        local history = db.routeSessions[historyKey]
        history[#history + 1] = {
            endedAt = tonumber(ended.endedAt) or time(),
            routeKey = routeKey,
            seconds = ended.seconds or 0,
            quality = ended.sessionQuality and ended.sessionQuality.status or "INSUFFICIENT",
            qualityConfidence = ended.sessionQuality and ended.sessionQuality.confidence or 0,
            pauseRatio = ended.sessionQuality and ended.sessionQuality.pauseRatio or 0,
            routeCompletion = ended.sessionQuality and ended.sessionQuality.routeCompletion or nil,
            mapID = tonumber(ended.routeMapID),
            path = type(ended.routePath) == "table" and ended.routePath or nil,
            pathMetrics = type(ended.routePath) == "table" and self:GetRoutePathMetrics(ended.routePath) or nil,
            value = tonumber(ended.routeValue) or 0,
            items = tonumber(ended.routeItems) or 0,
        }
        -- Keep the saved history bounded. Most recent sessions are the useful
        -- signal and this prevents the SavedVariables table from growing forever.
        while #history > 50 do
            table.remove(history, 1)
        end
    end

    self.session = nil
    self._sessionDirty = false
    self._lastSessionPersistAt = 0
    PersistActiveSession(nil)
    self:StopTicker()
    if self.frame then self.frame:Hide() end
end

function Tracker:Reset()
    if self.session and self.session.active then
        self.session = nil
        PersistActiveSession(nil)
        self:StopTicker()
        self:Refresh()
        return
    end
    self.session = nil
    PersistActiveSession(nil)
    self:StopTicker()
    if self.frame then self:Refresh() end
end

function Tracker:RecordLoot(itemLink, quantity)
    if not self:IsActive() or self.session.paused or not itemLink then return end
    quantity = math.max(tonumber(quantity) or 1, 1)
    local signature = tostring(itemLink) .. ":" .. tostring(quantity)
    local now = time()
    if self.session.lastLootSignature == signature and now - (tonumber(self.session.lastLootAt) or 0) <= 2 then
        return
    end
    self.session.lastLootSignature = signature
    self.session.lastLootAt = now
    local itemID = tonumber(itemLink:match("item:(%d+)"))
    local name, _, _, _, _, _, _, _, _, icon, vendor = GetItemInfo(itemLink)
    if not itemID and C_Item and C_Item.GetItemInfoInstant then
        local ok, id = pcall(C_Item.GetItemInfoInstant, itemLink)
        if ok then itemID = id end
    end
    local market = 0
    if itemID and GoldMint.Market then
        -- Loot events can fire in rapid bursts. Do not run a full TSM database
        -- capture for every item; use the market value already cached by the
        -- market/loot systems and let scheduled market scans refresh it.
        pcall(function()
            GoldMint.Market:RecordItem(itemID)
            market = (GoldMint.Market:GetUnitValue(itemID) or 0) * quantity
        end)
    end
    local vendorValue = (tonumber(vendor) or 0) * quantity
    if itemID and self.session.routeItemID and tonumber(itemID) == tonumber(self.session.routeItemID) then
        self.session.routeItems = (self.session.routeItems or 0) + quantity
        self.session.routeValue = (self.session.routeValue or 0) + math.max(market, vendorValue, 0)
    end
    if itemID then
        self.session.materials = self.session.materials or {}
        local material = self.session.materials[itemID] or {quantity = 0, value = 0, name = name or itemLink}
        material.quantity = (material.quantity or 0) + quantity
        material.value = (material.value or 0) + math.max(market, vendorValue, 0)
        material.name = material.name or name or itemLink
        self.session.materials[itemID] = material
    end
    self.session.items = (self.session.items or 0) + quantity
    self.session.marketValue = (self.session.marketValue or 0) + math.max(market, 0)
    self.session.vendorValue = (self.session.vendorValue or 0) + math.max(vendorValue, 0)
    self.session.lootValue = (self.session.lootValue or 0) + math.max(market, vendorValue, 0)
    table.insert(self.session.recentLoot, 1, {
        name=name or itemLink,
        quantity=quantity,
        value=math.max(market, vendorValue, 0),
        icon=icon,
        itemID=itemID,
        link=itemLink,
    })
    while #self.session.recentLoot > MAX_LOOT_ROWS do table.remove(self.session.recentLoot) end
    self:SaveActiveSession()
end

function Tracker:RecordMoneyChange(newMoney, reason)
    if not self:IsActive() or self.session.paused then
        return
    end
    newMoney = tonumber(newMoney) or 0
    local old = tonumber(self.session.lastGold) or newMoney
    local delta = newMoney - old
    if delta > 0 then
        self.session.rawGold = (self.session.rawGold or 0) + delta
        self._sessionDirty = true
    elseif delta < 0 then
        self.session.expenses = (self.session.expenses or 0) + math.abs(delta)
        self._sessionDirty = true
    end
    self.session.lastGold = newMoney
    self:SaveActiveSession()
end

function Tracker:ApplyHUDState(state)
    -- Keep action controls synchronized with the session lifecycle. This is
    -- intentionally centralized so Start/Pause/Resume/End/Reset cannot drift
    -- into contradictory button states.
    if not self.startButton or not self.pauseButton or not self.endButton then return end
    if state == "ACTIVE" then
        self.startButton:Disable()
        self.pauseButton:Enable()
        self.endButton:Enable()
        if self.resetButton then self.resetButton:Enable() end
    elseif state == "PAUSED" then
        self.startButton:Disable()
        self.pauseButton:Enable()
        self.endButton:Enable()
        if self.resetButton then self.resetButton:Enable() end
    else
        self.startButton:Enable()
        self.pauseButton:Disable()
        self.endButton:Disable()
        if self.resetButton then self.resetButton:Enable() end
    end
end

function Tracker:RefreshRecentLoot(session)
    if not self.recentLootRows then return end
    local settings = self:GetRecentLootSettings()
    local entries = session and type(session.recentLoot) == "table" and session.recentLoot or {}
    local shown = 0
    for _, row in ipairs(self.recentLootRows) do
        row:Hide()
    end
    if not settings.enabled then
        if self.recentLootHeader then self.recentLootHeader:SetText("RECENT LOOT: OFF") end
        return
    end
    if self.recentLootHeader then self.recentLootHeader:SetText("RECENT LOOT") end
    for _, entry in ipairs(entries) do
        local value = tonumber(entry.value) or 0
        if value >= settings.minValue then
            shown = shown + 1
            if shown > MAX_LOOT_ROWS then break end
            local row = self.recentLootRows[shown]
            local icon = entry.icon or "Interface\\Icons\\INV_Misc_QuestionMark"
            row.icon:SetTexture(icon)
            local qty = tonumber(entry.quantity) or 1
            local name = tostring(entry.name or "Unknown item")
            row.name:SetText(qty > 1 and (name .. " x" .. tostring(qty)) or name)
            row.value:SetText(GoldText(value))
            row:Show()
        end
    end
end

function Tracker:Refresh()
    if not self.frame then return end
    local s = self.session
    if not s then
        self:RefreshRecentLoot(nil)
        self.status:SetText("READY")
        self.status:SetTextColor(MUTED[1], MUTED[2], MUTED[3])
        self.timeValue:SetText("00:00:00")
        for _, key in ipairs({"rawGold","lootValue","vendorValue","marketValue","expenses"}) do self.valueLabels[key]:SetText("0g") end
        self.net:SetText("0g")
        self.rate:SetText("0g / hr")
        local historical = self:GetHistoricalGPH()
        local performance = self:GetRoutePerformance()
        if self.routeItemName then
            self.routeLabel:SetText("TARGET: " .. tostring(self.routeItemName))
        else
            self.routeLabel:SetText("NO FARM TARGET")
        end
        if performance then
            self.estimateLabel:SetText("YOUR FARM GPH: " .. GoldText(performance.valuePerHour) .. "  •  " .. string.format("%.1f %s/hr", performance.itemsPerHour, tostring(self.routeItemName or "items")))
        else
            self.estimateLabel:SetText(historical and ("EST. FARM GPH: " .. GoldText(historical)) or "EST. FARM GPH: Awaiting farm data")
        end
        local lastQuality = GoldMintDB.farmTracker and GoldMintDB.farmTracker.lastSession and GoldMintDB.farmTracker.lastSession.sessionQuality
        if lastQuality and lastQuality.status then
            self.lootLabel:SetText("LAST SESSION: " .. tostring(lastQuality.status) .. "  •  " .. tostring(lastQuality.confidence or 0) .. "% CONFIDENCE")
        else
            self.lootLabel:SetText("Start a session to begin tracking.")
        end
        local intelligence = activeRouteID and self.GetRouteIntelligence and self:GetRouteIntelligence(activeRouteID) or nil
        if intelligence then
            local confidence = tonumber(intelligence.recommendationConfidence or intelligence.confidence)
            local state = intelligence.state or intelligence.driftClassification
            if confidence then
                self.intelligenceLabel:SetText("ROUTE EVIDENCE: " .. string.format("%d%%", math.floor(confidence + 0.5)) .. (state and ("  •  " .. tostring(state)) or ""))
            else
                self.intelligenceLabel:SetText("ROUTE EVIDENCE: BUILDING")
            end
        else
            self.intelligenceLabel:SetText("ROUTE EVIDENCE: AWAITING DATA")
        end
        if self.pauseButton and self.pauseButton.text then
            self.pauseButton.text:SetText("PAUSE")
        end
        self:ApplyHUDState("READY")
        return
    end

    self:RefreshRecentLoot(s)
    local elapsed = self:GetElapsed()
    local h = math.floor(elapsed / 3600)
    local m = math.floor((elapsed % 3600) / 60)
    local sec = math.floor(elapsed % 60)
    self.timeValue:SetText(string.format("%02d:%02d:%02d", h, m, sec))

    local money = (GoldMint.Ledger and GoldMint.Ledger.GetMoney and GoldMint.Ledger:GetMoney()) or (GetMoney and GetMoney()) or s.lastGold
    self:RecordMoneyChange(money)

    local net = (s.rawGold or 0) + (s.lootValue or 0) - (s.expenses or 0)
    local gross = (s.rawGold or 0) + (s.lootValue or 0)
    local rate = elapsed > 0 and net / (elapsed / 3600) or 0

    self.valueLabels.rawGold:SetText(GoldText(s.rawGold))
    self.valueLabels.lootValue:SetText(GoldText(s.lootValue))
    self.valueLabels.vendorValue:SetText(GoldText(s.vendorValue))
    self.valueLabels.marketValue:SetText(GoldText(s.marketValue))
    self.valueLabels.expenses:SetText(GoldText(s.expenses))
    self.net:SetText(GoldText(net))
    self.rate:SetText(GoldText(rate) .. " / hr")

    local activeRouteID = tonumber(s.routeItemID)
    if activeRouteID and s.routeItemName then
        self.routeLabel:SetText("TARGET: " .. tostring(s.routeItemName))
        local hours = elapsed / 3600
        local routeRate = hours > 0 and (tonumber(s.routeValue) or 0) / hours or 0
        local itemsPerHour = hours > 0 and (tonumber(s.routeItems) or 0) / hours or 0
        self.estimateLabel:SetText(string.format("FARM GPH: %s  •  %.1f %s/hr", GoldText(routeRate), itemsPerHour, tostring(s.routeItemName)))
    else
        self.routeLabel:SetText("ALL LOOT")
        self.estimateLabel:SetText("FARM GPH: " .. GoldText(rate))
    end
    self.net:SetTextColor(net >= 0 and GREEN[1] or RED[1], net >= 0 and GREEN[2] or RED[2], net >= 0 and GREEN[3] or RED[3])

    if s.paused then
        self.status:SetText("PAUSED")
        self.status:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
        self.pauseButton.text:SetText("RESUME")
        self:ApplyHUDState("PAUSED")
    else
        self.status:SetText("FARMING")
        self.status:SetTextColor(GREEN[1], GREEN[2], GREEN[3])
        self.pauseButton.text:SetText("PAUSE")
        self:ApplyHUDState("ACTIVE")
    end
    self.lootLabel:SetText(string.format("%d ITEMS LOOTED  •  %s GROSS", s.items or 0, GoldText(gross)))

    local quality = nil
    if self.AnalyzeSessionQuality then
        -- Session quality changes more slowly than the live clock. Keep the
        -- HUD responsive while avoiding a full quality analysis on every
        -- one-second refresh. Invalidate this cache when session state changes.
        local nowQuality = GetTime()
        local cache = self._hudQualityCache
        if not cache or cache.session ~= s or cache.paused ~= (s.paused == true) or
            (nowQuality - (cache.at or 0)) >= 2 then
            quality = self:AnalyzeSessionQuality(s)
            self._hudQualityCache = {session = s, paused = (s.paused == true), at = nowQuality, data = quality}
        else
            quality = cache.data
        end
    else
        self._hudQualityCache = nil
    end
    -- Route intelligence aggregates geometry, baselines, drift, and evidence.
    -- Recomputing that full model every HUD tick is unnecessary while the
    -- session itself only changes incrementally. Refresh it on a short cache
    -- interval and invalidate it naturally when the active route changes.
    local intelligence = nil
    if activeRouteID and self.GetRouteIntelligence then
        local nowIntelligence = GetTime()
        local cache = self._hudIntelligenceCache
        if not cache or cache.routeID ~= activeRouteID or
            (nowIntelligence - (cache.at or 0)) >= INTELLIGENCE_REFRESH_INTERVAL then
            intelligence = self:GetRouteIntelligence(activeRouteID)
            self._hudIntelligenceCache = { routeID = activeRouteID, at = nowIntelligence, data = intelligence }
        else
            intelligence = cache.data
        end
    else
        self._hudIntelligenceCache = nil
    end
    if quality then
        local qualityText = tostring(quality.status or "BUILDING")
        local confidence = tonumber(quality.confidence) or 0
        self.intelligenceLabel:SetText("SESSION " .. qualityText .. "  •  " .. string.format("%d%%", math.floor(confidence + 0.5)))
        if quality.status == "STRONG" then
            self.intelligenceLabel:SetTextColor(unpack(GREEN))
        elseif quality.status == "USABLE" then
            self.intelligenceLabel:SetTextColor(unpack(CYAN))
        else
            self.intelligenceLabel:SetTextColor(unpack(MUTED))
        end

        if intelligence and tonumber(intelligence.recommendationConfidence) then
            local routeText = "ROUTE " .. string.format("%d%%", math.floor((tonumber(intelligence.recommendationConfidence) or 0) + 0.5))
            local ageState = tostring(intelligence.baselineAgeState or "NONE")
            if ageState ~= "NONE" then
                routeText = routeText .. "  •  BASELINE " .. ageState
            end
            self.evidenceLabel:SetText(routeText)
            self.evidenceLabel:SetTextColor(unpack(MUTED))
        else
            self.evidenceLabel:SetText("ROUTE EVIDENCE: BUILDING")
            self.evidenceLabel:SetTextColor(unpack(MUTED))
        end
    else
        self.intelligenceLabel:SetText("SESSION QUALITY: BUILDING")
        self.intelligenceLabel:SetTextColor(unpack(MUTED))
        if self.evidenceLabel then
            self.evidenceLabel:SetText("ROUTE EVIDENCE: BUILDING")
            self.evidenceLabel:SetTextColor(unpack(MUTED))
        end
    end
end

function Tracker:OnMinimapClick()
    self:Toggle()
end

return Tracker
