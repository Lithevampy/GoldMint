local ADDON_NAME, GoldMint = ...

GoldMint.Recipes = {}
local Recipes = GoldMint.Recipes

local function GetNow()
    return time()
end

local function GetCharacterKey()
    return GoldMint.characterKey
end

local function EnsureRecipeStore()
    GoldMintDB.recipes = GoldMintDB.recipes or {}
    GoldMintDB.recipeSpellIndex = GoldMintDB.recipeSpellIndex or {}
    return GoldMintDB.recipes
end

local function EnsureCharacterProfessionStore()
    local key = GetCharacterKey()
    GoldMintDB.characters[key].professions = GoldMintDB.characters[key].professions or {}
    return GoldMintDB.characters[key].professions
end

local function RegisterCharacterProfession(profession)
    if not profession or not profession.skillLineID then
        return
    end

    local professions = EnsureCharacterProfessionStore()
    local baseID = profession.parentSkillLineID or profession.skillLineID
    local name = profession.parentDisplayName or profession.displayName or tostring(baseID)

    professions[baseID] = professions[baseID] or {
        name = name,
        baseSkillLineID = baseID,
        variants = {},
    }

    local entry = professions[baseID]
    entry.name = name
    entry.lastSeen = GetNow()
    entry.variants = entry.variants or {}
    entry.rank = tonumber(profession.rank) or entry.rank
    entry.maxRank = tonumber(profession.maxRank) or entry.maxRank
    entry.variants[profession.skillLineID] = {
        name = profession.displayName or tostring(profession.skillLineID),
        skillLineID = profession.skillLineID,
        rank = tonumber(profession.rank),
        maxRank = tonumber(profession.maxRank),
        lastSeen = GetNow(),
    }
end

local function GetCurrentProfessionInfo()
    if not C_TradeSkillUI then
        return nil
    end

    -- Midnight's modern profession window exposes the parent profession and
    -- selected expansion variant separately. Use those APIs first.
    if C_TradeSkillUI.GetBaseProfessionInfo then
        local okBase, base = pcall(C_TradeSkillUI.GetBaseProfessionInfo)
        if not okBase then base = nil end
        if base and base.professionID then
            local child
            if C_TradeSkillUI.GetChildProfessionInfo then
                local okChild, value = pcall(C_TradeSkillUI.GetChildProfessionInfo)
                if okChild then child = value end
            end
            local skillLineID = (child and child.professionID) or base.professionID
            local displayName = (child and child.professionName) or base.professionName
            return {
                skillLineID = skillLineID,
                displayName = displayName,
                rank = (child and child.skillLevel) or base.skillLevel,
                maxRank = (child and child.maxSkillLevel) or base.maxSkillLevel,
                parentSkillLineID = base.professionID,
                parentDisplayName = base.professionName,
            }
        end
    end

    -- Legacy fallback for clients/UI states that still expose GetTradeSkillLine.
    if C_TradeSkillUI.GetTradeSkillLine then
        local okLine, skillLineID, displayName, rank, maxRank, modifier, parentSkillLineID, parentDisplayName = pcall(C_TradeSkillUI.GetTradeSkillLine)
        if not okLine then skillLineID = nil end
        if skillLineID then
            return {
                skillLineID = skillLineID,
                displayName = displayName,
                rank = rank,
                maxRank = maxRank,
                parentSkillLineID = parentSkillLineID,
                parentDisplayName = parentDisplayName,
            }
        end
    end

    return nil
end

local function GetRecipeProfessionInfo(recipeID)
    if not C_TradeSkillUI or not C_TradeSkillUI.GetProfessionInfoByRecipeID then
        return nil
    end

    local ok, info = pcall(C_TradeSkillUI.GetProfessionInfoByRecipeID, recipeID)
    if ok then
        return info
    end
end

local function GetSkillLineDisplayName(skillLineID)
    if C_TradeSkillUI and C_TradeSkillUI.GetTradeSkillLineInfoByID then
        local okName, name = pcall(C_TradeSkillUI.GetTradeSkillLineInfoByID, skillLineID)
        if not okName then name = nil end
        if name then
            return name
        end
    end
    return tostring(skillLineID)
end

local function RecordRecipe(recipeID, info, skillLineID, skillLineName, professionName)
    if not info or not info.name then
        return false, false
    end

    local recipes = EnsureRecipeStore()
    local characterKey = GetCharacterKey()
    local record = recipes[recipeID]

    if not record then
        record = {
            name = info.name,
            profession = professionName or "Unknown",
            characters = {},
            skillLines = {},
        }
        recipes[recipeID] = record
    end

    record.name = info.name
    record.profession = professionName or record.profession or "Unknown"
    -- Recipe teaching items expose the spell they teach in ItemSpellTriggerLearn.
    -- In the modern profession API the recipeID is the identifier we use for
    -- the recipe, so keep an explicit lookup index for tooltip matching.
    local spellIndex = GoldMintDB.recipeSpellIndex
    if spellIndex then
        spellIndex[recipeID] = recipeID
    end
    record.skillLines = record.skillLines or {}

    if skillLineID then
        record.skillLines[skillLineID] = {
            name = skillLineName or tostring(skillLineID),
            seen = GetNow(),
        }
        -- Keep the old field for compatibility with the early recipe database.
        record.skillLineID = record.skillLineID or skillLineID
    end

    record.characters = record.characters or {}
    record.characters[characterKey] = record.characters[characterKey] or {}

    local character = record.characters[characterKey]
    character.learned = info.learned == true
    character.seen = GetNow()
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm
    character.skillLineID = skillLineID or character.skillLineID
    character.skillLineName = skillLineName or character.skillLineName

    return true, info.learned == true
end

function Recipes:ScanCurrentProfession()
    local profession = GetCurrentProfessionInfo()
    if not profession then
        return 0, 0, nil
    end

    if not C_TradeSkillUI or not C_TradeSkillUI.GetAllRecipeIDs then
        return 0, 0, profession.displayName
    end

    local okIDs, recipeIDs = pcall(C_TradeSkillUI.GetAllRecipeIDs)
    if not okIDs then recipeIDs = nil end
    if type(recipeIDs) ~= "table" then
        return 0, 0, profession.displayName
    end

    local scanned = 0
    local learned = 0
    local skillLineName = profession.displayName or tostring(profession.skillLineID)
    local professionName = profession.parentDisplayName or profession.displayName

    -- Remember that this character actually has this profession. This is
    -- separate from recipe knowledge and is what lets GoldMint distinguish
    -- "can learn" from simply "has not been scanned".
    RegisterCharacterProfession(profession)

    for _, recipeID in ipairs(recipeIDs) do
        local okInfo, info = pcall(C_TradeSkillUI.GetRecipeInfo, recipeID)
        if not okInfo then info = nil end
        if info then
            local recipeProfession = GetRecipeProfessionInfo(recipeID)
            local parentName = recipeProfession and recipeProfession.parentProfessionName
            local baseProfession = parentName or professionName
            local ok, isLearned = RecordRecipe(
                recipeID,
                info,
                profession.skillLineID,
                skillLineName,
                baseProfession
            )

            if ok and recipeProfession then
                local record = EnsureRecipeStore()[recipeID]
                record.professionID = record.professionID or recipeProfession.parentProfessionID or recipeProfession.professionID
                record.professionEnum = record.professionEnum or recipeProfession.profession
                record.professionName = record.professionName or baseProfession
            end

            if ok then
                scanned = scanned + 1
                if isLearned then
                    learned = learned + 1
                end
            end
        end
    end

    local characterKey = GetCharacterKey()
    GoldMintDB.characters[characterKey].lastRecipeScan = GetNow()
    GoldMintDB.characters[characterKey].lastRecipeProfession = professionName
    GoldMintDB.characters[characterKey].lastRecipeSkillLine = profession.skillLineID

    return scanned, learned, skillLineName
end

local function GetProfessionVariants(current)
    local variants = {}
    local seen = {}
    local targetParent = current.parentSkillLineID

    if not C_TradeSkillUI or not C_TradeSkillUI.GetAllProfessionTradeSkillLines then
        return variants
    end

    -- GetAllProfessionTradeSkillLines() returns the available profession
    -- skill-line IDs.  We cannot reliably use GetTradeSkillLineInfoByID()'s
    -- return values here across current clients, so instead we validate each
    -- candidate by temporarily selecting it and checking the profession's
    -- parent skill line after the selection.
    local okLines, allLines = pcall(C_TradeSkillUI.GetAllProfessionTradeSkillLines)
    if not okLines then allLines = nil end
    if type(allLines) ~= "table" then
        return variants
    end

    local function add(id, name)
        if id and not seen[id] then
            seen[id] = true
            table.insert(variants, {
                skillLineID = id,
                name = name or (function()
                    if C_TradeSkillUI.GetTradeSkillDisplayName then
                        local ok, value = pcall(C_TradeSkillUI.GetTradeSkillDisplayName, id)
                        if ok then return value end
                    end
                end)() or tostring(id),
            })
        end
    end

    -- Always include the currently displayed skill line first.
    add(current.skillLineID, current.displayName)

    -- The expansion-specific profession variants are child skill lines of
    -- the current profession.  SetProfessionChildSkillLineID is the reliable
    -- way to validate them on the live profession UI.
    if C_TradeSkillUI.SetProfessionChildSkillLineID and C_TradeSkillUI.GetTradeSkillLine then
        for _, candidateID in ipairs(allLines) do
            if candidateID ~= current.skillLineID then
                SafeCall(C_TradeSkillUI.SetProfessionChildSkillLineID, candidateID)

                local okActive, activeID, activeName, _, _, _, activeParentID = pcall(C_TradeSkillUI.GetTradeSkillLine)
                if not okActive then activeID = nil end
                if activeID and activeParentID and targetParent and activeParentID == targetParent then
                    add(activeID, activeName)
                end
            end
        end

        -- Restore the profession the player was actually viewing.
        SafeCall(C_TradeSkillUI.SetProfessionChildSkillLineID, current.skillLineID)
    end

    table.sort(variants, function(a, b)
        if a.skillLineID == current.skillLineID then
            return true
        elseif b.skillLineID == current.skillLineID then
            return false
        end
        return a.skillLineID < b.skillLineID
    end)

    return variants
end

function Recipes:ScanAllProfessionVariants(onComplete)
    if not GoldMintDB or not GoldMint.characterKey then
        return false
    end

    local current = GetCurrentProfessionInfo()
    if not current then
        return false
    end

    if self._variantScanRunning then
        return false
    end

    self._variantScanRunning = true
    self._variantScanGeneration = (self._variantScanGeneration or 0) + 1
    local scanGeneration = self._variantScanGeneration

    local totalScanned = 0
    local totalKnown = 0
    local scannedLines = 0
    local originalChild = C_TradeSkillUI and C_TradeSkillUI.GetProfessionChildSkillLineID and C_TradeSkillUI.GetProfessionChildSkillLineID() or current.skillLineID

    -- ALWAYS scan the profession that the player actually opened first.
    -- This guarantees that opening a different profession (e.g. Alchemy after
    -- Jewelcrafting) adds that profession to the persistent account database.
    local scanned, known = self:ScanCurrentProfession()
    totalScanned = totalScanned + (scanned or 0)
    totalKnown = totalKnown + (known or 0)
    if scanned and scanned > 0 then
        scannedLines = scannedLines + 1
    end

    -- Historical/expansion variants are an enhancement, not a prerequisite for
    -- scanning the currently open profession. If the variant API is unavailable
    -- or cannot be safely used, the current profession scan above still counts.
    local variants = {}
    if C_TradeSkillUI and C_TradeSkillUI.SetProfessionChildSkillLineID and C_TradeSkillUI.GetAllProfessionTradeSkillLines then
        variants = GetProfessionVariants(current) or {}
    end

    local variantIndex = 1

    local function Restore()
        if originalChild and C_TradeSkillUI and C_TradeSkillUI.SetProfessionChildSkillLineID then
            SafeCall(C_TradeSkillUI.SetProfessionChildSkillLineID, originalChild)
        end
    end

    local function Finish()
        Restore()
        self._variantScanRunning = false
        if self._variantScanGeneration ~= scanGeneration then return end
        if onComplete then
            onComplete(totalScanned, totalKnown, scannedLines, current.displayName, #variants)
        end
    end

    local function Next()
        local variant = variants[variantIndex]
        variantIndex = variantIndex + 1

        -- The current profession was already scanned above, so do not scan it a
        -- second time during the variant pass.
        if variant and variant.skillLineID == current.skillLineID then
            Next()
            return
        end

        if not variant then
            Finish()
            return
        end

        SafeCall(C_TradeSkillUI.SetProfessionChildSkillLineID, variant.skillLineID)
        GoldMint:ScheduleGuardedCallback(self, "profession-variant", 0.35, function()
            if not self._variantScanRunning or self._variantScanGeneration ~= scanGeneration then
                return
            end

            local active = GetCurrentProfessionInfo()
            if active and active.skillLineID == variant.skillLineID then
                local variantScanned, variantKnown = self:ScanCurrentProfession()
                totalScanned = totalScanned + (variantScanned or 0)
                totalKnown = totalKnown + (variantKnown or 0)
                if variantScanned and variantScanned > 0 then
                    scannedLines = scannedLines + 1
                end
            end

            GoldMint:ScheduleGuardedCallback(self, "profession-variant-next", 0.10, Next)
        end)
    end

    -- Give the currently opened profession a moment to settle before changing
    -- expansion variants. This also keeps the visible profession stable while
    -- its first scan is being recorded.
    GoldMint:ScheduleGuardedCallback(self, "profession-variant-start", 0.10, Next)
    return true
end

function Recipes:FindByName(query)
    query = strlower(strtrim(query or ""))
    if query == "" then
        return {}
    end

    local results = {}
    local recipes = GoldMintDB and GoldMintDB.recipes or {}

    for recipeID, record in pairs(recipes) do
        if record.name and strfind(strlower(record.name), query, 1, true) then
            local result = {
                recipeID = recipeID,
                name = record.name,
                profession = record.profession,
                skillLines = record.skillLines or {},
                canLearn = {},
                known = {},
                scanned = {},
                notProfession = {},
            }

            for key, character in pairs(record.characters or {}) do
                local charDB = GoldMintDB.characters and GoldMintDB.characters[key]
                local hasProfession = false

                -- A recipe being unlearned is not enough to say a character
                -- can learn it. The character must have the matching profession
                -- recorded from an actual profession scan.
                if charDB and charDB.professions then
                    local professionID = record.professionID
                    if professionID and charDB.professions[professionID] then
                        hasProfession = true
                    elseif record.professionName then
                        for _, prof in pairs(charDB.professions) do
                            if prof.name == record.professionName then
                                hasProfession = true
                                break
                            end
                        end
                    end
                end

                if character.learned then
                    table.insert(result.known, key)
                elseif hasProfession then
                    table.insert(result.canLearn, key)
                else
                    table.insert(result.notProfession, key)
                end
                table.insert(result.scanned, key)
            end

            table.insert(results, result)
        end
    end

    table.sort(results, function(a, b)
        return a.name < b.name
    end)

    return results
end

function Recipes:GetCharacterDisplayName(key)
    local character = GoldMintDB and GoldMintDB.characters and GoldMintDB.characters[key]
    if character then
        if character.realm and character.name then
            return character.name .. "-" .. character.realm
        end
        return character.name or key
    end
    return key
end

function Recipes:PrintResult(result)
    GoldMint.Print("Recipe: " .. result.name .. " [" .. (result.profession or "Unknown") .. "]")
    GoldMint.Print("Recipe ID: " .. tostring(result.recipeID))

    if result.skillLines then
        local names = {}
        for _, skillLine in pairs(result.skillLines) do
            if skillLine.name then
                table.insert(names, skillLine.name)
            end
        end
        table.sort(names)
        if #names > 0 then
            GoldMint.Print("Skill lines: " .. table.concat(names, ", "))
        end
    end

    if #result.canLearn > 0 then
        GoldMint.Print("Can learn: " .. table.concat(self:FormatCharacters(result.canLearn), ", "))
    else
        GoldMint.Print("Can learn: none recorded")
    end

    if #result.known > 0 then
        GoldMint.Print("Already known: " .. table.concat(self:FormatCharacters(result.known), ", "))
    else
        GoldMint.Print("Already known: none recorded")
    end

    if #result.notProfession > 0 then
        GoldMint.Print("Not this profession / not verified: " .. table.concat(self:FormatCharacters(result.notProfession), ", "))
    end
end

function Recipes:FormatCharacters(keys)
    local names = {}
    for _, key in ipairs(keys) do
        table.insert(names, self:GetCharacterDisplayName(key))
    end
    table.sort(names)
    return names
end

function Recipes:ScanStatus()
    local key = GoldMint.characterKey
    local character = GoldMintDB and GoldMintDB.characters and GoldMintDB.characters[key]
    return character and character.lastRecipeScan or nil,
           character and character.lastRecipeProfession or nil
end
