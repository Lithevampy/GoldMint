local ADDON_NAME, GoldMint = ...

SLASH_GOLDMINT1 = "/goldmint"
SLASH_GOLDMINT2 = "/gm"
SLASH_GOLDMINTTODO1 = "/tdl"
SLASH_GOLDMINTTODO2 = "/goldminttodo"

SlashCmdList.GOLDMINTTODO = function(message)
    message = string.lower(strtrim(message or ""))
    if message == "" or message == "show" or message == "toggle" then
        if GoldMint.ToDoPopout then GoldMint.ToDoPopout:Toggle() end
    elseif message == "button" then
        if GoldMint.ToDoList and GoldMint.ToDoList.GetSettings and GoldMint.ToDoPopout then
            local s = GoldMint.ToDoList:GetSettings(); s.screenButton = not s.screenButton; GoldMint.ToDoPopout:UpdateScreenButton()
        end
    elseif message == "reset" then
        if GoldMint.ToDoList and GoldMint.ToDoList.ResetTab then GoldMint.ToDoList:ResetTab() end
    else
        GoldMint.Print("/tdl | show | button")
    end
end

local function PrintTransaction(transaction)
    local sign = transaction.amount >= 0 and "+" or "-"
    local amount = math.abs(transaction.amount)

    GoldMint.Print(string.format(
        "%s%s | %s | %s",
        sign,
        GoldMint.Ledger:FormatGold(amount),
        transaction.type,
        transaction.source
    ))
end

SlashCmdList.GOLDMINT = function(message)
    message = string.lower(strtrim(message or ""))

    if message == "" or message == "status" then
        local session = GoldMint.Ledger:GetSession()
        local accountGold = GoldMint.Ledger:GetKnownAccountGold()

        GoldMint.Print("----- GoldMint Ledger -----")
        GoldMint.Print("Character: " .. GoldMint.characterName .. "-" .. GoldMint.characterRealm)
        GoldMint.Print("Known account gold: " .. GoldMint.Ledger:FormatGoldFull(accountGold))
        GoldMint.Print("Current gold: " .. GoldMint.Ledger:FormatGoldFull(session.endingGold))
        GoldMint.Print("Session net: " .. GoldMint.Ledger:FormatGold(session.netGold))
        GoldMint.Print("Income: " .. GoldMint.Ledger:FormatGold(session.income))
        GoldMint.Print("Spending: " .. GoldMint.Ledger:FormatGold(session.spending))
        GoldMint.Print("Session speed: " .. GoldMint.Ledger:FormatRate(session.goldPerHour) .. "/hr")
        GoldMint.Print("Transactions: " .. #session.transactions)
        if GoldMint.Cooldowns then
            local ready, active = GoldMint.Cooldowns:GetSummary()
            GoldMint.Print("Profession cooldowns: " .. ready .. " ready | " .. active .. " active")
        end
        GoldMint.Print("---------------------------")
        return
    end

    if message == "session" then
        local session = GoldMint.Ledger:GetSession()
        GoldMint.Print(string.format(
            "Session: %s net | +%s income | -%s spending | %s/hr.",
            GoldMint.Ledger:FormatGold(session.netGold),
            GoldMint.Ledger:FormatGold(session.income),
            GoldMint.Ledger:FormatGold(session.spending),
            GoldMint.Ledger:FormatRate(session.goldPerHour)
        ))
        return
    end

    if message == "transactions" or message == "tx" then
        local session = GoldMint.Ledger:GetSession()

        GoldMint.Print("----- Current Session Transactions -----")

        if #session.transactions == 0 then
            GoldMint.Print("No gold changes recorded this session.")
        else
            local startIndex = math.max(1, #session.transactions - 19)
            for i = startIndex, #session.transactions do
                PrintTransaction(session.transactions[i])
            end
        end

        GoldMint.Print("---------------------------------------")
        return
    end

    if message == "characters" then
        GoldMint.Print("----- Known Characters -----")
        for key, character in pairs(GoldMintDB.characters or {}) do
            GoldMint.Print(key .. ": " .. GoldMint.Ledger:FormatGoldFull(character.gold or 0))
        end
        GoldMint.Print("----------------------------")
        return
    end

    if message == "goal" or message == "goals" then
        if not GoldMint.Milestones then
            GoldMint.Print("Milestone system is not loaded.")
            return
        end
        local goal = GoldMint.Milestones:GetActiveGoal()
        if not goal then
            GoldMint.Print("No active savings goal. Use: /gm goal set <gold> <name>")
            return
        end
        GoldMint.Print(string.format("Goal: %s | %s / %s | %s remaining", goal.name, GoldMint.Ledger:FormatGold(goal.currentValue), GoldMint.Ledger:FormatGold(goal.target), GoldMint.Ledger:FormatGold(goal.remaining)))
        if goal.nextCheckpoint then
            GoldMint.Print(string.format("Next checkpoint: %s | %s away", tostring(goal.nextCheckpoint.name or "Checkpoint"), GoldMint.Ledger:FormatGold(goal.nextCheckpoint.remaining)))
        end
        if goal.weekly then
            GoldMint.Print(string.format("7-day pace: %s", goal.weekly.status or "unknown"))
        end
        return
    end

    local goalAmount, goalName = message:match("^goal%s+set%s+(%d+)%s+(.+)$")
    if goalAmount and goalName then
        if not GoldMint.Milestones then
            GoldMint.Print("Milestone system is not loaded.")
            return
        end
        goalName = strtrim(goalName:gsub('^"(.*)"$', '%1'))
        local active = GoldMint.Milestones:GetActiveGoal()
        local result, err
        if active then
            result, err = GoldMint.Milestones:SetGoalTarget(active.id, goalName, tonumber(goalAmount) * 10000, { type = "gold" })
        else
            result, err = GoldMint.Milestones:CreateGoal(goalName, tonumber(goalAmount) * 10000, { type = "gold" })
        end
        if not result then
            GoldMint.Print("Unable to set goal: " .. tostring(err))
            return
        end
        GoldMint.Print(string.format("Savings goal set: %s | Target: %s", result.name, GoldMint.Ledger:FormatGold(result.target)))
        if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
            GoldMint.Dashboard:Refresh()
        end
        return
    end

    local deadlineDays = message:match("^goal%s+deadline%s+(%d+)$")
    if deadlineDays then
        if not GoldMint.Milestones then
            GoldMint.Print("Milestone system is not loaded.")
            return
        end
        local active = GoldMint.Milestones:GetActiveGoal()
        if not active then
            GoldMint.Print("No active goal. Set one first with: /gm goal set <gold> <name>")
            return
        end
        local days = tonumber(deadlineDays)
        if not days or days < 1 then
            GoldMint.Print("Deadline must be at least 1 day.")
            return
        end
        local deadline = time() + (days * 24 * 60 * 60)
        local result, err = GoldMint.Milestones:UpdateGoal(active.id, { deadline = deadline })
        if not result then
            GoldMint.Print("Unable to set deadline: " .. tostring(err))
            return
        end
        GoldMint.Print(string.format("Goal deadline set: %d day%s", days, days == 1 and "" or "s"))
        if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
            GoldMint.Dashboard:Refresh()
        end
        return
    end

    local checkpointAmount, checkpointName = message:match("^goal%s+checkpoint%s+(%d+)%s*(.*)$")
    if checkpointAmount then
        if not GoldMint.Milestones then
            GoldMint.Print("Milestone system is not loaded.")
            return
        end
        local active = GoldMint.Milestones:GetActiveGoal()
        if not active then
            GoldMint.Print("No active goal. Set one first with: /gm goal set <gold> <name>")
            return
        end
        local result, err = GoldMint.Milestones:SetCheckpoint(active.id, tonumber(checkpointAmount) * 10000, strtrim(checkpointName) ~= "" and strtrim(checkpointName) or nil)
        if not result then
            GoldMint.Print("Unable to add checkpoint: " .. tostring(err))
            return
        end
        GoldMint.Print(string.format("Checkpoint added: %s | %s", tostring(result.nextCheckpoint and result.nextCheckpoint.name or "Checkpoint"), GoldMint.Ledger:FormatGold(tonumber(checkpointAmount) * 10000)))
        if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
            GoldMint.Dashboard:Refresh()
        end
        return
    end

    if message == "goal clear" then
        if GoldMint.Milestones then
            local active = GoldMint.Milestones:GetActiveGoal()
            if active then
                GoldMint.Milestones:DeleteGoal(active.id)
                GoldMint.Print("Active savings goal cleared.")
                if GoldMint.Dashboard and GoldMint.Dashboard.Refresh then
                    GoldMint.Dashboard:Refresh()
                end
            else
                GoldMint.Print("No active savings goal to clear.")
            end
        end
        return
    end

    if message == "dashboard" or message == "ui" then
        if GoldMint.Dashboard then
            -- Always initialize the dashboard before opening it.  This keeps
            -- /gm dashboard reliable even if the UI has not been opened yet.
            if GoldMint.Dashboard.Initialize then
                GoldMint.Dashboard:Initialize()
            end
            if GoldMint.Dashboard.Show then
                GoldMint.Dashboard:Show()
            else
                GoldMint.Print("Dashboard UI is unavailable.")
            end
        else
            GoldMint.Print("Dashboard module is not loaded.")
        end
        return
    end

    if message == "cooldowns" or message == "cooldown tracker" or message == "cooldown track" then
        if GoldMint.Cooldowns and GoldMint.Cooldowns.OpenTracker then
            GoldMint.Cooldowns:OpenTracker()
        else
            GoldMint.Print("Cooldown tracker module is not loaded.")
        end
        return
    end

    if message == "tasks" or message == "current tasks" or message == "task popout" then
        if GoldMint.TaskPopout then
            GoldMint.TaskPopout:Toggle()
        else
            GoldMint.Print("Current Tasks popout module is not loaded.")
        end
        return
    end

    if message == "hub" or message == "home" then
        if GoldMint.Hub then
            GoldMint.Hub:Toggle()
        else
            GoldMint.Print("Hub module is not loaded.")
        end
        return
    end

    if message == "character" then
        if not GoldMint.CharacterTracking then
            GoldMint.Print("Character tracking module is not loaded.")
            return
        end
        local snapshot = GoldMint.CharacterTracking:GetHubSnapshot()
        GoldMint.Print("----- GoldMint Characters -----")
        GoldMint.Print(string.format("Known: %d | Active: %d | Known gold: %s", snapshot.characterCount, snapshot.activeCount, GoldMint.Ledger:FormatGoldFull(snapshot.totalGold)))
        for _, character in ipairs(snapshot.characters) do
            local marker = character.key == GoldMint.characterKey and " [CURRENT]" or ""
            GoldMint.Print(string.format("%s%s-%s | Lv.%d | %s", character.name, marker, character.realm, character.level, GoldMint.Ledger:FormatGoldFull(character.gold)))
        end
        GoldMint.Print("-------------------------------")
        return
    end

    if message == "character workflow" or message == "character context" then
        if not GoldMint.CharacterTracking then
            GoldMint.Print("Character tracking module is not loaded.")
            return
        end
        local current = GoldMint.CharacterTracking:GetCharacterWorkflowOverview(GoldMint.characterKey)
        GoldMint.Print("----- Character Workflow -----")
        GoldMint.Print(tostring(current.name) .. "-" .. tostring(current.realm))
        GoldMint.Print("Current task: " .. (current.task and tostring(current.task.title) or "none"))
        GoldMint.Print("Next action: " .. (current.nextAction and tostring(current.nextAction.title) or "none"))
        GoldMint.Print("Last activity: " .. (current.lastActivity and tostring(current.lastActivity.label) or "none"))
        GoldMint.Print("Reminders: " .. tostring(current.reminderCount or 0))
        GoldMint.Print("Recent completed tasks: " .. tostring(#(current.recentTasks or {})))
        GoldMint.Print("------------------------------")
        return
    end

    if message == "mail" or message == "mail status" or message == "mail scan" then
        if not GoldMint.MailTracking then
            GoldMint.Print("Mail tracking module is not loaded.")
            return
        end
        if message == "mail scan" and GoldMint.MailTracking:IsMailboxOpen() then
            GoldMint.MailTracking:Scan("command")
        end
        local state = GoldMint.MailTracking:GetStatus()
        GoldMint.Print("----- GoldMint Mail -----")
        GoldMint.Print("Messages: " .. tostring(state and state.mailCount or 0))
        GoldMint.Print("Attachments: " .. tostring(state and state.attachmentCount or 0))
        GoldMint.Print("Attached money: " .. GoldMint.Ledger:FormatGoldFull(state and state.moneyTotal or 0))
        GoldMint.Print("Unread: " .. tostring(state and state.unreadCount or 0))
        GoldMint.Print("Known-character mail: " .. tostring(state and state.internalCount or 0))
        GoldMint.Print("Last scan: " .. (state and state.lastScanAt and date("!%Y-%m-%d %H:%M:%S", state.lastScanAt) or "never"))
        GoldMint.Print("Mailbox open: " .. ((state and state.mailboxOpen) and "yes" or "no"))
        GoldMint.Print("-------------------------")
        return
    end

    local lootAlertsCommand = message:match("^lootalerts%s*(.*)$")
    if lootAlertsCommand ~= nil then
        if not GoldMint.LootAlerts then
            GoldMint.Print("Loot alert module is not loaded.")
            return
        end

        local args = strtrim(lootAlertsCommand or "")
        if args == "" or args == "status" then
            local threshold = GoldMint.LootAlerts:GetThreshold()
            local settings = GoldMint.LootAlerts:GetSettings()
            GoldMint.Print("----- GoldMint Loot Alerts -----")
            GoldMint.Print("BoE value threshold: " .. GoldMint.Ledger:FormatGoldFull(threshold))
            GoldMint.Print("Valuable BoE alerts: " .. (settings.alertHighValue and "ON" or "OFF"))
            GoldMint.Print("Unknown transmog alerts: " .. (settings.alertUncollected and "ON" or "OFF"))
            GoldMint.Print("Sound: " .. (settings.soundEnabled and "ON" or "OFF"))
            GoldMint.Print("Pending: " .. tostring(#GoldMint.LootAlerts:GetPendingAlerts()))
            GoldMint.Print("-----------------------------------")
            return
        end

        local thresholdGold = args:match("^threshold%s+([%d%.]+)$")
        if thresholdGold then
            local gold = tonumber(thresholdGold)
            if gold and gold >= 0 then
                GoldMint.LootAlerts:SetThreshold(math.floor(gold * 10000))
                GoldMint.Print("BoE value threshold set to " .. GoldMint.Ledger:FormatGoldFull(gold * 10000) .. ".")
            else
                GoldMint.Print("Invalid threshold. Example: /gm lootalerts threshold 10000")
            end
            return
        end

        local toggleName, toggleValue = args:match("^(high|uncollected|sound)%s+(on|off)$")
        if toggleName and toggleValue then
            local setting = ({ high = "alertHighValue", uncollected = "alertUncollected", sound = "soundEnabled" })[toggleName]
            GoldMint.LootAlerts:SetSetting(setting, toggleValue == "on")
            GoldMint.Print(string.format("Loot alert setting %s: %s.", toggleName, toggleValue:upper()))
            return
        end

        if args == "clear" then
            GoldMint.LootAlerts:ClearPendingAlerts()
            GoldMint.Print("Pending loot alerts cleared.")
            return
        end

        GoldMint.Print("Usage: /gm lootalerts | threshold <gold> | high on/off | uncollected on/off | sound on/off | clear")
        return
    end

    if message == "alerts" then
        if GoldMint.Alerts then
            GoldMint.Alerts:Toggle()
        else
            GoldMint.Print("Alert module is not loaded.")
        end
        return
    end

    if message == "workflow" then
        if not GoldMint.WorkflowState then
            GoldMint.Print("Workflow state module is not loaded.")
            return
        end

        local state = GoldMint.WorkflowState:GetWelcomeBackState()
        GoldMint.Print("----- GoldMint Workflow State -----")
        GoldMint.Print("Character: " .. tostring(state.characterName) .. "-" .. tostring(state.characterRealm))

        if state.task then
            GoldMint.Print("Current task: " .. tostring(state.task.title))
        else
            GoldMint.Print("Current task: none")
        end

        if state.nextAction then
            GoldMint.Print("Next action: " .. tostring(state.nextAction.title))
        else
            GoldMint.Print("Next action: none")
        end

        if state.lastActivity then
            GoldMint.Print("Last activity: " .. tostring(state.lastActivity.label))
        else
            GoldMint.Print("Last activity: none")
        end

        GoldMint.Print("Active reminders: " .. tostring(state.reminderCount))
        GoldMint.Print("Returning character: " .. (state.isReturning and "yes" or "no previous session"))
        if state.lastSession and state.lastSession.endedAt then
            GoldMint.Print("Last session ended: " .. date("!%Y-%m-%d %H:%M:%S", state.lastSession.endedAt))
        end
        GoldMint.Print("----------------------------------")
        return
    end

    if message == "workflow characters" and GoldMint.CharacterTracking then
        GoldMint.Print("----- Character Workflow -----")
        for _, character in ipairs(GoldMint.CharacterTracking:GetAll()) do
            local context = GoldMint.WorkflowState and GoldMint.WorkflowState:GetCharacterContext(character.key)
            local task = context and context.currentTask and context.currentTask.title or "none"
            local nextAction = context and context.nextAction and context.nextAction.title or "none"
            local reminders = context and context.reminderCount or 0
            GoldMint.Print(string.format("%s: Task=%s | Next=%s | Reminders=%d", character.name, task, nextAction, reminders))
        end
        GoldMint.Print("------------------------------")
        return
    end

    local workflowTask = message:match("^workflow%s+task%s+(.+)$")
    if workflowTask and GoldMint.WorkflowState then
        GoldMint.WorkflowState:SetCurrentTask(workflowTask)
        if GoldMint.Alerts then GoldMint.Alerts:Evaluate("workflow") end
        GoldMint.Print("Workflow task set: " .. workflowTask)
        return
    end

    local workflowNext = message:match("^workflow%s+next%s+(.+)$")
    if workflowNext and GoldMint.WorkflowState then
        GoldMint.WorkflowState:SetNextAction(workflowNext)
        if GoldMint.Alerts then GoldMint.Alerts:Evaluate("workflow-next") end
        GoldMint.Print("Next action set: " .. workflowNext)
        return
    end

    if message == "workflow complete" then
        if not GoldMint.WorkflowState then
            GoldMint.Print("Workflow state module is not loaded.")
            return
        end
        if not GoldMint.WorkflowState:CompleteTask() then
            GoldMint.Print("No active workflow task to complete.")
        else
            GoldMint.Print("Workflow task completed.")
        end
        return
    end

    local workflowReminder = message:match("^workflow%s+remind%s+(.+)$")
    if workflowReminder and GoldMint.WorkflowState then
        GoldMint.WorkflowState:AddReminder(workflowReminder)
        if GoldMint.Alerts then GoldMint.Alerts:Evaluate("reminder") end
        GoldMint.Print("Workflow reminder added: " .. workflowReminder)
        return
    end

    if message == "routines ready" then
        if not GoldMint.RoutineState then
            GoldMint.Print("Routine state module is not loaded.")
            return
        end
        local summary = GoldMint.RoutineState:GetSummary()
        GoldMint.Print("----- GoldMint Routine State -----")
        GoldMint.Print("Character: " .. tostring(GoldMint.characterName) .. "-" .. tostring(GoldMint.characterRealm))
        GoldMint.Print("Level: " .. tostring(summary.level))
        GoldMint.Print("Current Season 2 catalog entries: " .. tostring(summary.totalCatalog))
        GoldMint.Print("Observed: " .. tostring(summary.observed))
        GoldMint.Print("Ready: " .. tostring(summary.ready))
        GoldMint.Print("Completed: " .. tostring(summary.completed))
        GoldMint.Print("----------------------------------")
        return
    end

    if message == "routines" then
        if not GoldMint.Routines then
            GoldMint.Print("Routine module is not loaded.")
            return
        end

        local summary = GoldMint.Routines:GetSummary()
        GoldMint.Print("----- GoldMint Routines -----")
        GoldMint.Print(string.format("Current: %d daily | %d weekly | %d scheduled", summary.current.daily, summary.current.weekly, summary.current.scheduled))
        GoldMint.Print(string.format("Legacy: %d daily | %d weekly | %d scheduled", summary.legacy.daily, summary.legacy.weekly, summary.legacy.scheduled))
        GoldMint.Print("Ready: " .. tostring(summary.ready) .. " | Completed: " .. tostring(summary.completed))
        GoldMint.Print("-----------------------------")
        return
    end

    if message == "recipes scan" then
        if not GoldMint.Recipes then
            GoldMint.Print("Recipe module is not loaded.")
            return
        end

        local started = GoldMint.Recipes:ScanAllProfessionVariants(function(scanned, learned, lines, profession, variants)
            if scanned == 0 then
                GoldMint.Print("No profession recipes found. Open a profession window first.")
                return
            end

            GoldMint.Print(string.format(
                "Scanned %d recipes (%d known) across %d skill lines for %s.",
                scanned,
                learned,
                lines,
                profession or "Unknown profession"
            ))
        end)

        if not started then
            local scanned, learned, profession = GoldMint.Recipes:ScanCurrentProfession()
            if scanned == 0 then
                GoldMint.Print("No profession recipes found. Open a profession window first.")
                return
            end
            GoldMint.Print(string.format(
                "Scanned %d recipes for %s (%d known).",
                scanned,
                profession or "Unknown profession",
                learned
            ))
        end
        return
    end

    if message == "recipes" then
        local recipeCount = 0
        local byProfession = {}
        local characterCount = 0

        for _ in pairs(GoldMintDB.characters or {}) do
            characterCount = characterCount + 1
        end

        for _, record in pairs(GoldMintDB.recipes or {}) do
            recipeCount = recipeCount + 1
            local profession = record.professionName or record.profession or "Unknown"
            byProfession[profession] = (byProfession[profession] or 0) + 1
        end

        GoldMint.Print("Saved recipe records: " .. recipeCount)
        GoldMint.Print("Characters recorded: " .. characterCount)

        local professions = {}
        for profession in pairs(byProfession) do
            professions[#professions + 1] = profession
        end
        table.sort(professions)
        for _, profession in ipairs(professions) do
            GoldMint.Print("  " .. profession .. ": " .. byProfession[profession])
        end

        GoldMint.Print("Opening a profession scans it automatically and adds to the account database.")
        return
    end

    local recipeQuery = message:match("^recipes%s+find%s+(.+)$")
    if recipeQuery and GoldMint.Recipes then
        local results = GoldMint.Recipes:FindByName(recipeQuery)

        if #results == 0 then
            GoldMint.Print("No recorded recipe matches: " .. recipeQuery)
            return
        end

        for i, result in ipairs(results) do
            if i > 10 then
                GoldMint.Print("More matches exist. Be more specific.")
                break
            end
            GoldMint.Recipes:PrintResult(result)
        end
        return
    end

    if message == "economy" then
        if not GoldMint.Economy then
            GoldMint.Print("Economy module is not loaded.")
            return
        end

        local status = GoldMint.Economy:GetStatus()
        local session = status.session
        local valuation = status.valuation

        GoldMint.Print("----- GoldMint Economy -----")
        GoldMint.Print("Account gold: " .. GoldMint.Ledger:FormatGoldFull(status.wallet.totalGold))
        GoldMint.Print("Characters: " .. tostring(status.wallet.characterCount))

        if session then
            GoldMint.Print("Session net: " .. GoldMint.Ledger:FormatGold(session.netGold))
            GoldMint.Print("Session speed: " .. GoldMint.Ledger:FormatRate(session.goldPerHour) .. "/hr")
            GoldMint.Print("Transactions: " .. tostring(session.transactionCount))
        end

        GoldMint.Print("Tracked market items: " .. tostring(status.market.trackedItems))
        GoldMint.Print("Owned tracked value: " .. GoldMint.Ledger:FormatGoldFull(status.market.ownedValue))
        if status.mail then
            GoldMint.Print("Mail: " .. tostring(status.mail.mailCount) .. " message(s), " .. tostring(status.mail.attachmentCount) .. " attachment(s)")
            GoldMint.Print("Mail attached money: " .. GoldMint.Ledger:FormatGoldFull(status.mail.moneyTotal))
        end
        GoldMint.Print("Account item value: " .. GoldMint.Ledger:FormatGoldFull(valuation.items))
        GoldMint.Print("Account total value: " .. GoldMint.Ledger:FormatGoldFull(valuation.total))
        GoldMint.Print("Crafting profit records: " .. tostring(status.crafting.recipesWithProfitData))
        GoldMint.Print("Profitable recipes: " .. tostring(status.crafting.profitableRecipes))
        GoldMint.Print("----------------------------")
        return
    end

    if message == "valuation" then
        if not GoldMint.Valuation then
            GoldMint.Print("Valuation module is not loaded.")
            return
        end

        local status = GoldMint.Valuation:GetStatus()
        GoldMint.Print("----- GoldMint Valuation -----")
        GoldMint.Print("Account gold: " .. GoldMint.Ledger:FormatGoldFull(status.gold))
        GoldMint.Print("Tracked account items: " .. GoldMint.Ledger:FormatGoldFull(status.items))
        GoldMint.Print("Account total: " .. GoldMint.Ledger:FormatGoldFull(status.total))
        GoldMint.Print("Visible character items: " .. GoldMint.Ledger:FormatGoldFull(status.visibleCharacterItems))
        GoldMint.Print("Visible bank items: " .. GoldMint.Ledger:FormatGoldFull(status.visibleBankItems))
        GoldMint.Print("Tracked market items: " .. tostring(status.trackedMarketItems))
        GoldMint.Print("------------------------------")
        return
    end

    if message == "market" then
        if not GoldMint.Market then
            GoldMint.Print("Market module is not loaded.")
            return
        end

        local tracked = GoldMint.Market:GetTrackedCount()
        local ownedValue = GoldMint.Market:GetOwnedValue()
        GoldMint.Print("----- GoldMint Market -----")
        GoldMint.Print("Tracked items: " .. tracked)
        GoldMint.Print("Owned tracked value: " .. GoldMint.Ledger:FormatGoldFull(ownedValue))
        GoldMint.Print("Auction prices: recorded from AH search results")
        GoldMint.Print("Vendor prices: recorded automatically from cached item data")
        GoldMint.Print("---------------------------")
        return
    end

    local marketItem = message:match("^market%s+(%d+)$")
    if marketItem and GoldMint.Market then
        local itemID = tonumber(marketItem)
        local status = GoldMint.Market:GetStatus(itemID)
        if not status then
            GoldMint.Print("Item " .. tostring(itemID) .. " is not tracked yet. Put it in your bags or view it at the Auction House.")
            return
        end

        GoldMint.Print("----- Market Item -----")
        GoldMint.Print("Item: " .. (status.name or tostring(itemID)))
        if status.value then
            GoldMint.Print("Current value: " .. GoldMint.Market:FormatUnit(status.value) .. " / item (" .. status.source .. ")")
        else
            GoldMint.Print("Current value: no market value recorded yet")
        end
        if status.vendorSellPrice and status.vendorSellPrice > 0 then
            GoldMint.Print("Vendor sell: " .. GoldMint.Market:FormatGold(status.vendorSellPrice))
        end
        if status.auctionLowest then
            GoldMint.Print("Lowest observed AH: " .. GoldMint.Market:FormatUnit(status.auctionLowest) .. " / item")
        end
        GoldMint.Print("AH observations: " .. tostring(status.observationCount or 0))
        GoldMint.Print("-----------------------")
        return
    end

    if message == "help" then
        GoldMint.Print("/goldmint status")
        GoldMint.Print("/goldmint session")
        GoldMint.Print("/goldmint transactions")
        GoldMint.Print("/goldmint characters")
        GoldMint.Print("/goldmint workflow")
        GoldMint.Print("/goldmint workflow characters")
        GoldMint.Print("/goldmint workflow task <text>")
        GoldMint.Print("/goldmint workflow next <text>")
        GoldMint.Print("/goldmint workflow complete")
        GoldMint.Print("/goldmint workflow remind <text>")
        GoldMint.Print("/goldmint recipes scan (manual refresh)")
        GoldMint.Print("/goldmint recipes find <recipe name>")
        GoldMint.Print("/goldmint economy")
        GoldMint.Print("/goldmint valuation")
        GoldMint.Print("/goldmint market")
        GoldMint.Print("/goldmint market <itemID>")
        return
    end

    GoldMint.Print("Unknown command. Try /goldmint help")
end
