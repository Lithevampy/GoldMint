local ADDON_NAME, GoldMint = ...

-- GoldMint Cognitive Workflow State
--
-- This module is intentionally small and evidence-based. It remembers what the
-- player was doing, what they explicitly said was next, and the last activity
-- GoldMint observed. It does not invent mail/auction/gold workflow facts that
-- other modules have not established yet.

GoldMint.WorkflowState = {}
local Workflow = GoldMint.WorkflowState

local STORE_VERSION = 2
local MAX_HISTORY = 50
local MAX_CHARACTER_HISTORY = 50
local MAX_REMINDERS = 50
local MAX_MANUAL_TODOS = 50

local function Now()
    return time()
end

local function EnsureStore()
    GoldMintDB.workflowState = type(GoldMintDB.workflowState) == "table" and GoldMintDB.workflowState or {}
    local store = GoldMintDB.workflowState
    store.version = math.max(tonumber(store.version) or 0, STORE_VERSION)
    store.characters = type(store.characters) == "table" and store.characters or {}
    store.history = type(store.history) == "table" and store.history or {}
    store.reminders = type(store.reminders) == "table" and store.reminders or {}
    store.manualTodos = type(store.manualTodos) == "table" and store.manualTodos or {}
    store.manualTodoNextID = tonumber(store.manualTodoNextID) or 0
    store.current = type(store.current) == "table" and store.current or {}
    store.lastSession = type(store.lastSession) == "table" and store.lastSession or {}
    return store
end

local function CurrentCharacterKey()
    return GoldMint.characterKey
end

local function GetCharacterStore(key)
    local store = EnsureStore()
    key = key or CurrentCharacterKey()
    if not key then return nil end

    local character = store.characters[key]
    if type(character) ~= "table" then
        character = {}
        store.characters[key] = character
    end

    if key == CurrentCharacterKey() then
        character.name = GoldMint.characterName or character.name or "Unknown"
        character.realm = GoldMint.characterRealm or character.realm or "Unknown"
    else
        character.name = character.name or key
        character.realm = character.realm or "Unknown"
    end
    character.currentTask = type(character.currentTask) == "table" and character.currentTask or nil
    character.nextAction = type(character.nextAction) == "table" and character.nextAction or nil
    character.lastActivity = type(character.lastActivity) == "table" and character.lastActivity or nil
    character.lastSession = type(character.lastSession) == "table" and character.lastSession or nil
    character.history = type(character.history) == "table" and character.history or {}
    return character
end

local function CopyTable(source)
    if type(source) ~= "table" then return source end
    local result = {}
    for key, value in pairs(source) do
        if type(value) == "table" then
            result[key] = CopyTable(value)
        else
            result[key] = value
        end
    end
    return result
end

local function RefreshTaskUI()
    if GoldMint.TaskPopout and GoldMint.TaskPopout.Refresh then
        GoldMint.TaskPopout:Refresh()
    end
end

local function AlertNextSuggestion(action)
    if not action or not GoldMint.Alerts then return end
    if GoldMint.Alerts.ShowNextSuggestion then
        GoldMint.Alerts:ShowNextSuggestion(action)
    end
end

local function TrimHistory(store)
    while #store.history > MAX_HISTORY do
        table.remove(store.history, 1)
    end
end

local function TrimReminders(store)
    while #store.reminders > MAX_REMINDERS do
        table.remove(store.reminders, 1)
    end
end

local function TrimCharacterHistory(character)
    while #character.history > MAX_CHARACTER_HISTORY do
        table.remove(character.history, 1)
    end
end

local function GetStoredCharacter(key)
    local store = EnsureStore()
    key = key or CurrentCharacterKey()
    if not key then return nil end
    return store.characters[key]
end

function Workflow:Initialize()
    local store = EnsureStore()
    local character = GetCharacterStore(CurrentCharacterKey())
    if not character then return nil end

    local now = Now()
    character.lastLoginAt = now
    character.sessionStartedAt = now
    character.name = GoldMint.characterName
    character.realm = GoldMint.characterRealm

    -- Restore the character's workflow into the account-level current snapshot.
    -- This is what allows a later Hub to ask one stable object for the player's
    -- current context without coupling itself to the individual modules.
    store.current.characterKey = CurrentCharacterKey()
    store.current.characterName = GoldMint.characterName
    store.current.characterRealm = GoldMint.characterRealm
    store.current.task = CopyTable(character.currentTask)
    store.current.nextAction = CopyTable(character.nextAction)
    store.current.activity = CopyTable(character.lastActivity)
    store.current.updatedAt = Now()

    return self:GetWelcomeBackState()
end

function Workflow:SetCurrentTask(title, taskID, details)
    if not title or tostring(title) == "" then return false end

    local store = EnsureStore()
    local character = GetCharacterStore()
    if not character then return false end

    local now = Now()
    local task = {
        id = taskID and tostring(taskID) or nil,
        title = tostring(title),
        details = details ~= nil and tostring(details) or nil,
        characterKey = CurrentCharacterKey(),
        startedAt = (character.currentTask and character.currentTask.startedAt) or now,
        updatedAt = now,
        status = "active",
    }

    character.currentTask = task
    store.current.task = CopyTable(task)
    store.current.characterKey = CurrentCharacterKey()
    store.current.characterName = GoldMint.characterName
    store.current.characterRealm = GoldMint.characterRealm
    store.current.updatedAt = now
    RefreshTaskUI()
    return CopyTable(task)
end

function Workflow:GetCurrentTask(characterKey)
    if characterKey and characterKey ~= CurrentCharacterKey() then
        local character = GetCharacterStore(characterKey)
        return character and CopyTable(character.currentTask) or nil
    end
    local character = GetCharacterStore()
    return character and CopyTable(character.currentTask) or nil
end

function Workflow:SetNextAction(title, taskID, details)
    if not title or tostring(title) == "" then return false end

    local store = EnsureStore()
    local character = GetCharacterStore()
    if not character then return false end

    local action = {
        id = taskID and tostring(taskID) or nil,
        title = tostring(title),
        details = details ~= nil and tostring(details) or nil,
        characterKey = CurrentCharacterKey(),
        createdAt = (character.nextAction and character.nextAction.createdAt) or Now(),
        updatedAt = Now(),
    }

    character.nextAction = action
    store.current.nextAction = CopyTable(action)
    store.current.updatedAt = Now()
    RefreshTaskUI()
    AlertNextSuggestion(action)
    return CopyTable(action)
end

local SYSTEM_ACTION_PRIORITY = {
    ["goal-method"] = 100,
    ["goal-strategy"] = 90,
    ["logistics"] = 70,
    ["goal-focus"] = 50,
    ["system"] = 10,
}

local function SystemActionPriority(source)
    return SYSTEM_ACTION_PRIORITY[tostring(source or "system")] or 10
end

function Workflow:SetSystemNextAction(title, taskID, details, source)
    if not title or tostring(title) == "" then return false end

    local requestedSource = tostring(source or "system")
    local current = self:GetNextAction()
    if current then
        local currentSource = tostring(current.source or "player")
        -- Player-authored actions are the highest-priority source. System
        -- modules must never silently replace them.
        if currentSource ~= "goal-method" and currentSource ~= "goal-strategy"
            and currentSource ~= "logistics" and currentSource ~= "goal-focus"
            and currentSource ~= "system" then
            return CopyTable(current)
        end

        -- When two system modules compete, keep the more important workflow
        -- action. The same source may refresh its own action.
        if currentSource ~= requestedSource
            and SystemActionPriority(currentSource) > SystemActionPriority(requestedSource) then
            return CopyTable(current)
        end
    end

    local action = self:SetNextAction(title, taskID, details)
    if not action then return false end
    local store = EnsureStore()
    local character = GetCharacterStore()
    if character and character.nextAction then
        character.nextAction.source = requestedSource
        store.current.nextAction = CopyTable(character.nextAction)
        store.current.updatedAt = Now()
        RefreshTaskUI()
        AlertNextSuggestion(character.nextAction)
        return CopyTable(character.nextAction)
    end
    return action
end

function Workflow:GetNextAction(characterKey)
    if characterKey and characterKey ~= CurrentCharacterKey() then
        local character = GetCharacterStore(characterKey)
        return character and CopyTable(character.nextAction) or nil
    end
    local character = GetCharacterStore()
    return character and CopyTable(character.nextAction) or nil
end

function Workflow:ClearNextAction()
    local store = EnsureStore()
    local character = GetCharacterStore()
    if not character then return false end
    character.nextAction = nil
    store.current.nextAction = nil
    store.current.updatedAt = Now()
    RefreshTaskUI()
    return true
end


-- ---------------------------------------------------------------------------
-- Manual World Quests list
-- ---------------------------------------------------------------------------
-- These tasks are deliberately player-authored and independent of Blizzard's
-- quest/routine state. They persist across reloads and are account-wide so the
-- Routines page can serve as one simple personal checklist.
local function TrimManualTodos(store)
    while #store.manualTodos > MAX_MANUAL_TODOS do
        table.remove(store.manualTodos, 1)
    end
end

function Workflow:GetManualTodos()
    local store = EnsureStore()
    local result = {}
    for _, todo in ipairs(store.manualTodos) do
        if type(todo) == "table" and todo.id and todo.title then
            result[#result + 1] = CopyTable(todo)
        end
    end
    table.sort(result, function(a, b)
        if (a.completed == true) ~= (b.completed == true) then
            return a.completed ~= true
        end
        return (tonumber(a.createdAt) or 0) < (tonumber(b.createdAt) or 0)
    end)
    return result
end

function Workflow:AddManualTodo(title)
    title = strtrim(tostring(title or ""))
    if title == "" then return nil end

    local store = EnsureStore()
    store.manualTodoNextID = (tonumber(store.manualTodoNextID) or 0) + 1
    local todo = {
        id = "todo-" .. tostring(store.manualTodoNextID),
        title = title,
        completed = false,
        createdAt = Now(),
        updatedAt = Now(),
    }
    store.manualTodos[#store.manualTodos + 1] = todo
    TrimManualTodos(store)
    RefreshTaskUI()
    return CopyTable(todo)
end

function Workflow:ToggleManualTodo(todoID)
    if not todoID then return nil end
    local store = EnsureStore()
    for _, todo in ipairs(store.manualTodos) do
        if todo.id == todoID then
            todo.completed = not (todo.completed == true)
            todo.updatedAt = Now()
            RefreshTaskUI()
            return CopyTable(todo)
        end
    end
    return nil
end

function Workflow:RemoveManualTodo(todoID)
    if not todoID then return false end
    local store = EnsureStore()
    for i, todo in ipairs(store.manualTodos) do
        if todo.id == todoID then
            table.remove(store.manualTodos, i)
            RefreshTaskUI()
            return true
        end
    end
    return false
end

function Workflow:ClearCompletedManualTodos()
    local store = EnsureStore()
    local kept = {}
    local removed = 0
    for _, todo in ipairs(store.manualTodos) do
        if todo.completed == true then
            removed = removed + 1
        else
            kept[#kept + 1] = todo
        end
    end
    store.manualTodos = kept
    return removed
end

function Workflow:CompleteTask(note)
    local store = EnsureStore()
    local character = GetCharacterStore()
    if not character or not character.currentTask then return false end

    local task = CopyTable(character.currentTask)
    task.status = "completed"
    task.completedAt = Now()
    task.note = note ~= nil and tostring(note) or nil
    task.characterKey = CurrentCharacterKey()

    store.history[#store.history + 1] = CopyTable(task)
    TrimHistory(store)

    character.history[#character.history + 1] = CopyTable(task)
    TrimCharacterHistory(character)

    character.currentTask = nil
    store.current.task = nil
    store.current.updatedAt = Now()
    RefreshTaskUI()
    return true
end

function Workflow:TouchActivity(activityID, label, details)
    if not label or tostring(label) == "" then return false end

    local store = EnsureStore()
    local character = GetCharacterStore()
    if not character then return false end

    local activity = {
        id = activityID and tostring(activityID) or nil,
        label = tostring(label),
        details = details ~= nil and tostring(details) or nil,
        characterKey = CurrentCharacterKey(),
        observedAt = Now(),
    }

    character.lastActivity = activity
    character.lastActivityAt = activity.observedAt
    store.current.activity = CopyTable(activity)
    store.current.characterKey = CurrentCharacterKey()
    store.current.characterName = GoldMint.characterName
    store.current.characterRealm = GoldMint.characterRealm
    store.current.updatedAt = activity.observedAt
    return CopyTable(activity)
end

function Workflow:GetLastActivity(characterKey)
    local character = GetCharacterStore(characterKey or CurrentCharacterKey())
    return character and CopyTable(character.lastActivity) or nil
end

function Workflow:AddReminder(text, dueAt, reminderID)
    if not text or tostring(text) == "" then return false end

    local store = EnsureStore()
    local reminder = {
        id = reminderID and tostring(reminderID) or ("reminder-" .. tostring(Now()) .. "-" .. tostring(#store.reminders + 1)),
        text = tostring(text),
        characterKey = CurrentCharacterKey(),
        createdAt = Now(),
        dueAt = tonumber(dueAt) or nil,
        completed = false,
    }

    store.reminders[#store.reminders + 1] = reminder
    TrimReminders(store)
    return CopyTable(reminder)
end

function Workflow:CompleteReminder(reminderID)
    if not reminderID then return false end
    local store = EnsureStore()
    reminderID = tostring(reminderID)

    for _, reminder in ipairs(store.reminders) do
        if tostring(reminder.id) == reminderID and reminder.completed ~= true then
            reminder.completed = true
            reminder.completedAt = Now()
            return true
        end
    end
    return false
end

function Workflow:RemoveReminder(reminderID)
    if not reminderID then return false end
    local store = EnsureStore()
    reminderID = tostring(reminderID)

    for index, reminder in ipairs(store.reminders) do
        if tostring(reminder.id) == reminderID then
            table.remove(store.reminders, index)
            return true
        end
    end
    return false
end

function Workflow:GetReminders(includeCompleted, characterKey)
    local store = EnsureStore()
    characterKey = characterKey or CurrentCharacterKey()
    local result = {}

    for _, reminder in ipairs(store.reminders) do
        if (not characterKey or reminder.characterKey == characterKey)
            and (includeCompleted == true or reminder.completed ~= true) then
            result[#result + 1] = CopyTable(reminder)
        end
    end

    table.sort(result, function(a, b)
        local ad = tonumber(a.dueAt) or math.huge
        local bd = tonumber(b.dueAt) or math.huge
        if ad ~= bd then return ad < bd end
        return (tonumber(a.createdAt) or 0) < (tonumber(b.createdAt) or 0)
    end)

    return result
end

function Workflow:RecordSessionSummary(summary)
    local store = EnsureStore()
    local character = GetCharacterStore()
    if not character then return false end

    local record = type(summary) == "table" and CopyTable(summary) or {}
    record.characterKey = CurrentCharacterKey()
    record.endedAt = tonumber(record.endedAt) or Now()
    record.lastTask = CopyTable(character.currentTask)
    record.nextAction = CopyTable(character.nextAction)
    record.lastActivity = CopyTable(character.lastActivity)

    character.lastSession = record
    store.lastSession = CopyTable(record)
    return CopyTable(record)
end

function Workflow:GetLastSession(characterKey)
    if characterKey and characterKey ~= CurrentCharacterKey() then
        local character = GetCharacterStore(characterKey)
        return character and CopyTable(character.lastSession) or nil
    end
    local character = GetCharacterStore()
    return character and CopyTable(character.lastSession) or nil
end

function Workflow:GetCharacterWorkflowState(characterKey)
    characterKey = characterKey or CurrentCharacterKey()
    local character = GetStoredCharacter(characterKey)
    if type(character) ~= "table" then return nil end

    local reminders = self:GetReminders(false, characterKey)
    local history = {}
    for _, task in ipairs(character.history or {}) do
        history[#history + 1] = CopyTable(task)
    end

    table.sort(history, function(a, b)
        return (tonumber(a.completedAt) or tonumber(a.updatedAt) or 0) > (tonumber(b.completedAt) or tonumber(b.updatedAt) or 0)
    end)

    return {
        characterKey = characterKey,
        characterName = character.name or (characterKey == CurrentCharacterKey() and GoldMint.characterName) or "Unknown",
        characterRealm = character.realm or (characterKey == CurrentCharacterKey() and GoldMint.characterRealm) or "Unknown",
        task = CopyTable(character.currentTask),
        nextAction = CopyTable(character.nextAction),
        lastActivity = CopyTable(character.lastActivity),
        reminders = reminders,
        reminderCount = #reminders,
        lastSession = CopyTable(character.lastSession),
        recentTasks = history,
        updatedAt = tonumber(character.lastActivityAt) or 0,
    }
end

function Workflow:GetCharacterSummaries()
    local store = EnsureStore()
    local result = {}
    for key, character in pairs(store.characters) do
        if type(character) == "table" then
            result[#result + 1] = self:GetCharacterWorkflowState(key)
        end
    end
    table.sort(result, function(a, b)
        local ac = a and a.characterKey == CurrentCharacterKey()
        local bc = b and b.characterKey == CurrentCharacterKey()
        if ac ~= bc then return ac end
        local at = (a and a.updatedAt) or 0
        local bt = (b and b.updatedAt) or 0
        return at > bt
    end)
    return result
end

function Workflow:OnCharacterContextReady()
    -- Explicit lifecycle entry point for character switches/login. All state is
    -- already keyed by character, so restoring context never overwrites another
    -- character's task, next action, reminders, or last session.
    return self:Initialize()
end

function Workflow:GetWelcomeBackState()
    local state = self:GetCharacterWorkflowState(CurrentCharacterKey())
    if not state then return nil end

    return {
        characterKey = state.characterKey,
        characterName = state.characterName,
        characterRealm = state.characterRealm,
        task = state.task,
        nextAction = state.nextAction,
        lastActivity = state.lastActivity,
        reminders = state.reminders,
        reminderCount = state.reminderCount,
        lastSession = state.lastSession,
        recentTasks = state.recentTasks,
        welcomeAt = Now(),
    }
end

function Workflow:GetStatus()
    local state = self:GetWelcomeBackState()
    if not state then return nil end

    local history = EnsureStore().history
    return {
        version = STORE_VERSION,
        characterKey = state.characterKey,
        characterName = state.characterName,
        characterRealm = state.characterRealm,
        currentTask = state.task,
        nextAction = state.nextAction,
        lastActivity = state.lastActivity,
        lastSession = state.lastSession,
        reminderCount = state.reminderCount,
        historyCount = #history,
        updatedAt = EnsureStore().current.updatedAt or 0,
    }
end

function Workflow:GetHistory(limit)
    local store = EnsureStore()
    local result = {}
    local count = tonumber(limit) or 20
    count = math.max(1, math.min(count, #store.history))

    for i = math.max(1, #store.history - count + 1), #store.history do
        result[#result + 1] = CopyTable(store.history[i])
    end
    return result
end

-- A character-specific read model used by the Hub and future alert system.
-- This never changes the active character; it only reads persisted context.
function Workflow:GetCharacterContext(characterKey)
    local state = self:GetCharacterWorkflowState(characterKey)
    if not state then return nil end
    return {
        characterKey = state.characterKey,
        name = state.characterName,
        realm = state.characterRealm,
        currentTask = state.task,
        nextAction = state.nextAction,
        lastActivity = state.lastActivity,
        lastSession = state.lastSession,
        reminderCount = state.reminderCount,
        reminders = state.reminders,
        recentTasks = state.recentTasks,
    }
end

function Workflow:GetCharacterContexts(characterKeys)
    local result = {}
    if type(characterKeys) ~= "table" then return result end
    for _, key in ipairs(characterKeys) do
        local context = self:GetCharacterContext(key)
        if context then result[#result + 1] = context end
    end
    return result
end
