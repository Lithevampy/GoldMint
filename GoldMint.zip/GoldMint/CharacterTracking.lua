local ADDON_NAME, GoldMint = ...

-- GoldMint character tracking facade.
-- Keeps character identity/capability metadata in the existing GoldMintDB.characters
-- records and exposes a clean read model for the Hub. Workflow data remains owned by
-- WorkflowState; this module only joins the two systems.

GoldMint.CharacterTracking = {}
local Characters = GoldMint.CharacterTracking

local STORE_VERSION = 2
local MAX_CHARACTERS = 100

local function Now()
    return time()
end

local function EnsureStore()
    GoldMintDB.characters = type(GoldMintDB.characters) == "table" and GoldMintDB.characters or {}
    return GoldMintDB.characters
end

local function SafeUnitClass()
    local _, class = UnitClass("player")
    return class
end

local function SafeUnitRace()
    local _, race = UnitRace("player")
    return race
end

local function SafeGuildInfo()
    if type(GetGuildInfo) ~= "function" then return nil, nil end
    local guildName = GetGuildInfo("player")
    if not guildName or guildName == "" then return nil, nil end
    local guildRealm = (GetNormalizedRealmName and GetNormalizedRealmName()) or GetRealmName() or "Unknown"
    return guildName, guildRealm
end

function Characters:Initialize()
    local store = EnsureStore()
    GoldMintDB.characterTrackingVersion = math.max(tonumber(GoldMintDB.characterTrackingVersion) or 0, STORE_VERSION)
    self:SyncCurrent()
    self.initialized = true
    return store
end

function Characters:SyncCurrent()
    local key = GoldMint.characterKey
    if not key then return nil end

    local store = EnsureStore()
    local character = store[key] or {}
    character.name = GoldMint.characterName or character.name or "Unknown"
    character.realm = GoldMint.characterRealm or character.realm or "Unknown"
    character.level = tonumber(UnitLevel("player")) or tonumber(character.level) or 0
    character.class = SafeUnitClass() or character.class
    character.race = SafeUnitRace() or character.race
    character.faction = UnitFactionGroup and UnitFactionGroup("player") or character.faction
    local guildName, guildRealm = SafeGuildInfo()
    character.guildName = guildName
    character.guildRealm = guildRealm or character.guildRealm
    character.lastSeen = Now()
    character.lastSeenAt = character.lastSeen
    character.lastActive = true

    -- A compact session marker makes it possible for the Hub to identify the
    -- character that is currently logged in without changing older records.
    character.currentSession = true

    store[key] = character
    return character
end

function Characters:MarkAllInactive()
    local store = EnsureStore()
    for _, character in pairs(store) do
        if type(character) == "table" then
            character.lastActive = false
            character.currentSession = false
        end
    end
end

function Characters:Get(characterKey)
    local store = EnsureStore()
    characterKey = characterKey or GoldMint.characterKey
    local character = characterKey and store[characterKey]
    if type(character) ~= "table" then return nil end
    return character
end

function Characters:GetAll()
    local store = EnsureStore()
    local result = {}

    for key, character in pairs(store) do
        if type(character) == "table" and (character.name or character.realm) then
            result[#result + 1] = {
                key = key,
                name = character.name or key,
                realm = character.realm or "Unknown",
                level = tonumber(character.level) or 0,
                class = character.class,
                race = character.race,
                faction = character.faction,
                guildName = character.guildName,
                guildRealm = character.guildRealm,
                gold = tonumber(character.gold) or 0,
                lastSeen = tonumber(character.lastSeen) or 0,
                lastActive = character.currentSession == true or character.lastActive == true,
            }
        end
    end

    table.sort(result, function(a, b)
        if a.lastActive ~= b.lastActive then return a.lastActive end
        if a.lastSeen ~= b.lastSeen then return a.lastSeen > b.lastSeen end
        return string.lower(a.name) < string.lower(b.name)
    end)

    return result
end

local function ApplyWorkflow(result, key)
    if not GoldMint.WorkflowState then return end
    local workflow = GoldMint.WorkflowState:GetCharacterWorkflowState(key)
    if not workflow then return end
    result.task = workflow.task
    result.nextAction = workflow.nextAction
    result.lastActivity = workflow.lastActivity
    result.reminders = workflow.reminders
    result.reminderCount = workflow.reminderCount
    result.lastSession = workflow.lastSession
    result.recentTasks = workflow.recentTasks
end

function Characters:GetOverview(characterKey)
    local character = self:Get(characterKey)
    if not character then return nil end

    local result = {
        key = characterKey or GoldMint.characterKey,
        name = character.name or characterKey,
        realm = character.realm or "Unknown",
        level = tonumber(character.level) or 0,
        class = character.class,
        race = character.race,
        faction = character.faction,
        guildName = character.guildName,
        guildRealm = character.guildRealm,
        gold = tonumber(character.gold) or 0,
        lastSeen = tonumber(character.lastSeen) or 0,
        lastActive = character.currentSession == true or character.lastActive == true,
    }

    ApplyWorkflow(result, result.key)
    return result
end

function Characters:GetCharacterWorkflowOverview(characterKey)
    local overview = self:GetOverview(characterKey)
    if not overview then return nil end
    return overview
end

function Characters:GetHubSnapshot()
    self:SyncCurrent()

    local list = self:GetAll()
    local current = self:GetOverview(GoldMint.characterKey)
    local totalGold = 0
    if GoldMint.Ledger and GoldMint.Ledger.GetAccountWallet then
        totalGold = tonumber(GoldMint.Ledger:GetAccountWallet().totalGold) or 0
    else
        for _, character in ipairs(list) do
            totalGold = totalGold + (tonumber(character.gold) or 0)
        end
    end

    return {
        current = current,
        characters = list,
        characterCount = #list,
        activeCount = (function()
            local count = 0
            for _, character in ipairs(list) do
                if character.lastActive then count = count + 1 end
            end
            return count
        end)(),
        totalGold = totalGold,
        generatedAt = Now(),
    }
end

function Characters:PruneOldRecords()
    local store = EnsureStore()
    local entries = self:GetAll()
    if #entries <= MAX_CHARACTERS then return end

    table.sort(entries, function(a, b)
        local aSeen = tonumber(a.lastSeen) or 0
        local bSeen = tonumber(b.lastSeen) or 0
        if aSeen == bSeen then
            return tostring(a.key or "") < tostring(b.key or "")
        end
        return aSeen < bSeen
    end)
    for i = 1, #entries - MAX_CHARACTERS do
        local entry = entries[i]
        if entry.key ~= GoldMint.characterKey then
            store[entry.key] = nil
        end
    end
end
