local ADDON_NAME, GoldMint = ...

GoldMint.Market = {}
local Market = GoldMint.Market

local function Now()
    return time()
end

-- Convert a single scalar to a number. Keeping this as a one-argument helper
-- prevents Lua multi-return values (such as ITEM_DATA_LOAD_RESULT's
-- itemID, success payload) from accidentally becoming tonumber(value, success).
local function ToNumber(value)
    if type(value) == "number" then return value end
    if type(value) == "string" then return tonumber(value) end
    return nil
end

local MAX_PRICE_HISTORY = 60
local MAX_TOKEN_HISTORY = 144 -- 24 hours at a 10-minute observation cadence
local materialIndexCache = nil
local materialInfoCache = {}
local craftedOutputIndexCache = nil
local recipeInputIndexCache = nil
local recipeOutputIndexCache = nil
local smartValuationCache = {}
local SMART_VALUATION_TTL = 5
local TSM_CACHE_TTL = 60
local tsmPriceCache = {}
local tsmDatabaseCache = {}
local BuildMaterialIndex
local IsKnownMaterial
local BuildRecipeIndexes

local function NormalizeTokenPrice(price)
    price = tonumber(price)
    if not price or price <= 0 then return nil end
    -- C_WowTokenPublic reports WoW money in copper. GoldMint displays gold.
    return math.floor(price / 10000)
end

local function EnsureStore()
    GoldMintDB.market = type(GoldMintDB.market) == "table" and GoldMintDB.market or {}
    GoldMintDB.market.version = tonumber(GoldMintDB.market.version) or 2
    GoldMintDB.market.items = type(GoldMintDB.market.items) == "table" and GoldMintDB.market.items or {}
    GoldMintDB.market.matrix = type(GoldMintDB.market.matrix) == "table" and GoldMintDB.market.matrix or {}
    GoldMintDB.market.ownedAuctionsValue = tonumber(GoldMintDB.market.ownedAuctionsValue) or 0
    GoldMintDB.market.ownedAuctionsCount = tonumber(GoldMintDB.market.ownedAuctionsCount) or 0
    GoldMintDB.market.ownedAuctionsUpdatedAt = tonumber(GoldMintDB.market.ownedAuctionsUpdatedAt) or 0
    GoldMintDB.market.lastAuctionScanAt = tonumber(GoldMintDB.market.lastAuctionScanAt) or 0
    GoldMintDB.market.ownedAuctionsByCharacter = type(GoldMintDB.market.ownedAuctionsByCharacter) == "table" and GoldMintDB.market.ownedAuctionsByCharacter or {}
    GoldMintDB.market.activeAuctionsByCharacter = type(GoldMintDB.market.activeAuctionsByCharacter) == "table" and GoldMintDB.market.activeAuctionsByCharacter or {}
    GoldMintDB.market.salesByItem = type(GoldMintDB.market.salesByItem) == "table" and GoldMintDB.market.salesByItem or {}
    GoldMintDB.market.salesSeen = type(GoldMintDB.market.salesSeen) == "table" and GoldMintDB.market.salesSeen or {}
    GoldMintDB.market.tokenHistory = type(GoldMintDB.market.tokenHistory) == "table" and GoldMintDB.market.tokenHistory or {}
    GoldMintDB.market.fullScan = type(GoldMintDB.market.fullScan) == "table" and GoldMintDB.market.fullScan or {}
    GoldMintDB.market.fullScan.lastStartedAt = tonumber(GoldMintDB.market.fullScan.lastStartedAt) or 0
    GoldMintDB.market.fullScan.lastCompletedAt = tonumber(GoldMintDB.market.fullScan.lastCompletedAt) or 0
    GoldMintDB.market.fullScan.lastTotal = tonumber(GoldMintDB.market.fullScan.lastTotal) or 0
    GoldMintDB.market.fullScan.lastCaptured = tonumber(GoldMintDB.market.fullScan.lastCaptured) or 0
    GoldMintDB.market.fullScan.lastDuration = tonumber(GoldMintDB.market.fullScan.lastDuration) or 0
    GoldMintDB.market.fullScan.lastQueue = type(GoldMintDB.market.fullScan.lastQueue) == "table" and GoldMintDB.market.fullScan.lastQueue or {}
    GoldMintDB.market.characterPools = type(GoldMintDB.market.characterPools) == "table" and GoldMintDB.market.characterPools or {}
    GoldMintDB.market.watchlist = type(GoldMintDB.market.watchlist) == "table" and GoldMintDB.market.watchlist or {}
    GoldMintDB.market.watchlist.version = tonumber(GoldMintDB.market.watchlist.version) or 1
    GoldMintDB.market.watchlist.items = type(GoldMintDB.market.watchlist.items) == "table" and GoldMintDB.market.watchlist.items or {}
    GoldMintDB.market.watchlist.targets = type(GoldMintDB.market.watchlist.targets) == "table" and GoldMintDB.market.watchlist.targets or {}
    -- Keep the tracked-item count O(1) during login/Economy refreshes. Older
    -- databases may not have it yet; rebuild it lazily only when explicitly
    -- requested by the Market page/command path.
    GoldMintDB.market.trackedCount = tonumber(GoldMintDB.market.trackedCount) or 0
    -- Migrate older token observations that were stored as copper.
    local tokenHistory = GoldMintDB.market.tokenHistory
    for _, point in ipairs(tokenHistory) do
        local value = tonumber(point.price)
        if value and value >= 10000000 then
            point.price = math.floor(value / 10000)
        end
    end
    local currentToken = tonumber(GoldMintDB.market.tokenCurrentPrice)
    if currentToken and currentToken >= 10000000 then
        GoldMintDB.market.tokenCurrentPrice = math.floor(currentToken / 10000)
    end
    return GoldMintDB.market
end

local function GetItemID(itemInfo)
    if not itemInfo then return nil end
    if type(itemInfo) == "number" then return itemInfo end

    if C_Item and C_Item.GetItemIDForItemInfo then
        local ok, id = pcall(C_Item.GetItemIDForItemInfo, itemInfo)
        if ok and tonumber(id) then return tonumber(id) end
    end
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, id = pcall(C_Item.GetItemInfoInstant, itemInfo)
        if ok and tonumber(id) then return tonumber(id) end
    end
    if type(itemInfo) == "string" then
        return tonumber(itemInfo:match("item:(%d+)"))
    end
end

local function GetItemNameAndSellPrice(itemID)
    if not itemID or not C_Item or not C_Item.GetItemInfo then return nil, nil end
    local ok, name, _, _, _, _, _, _, _, _, sellPrice = pcall(C_Item.GetItemInfo, itemID)
    if not ok then return nil, nil end
    return name, tonumber(sellPrice) or 0
end

local function EnsureItem(itemID)
    itemID = tonumber(itemID)
    if not itemID then return nil end

    local store = EnsureStore()
    local record = store.items[itemID]
    if not record then
        record = {
            itemID = itemID,
            firstSeen = Now(),
            lastSeen = Now(),
            name = nil,
            vendorSellPrice = 0,
            ah = {},
            tsm = {},
        }
        store.items[itemID] = record
        store.trackedCount = (tonumber(store.trackedCount) or 0) + 1
    end

    record.itemID = itemID
    record.ah = type(record.ah) == "table" and record.ah or {}
    record.tsm = type(record.tsm) == "table" and record.tsm or {}
    return record
end

function Market:RecordItem(itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end
    local record = EnsureItem(itemID)
    if not record then return false end

    local name, sellPrice = GetItemNameAndSellPrice(itemID)
    if name then record.name = name end
    if sellPrice and sellPrice > 0 then record.vendorSellPrice = sellPrice end
    record.lastSeen = Now()
    return true
end

function Market:RecordAuctionPrice(itemID, unitPrice, quantity, source)
    itemID = tonumber(itemID)
    unitPrice = tonumber(unitPrice)
    quantity = tonumber(quantity) or 1
    if not itemID or not unitPrice or unitPrice <= 0 then return false end

    local record = EnsureItem(itemID)
    if not record then return false end

    local ah = record.ah
    -- This field represents the lowest price from the MOST RECENT scan.
    -- Historical observations remain in ah.history; never let an old low
    -- price permanently mask a newer undercut.
    ah.lowestUnitPrice = unitPrice
    ah.lastUnitPrice = unitPrice
    ah.lastQuantity = quantity
    ah.observedAt = Now()
    ah.observationCount = (tonumber(ah.observationCount) or 0) + 1
    ah.source = source or ah.source or "auction-house"
    ah.history = type(ah.history) == "table" and ah.history or {}
    ah.history[#ah.history + 1] = {
        time = Now(),
        unitPrice = unitPrice,
        quantity = quantity,
        source = source or "auction-house",
    }
    while #ah.history > MAX_PRICE_HISTORY do
        table.remove(ah.history, 1)
    end
    record.lastSeen = Now()
    return true
end

function Market:RecordTSMPrice(itemID, value, source)
    itemID = tonumber(itemID)
    value = tonumber(value)
    if not itemID or not value or value <= 0 then return false end

    local record = EnsureItem(itemID)
    if not record then return false end

    local tsm = record.tsm
    tsm.marketValue = value
    tsm.observedAt = Now()
    tsm.source = source or "tsm"
    tsm.observationCount = (tonumber(tsm.observationCount) or 0) + 1
    tsm.history = type(tsm.history) == "table" and tsm.history or {}
    tsm.history[#tsm.history + 1] = {
        time = Now(),
        marketValue = value,
        source = source or "tsm",
    }
    while #tsm.history > MAX_PRICE_HISTORY do
        table.remove(tsm.history, 1)
    end
    record.lastSeen = Now()
    return true
end

local function GetTSMItemString(itemID)
    return "i:" .. tostring(itemID)
end

function Market:CaptureTSM(itemID)
    itemID = tonumber(itemID)
    if not itemID or type(TSM_API) ~= "table" or type(TSM_API.GetCustomPriceValue) ~= "function" then
        return false
    end

    local now = Now()
    local cached = tsmPriceCache[itemID]
    if cached and (now - cached.observedAt) < TSM_CACHE_TTL then
        local record = EnsureItem(itemID)
        if record then
            record.tsm = type(record.tsm) == "table" and record.tsm or {}
            record.tsm.marketValue = cached.value
            record.tsm.observedAt = cached.observedAt
            record.tsm.source = "tsm-cache"
            record.lastSeen = now
            return true
        end
        return false
    end

    -- TSM's in-game Addon API exposes AuctionDB price sources. The Desktop
    -- Application supplies/updates the data used by the TSM addon; GoldMint
    -- does not make network requests or attempt to talk to the desktop process.
    local ok, value = pcall(TSM_API.GetCustomPriceValue, "DBMarket", GetTSMItemString(itemID))
    value = ok and tonumber(value) or nil
    if value and value > 0 then
        tsmPriceCache[itemID] = { value = value, observedAt = now }
        return self:RecordTSMPrice(itemID, value, "tsm-dbmarket")
    end

    return false
end

function Market:CaptureTSMDatabase(itemID, forceRefresh)
    itemID = tonumber(itemID)
    if not itemID or type(TSM_API) ~= "table" or type(TSM_API.GetCustomPriceValue) ~= "function" then
        return false
    end

    local record = EnsureItem(itemID)
    if not record then return false end
    record.region = type(record.region) == "table" and record.region or {}

    local sources = {
        marketValue = "DBMarket",
        historical = "DBHistorical",
        regionMarketAvg = "DBRegionMarketAvg",
        regionHistorical = "DBRegionHistorical",
        regionSaleAvg = "DBRegionSaleAvg",
        regionSaleRate = "DBRegionSaleRate",
        regionSoldPerDay = "DBRegionSoldPerDay",
        minBuyout = "DBMinBuyout",
        destroyValue = "Destroy",
    }

    local now = Now()
    local cached = tsmDatabaseCache[itemID]
    if not forceRefresh and cached and (now - cached.observedAt) < TSM_CACHE_TTL then
        for field, value in pairs(cached.values) do
            record.region[field] = value
        end
        record.region.observedAt = cached.observedAt
        record.lastSeen = now
        return cached.captured
    end

    local captured = false
    local values = {}
    local itemString = GetTSMItemString(itemID)
    for field, source in pairs(sources) do
        local ok, value = pcall(TSM_API.GetCustomPriceValue, source, itemString)
        value = ok and tonumber(value) or nil
        if value and value > 0 then
            record.region[field] = value
            values[field] = value
            captured = true
        end
    end

    tsmDatabaseCache[itemID] = { values = values, captured = captured, observedAt = now }
    record.region.observedAt = now
    record.lastSeen = now
    return captured
end


local function AddScanCandidate(candidateSet, itemID)
    itemID = tonumber(itemID)
    if itemID and itemID > 0 then
        candidateSet[itemID] = true
    end
end

function Market:GetFullMarketScanQueue(mode)
    mode = mode or "materials"
    -- Record current bags so newly observed items are eligible even if the
    -- deferred BAG_UPDATE scan has not run yet. RecordItem is intentionally
    -- lightweight and does not invoke TSM.
    self:ScanBags()

    local candidates = {}
    local store = EnsureStore()
    local materialIndex = BuildMaterialIndex()
    local function QueueIsMaterial(itemID)
        itemID = tonumber(itemID)
        if not itemID then return false end
        if materialIndex[itemID] then return true end
        return IsKnownMaterial(itemID)
    end

    -- Start with everything GoldMint has already observed. This includes
    -- items discovered through bags, tooltips, AH searches, mail/inventory
    -- workflows, and prior Market scans. Additional saved mail/project
    -- references are merged below so coverage extends beyond current bags.
    for itemID in pairs(store.items or {}) do
        local numericID = tonumber(itemID)
        if numericID and (mode == "all" or self:IsMaterial(numericID)) then
            AddScanCandidate(candidates, numericID)
        end
    end

    -- Include items currently known through saved mailbox scans as well.
    -- Mail can contain auction proceeds, crafting materials, reagents, and
    -- finished goods that are not in the player's bags when the scan starts.
    local mailStore = GoldMintDB and GoldMintDB.mailTracking
    for _, character in pairs((mailStore and mailStore.characters) or {}) do
        if type(character) == "table" then
            for _, message in pairs(character.messages or {}) do
                if type(message) == "table" then
                    for _, attachment in ipairs(message.attachments or {}) do
                        local attachmentID = tonumber(attachment.itemID)
                        if attachmentID and (mode == "all" or self:IsMaterial(attachmentID)) then
                            AddScanCandidate(candidates, attachmentID)
                        end
                    end
                end
            end
        end
    end

    -- Include project/goal material references when those records expose item
    -- IDs. This broadens coverage without inventing item IDs from free-form text.
    local projects = GoldMintDB and GoldMintDB.projects
    local function AddProjectItem(value)
        if type(value) == "number" or type(value) == "string" then
            local id = tonumber(value)
            if id and (mode == "all" or QueueIsMaterial(id)) then
                AddScanCandidate(candidates, id)
            end
        elseif type(value) == "table" then
            local id = tonumber(value.itemID or value.itemId or value.itemIDValue)
            if id and (mode == "all" or QueueIsMaterial(id)) then
                AddScanCandidate(candidates, id)
            end
        end
    end
    for _, project in pairs((projects and projects.goals) or {}) do
        if type(project) == "table" then
            AddProjectItem(project.itemID or project.itemId)
            for _, material in pairs(project.materials or project.requirements or {}) do
                AddProjectItem(material)
            end
        end
    end

    -- Include recipe outputs and every known reagent option so the Market
    -- database can refresh materials even when the player does not currently
    -- have one in their bags.
    for _, recipe in pairs((GoldMintDB and GoldMintDB.recipes) or {}) do
        if type(recipe) == "table" then
            if mode == "all" or self:IsMaterial(recipe.outputItemID) then
                AddScanCandidate(candidates, recipe.outputItemID)
            end
            for _, reagent in ipairs(recipe.reagents or {}) do
                for _, option in ipairs(reagent.options or {}) do
                    AddScanCandidate(candidates, option.itemID)
                end
            end
        end
    end

    local queue = {}
    for itemID in pairs(candidates) do
        queue[#queue + 1] = itemID
    end
    table.sort(queue)
    return queue
end

function Market:IsFullMarketScanRunning()
    return self._fullScan and self._fullScan.running == true
end

function Market:GetFullMarketScanStatus()
    local scan = self._fullScan
    local saved = EnsureStore().fullScan or {}
    if scan and scan.running then
        return {
            running = true,
            completed = scan.index - 1,
            total = scan.total,
            captured = scan.captured,
            startedAt = scan.startedAt,
        }
    end
    return {
        running = false,
        completed = tonumber(saved.lastTotal) or 0,
        total = tonumber(saved.lastTotal) or 0,
        captured = tonumber(saved.lastCaptured) or 0,
        startedAt = tonumber(saved.lastStartedAt) or 0,
        completedAt = tonumber(saved.lastCompletedAt) or 0,
        duration = tonumber(saved.lastDuration) or 0,
    }
end

function Market:StartFullMarketScan(mode, onProgress, onComplete, forceRefresh)
    if self:IsFullMarketScanRunning() then
        return false, "already-running"
    end
    if type(TSM_API) ~= "table" or type(TSM_API.GetCustomPriceValue) ~= "function" then
        return false, "tsm-unavailable"
    end

    local queue = self:GetFullMarketScanQueue(mode or "materials")
    local startedAt = Now()
    local scan = {
        running = true,
        queue = queue,
        index = 1,
        total = #queue,
        captured = 0,
        startedAt = startedAt,
        onProgress = onProgress,
        onComplete = onComplete,
    }
    self._fullScan = scan

    local store = EnsureStore()
    local saved = store.fullScan
    saved.lastStartedAt = startedAt
    saved.lastCompletedAt = 0
    saved.lastTotal = #queue
    saved.lastCaptured = 0
    saved.lastDuration = 0
    local characterKey = GoldMint.characterKey or "Unknown"
    store.characterPools[characterKey] = { mode = mode or "materials", itemIDs = {}, updatedAt = startedAt }
    for i, itemID in ipairs(queue) do
        store.characterPools[characterKey].itemIDs[i] = tonumber(itemID)
    end
    saved.lastQueue = {}
    for i, itemID in ipairs(queue) do saved.lastQueue[i] = tonumber(itemID) end

    local function Finish(cancelled)
        if not scan.running then return end
        scan.running = false
        if scan.ticker and scan.ticker.Cancel then scan.ticker:Cancel() end
        local finishedAt = Now()
        local duration = math.max(0, finishedAt - startedAt)
        saved.lastTotal = scan.total
        saved.lastCaptured = scan.captured
        saved.lastDuration = duration
        saved.lastCompletedAt = cancelled and 0 or finishedAt
        self:InvalidateTrackedItemsCache()
        if onComplete then
            pcall(onComplete, scan.captured, scan.total, duration, cancelled == true)
        end
        if self._fullScan == scan then self._fullScan = nil end
    end
    scan.finish = Finish

    if scan.total == 0 then
        Finish(false)
        return true, "empty"
    end

    local function Step()
        if not scan.running then return end

        -- This is an explicit, user-started market scan. The expensive work that
        -- was causing login/Market-page lag is no longer performed automatically,
        -- so do not artificially throttle the manual scan. Process the complete
        -- queue immediately and only report progress periodically to avoid
        -- rebuilding the Market UI for every single item.
        local nextProgress = scan.index + 24
        while scan.index <= scan.total do
            local itemID = scan.queue[scan.index]
            scan.index = scan.index + 1
            if self:CaptureTSMDatabase(itemID, forceRefresh == true) then
                scan.captured = scan.captured + 1
            end

            if scan.index >= nextProgress then
                if onProgress then
                    pcall(onProgress, scan.index - 1, scan.total, scan.captured)
                end
                nextProgress = scan.index + 25
            end
        end

        if onProgress then
            pcall(onProgress, scan.total, scan.total, scan.captured)
        end
        Finish(false)
    end

    -- No background ticker/throttle: this path only runs after the user clicks
    -- SCAN MARKET. Market opening/login remains lightweight.
    Step()
    return true, "started"
end

function Market:CancelFullMarketScan()
    local scan = self._fullScan
    if scan and scan.running and scan.finish then
        scan.finish(true)
        return true
    end
    return false
end


function Market:RecordTokenPrice(price)
    price = tonumber(price)
    if not price or price <= 0 then return false end
    if price >= 10000000 then
        price = NormalizeTokenPrice(price)
    end
    if not price or price <= 0 then return false end

    local store = EnsureStore()
    local history = store.tokenHistory
    local now = Now()
    local last = history[#history]
    -- Keep the chart readable and avoid duplicate observations from the
    -- TOKEN_MARKET_PRICE_UPDATED event and our periodic refresh.
    if last and now - (tonumber(last.time) or 0) < 300 then
        last.price = price
        return true
    end

    history[#history + 1] = { time = now, price = price }
    while #history > MAX_TOKEN_HISTORY do
        table.remove(history, 1)
    end
    store.tokenCurrentPrice = price
    store.tokenObservedAt = now
    return true
end

function Market:RefreshTokenPrice()
    if not C_WowTokenPublic or type(C_WowTokenPublic.GetCurrentMarketPrice) ~= "function" then
        return nil
    end

    local ok, rawPrice = pcall(C_WowTokenPublic.GetCurrentMarketPrice)
    local price = ok and NormalizeTokenPrice(rawPrice) or nil
    -- Ignore the API/event placeholder such as 1. The public API reports
    -- copper, so normalize it to gold before storing/displaying it.
    if price and price >= 1000 then
        self:RecordTokenPrice(price)
        return price
    end

    if type(C_WowTokenPublic.UpdateMarketPrice) == "function" then
        pcall(C_WowTokenPublic.UpdateMarketPrice)
    end
    return tonumber(EnsureStore().tokenCurrentPrice) or nil
end

function Market:GetTokenHistory(hours)
    local store = EnsureStore()
    local history = store.tokenHistory or {}
    local cutoff = Now() - (tonumber(hours) or 24) * 3600
    local result = {}
    for _, point in ipairs(history) do
        if tonumber(point.time) and tonumber(point.time) >= cutoff and tonumber(point.price) and tonumber(point.price) > 0 then
            result[#result + 1] = { time = tonumber(point.time), price = tonumber(point.price) }
        end
    end
    return result
end

function Market:GetCurrentTokenPrice()
    local store = EnsureStore()
    local current = tonumber(store.tokenCurrentPrice)
    if current and current > 0 then return current end
    return self:RefreshTokenPrice()
end

function Market:GetMultiverseData(itemID)
    local record = self:GetRecord(itemID)
    if not record then return nil end
    local region = record.region or {}
    local ah = record.ah or {}
    local tsm = record.tsm or {}
    return {
        itemID = tonumber(itemID),
        name = record.name,
        marketValue = tonumber(region.marketValue) or tonumber(tsm.marketValue) or tonumber(ah.lowestUnitPrice),
        historical = tonumber(region.historical),
        regionMarketAvg = tonumber(region.regionMarketAvg),
        regionHistorical = tonumber(region.regionHistorical),
        regionSaleAvg = tonumber(region.regionSaleAvg),
        regionSaleRate = tonumber(region.regionSaleRate),
        regionSoldPerDay = tonumber(region.regionSoldPerDay),
        minBuyout = tonumber(region.minBuyout) or tonumber(ah.lowestUnitPrice),
        destroyValue = tonumber(region.destroyValue),
        observedAt = tonumber(region.observedAt) or tonumber(record.lastSeen) or 0,
    }
end

function Market:GetHistory(itemID, days)
    local record = self:GetRecord(itemID)
    if not record then return {} end
    days = tonumber(days) or 30
    local cutoff = Now() - days * 86400
    local points = {}
    local function addHistory(history, field, source)
        for _, point in ipairs(history or {}) do
            local stamp = tonumber(point.time) or 0
            local value = tonumber(point[field]) or 0
            if stamp >= cutoff and value > 0 then
                points[#points + 1] = { time = stamp, value = value, source = source }
            end
        end
    end
    addHistory(record.ah and record.ah.history, "unitPrice", "AH")
    addHistory(record.tsm and record.tsm.history, "marketValue", "Realm")
    table.sort(points, function(a, b) return a.time < b.time end)
    return points
end

local function RecipeUsesItem(recipe, itemID)
    local qty = 0
    for _, reagent in ipairs(recipe.reagents or {}) do
        local matches = false
        for _, option in ipairs(reagent.options or {}) do
            if tonumber(option.itemID) == tonumber(itemID) then
                matches = true
                break
            end
        end
        if matches then
            qty = qty + (tonumber(reagent.quantity) or 0)
        end
    end
    return qty
end

function Market:GetSmartValuation(itemID)
    itemID = tonumber(itemID)
    if not itemID then return nil end

    local now = Now()
    local cached = smartValuationCache[itemID]
    if cached and (now - (cached.time or 0)) < SMART_VALUATION_TTL then
        return cached.value
    end

    local rawValue = self:GetUnitValue(itemID)
    local raw = tonumber(rawValue) or 0
    local result = {
        itemID = itemID,
        raw = raw,
        processed = nil,
        shatter = nil,
        best = "RAW",
        bestValue = raw,
        recipeName = nil,
        rawProfit = 0,
        processedProfit = 0,
        shatterProfit = 0,
    }

    -- Multi-step valuation: recursively evaluate the market opportunity cost
    -- of each reagent.  This lets GoldMint recognize chains such as:
    -- raw ore -> bars -> component -> finished item, rather than stopping at
    -- the first recipe.  Raw market value remains the baseline and cycles are
    -- blocked so recipe graphs cannot recurse forever.
    local recipes = GoldMintDB and GoldMintDB.recipes or {}
    local inputIndex, outputIndex = BuildRecipeIndexes()
    local memo = {}
    local visiting = {}
    local MAX_DEPTH = 6

    local function recipeUses(recipe, targetID)
        local qty = 0
        for _, reagent in ipairs(recipe.reagents or {}) do
            for _, option in ipairs(reagent.options or {}) do
                if tonumber(option.itemID) == targetID then
                    qty = qty + (tonumber(reagent.quantity) or 0)
                    break
                end
            end
        end
        return qty
    end

    local function itemOpportunityValue(targetID, depth)
        targetID = tonumber(targetID)
        depth = tonumber(depth) or 0
        if not targetID then return 0 end

        local directValue = self:GetUnitValue(targetID)
        local direct = tonumber(directValue) or 0
        if depth >= MAX_DEPTH or visiting[targetID] then
            return direct
        end
        if memo[targetID] ~= nil then
            return memo[targetID]
        end

        visiting[targetID] = true
        local bestValue = direct

        for _, entry in ipairs(outputIndex[targetID] or {}) do
            local recipeID, recipe = entry.id, entry.recipe
            if type(recipe) == "table" then
                local outputQty = math.max(tonumber(recipe.outputQuantity) or 1, 1)
                local valid = true
                local inputCost = 0

                for _, reagent in ipairs(recipe.reagents or {}) do
                    local qty = tonumber(reagent.quantity) or 0
                    if qty > 0 then
                        local cheapest = nil
                        for _, option in ipairs(reagent.options or {}) do
                            local optionID = tonumber(option.itemID)
                            if optionID then
                                local v = itemOpportunityValue(optionID, depth + 1)
                                if v > 0 and (not cheapest or v < cheapest) then
                                    cheapest = v
                                end
                            end
                        end
                        if not cheapest then
                            valid = false
                            break
                        end
                        inputCost = inputCost + cheapest * qty
                    end
                end

                if valid and inputCost > 0 then
                    local net = (direct > 0 and direct or ((self:GetUnitValue(targetID) or 0)))
                    local recipeOutputValue = self:GetUnitValue(recipe.outputItemID)
                    local recipeValuePerOutput = ((tonumber(recipeOutputValue) or 0) * outputQty - inputCost) / outputQty
                    if recipeValuePerOutput > bestValue then
                        bestValue = recipeValuePerOutput
                    end
                end
            end
        end

        visiting[targetID] = nil
        memo[targetID] = bestValue
        return bestValue
    end

    -- Evaluate recipes which consume the selected item.  Each other reagent
    -- is valued at its best available opportunity cost, including its own
    -- downstream crafting chain.  The selected material itself is excluded
    -- from input cost and treated as the opportunity cost of selling raw.
    for _, entry in ipairs(inputIndex[itemID] or {}) do
        local recipeID, recipe = entry.id, entry.recipe
        if type(recipe) == "table" and tonumber(recipe.outputItemID) and tonumber(recipe.outputItemID) ~= itemID then
            local targetQty = recipeUses(recipe, itemID)
            if targetQty > 0 then
                local outputID = tonumber(recipe.outputItemID)
                local outputQty = math.max(tonumber(recipe.outputQuantity) or 1, 1)
                local outputValueRaw = self:GetUnitValue(outputID)
                    local outputValue = tonumber(outputValueRaw) or 0
                local otherCost = 0
                local valid = outputValue > 0

                for _, reagent in ipairs(recipe.reagents or {}) do
                    local qty = tonumber(reagent.quantity) or 0
                    if qty > 0 then
                        local isTarget = false
                        for _, option in ipairs(reagent.options or {}) do
                            if tonumber(option.itemID) == itemID then
                                isTarget = true
                                break
                            end
                        end

                        if not isTarget then
                            local cheapest = nil
                            for _, option in ipairs(reagent.options or {}) do
                                local optionID = tonumber(option.itemID)
                                if optionID then
                                    local v = itemOpportunityValue(optionID, 0)
                                    if v > 0 and (not cheapest or v < cheapest) then
                                        cheapest = v
                                    end
                                end
                            end
                            if not cheapest then
                                valid = false
                                break
                            end
                            otherCost = otherCost + cheapest * qty
                        end
                    end
                end

                if valid then
                    local totalOutputValue = outputValue * outputQty
                    local valuePerTarget = (totalOutputValue - otherCost) / targetQty
                    local profitPerTarget = valuePerTarget - raw

                    if valuePerTarget > 0 and (not result.processed or profitPerTarget > result.processed.profit) then
                        result.processed = {
                            value = valuePerTarget,
                            profit = profitPerTarget,
                            margin = raw > 0 and (profitPerTarget / raw) or 0,
                            recipeID = tonumber(recipeID),
                            recipeName = recipe.name,
                            outputItemID = outputID,
                            outputQuantity = outputQty,
                            otherCost = otherCost,
                            multiStep = true,
                        }
                        result.processedProfit = profitPerTarget
                    end
                end
            end
        end
    end

    local record = self:GetRecord(itemID)
    local destroyValue = record and record.region and tonumber(record.region.destroyValue) or nil
    if destroyValue and destroyValue > 0 then
        result.shatter = {
            value = destroyValue,
            profit = destroyValue - raw,
            margin = raw > 0 and ((destroyValue - raw) / raw) or 0,
            source = "TSM Destroy",
        }
        result.shatterProfit = result.shatter.profit
    end

    if result.processed and result.processed.value > result.bestValue and result.processed.profit > 0 then
        result.best = "PROCESSED"
        result.bestValue = result.processed.value
    end
    if result.shatter and result.shatter.value > result.bestValue and result.shatter.profit > 0 then
        result.best = "SHATTER"
        result.bestValue = result.shatter.value
    end

    result.rawProfit = 0
    result.routeDelta = result.bestValue - raw
    result.routeMargin = raw > 0 and (result.routeDelta / raw) or 0
    smartValuationCache[itemID] = { time = now, value = result }
    return result
end

-- Returns a practical gathering route for common Midnight gathered materials.
-- Route metadata is intentionally descriptive: GoldMint does not pretend that
-- Blizzard exposes a per-item "best route" API.  The route is a suggested
-- farming area/start point and can be updated independently as route data improves.
local GATHERING_ROUTES = {
    ["void-tempered scales"] = {
        profession = "Skinning", zone = "Eversong Woods", mapID = 2395,
        x = 51.0, y = 77.0, start = "South of Tranquillien",
        targets = "Agitated Wyrms • Territorial Dragonhawks",
        notes = "Farm the scaled beasts south of Tranquillien. Agitated Wyrms and Territorial Dragonhawks respawn steadily here; skin them continuously through the area.",
    },
    ["tranquility bloom"] = {
        profession = "Herbalism", zone = "Eversong Woods", mapID = 2395,
        x = 42.0, y = 79.0, start = "Eversong loop",
        notes = "Run a broad loop around the zone; follow the main waterways and pick every herb node you pass.",
    },
    ["argentleaf"] = {
        profession = "Herbalism", zone = "Harandar", mapID = 2413,
        x = 32.87, y = 76.32, start = "The Blinding Bloom",
        targets = "Argentleaf herb nodes",
        notes = "Loop through The Blinding Bloom, including the middle platforms. Supplement the loop around Fungara Village when nodes are sparse.",
    },
    ["azeroot"] = {
        profession = "Herbalism", zone = "Harandar", mapID = 2413,
        x = 32.87, y = 76.32, start = "The Blinding Bloom",
        targets = "Azeroot herb nodes",
        notes = "Farm the roots and foliage through The Blinding Bloom; the area also produces Tranquility Bloom and Argentleaf.",
    },
    ["mana lily"] = {
        profession = "Herbalism", zone = "Voidstorm", mapID = 2405,
        x = 65.0, y = 88.0, start = "Voidstorm lily route",
        notes = "Work the water and the tall seaweed-like growths. Mana Lilies tend to spawn beneath those plants and around gorges.",
    },
    ["sanguithorn"] = {
        profession = "Herbalism", zone = "Zul'Aman", mapID = 2437,
        x = 33.09, y = 32.71, start = "Temple of Halazzi",
        notes = "Follow rugged terrain and rock faces through a looping Zul'Aman route; Sanguithorn favors rocky terrain.",
    },
    ["refulgent copper ore"] = {
        profession = "Mining", zone = "Eversong Woods", mapID = 2395,
        x = 42.0, y = 79.0, start = "Eversong mining loop",
        notes = "Use the broad Eversong loop and prioritize mountain edges, cliffs, and visible deposits while keeping momentum.",
    },
    ["umbral tin ore"] = {
        profession = "Mining", zone = "Zul'Aman", mapID = 2437,
        x = 33.09, y = 32.71, start = "Zul'Aman ridge loop",
        notes = "Run the outer ridges and mountain lines, dropping to visible deposit clusters before returning to the ridge.",
    },
    ["brilliant silver ore"] = {
        profession = "Mining", zone = "Harandar", mapID = 2413,
        x = 43.83, y = 64.29, start = "Fungara / Harandar route",
        notes = "Use the Harandar route with extra attention to ground deposits and seams; expect vertical movement around the terrain.",
    },
    ["dazzling thorium"] = {
        profession = "Mining", zone = "Voidstorm", mapID = 2405,
        x = 54.0, y = 65.0, start = "Voidstorm outer loop",
        notes = "Work the outer edge and central lanes of Voidstorm. Keep moving through dense deposit areas and return to the loop.",
    },
    ["majestic hide"] = {
        profession = "Skinning", zone = "Voidstorm", mapID = 2405,
        x = 54.60, y = 65.80, start = "Umbrafang renowned-beast area",
        targets = "Umbrafang • Netherscythe • Gloomclaw",
        notes = "Use the renowned-beast lure route. Majestic Hide comes from the Midnight renowned beasts; each zone has its own lure location and the Grand Beast route adds Netherscythe.",
    },
    ["savage leather"] = {
        profession = "Skinning", zone = "Tol Barad Peninsula", mapID = 245,
        x = 45.0, y = 45.0, start = "The Darkwood",
        targets = "Darkwood Lurkers • Darkwood Broodmothers • Baradin Foxes",
        notes = "Farm the dense skinnable mobs in The Darkwood. The spiders have fast respawns and are a well-established Savage Leather farm.",
    },
    ["core leather"] = {
        profession = "Skinning", zone = "Molten Core", mapID = 232,
        x = 50.0, y = 50.0, start = "Core Hound packs",
        targets = "Core Hounds • Ancient Core Hounds • Magmadar",
        notes = "Core Leather comes from Core Hounds and Magmadar in Molten Core; Firelands Ancient Core Hounds can also produce it.",
    },
    ["dredged leather"] = {
        profession = "Skinning", zone = "Nazjatar", mapID = 1355,
        x = 69.0, y = 50.0, start = "Eel / beast routes",
        targets = "Nazjatar beasts and snapdragons",
        notes = "Farm skinnable beasts in Nazjatar; keep moving through dense beast packs and use the Skinning route appropriate to your phase.",
    },
}

-- Additional route variants.  The primary GATHERING_ROUTES table remains
-- backward-compatible; these variants add optional alternate loops/areas
-- without forcing existing users to migrate saved route data.
local GATHERING_ROUTE_ALTERNATES = {
    ["void-tempered scales"] = {
        {routeID="Eversong Woods|Sunstrider Isle beast loop|2395|alt1", profession="Skinning", zone="Eversong Woods", mapID=2395, x=58.0, y=61.0, start="Sunstrider Isle beast loop", targets="Scaled beasts", notes="Alternate Eversong beast loop; use when the southern route is crowded."},
        {routeID="Eversong Woods|Goldenmist beast loop|2395|alt2", profession="Skinning", zone="Eversong Woods", mapID=2395, x=35.0, y=61.0, start="Goldenmist beast loop", targets="Scaled beasts", notes="Secondary Eversong loop for comparing spawn density and competition."},
    },
    ["tranquility bloom"] = {
        {routeID="Eversong Woods|Northern waterways|2395|alt1", profession="Herbalism", zone="Eversong Woods", mapID=2395, x=57.0, y=35.0, start="Northern waterways", notes="Northern waterway loop; useful as an alternate node-density sample."},
        {routeID="Eversong Woods|Eastern coast loop|2395|alt2", profession="Herbalism", zone="Eversong Woods", mapID=2395, x=67.0, y=73.0, start="Eastern coast loop", notes="Eastern coast loop for a second Eversong comparison route."},
    },
    ["argentleaf"] = {
        {routeID="Harandar|Fungara Village loop|2413|alt1", profession="Herbalism", zone="Harandar", mapID=2413, x=45.0, y=70.0, start="Fungara Village loop", targets="Argentleaf herb nodes", notes="Alternate Harandar loop around Fungara Village; compare node density with The Blinding Bloom."},
    },
    ["azeroot"] = {
        {routeID="Harandar|Southern shelf loop|2413|alt1", profession="Herbalism", zone="Harandar", mapID=2413, x=55.0, y=78.0, start="Southern shelf loop", targets="Azeroot herb nodes", notes="Secondary Azeroot loop for lower-competition route sampling."},
    },
    ["refulgent copper ore"] = {
        {routeID="Eversong Woods|Northern cliff mining loop|2395|alt1", profession="Mining", zone="Eversong Woods", mapID=2395, x=57.0, y=35.0, start="Northern cliff mining loop", notes="Alternate cliff-focused mining loop for comparing deposit density."},
    },
    ["umbral tin ore"] = {
        {routeID="Zul'Aman|Southern ridge loop|2437|alt1", profession="Mining", zone="Zul'Aman", mapID=2437, x=61.0, y=66.0, start="Southern ridge loop", notes="Alternate Zul'Aman ridge route for comparing deposit density."},
    },
    ["majestic hide"] = {
        {routeID="Voidstorm|Grand Beast outer loop|2405|alt1", profession="Skinning", zone="Voidstorm", mapID=2405, x=67.0, y=55.0, start="Grand Beast outer loop", targets="Netherscythe • Gloomclaw", notes="Alternate renowned-beast loop; compare sustained hide yield against the primary route."},
    },
}

function Market:GetGatheringRoutes(itemID)
    local record = self:GetRecord(itemID)
    local name = record and record.name
    if not name and C_Item and C_Item.GetItemInfo then
        local ok, itemName = pcall(C_Item.GetItemInfo, itemID)
        if ok then name = itemName end
    end
    name = strlower(strtrim(tostring(name or "")))
    if name == "" then return {} end

    local routes = {}
    local primary = GATHERING_ROUTES[name]
    if primary then
        -- Accept both the legacy single-route record and the newer multi-route
        -- form so existing databases remain compatible.
        if primary[1] then
            for _, route in ipairs(primary) do routes[#routes + 1] = route end
        else
            routes[1] = primary
        end
    end
    for _, route in ipairs(GATHERING_ROUTE_ALTERNATES[name] or {}) do
        routes[#routes + 1] = route
    end

    -- Keep the historical mote fallback routes available through the same API.
    if #routes == 0 then
        local moteRoutes = {
            ["mote of light"] = {profession="Gathering", zone="Eversong Woods", mapID=2395, x=42.0, y=79.0, start="Lightfused Eversong route", notes="Prioritize Lightfused herb and ore nodes for Mote of Light."},
            ["mote of wild magic"] = {profession="Gathering", zone="Zul'Aman", mapID=2437, x=33.09, y=32.71, start="Wild Zul'Aman route", notes="Prioritize Wild herb and ore nodes for Mote of Wild Magic."},
            ["mote of primal energy"] = {profession="Gathering", zone="Harandar", mapID=2413, x=43.83, y=64.29, start="Primal Harandar route", notes="Prioritize Primal herb and ore nodes for Mote of Primal Energy."},
            ["mote of pure void"] = {profession="Gathering", zone="Voidstorm", mapID=2405, x=54.0, y=65.0, start="Voidbound Voidstorm route", notes="Prioritize Voidbound herb and ore nodes for Mote of Pure Void."},
        }
        if moteRoutes[name] then routes[1] = moteRoutes[name] end
    end

    local result = {}
    for index, route in ipairs(routes) do
        if type(route) == "table" then
            local copy = {}
            for k, v in pairs(route) do copy[k] = v end
            copy.itemID = tonumber(itemID)
            copy.itemName = name
            copy.routeIndex = index
            copy.routeID = copy.routeID or ((copy.zone or "") .. "|" .. (copy.start or "") .. "|" .. tostring(copy.mapID or "") .. "|" .. tostring(index))

            -- Normalize Farming DB records so downstream systems can reason
            -- about route quality without having to understand legacy records.
            copy.dbSource = copy.dbSource or (index == 1 and "PRIMARY" or "ALTERNATE")
            copy.routeType = copy.routeType or ((copy.profession == "Skinning") and "SKINNING" or "GATHERING")
            copy.hasLocation = (tonumber(copy.mapID) ~= nil and tonumber(copy.x) ~= nil and tonumber(copy.y) ~= nil)
            copy.hasStart = tostring(copy.start or "") ~= ""
            copy.hasNotes = tostring(copy.notes or "") ~= ""
            copy.dataQuality = (copy.hasLocation and copy.hasStart and copy.hasNotes) and "COMPLETE"
                or (copy.hasLocation and copy.hasStart) and "PARTIAL" or "MINIMAL"
            copy.databaseVersion = 1
            result[#result + 1] = copy
        end
    end
    return result
end

-- Lightweight Farming DB health information.  This validates the static
-- catalog itself without treating missing records as player evidence.
function Market:GetFarmingDatabaseStatus()
    local materials, routes, complete, partial, minimal = 0, 0, 0, 0, 0
    local byProfession, byZone = {}, {}
    local seen = {}
    for itemName in pairs(GATHERING_ROUTES) do
        if not seen[itemName] then
            seen[itemName] = true
            materials = materials + 1
            -- Static catalog entries are validated directly when an item ID is
            -- unavailable; route count still reflects the shipped DB.
            local primary = GATHERING_ROUTES[itemName]
            local list = type(primary) == "table" and primary[1] and primary or {primary}
            for _, route in ipairs(list) do
                if type(route) == "table" then
                    routes = routes + 1
                    byProfession[route.profession or "Unknown"] = (byProfession[route.profession or "Unknown"] or 0) + 1
                    byZone[route.zone or "Unknown"] = (byZone[route.zone or "Unknown"] or 0) + 1
                    local location = tonumber(route.mapID) and tonumber(route.x) and tonumber(route.y)
                    local start = tostring(route.start or "") ~= ""
                    local notes = tostring(route.notes or "") ~= ""
                    if location and start and notes then complete = complete + 1
                    elseif location and start then partial = partial + 1
                    else minimal = minimal + 1 end
                end
            end
            for _, route in ipairs(GATHERING_ROUTE_ALTERNATES[itemName] or {}) do
                if type(route) == "table" then
                    routes = routes + 1
                    byProfession[route.profession or "Unknown"] = (byProfession[route.profession or "Unknown"] or 0) + 1
                    byZone[route.zone or "Unknown"] = (byZone[route.zone or "Unknown"] or 0) + 1
                    local location = tonumber(route.mapID) and tonumber(route.x) and tonumber(route.y)
                    local start = tostring(route.start or "") ~= ""
                    local notes = tostring(route.notes or "") ~= ""
                    if location and start and notes then complete = complete + 1
                    elseif location and start then partial = partial + 1
                    else minimal = minimal + 1 end
                end
            end
        end
    end
    return {
        version = 1, materials = materials, routes = routes, complete = complete,
        partial = partial, minimal = minimal, byProfession = byProfession, byZone = byZone,
        completeness = routes > 0 and (complete / routes) or 0,
        checkedAt = Now(),
    }
end

-- Audits the Farming DB against GoldMint's tracked material records. This is
-- intentionally an audit rather than player evidence: a tracked material with
-- no static route is reported as missing instead of being silently treated as
-- a bad farming result.
function Market:GetFarmingDatabaseCoverage()
    local store = EnsureStore()
    local covered, partial, missing, total = 0, 0, 0, 0
    local rows = {}
    local seen = {}

    for itemID, record in pairs(store.items or {}) do
        if type(record) == "table" and self:IsMaterial(itemID) then
            local name = strlower(strtrim(tostring(record.name or "")))
            if name ~= "" and not seen[name] then
                seen[name] = true
                local routes = self:GetGatheringRoutes(itemID)
                local bestQuality = "MISSING"
                local routeCount = #routes
                if routeCount > 0 then
                    bestQuality = "MINIMAL"
                    for _, route in ipairs(routes) do
                        if route.dataQuality == "COMPLETE" then
                            bestQuality = "COMPLETE"
                            break
                        elseif route.dataQuality == "PARTIAL" then
                            bestQuality = "PARTIAL"
                        end
                    end
                end

                -- Only treat items that GoldMint can reasonably classify as
                -- gathering resources as Farming DB coverage targets. Generic
                -- crafting reagents remain outside this audit.
                local kind = GetGatheringTypeForMaterial(itemID, record)
                local gatheringTarget = kind == "herbalism"
                    or kind == "mining"
                    or kind == "skinning"
                    or kind == "fishing"
                    or kind == "herbalism_or_mining"
                    or kind == "warwithin_cloth"
                    or kind == "midnight_cloth"
                if gatheringTarget then
                    total = total + 1
                    if bestQuality == "COMPLETE" then
                        covered = covered + 1
                    elseif bestQuality == "PARTIAL" or bestQuality == "MINIMAL" then
                        partial = partial + 1
                    else
                        missing = missing + 1
                    end
                    rows[#rows + 1] = {
                        itemID = tonumber(itemID),
                        itemName = record.name,
                        gatheringType = kind,
                        routeCount = routeCount,
                        coverage = bestQuality,
                    }
                end
            end
        end
    end

    table.sort(rows, function(a, b)
        local rank = { MISSING = 1, MINIMAL = 2, PARTIAL = 3, COMPLETE = 4 }
        local ar, br = rank[a.coverage] or 9, rank[b.coverage] or 9
        if ar ~= br then return ar < br end
        return tostring(a.itemName or "") < tostring(b.itemName or "")
    end)

    return {
        version = 1,
        total = total,
        complete = covered,
        partial = partial,
        missing = missing,
        completeness = total > 0 and (covered / total) or 0,
        rows = rows,
        checkedAt = Now(),
    }
end

-- Builds a deterministic, non-evidentiary expansion plan for the Farming DB.
-- This does not invent routes: it identifies tracked gatherables that need
-- additional static route data and gives them a stable priority for future DB work.
function Market:GetFarmingDatabaseExpansionPlan()
    local coverage = self:GetFarmingDatabaseCoverage()
    local plan = {version = 1, generatedAt = Now(), total = coverage.total or 0, items = {}, summary = {
        missing = 0, minimal = 0, partial = 0, singleRoute = 0, complete = 0,
    }}

    for _, row in ipairs(coverage.rows or {}) do
        local status = tostring(row.coverage or "MISSING")
        local priority = 0
        local action = "MAINTAIN"
        if status == "MISSING" then
            priority = 100
            action = "ADD_PRIMARY_ROUTE"
            plan.summary.missing = plan.summary.missing + 1
        elseif status == "MINIMAL" then
            priority = 80
            action = "COMPLETE_PRIMARY_ROUTE"
            plan.summary.minimal = plan.summary.minimal + 1
        elseif status == "PARTIAL" then
            priority = 60
            action = "COMPLETE_ROUTE_METADATA"
            plan.summary.partial = plan.summary.partial + 1
        else
            plan.summary.complete = plan.summary.complete + 1
        end

        if (tonumber(row.routeCount) or 0) == 1 and status ~= "MISSING" then
            priority = math.max(priority, 40)
            action = action == "MAINTAIN" and "ADD_ALTERNATE_ROUTE" or action
            plan.summary.singleRoute = plan.summary.singleRoute + 1
        end

        plan.items[#plan.items + 1] = {
            itemID = tonumber(row.itemID),
            itemName = row.itemName,
            gatheringType = row.gatheringType,
            routeCount = tonumber(row.routeCount) or 0,
            coverage = status,
            priority = priority,
            action = action,
        }
    end

    table.sort(plan.items, function(a, b)
        if (a.priority or 0) ~= (b.priority or 0) then
            return (a.priority or 0) > (b.priority or 0)
        end
        return tostring(a.itemName or "") < tostring(b.itemName or "")
    end)

    -- Keep the plan compact for consumers and future UI.
    plan.top = {}
    for i = 1, math.min(20, #plan.items) do
        plan.top[i] = plan.items[i]
    end
    return plan
end

-- Performs a final structural audit of the static Farming DB. This is a
-- data-quality check only; it never turns incomplete route records into player
-- evidence. It also detects duplicate route IDs and duplicate start/map pairs so
-- future DB expansion does not quietly add redundant routes.
function Market:GetFarmingDatabaseRouteAudit()
    local status = self:GetFarmingDatabaseStatus()
    local coverage = self:GetFarmingDatabaseCoverage()
    local plan = self:GetFarmingDatabaseExpansionPlan()
    local audit = {
        version = 1,
        checkedAt = Now(),
        materials = status.materials or 0,
        routes = status.routes or 0,
        complete = status.complete or 0,
        partial = status.partial or 0,
        minimal = status.minimal or 0,
        duplicateRouteIDs = {},
        duplicateLocations = {},
        weakMaterials = {},
        singleRouteMaterials = {},
        healthyMaterials = 0,
        warnings = {},
    }

    local seenIDs, seenLocations, perMaterial = {}, {}, {}
    for itemName, primary in pairs(GATHERING_ROUTES) do
        local all = {}
        if type(primary) == "table" and primary[1] then
            for _, route in ipairs(primary) do all[#all + 1] = route end
        elseif type(primary) == "table" then
            all[#all + 1] = primary
        end
        for _, route in ipairs(GATHERING_ROUTE_ALTERNATES[itemName] or {}) do all[#all + 1] = route end

        perMaterial[itemName] = #all
        if #all <= 1 then
            audit.singleRouteMaterials[#audit.singleRouteMaterials + 1] = itemName
        end

        local materialHealthy = false
        for _, route in ipairs(all) do
            if type(route) == "table" then
                local id = tostring(route.routeID or ((route.zone or "") .. "|" .. (route.start or "") .. "|" .. tostring(route.mapID or "")))
                if seenIDs[id] then
                    audit.duplicateRouteIDs[#audit.duplicateRouteIDs + 1] = {
                        routeID = id, itemName = itemName, duplicateOf = seenIDs[id],
                    }
                else
                    seenIDs[id] = itemName
                end

                local mapID, x, y = tonumber(route.mapID), tonumber(route.x), tonumber(route.y)
                if mapID and x and y then
                    local locationKey = tostring(mapID) .. "|" .. string.format("%.3f", x) .. "|" .. string.format("%.3f", y)
                    if seenLocations[locationKey] and seenLocations[locationKey] ~= itemName then
                        audit.duplicateLocations[#audit.duplicateLocations + 1] = {
                            location = locationKey, itemName = itemName, duplicateOf = seenLocations[locationKey],
                        }
                    else
                        seenLocations[locationKey] = itemName
                    end
                    materialHealthy = true
                end
            end
        end
        if materialHealthy and #all > 0 then
            audit.healthyMaterials = audit.healthyMaterials + 1
        end
    end

    for _, row in ipairs(coverage.rows or {}) do
        if row.coverage ~= "COMPLETE" then
            audit.weakMaterials[#audit.weakMaterials + 1] = {
                itemID = row.itemID, itemName = row.itemName, coverage = row.coverage,
                routeCount = row.routeCount, gatheringType = row.gatheringType,
            }
        end
    end

    if #audit.duplicateRouteIDs > 0 then
        audit.warnings[#audit.warnings + 1] = "Duplicate route IDs detected"
    end
    if #audit.duplicateLocations > 0 then
        audit.warnings[#audit.warnings + 1] = "Shared route locations detected"
    end
    if #audit.weakMaterials > 0 then
        audit.warnings[#audit.warnings + 1] = "Incomplete Farming DB records remain"
    end
    if #audit.singleRouteMaterials > 0 then
        audit.warnings[#audit.warnings + 1] = "Some materials have only one static route"
    end

    audit.routeIntegrity = audit.routes > 0 and (#audit.duplicateRouteIDs == 0) and (#audit.duplicateLocations == 0) or audit.routes == 0
    audit.metadataCompleteness = audit.routes > 0 and (audit.complete / audit.routes) or 0
    audit.coverageCompleteness = coverage.completeness or 0
    audit.expansionItems = #(plan.items or {})
    audit.readyForFinalization = audit.routeIntegrity and #audit.weakMaterials == 0
        and (audit.metadataCompleteness >= 0.90)
    return audit
end


-- Consolidates the Farming DB health, coverage, expansion plan, and structural
-- audit into one authoritative readiness result. This is the finalization gate
-- for the static database; it does not modify routes or player evidence.
function Market:GetFarmingDatabaseReadiness()
    local status = self:GetFarmingDatabaseStatus()
    local coverage = self:GetFarmingDatabaseCoverage()
    local plan = self:GetFarmingDatabaseExpansionPlan()
    local audit = self:GetFarmingDatabaseRouteAudit()

    local blockers = {}
    if (audit.duplicateRouteIDs and #audit.duplicateRouteIDs > 0) then
        blockers[#blockers + 1] = "DUPLICATE_ROUTE_IDS"
    end
    if (audit.duplicateLocations and #audit.duplicateLocations > 0) then
        blockers[#blockers + 1] = "DUPLICATE_LOCATIONS"
    end
    if (coverage.missing or 0) > 0 then
        blockers[#blockers + 1] = "MISSING_MATERIAL_ROUTES"
    end
    if (coverage.partial or 0) > 0 then
        blockers[#blockers + 1] = "PARTIAL_MATERIAL_COVERAGE"
    end
    if (status.minimal or 0) > 0 then
        blockers[#blockers + 1] = "MINIMAL_ROUTE_RECORDS"
    end

    local routeCompleteness = tonumber(audit.metadataCompleteness) or 0
    local materialCompleteness = tonumber(coverage.completeness) or 0
    local structuralReady = audit.routeIntegrity == true and routeCompleteness >= 0.90
    local coverageReady = (coverage.missing or 0) == 0 and (coverage.partial or 0) == 0
    local ready = structuralReady and coverageReady

    local state
    if ready then
        state = "READY"
    elseif #blockers == 0 then
        state = "REVIEW"
    elseif structuralReady and not coverageReady then
        state = "EXPANSION_REQUIRED"
    else
        state = "REPAIR_REQUIRED"
    end

    local score = math.min(100, math.max(0,
        (routeCompleteness * 45) + (materialCompleteness * 45) +
        ((audit.routeIntegrity == true) and 10 or 0)))

    return {
        version = 1,
        state = state,
        ready = ready,
        score = score,
        routeCompleteness = routeCompleteness,
        materialCompleteness = materialCompleteness,
        routeIntegrity = audit.routeIntegrity == true,
        materials = status.materials or 0,
        routes = status.routes or 0,
        completeRoutes = status.complete or 0,
        partialRoutes = status.partial or 0,
        minimalRoutes = status.minimal or 0,
        coveredMaterials = coverage.complete or 0,
        partialMaterials = coverage.partial or 0,
        missingMaterials = coverage.missing or 0,
        expansionItems = #(plan.items or {}),
        blockers = blockers,
        warnings = audit.warnings or {},
        checkedAt = Now(),
    }
end

-- Final static-database certification.  This deliberately separates the
-- shipped Farming DB from dynamic player-tracking coverage: a player's
-- currently tracked materials may be incomplete without making the packaged
-- route catalog itself "uncertified".  Certification is deterministic and
-- can therefore be used by downstream systems as a stable release gate.
function Market:GetFarmingDatabaseCertification()
    local status = self:GetFarmingDatabaseStatus()
    local audit = self:GetFarmingDatabaseRouteAudit()
    local staticComplete = (status.routes or 0) > 0
        and (status.complete or 0) == (status.routes or 0)
    local certified = staticComplete
        and audit.routeIntegrity == true
        and (audit.metadataCompleteness or 0) >= 0.90

    local state = certified and "CERTIFIED" or "REVIEW_REQUIRED"
    local reasons = {}
    if (status.routes or 0) == 0 then
        reasons[#reasons + 1] = "NO_STATIC_ROUTES"
    end
    if (status.minimal or 0) > 0 then
        reasons[#reasons + 1] = "MINIMAL_ROUTE_RECORDS"
    end
    if (status.partial or 0) > 0 then
        reasons[#reasons + 1] = "PARTIAL_ROUTE_RECORDS"
    end
    if not audit.routeIntegrity then
        reasons[#reasons + 1] = "ROUTE_INTEGRITY_ISSUES"
    end
    if (audit.metadataCompleteness or 0) < 0.90 then
        reasons[#reasons + 1] = "METADATA_BELOW_THRESHOLD"
    end

    return {
        version = 2,
        databaseVersion = 1,
        state = state,
        certified = certified,
        staticRoutes = status.routes or 0,
        staticMaterials = status.materials or 0,
        completeRoutes = status.complete or 0,
        partialRoutes = status.partial or 0,
        minimalRoutes = status.minimal or 0,
        metadataCompleteness = audit.metadataCompleteness or 0,
        routeIntegrity = audit.routeIntegrity == true,
        certifiedAt = certified and Now() or nil,
        reasons = reasons,
        dynamicCoverageRequired = true,
        note = "Static DB certification is independent of player-tracked material coverage.",
    }
end

-- Final static Farming DB release gate. This intentionally certifies the
-- shipped catalog independently of dynamic player coverage. A missing player
-- observation must never make the packaged DB appear incomplete.
function Market:GetFarmingDatabaseFinalization()
    local status = self:GetFarmingDatabaseStatus()
    local audit = self:GetFarmingDatabaseRouteAudit()
    local certification = self:GetFarmingDatabaseCertification()

    local complete = (status.routes or 0) > 0
        and (status.partial or 0) == 0
        and (status.minimal or 0) == 0
        and audit.routeIntegrity == true
        and (audit.metadataCompleteness or 0) >= 0.90

    local reasons = {}
    if (status.routes or 0) == 0 then
        reasons[#reasons + 1] = "NO_STATIC_ROUTES"
    end
    if (status.partial or 0) > 0 then
        reasons[#reasons + 1] = "PARTIAL_ROUTE_RECORDS"
    end
    if (status.minimal or 0) > 0 then
        reasons[#reasons + 1] = "MINIMAL_ROUTE_RECORDS"
    end
    if audit.routeIntegrity ~= true then
        reasons[#reasons + 1] = "ROUTE_INTEGRITY_ISSUES"
    end
    if (audit.metadataCompleteness or 0) < 0.90 then
        reasons[#reasons + 1] = "METADATA_BELOW_THRESHOLD"
    end

    return {
        version = 1,
        databaseVersion = 1,
        state = complete and "FINALIZED" or "FINAL_REVIEW",
        finalized = complete,
        certificationState = certification.state,
        materials = status.materials or 0,
        routes = status.routes or 0,
        completeRoutes = status.complete or 0,
        partialRoutes = status.partial or 0,
        minimalRoutes = status.minimal or 0,
        completeness = tonumber(status.completeness) or 0,
        metadataCompleteness = tonumber(audit.metadataCompleteness) or 0,
        routeIntegrity = audit.routeIntegrity == true,
        finalizedAt = complete and Now() or nil,
        reasons = reasons,
        dynamicPlayerCoverageSeparate = true,
        note = "Static Farming DB finalization is independent of player-tracked coverage.",
    }
end

function Market:GetGatheringRoute(itemID)
    local routes = self:GetGatheringRoutes(itemID)
    if routes[1] then return routes[1] end
    local record = self:GetRecord(itemID)
    local name = record and record.name
    if not name and C_Item and C_Item.GetItemInfo then
        local ok, itemName = pcall(C_Item.GetItemInfo, itemID)
        if ok then name = itemName end
    end
    name = strlower(strtrim(tostring(name or "")))
    if name == "" then return nil end
    return nil
end

local trackedItemsCache = {}
local TRACKED_ITEMS_CACHE_TTL = 2

function Market:InvalidateTrackedItemsCache()
    wipe(trackedItemsCache)
end

function Market:GetTrackedItems(limit, query, mode)
    local store = EnsureStore()
    limit = tonumber(limit) or 100
    query = strlower(strtrim(query or ""))
    mode = mode or "materials"
    local characterKey = GoldMint.characterKey or "Unknown"
    local cacheKey = table.concat({characterKey, mode, query, tostring(limit)}, "|")
    local now = Now()
    local cached = trackedItemsCache[cacheKey]
    if cached and (now - cached.time) < TRACKED_ITEMS_CACHE_TTL then return cached.rows end

    local rows, candidateIDs = {}, nil
    if mode == "materials" then
        local pool = store.characterPools and store.characterPools[characterKey]
        if type(pool) == "table" and type(pool.itemIDs) == "table" and #pool.itemIDs > 0 then candidateIDs = pool.itemIDs end
    end

    local function AddRecord(numericID, record)
        if not numericID or type(record) ~= "table" then return end
        local name = record.name or ("Item " .. tostring(numericID))
        if query ~= "" and not strfind(strlower(name), query, 1, true) then return end
        local material = self:IsMaterial(numericID)
        local gatheringMaterial = self:IsGatheringMaterialForCurrentCharacter(numericID, record)
        local allTrackedMaterial = self:IsAllTrackedMaterial(numericID, record)

        -- The saved character pool is only a performance cache; it is NOT an
        -- authority on what this character can currently gather.  Older pools
        -- can contain materials captured before a profession was changed, or
        -- materials collected by another character.  Always apply the live
        -- current-character profession gate here.  This prevents a Skinning +
        -- Leatherworking character from inheriting Mining/Herbalism materials
        -- simply because those IDs exist in the cached pool.
        local modeMatch
        if mode == "materials" then
            modeMatch = gatheringMaterial
        else
            modeMatch = allTrackedMaterial
        end
        if not modeMatch then return end
        local data = self:GetMultiverseData(numericID) or {}
        data.itemID, data.name, data.isMaterial = numericID, name, material
        data.historyCount = #(record.ah and record.ah.history or {}) + #(record.tsm and record.tsm.history or {})
        rows[#rows + 1] = data
    end

    if candidateIDs then
        for _, itemID in ipairs(candidateIDs) do
            local numericID = tonumber(itemID)
            local record = numericID and (store.items[numericID] or store.items[tostring(numericID)])
            AddRecord(numericID, record)
        end
    else
        for itemID, record in pairs(store.items or {}) do AddRecord(tonumber(itemID), record) end
    end

    table.sort(rows, function(a,b)
        local av,bv=tonumber(a.regionSoldPerDay) or 0,tonumber(b.regionSoldPerDay) or 0
        if av~=bv then return av>bv end
        local am,bm=tonumber(a.marketValue) or 0,tonumber(b.marketValue) or 0
        if am~=bm then return am>bm end
        return tostring(a.name)<tostring(b.name)
    end)
    while #rows > limit do table.remove(rows) end
    trackedItemsCache[cacheKey]={time=now,rows=rows}
    return rows
end

local function RecordCommodityResults(itemID)
    if not C_AuctionHouse or not C_AuctionHouse.GetNumCommoditySearchResults or not C_AuctionHouse.GetCommoditySearchResultInfo then return end
    local count = C_AuctionHouse.GetNumCommoditySearchResults(itemID) or 0
    local lowest, lowestQuantity
    for i = 1, count do
        local result = C_AuctionHouse.GetCommoditySearchResultInfo(itemID, i)
        local price = result and tonumber(result.unitPrice)
        if price and price > 0 then
            if not lowest or price < lowest then
                lowest = price
                lowestQuantity = tonumber(result.quantity) or 1
            end
        end
    end
    if lowest then Market:RecordAuctionPrice(itemID, lowest, lowestQuantity, "commodity") end
end

local function RecordItemResults(itemKey)
    if type(itemKey) ~= "table" or not itemKey.itemID then return end
    if not C_AuctionHouse or not C_AuctionHouse.GetNumItemSearchResults or not C_AuctionHouse.GetItemSearchResultInfo then return end
    local count = C_AuctionHouse.GetNumItemSearchResults(itemKey) or 0
    local lowest, lowestQuantity
    for i = 1, count do
        local result = C_AuctionHouse.GetItemSearchResultInfo(itemKey, i)
        local buyout = result and tonumber(result.buyoutAmount)
        local quantity = result and tonumber(result.quantity) or 1
        if buyout and buyout > 0 and quantity > 0 then
            local unitPrice = buyout / quantity
            if not lowest or unitPrice < lowest then
                lowest = unitPrice
                lowestQuantity = quantity
            end
        end
    end
    if lowest then Market:RecordAuctionPrice(itemKey.itemID, lowest, lowestQuantity, "item") end
end

local function RecordBrowseResults()
    if not C_AuctionHouse or not C_AuctionHouse.GetBrowseResults then return end
    local results = C_AuctionHouse.GetBrowseResults()
    if type(results) ~= "table" then return end

    for _, result in ipairs(results) do
        local itemKey = result and result.itemKey
        local itemID = itemKey and tonumber(itemKey.itemID)
        local minPrice = result and tonumber(result.minPrice)
        local quantity = result and tonumber(result.totalQuantity) or 1
        if itemID then
            Market:RecordItem(itemID)
            if minPrice and minPrice > 0 then
                Market:RecordAuctionPrice(itemID, minPrice, quantity, "browse")
            end
            Market:CaptureTSM(itemID)
        end
    end
end

function Market:ScanAuctionResults(kind, key)
    self:InvalidateTrackedItemsCache()
    if kind == "commodity" then
        RecordCommodityResults(key)
        self:CaptureTSM(key)
    elseif kind == "item" then
        RecordItemResults(key)
        if type(key) == "table" then self:CaptureTSM(key.itemID) end
    end
end

function Market:ScanContainer(containerID)
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then return 0 end
    local okSlots, rawSlots = pcall(C_Container.GetContainerNumSlots, containerID)
    local slots = okSlots and (tonumber(rawSlots) or 0) or 0
    local count = 0
    for slot = 1, slots do
        local okInfo, info = pcall(C_Container.GetContainerItemInfo, containerID, slot)
        if not okInfo then info = nil end
        if info and info.itemID then
            if self:RecordItem(info.itemID) then
                count = count + 1
            end
        end
    end
    return count
end

function Market:ScanBags()
    local scanned = 0
    if C_Container and C_Container.GetContainerNumSlots then
        for bag = BACKPACK_CONTAINER, NUM_BAG_SLOTS do
            scanned = scanned + self:ScanContainer(bag)
        end
    end
    return scanned
end

function Market:GetRecord(itemID)
    itemID = tonumber(itemID)
    if not itemID or not GoldMintDB or not GoldMintDB.market then return nil end
    return GoldMintDB.market.items and GoldMintDB.market.items[itemID]
end

function Market:GetUnitValue(itemID)
    local record = self:GetRecord(itemID)
    if not record then return nil, "untracked" end

    -- The Market page is now a market-intelligence surface. Prefer the
    -- Multiverse/region market value when it has been synchronized, then fall
    -- back through TSM realm data, the last observed local price, and vendor.
    local region = record.region or {}
    if tonumber(region.marketValue) and tonumber(region.marketValue) > 0 then
        return tonumber(region.marketValue), "region-market"
    end
    if record.tsm and record.tsm.marketValue and record.tsm.marketValue > 0 then
        return record.tsm.marketValue, "tsm"
    end
    if record.ah and record.ah.lowestUnitPrice and record.ah.lowestUnitPrice > 0 then
        return record.ah.lowestUnitPrice, "observed"
    end
    if record.vendorSellPrice and record.vendorSellPrice > 0 then
        return record.vendorSellPrice, "vendor"
    end
    return nil, "unknown"
end

local function BuildCraftedOutputIndex()
    if craftedOutputIndexCache then return craftedOutputIndexCache end
    local index = {}
    for _, recipe in pairs((GoldMintDB and GoldMintDB.recipes) or {}) do
        if type(recipe) == "table" then
            local outputID = tonumber(recipe.outputItemID)
            if outputID then
                index[outputID] = true
            end
        end
    end
    craftedOutputIndexCache = index
    return index
end

BuildRecipeIndexes = function()
    if recipeInputIndexCache and recipeOutputIndexCache then
        return recipeInputIndexCache, recipeOutputIndexCache
    end
    local inputIndex, outputIndex = {}, {}
    for recipeID, recipe in pairs((GoldMintDB and GoldMintDB.recipes) or {}) do
        if type(recipe) == "table" then
            local rid = tonumber(recipeID) or recipeID
            local outputID = tonumber(recipe.outputItemID)
            if outputID then
                outputIndex[outputID] = outputIndex[outputID] or {}
                outputIndex[outputID][#outputIndex[outputID] + 1] = { id = rid, recipe = recipe }
            end
            for _, reagent in ipairs(recipe.reagents or {}) do
                for _, option in ipairs(reagent.options or {}) do
                    local itemID = tonumber(option.itemID)
                    if itemID then
                        inputIndex[itemID] = inputIndex[itemID] or {}
                        inputIndex[itemID][#inputIndex[itemID] + 1] = { id = rid, recipe = recipe }
                    end
                end
            end
        end
    end
    recipeInputIndexCache, recipeOutputIndexCache = inputIndex, outputIndex
    return inputIndex, outputIndex
end

local function IsCraftedRecipeOutput(itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end
    return BuildCraftedOutputIndex()[itemID] == true
end

local function ItemIsCraftingReagent(itemID)
    if not itemID or not C_Item or not C_Item.GetItemInfo then return false end
    local ok, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, isCraftingReagent = pcall(C_Item.GetItemInfo, itemID)
    return ok and isCraftingReagent == true
end

BuildMaterialIndex = function()
    if materialIndexCache then return materialIndexCache end
    local index = {}
    for _, recipe in pairs((GoldMintDB and GoldMintDB.recipes) or {}) do
        if type(recipe) == "table" then
            for _, reagent in ipairs(recipe.reagents or {}) do
                for _, option in ipairs(reagent.options or {}) do
                    local id = tonumber(option.itemID)
                    if id then index[id] = true end
                end
            end
        end
    end
    materialIndexCache = index
    return index
end

IsKnownMaterial = function(itemID)
    itemID = tonumber(itemID)
    if not itemID then return false end
    local index = BuildMaterialIndex()
    if index[itemID] then return true end
    if materialInfoCache[itemID] ~= nil then return materialInfoCache[itemID] end
    local result = ItemIsCraftingReagent(itemID)
    materialInfoCache[itemID] = result
    return result
end

function Market:IsMaterial(itemID)
    return IsKnownMaterial(itemID)
end

-- Gathering materials shown on the Market page are character-specific.
-- A character with Skinning should not be sent after herbs or ore, for example.
-- Keep this separate from IsMaterial(): IsMaterial() is the broad market/material
-- classifier used by the scanner, while this helper controls the character-facing
-- Gathering Materials view.
local GATHERING_PROFESSIONS = {
    herbalism = true,
    mining = true,
    skinning = true,
    fishing = true,
}

-- Cloth needs an expansion-aware rule. In The War Within, humanoid cloth
-- gathering is Tailoring-only for the character-facing Materials list. Older
-- expansions retain the broader legacy rule. Midnight is also Tailoring-gated
-- for naturally looted cloth. This view is intentionally about what the
-- character can personally gather, not every possible alternate acquisition
-- method (such as Mining/Alchemy sources for Weavercloth).
local MIDNIGHT_CLOTH_NAMES = {
    ["bright linen"] = true,
    ["sunfire silk"] = true,
    ["arcanoweave"] = true,
}

local NON_GATHERED_CLOTH_WORDS = {
    "bolt", "thread", "spool", "bandage", "ribbon", "lining",
}

local GATHERING_SKILL_LINES = {
    [182] = "herbalism",
    [186] = "mining",
    [393] = "skinning",
    [356] = "fishing",
}

local GATHERING_SUBTYPES = {
    herbalism = { ["herbs"] = true, ["herb"] = true },
    mining = { ["metal & stone"] = true, ["metal and stone"] = true, ["ore"] = true },
    skinning = { ["leather"] = true, ["leatherworking"] = true, ["hides"] = true },
    fishing = { ["fish"] = true, ["fishing"] = true },
}

local function GetCurrentCharacterGatheringProfessions()
    -- IMPORTANT: this must be based on the professions the CURRENT PLAYER
    -- actually knows, not GoldMint's saved character.professions table. That
    -- table is intentionally persistent and can contain stale data from older
    -- scans/profession changes. Using it here was the reason a Leatherworking +
    -- Skinning character could inherit Herbalism, Mining, or Tailoring materials.
    --
    -- GetProfessions()/GetProfessionInfo() is the live character source for
    -- the player's two primary professions. The modern TradeSkillUI APIs are
    -- useful when a profession window is open, but they only expose the
    -- currently displayed profession and therefore are not sufficient by
    -- themselves for this character-wide filter.
    local result = {}

    local function AddProfession(skillLineID, name)
        skillLineID = tonumber(skillLineID)
        local gatheringType = skillLineID and GATHERING_SKILL_LINES[skillLineID]
        if gatheringType then
            result[gatheringType] = true
        end

        local cleanName = tostring(name or ""):lower():gsub("[^%a]", "")
        if GATHERING_PROFESSIONS[cleanName] then
            result[cleanName] = true
        elseif cleanName == "tailoring" then
            result.tailoring = true
        end
    end

    -- Retail still exposes the player's primary profession slots through
    -- GetProfessions(). Use the actual live skill line rather than persisted
    -- GoldMint data.
    if type(GetProfessions) == "function" and type(GetProfessionInfo) == "function" then
        local ok, prof1, prof2 = pcall(GetProfessions)
        if ok then
            for _, professionIndex in ipairs({prof1, prof2}) do
                if professionIndex then
                    local infoOK, name, _, _, _, _, skillLineID = pcall(GetProfessionInfo, professionIndex)
                    if infoOK then
                        AddProfession(skillLineID, name)
                    end
                end
            end
        end
    end

    return result
end

local function GetItemMarketSubtype(itemID)
    if not itemID or not C_Item or not C_Item.GetItemInfo then return nil, nil, nil end

    -- C_Item.GetItemInfo returns the localized item type/subtype at positions
    -- 6/7. Positions 12/13 are numeric class/subclass IDs. The old code read
    -- those numeric IDs as names, which prevented valid herbs/ore/leather/cloth
    -- from matching the gathering filters and broke the Trade Goods check.
    local ok, _, _, _, _, _, itemType, itemSubType, _, _, _, _, _, _, _, expansionID =
        pcall(C_Item.GetItemInfo, itemID)

    if ok then
        local subtype = itemSubType and tostring(itemSubType):lower() or nil
        local className = itemType and tostring(itemType):lower() or nil
        return subtype, tonumber(expansionID), className
    end

    return nil, nil, nil
end

local function GetGatheringTypeForMaterial(itemID, record)
    local route = Market:GetGatheringRoute(itemID)
    if route and route.profession then
        local profession = tostring(route.profession):lower():gsub("[^%a]", "")
        if GATHERING_PROFESSIONS[profession] then
            return profession
        end
    end

    local name = tostring(record and record.name or ""):lower()
    -- Midnight mote materials can come from themed herb/ore nodes. They are
    -- therefore relevant to Herbalism or Mining, but never to Skinning alone.
    if name:match("^mote of ") then
        return "herbalism_or_mining"
    end

    -- Skinning produces the Midnight bone/hide materials. Keep this narrow so
    -- ordinary crafted items containing the word "bone" are not classified as
    -- gatherables accidentally.
    if name:find("bone", 1, true) or name:find("hide", 1, true) or name:find("leather", 1, true) then
        return "skinning"
    end

    local subtype, expansionID = GetItemMarketSubtype(itemID)
    if subtype then
        for profession, values in pairs(GATHERING_SUBTYPES) do
            if values[subtype] then return profession end
        end

        -- Item subtype is the safest generic way to recognize cloth across
        -- older expansions. We separately gate Midnight's Tailoring-only cloth
        -- below, and exclude processed cloth such as bolts and thread.
        if subtype == "cloth" or subtype == "cloth & leather" or subtype == "cloth and leather" then
            local name = tostring(record and record.name or ""):lower()
            for _, word in ipairs(NON_GATHERED_CLOTH_WORDS) do
                if name:find(word, 1, true) then
                    return nil
                end
            end
            -- Expansion IDs are authoritative when item data is cached.
            -- The War Within is expansion 10; Midnight is expansion 11.
            -- Keep the name fallback for cached/legacy records where the
            -- expansion ID is unavailable.
            if expansionID == 10 then
                return "warwithin_cloth"
            end
            if expansionID == 11 or MIDNIGHT_CLOTH_NAMES[name] then
                return "midnight_cloth"
            end
            return "legacy_cloth"
        end
    end

    return nil
end


-- ALL TRACKED is intentionally different from MATERIALS. It is the
-- character-independent market list for useful gathering-style materials
-- that do not require a gathering profession: legacy cloth (Dragonflight and
-- older) plus other crafting reagents that can be obtained without Herbalism,
-- Mining, Skinning, Fishing, or Tailoring. Modern War Within/Midnight cloth,
-- profession-gathered resources, and enchanting-only reagents stay out.
function Market:IsAllTrackedMaterial(itemID, record)
    if not self:IsMaterial(itemID) then return false end

    -- Recipe outputs are crafted products, not gathered materials.  Blizzard
    -- can flag some of these as generic crafting reagents, which otherwise
    -- makes them look eligible for ALL TRACKED.  Keep crafted outputs out of
    -- this view even when they are useful inputs to another recipe.
    if IsCraftedRecipeOutput(itemID) then return false end

    -- ALL TRACKED must contain raw/independently-obtainable materials only.
    -- Tailoring-produced items are excluded even when Blizzard classifies them
    -- as generic Trade Goods/Crafting Reagents.  In particular, processed cloth
    -- such as Bolts, Mooncloth, and the Cindercloth Cloak must never leak into
    -- this profession-independent list.
    local itemName = tostring(record and record.name or ""):lower()
    if itemName:match("^bolt of ") then return false end
    if itemName:find("mooncloth", 1, true) then return false end
    if itemName == "cindercloth cloak" then return false end

    local kind = GetGatheringTypeForMaterial(itemID, record)

    -- ALL TRACKED is still a character-facing Market view. It may include
    -- profession-independent materials, but it must never recommend a raw
    -- gathering material that this character cannot actually gather. This is
    -- especially important on multi-character accounts: the shared Market
    -- database can contain herbs/ore/leather/fish learned from other alts.
    if kind == "herbalism" or kind == "mining" or kind == "skinning"
        or kind == "fishing" or kind == "herbalism_or_mining"
        or kind == "warwithin_cloth" or kind == "midnight_cloth" then
        return self:IsGatheringMaterialForCurrentCharacter(itemID, record)
    end

    if kind == "legacy_cloth" then
        -- Legacy raw cloth is profession-independent and can be farmed by any
        -- character, so it remains eligible for ALL TRACKED.
        return true
    end

    local subtype = GetItemMarketSubtype(itemID)

    -- ALL TRACKED also includes crafting reagents that can be obtained without
    -- owning a profession. Do not require Blizzard's localized item-class
    -- string to be exactly "Trade Goods" here: that metadata can be missing or
    -- vary while item information is being cached, which caused legitimate
    -- profession-independent crafting reagents to disappear from this view.
    -- The crafting-reagent flag is the authoritative check.
    --
    -- Enchanting reagents remain excluded because obtaining them as intended
    -- requires Enchanting rather than a profession-independent farm.
    if subtype == "enchanting" then
        return false
    end

    -- A number of legitimate profession-independent reagents are not reliably
    -- reported by Blizzard's isCraftingReagent flag. GoldMint already knows
    -- about these items because they appear as inputs to known recipes. Use
    -- that recipe-input index as the fallback, after all profession-gated and
    -- crafted-output exclusions above have been applied.
    return ItemIsCraftingReagent(itemID) or BuildMaterialIndex()[itemID] == true
end

local function IsTailoringProducedMaterial(itemID, record)
    -- Prefer the live item name, but fall back to GoldMint's stored record name.
    -- GetItemInfo can return no name while the item is not cached; without the
    -- fallback, Tailoring products could leak into MATERIALS as generic reagents.
    local itemName
    if itemID and C_Item and C_Item.GetItemInfo then
        local ok, name = pcall(C_Item.GetItemInfo, itemID)
        if ok and name then itemName = name end
    end
    if not itemName and record and record.name then
        itemName = record.name
    end
    if not itemName then return false end

    local n = tostring(itemName):lower()

    -- Bolts are Tailoring-produced materials, not raw cloth drops.
    if n:match("^bolt of ") then return true end

    -- Mooncloth and its Tailoring-produced variants are profession materials.
    if n:find("mooncloth", 1, true) then return true end

    return false
end

function Market:IsGatheringMaterialForCurrentCharacter(itemID, record)
    -- MATERIALS includes profession-produced Tailoring materials for Tailors.
    -- Raw cloth drops are handled separately by the profession-independent
    -- ALL TRACKED pool.
    local gathering = GetCurrentCharacterGatheringProfessions()

    if IsTailoringProducedMaterial(itemID, record) then
        return gathering.tailoring == true
    end

    -- Do not make MATERIALS depend exclusively on ItemIsCraftingReagent():
    -- Blizzard can leave that metadata unset until item information is cached.
    local kind = GetGatheringTypeForMaterial(itemID, record)
    if not self:IsMaterial(itemID) and not kind then
        return false
    end

    local gathering = GetCurrentCharacterGatheringProfessions()

    if kind == "warwithin_cloth" then
        -- The War Within cloth is available to Tailors through their profession.
        return gathering.tailoring == true
    end

    if kind == "midnight_cloth" then
        -- Midnight cloth is available to Tailors through their profession.
        return gathering.tailoring == true
    end

    if kind == "legacy_cloth" then
        -- Dragonflight and older cloth is profession-independent.
        -- It belongs in ALL TRACKED, not MATERIALS.
        return false
    end

    if not next(gathering) then return false end
    if kind == "herbalism_or_mining" then
        return gathering.herbalism == true or gathering.mining == true
    end
    return kind and gathering[kind] == true or false
end

local function CalculateVolatility(history, field)
    if type(history) ~= "table" or #history < 2 then return nil end
    local sum, count = 0, 0
    for _, point in ipairs(history) do
        local value = tonumber(point[field])
        if value and value > 0 then
            sum = sum + value
            count = count + 1
        end
    end
    if count < 2 then return nil end
    local mean = sum / count
    if mean <= 0 then return nil end
    local variance = 0
    for _, point in ipairs(history) do
        local value = tonumber(point[field])
        if value and value > 0 then
            local diff = value - mean
            variance = variance + diff * diff
        end
    end
    return math.sqrt(variance / count) / mean
end

function Market:GetPriceMatrix(itemID)
    local record = self:GetRecord(itemID)
    if not record then return nil end
    local value, source = self:GetUnitValue(itemID)
    local ah, tsm = record.ah or {}, record.tsm or {}
    return {
        itemID = tonumber(itemID),
        name = record.name,
        vendorSellPrice = tonumber(record.vendorSellPrice) or 0,
        value = value,
        valueSource = source,
        auction = {
            lowestUnitPrice = tonumber(ah.lowestUnitPrice),
            lastUnitPrice = tonumber(ah.lastUnitPrice),
            lastQuantity = tonumber(ah.lastQuantity) or 0,
            observedAt = tonumber(ah.observedAt),
            volatility = CalculateVolatility(ah.history, "unitPrice"),
            observationCount = tonumber(ah.observationCount) or 0,
        },
        tsm = {
            marketValue = tonumber(tsm.marketValue),
            observedAt = tonumber(tsm.observedAt),
            volatility = CalculateVolatility(tsm.history, "marketValue"),
            observationCount = tonumber(tsm.observationCount) or 0,
        },
        updatedAt = tonumber(record.lastSeen),
    }
end

function Market:GetVolatility(itemID)
    local matrix = self:GetPriceMatrix(itemID)
    if not matrix then return nil end
    local values = {}
    if matrix.auction.volatility then values[#values + 1] = matrix.auction.volatility end
    if matrix.tsm.volatility then values[#values + 1] = matrix.tsm.volatility end
    if #values == 0 then return nil end
    local total = 0
    for _, value in ipairs(values) do total = total + value end
    return total / #values
end

function Market:CompareSources(itemID)
    local matrix = self:GetPriceMatrix(itemID)
    if not matrix then return nil end
    local prices = {}
    if matrix.auction.lowestUnitPrice and matrix.auction.lowestUnitPrice > 0 then
        prices[#prices + 1] = { source = "auction", value = matrix.auction.lowestUnitPrice }
    end
    if matrix.tsm.marketValue and matrix.tsm.marketValue > 0 then
        prices[#prices + 1] = { source = "tsm", value = matrix.tsm.marketValue }
    end
    if matrix.vendorSellPrice > 0 then
        prices[#prices + 1] = { source = "vendor", value = matrix.vendorSellPrice }
    end
    table.sort(prices, function(a, b) return a.value > b.value end)
    return {
        itemID = matrix.itemID,
        name = matrix.name,
        prices = prices,
        spread = (#prices >= 2) and (prices[1].value - prices[#prices].value) or 0,
        spreadPercent = (#prices >= 2 and prices[#prices].value > 0)
            and ((prices[1].value - prices[#prices].value) / prices[#prices].value)
            or 0,
    }
end


function Market:RecordSoldAuction(auction)
    if type(auction) ~= "table" then return false end
    local auctionID = tonumber(auction.auctionID)
    local itemKey = auction.itemKey or {}
    local itemID = tonumber(itemKey.itemID)
    local quantity = tonumber(auction.quantity) or 1
    local saleValue = tonumber(auction.buyoutAmount) or tonumber(auction.bidAmount) or 0
    if not auctionID or not itemID or quantity <= 0 or saleValue <= 0 then return false end

    local store = EnsureStore()
    local saleKey = tostring(GoldMint.characterKey or "Unknown") .. ":" .. tostring(auctionID)
    if store.salesSeen[saleKey] then return false end
    store.salesSeen[saleKey] = Now()

    local record = store.salesByItem[itemID]
    if type(record) ~= "table" then
        record = { itemID = itemID, name = auction.itemLink, unitsSold = 0, revenue = 0, sales = 0, history = {} }
        store.salesByItem[itemID] = record
    end
    record.name = record.name or auction.itemLink
    record.unitsSold = (tonumber(record.unitsSold) or 0) + quantity
    record.revenue = (tonumber(record.revenue) or 0) + saleValue
    record.sales = (tonumber(record.sales) or 0) + 1
    record.lastSoldAt = Now()
    record.lastUnitSale = saleValue / quantity
    record.history = type(record.history) == "table" and record.history or {}
    record.history[#record.history + 1] = { time = Now(), quantity = quantity, value = saleValue, unitValue = saleValue / quantity }
    while #record.history > 100 do table.remove(record.history, 1) end

    Market:RecordItem(itemID)
    if GoldMint.Ledger and GoldMint.Ledger.QueueAuctionSale then
        GoldMint.Ledger:QueueAuctionSale(saleValue, itemID, quantity, auctionID)
    end
    return true
end

function Market:GetTopSellers(limit, days)
    local store = EnsureStore()
    limit = tonumber(limit) or 10
    days = tonumber(days) or 30
    local cutoff = Now() - (days * 86400)
    local rows = {}
    for itemID, record in pairs(store.salesByItem or {}) do
        if type(record) == "table" then
            local units, revenue, sales = 0, 0, 0
            for _, sale in ipairs(record.history or {}) do
                if tonumber(sale.time) and sale.time >= cutoff then
                    units = units + (tonumber(sale.quantity) or 0)
                    revenue = revenue + (tonumber(sale.value) or 0)
                    sales = sales + 1
                end
            end
            if units > 0 then
                local okCount, rawCount = false, 0
                if C_Item and C_Item.GetItemCount then okCount, rawCount = pcall(C_Item.GetItemCount, tonumber(itemID), true, true, true, true) end
                local current = okCount and (tonumber(rawCount) or 0) or 0
                rows[#rows + 1] = {
                    itemID = tonumber(itemID),
                    name = record.name or (self:GetRecord(itemID) and self:GetRecord(itemID).name) or ("Item " .. tostring(itemID)),
                    unitsSold = units,
                    revenue = revenue,
                    sales = sales,
                    stock = tonumber(current) or 0,
                    avgUnit = units > 0 and revenue / units or 0,
                    lastSoldAt = tonumber(record.lastSoldAt) or 0,
                }
            end
        end
    end
    table.sort(rows, function(a,b)
        if a.unitsSold ~= b.unitsSold then return a.unitsSold > b.unitsSold end
        if a.revenue ~= b.revenue then return a.revenue > b.revenue end
        return a.name < b.name
    end)
    while #rows > limit do table.remove(rows) end
    return rows
end

function Market:GetRestockRecommendations(limit, days)
    local rows = self:GetTopSellers(limit or 8, days or 30)
    for _, row in ipairs(rows) do
        -- Keep a practical buffer: roughly one recent 30-day sales cycle,
        -- with a small floor so a single observed sale is still actionable.
        row.target = math.max(5, math.min(200, row.unitsSold))
        row.need = math.max(0, row.target - row.stock)
        row.priority = row.need > 0 and (row.unitsSold * row.avgUnit) or 0
    end
    table.sort(rows, function(a,b)
        if (a.need > 0) ~= (b.need > 0) then return a.need > 0 end
        if a.priority ~= b.priority then return a.priority > b.priority end
        return a.unitsSold > b.unitsSold
    end)
    return rows
end

function Market:IsAuctionHouseOpen()
    return AuctionHouseFrame and type(AuctionHouseFrame.IsShown) == "function" and AuctionHouseFrame:IsShown() or false
end

function Market:RefreshOwnedAuctions()
    -- Owned-auction data is only refreshed from the Auction House. Outside
    -- the AH, preserve the last known snapshot instead of replacing it with
    -- an empty/non-authoritative result. This is what makes the Market page
    -- useful from anywhere in the world.
    if not self:IsAuctionHouseOpen() then
        return 0, 0
    end

    if not C_AuctionHouse or type(C_AuctionHouse.GetOwnedAuctions) ~= "function" then
        return 0, 0
    end

    local ok, auctions = pcall(C_AuctionHouse.GetOwnedAuctions)
    if not ok or type(auctions) ~= "table" then
        return 0, 0
    end

    local total = 0
    local count = 0
    local activeRows = {}
    for _, auction in ipairs(auctions) do
        if type(auction) == "table" then
            local status = auction.status
            local active = true
            if Enum and Enum.AuctionStatus and Enum.AuctionStatus.Active ~= nil then
                active = status == Enum.AuctionStatus.Active
            elseif tonumber(status) ~= nil then
                active = tonumber(status) == 0
            end

            if status == (Enum and Enum.AuctionStatus and Enum.AuctionStatus.Sold) then
                self:RecordSoldAuction(auction)
            end

            if active then
                local itemKey = auction.itemKey or {}
                local itemID = tonumber(itemKey.itemID)
                local value = tonumber(auction.buyoutAmount) or tonumber(auction.bidAmount) or 0
                local quantity = tonumber(auction.quantity) or 1

                -- ACTIVE TRADES means actual sellable auctions only. Do not
                -- count Warbound, Warbound-until-equipped, BoP, account-bound,
                -- quest-bound, or other restricted items. Blizzard exposes the
                -- binding state through C_Item.GetItemInfo's bindType return.
                local eligible = true
                if itemID and C_Item and type(C_Item.GetItemInfo) == "function" then
                    local ok, _, _, _, _, _, _, _, _, _, _, _, _, _, bindType = pcall(C_Item.GetItemInfo, itemID)
                    if ok and bindType ~= nil then
                        bindType = tonumber(bindType)
                        eligible = (bindType == 0 or bindType == 2)
                    elseif ok then
                        -- Do not manufacture a trade from incomplete item data.
                        eligible = false
                    end
                elseif itemID and type(GetItemInfo) == "function" then
                    local ok, _, _, _, _, _, _, _, _, _, _, _, _, _, bindType = pcall(GetItemInfo, itemID)
                    if ok and bindType ~= nil then
                        bindType = tonumber(bindType)
                        eligible = (bindType == 0 or bindType == 2)
                    elseif ok then
                        eligible = false
                    end
                end

                if itemID and value > 0 and eligible then
                    total = total + value
                    count = count + 1
                    local marketRecord = self:GetRecord(itemID)
                    local observedLowest = marketRecord and marketRecord.ah and tonumber(marketRecord.ah.lowestUnitPrice) or nil
                    local marketObservedAt = marketRecord and marketRecord.ah and tonumber(marketRecord.ah.observedAt) or nil
                    activeRows[#activeRows + 1] = {
                        auctionID = auction.auctionID,
                        itemID = itemID,
                        itemLink = auction.itemLink,
                        quantity = quantity,
                        value = math.floor(value),
                        timeLeftSeconds = tonumber(auction.timeLeftSeconds) or 0,
                        observedAt = Now(),
                        marketLowestUnitPrice = observedLowest,
                        marketObservedAt = marketObservedAt,
                    }
                end
            end
        end
    end

    local store = EnsureStore()
    local characterKey = GoldMint.characterKey or "Unknown"
    local scanAt = Now()

    -- This is the latest authoritative snapshot for THIS character. It is
    -- deliberately persisted so the Market page can continue showing the
    -- player's auctions after leaving the Auction House or reloading the UI.
    store.activeAuctionsByCharacter[characterKey] = {
        auctions = activeRows,
        updatedAt = scanAt,
    }
    store.ownedAuctionsByCharacter[characterKey] = {
        value = math.floor(total),
        count = count,
        updatedAt = scanAt,
    }
    store.ownedAuctionsValue = math.floor(total)
    store.ownedAuctionsCount = count
    store.ownedAuctionsUpdatedAt = scanAt
    store.lastAuctionScanAt = scanAt
    return total, count
end


function Market:GetActiveOwnedAuctionsForCharacter()
    local store = EnsureStore()
    local characterKey = GoldMint.characterKey or "Unknown"
    local record = store.activeAuctionsByCharacter and store.activeAuctionsByCharacter[characterKey]
    if type(record) ~= "table" or type(record.auctions) ~= "table" then
        return {}
    end
    return record.auctions
end

function Market:GetOwnedAuctionValue()
    local store = EnsureStore()
    local total = 0
    for _, record in pairs(store.ownedAuctionsByCharacter or {}) do
        if type(record) == "table" then
            total = total + (tonumber(record.value) or 0)
        end
    end
    -- Preserve legacy single-character data if no per-character records exist.
    if total == 0 then
        total = tonumber(store.ownedAuctionsValue) or 0
    end
    return total
end

function Market:GetOwnedAuctionCount()
    local store = EnsureStore()
    local total = 0
    for _, record in pairs(store.ownedAuctionsByCharacter or {}) do
        if type(record) == "table" then
            total = total + (tonumber(record.count) or 0)
        end
    end
    if total == 0 then
        total = tonumber(store.ownedAuctionsCount) or 0
    end
    return total
end

function Market:GetOwnedValue()
    local total = 0
    local items = GoldMintDB and GoldMintDB.market and GoldMintDB.market.items or {}
    for itemID, record in pairs(items) do
        local value = self:GetUnitValue(itemID)
        if value and C_Item and C_Item.GetItemCount then
            local ok, result = pcall(C_Item.GetItemCount, tonumber(itemID), true, true, true, true)
            if ok then total = total + value * (tonumber(result) or 0) end
        end
    end
    return total
end

function Market:GetAuctionHouseFlipOpportunities(limit)
    local store = EnsureStore()
    limit = math.max(1, math.min(5, tonumber(limit) or 5))

    -- Home should surface actual flip candidates, not a static watchlist. Use
    -- the latest known AH price against TSM's market value and only keep items
    -- with enough discount to leave room for the 5% Auction House cut.
    local candidates = {}
    for itemID, record in pairs(store.items or {}) do
        if type(record) == "table" then
            local id = tonumber(itemID)
            local region = record.region or {}
            local ah = record.ah or {}

            -- A flip must be based on an actual Auction House observation.
            -- TSM DBMinBuyout is useful as reference data, but it is not a
            -- live AH price and may be stale. Never use it as the purchase
            -- price for a flip calculation.
            local current = tonumber(ah.lowestUnitPrice) or 0
            local ahObservedAt = tonumber(ah.observedAt) or 0
            local ahAge = ahObservedAt > 0 and (Now() - ahObservedAt) or math.huge
            local AH_PRICE_MAX_AGE = 15 * 60
            local market = tonumber(region.marketValue) or tonumber(record.tsm and record.tsm.marketValue) or 0
            local regionMarket = tonumber(region.regionMarketAvg) or 0
            local saleAvg = tonumber(region.regionSaleAvg) or 0
            local saleRate = tonumber(region.regionSaleRate) or 0
            local soldPerDay = tonumber(region.regionSoldPerDay) or 0

            -- A flip needs evidence of an achievable sale price, not just a
            -- listing-based market value. DBRegionSaleAvg is based on actual
            -- regional sales/purchases collected by the TSM Desktop App.
            local supportedSaleValue = saleAvg > 0 and saleAvg or 0
            local valuationWarning = false
            local valuationReasons = {}
            if market >= 10000000000 then -- 1,000,000g in copper
                if supportedSaleValue <= 0 then
                    valuationWarning = true
                    valuationReasons[#valuationReasons + 1] = "No regional sale average is available to support this valuation."
                elseif supportedSaleValue < market * 0.50 then
                    valuationWarning = true
                    valuationReasons[#valuationReasons + 1] = "Regional sale average is less than half of the TSM market value."
                end
                if regionMarket > 0 and regionMarket < market * 0.50 then
                    valuationWarning = true
                    valuationReasons[#valuationReasons + 1] = "Regional market average is less than half of the TSM market value."
                end
                if saleRate > 0 and saleRate < 0.05 then
                    valuationWarning = true
                    valuationReasons[#valuationReasons + 1] = string.format("Regional sale rate is only %.1f%%.", saleRate * 100)
                end
                if soldPerDay <= 0 then
                    valuationWarning = true
                    valuationReasons[#valuationReasons + 1] = "No regional sales-per-day data is available."
                end
            end

            -- Never use TSM DBMinBuyout as the purchase price. It can be stale;
            -- this panel requires a recent price actually observed from the AH.
            if id and id > 0 and current > 0 and ahAge <= AH_PRICE_MAX_AGE and supportedSaleValue > 0 and current < supportedSaleValue then
                local discount = (supportedSaleValue - current) / supportedSaleValue
                local netSale = supportedSaleValue * 0.95
                local profit = netSale - current
                if discount >= 0.10 and profit > 0 then
                    candidates[#candidates + 1] = {
                        itemID = id,
                        name = record.name,
                        current = current,
                        marketValue = market,
                        supportedSaleValue = supportedSaleValue,
                        profit = profit,
                        roi = profit / current,
                        discount = discount,
                        volume = soldPerDay,
                        saleAvg = saleAvg,
                        saleRate = saleRate,
                        regionMarket = regionMarket,
                        ahAge = ahAge,
                        ahSource = ah.source,
                        valuationWarning = valuationWarning,
                        valuationReasons = valuationReasons,
                        observedAt = tonumber(region.observedAt) or tonumber(ah.observedAt) or tonumber(record.lastSeen) or 0,
                    }
                end
            end
        end
    end

    table.sort(candidates, function(a, b)
        if a.valuationWarning ~= b.valuationWarning then return not a.valuationWarning end
        if a.roi ~= b.roi then return a.roi > b.roi end
        if a.profit ~= b.profit then return a.profit > b.profit end
        if a.volume ~= b.volume then return a.volume > b.volume end
        return tostring(a.name or "") < tostring(b.name or "")
    end)

    while #candidates > limit do table.remove(candidates) end
    return candidates
end

function Market:SetAuctionHouseWatchTarget(itemID, buyPrice, sellPrice)
    local store = EnsureStore()
    itemID = tonumber(itemID)
    if not itemID then return false end
    store.watchlist.targets = type(store.watchlist.targets) == "table" and store.watchlist.targets or {}
    store.watchlist.targets[itemID] = { buy = tonumber(buyPrice) or 0, sell = tonumber(sellPrice) or 0 }
    return true
end

function Market:GetTrackedCount(rebuild)
    local store = EnsureStore()
    local count = tonumber(store.trackedCount)
    if count and count > 0 then return count end

    -- Do not walk a potentially very large saved-variable table during login or
    -- normal Economy refreshes. A rebuild is only performed when the caller
    -- explicitly asks for it (for example, a diagnostic command).
    if rebuild then
        count = 0
        for _ in pairs(store.items or {}) do count = count + 1 end
        store.trackedCount = count
        return count
    end
    return 0
end

function Market:FormatGold(copper)
    copper = math.floor(tonumber(copper) or 0)
    local gold = math.floor(copper / 10000)
    local silver = math.floor((copper % 10000) / 100)
    local copperPart = copper % 100
    if gold > 0 then return string.format("%dg %02ds %02dc", gold, silver, copperPart) end
    if silver > 0 then return string.format("%ds %02dc", silver, copperPart) end
    return string.format("%dc", copperPart)
end

function Market:FormatUnit(copper)
    copper = tonumber(copper) or 0
    if copper >= 10000 then return string.format("%.2fg", copper / 10000) end
    if copper >= 100 then return string.format("%.2fs", copper / 100) end
    return string.format("%dc", math.floor(copper))
end

function Market:GetStatus(itemID)
    local record = self:GetRecord(itemID)
    if not record then return nil end
    local value, source = self:GetUnitValue(itemID)
    return {
        itemID = tonumber(itemID),
        name = record.name,
        value = value,
        source = source,
        vendorSellPrice = record.vendorSellPrice or 0,
        auctionLowest = record.ah and record.ah.lowestUnitPrice or nil,
        auctionObservedAt = record.ah and record.ah.observedAt or nil,
        tsmMarketValue = record.tsm and record.tsm.marketValue or nil,
        tsmObservedAt = record.tsm and record.tsm.observedAt or nil,
    }
end

local function CaptureTooltipItem(_, data)
    if type(data) ~= "table" then return end
    local itemID = tonumber(data.id)
    if not itemID then return end
    Market:RecordItem(itemID)
    Market:CaptureTSM(itemID)
end

-- Auction result events can arrive in dense bursts. Keep a small pending set
-- so one logical result refresh is processed once per burst instead of once per
-- Blizzard event. This preserves every distinct item while avoiding duplicate
-- Record/TSM work when UPDATED and ADDED fire together.
local function QueueAuctionResult(self, kind, key)
    self._auctionBurstQueue = self._auctionBurstQueue or { commodity = {}, item = {} }
    self._auctionBurstQueue[kind] = self._auctionBurstQueue[kind] or {}

    if kind == "commodity" then
        local itemID = tonumber(key)
        if not itemID or itemID <= 0 then return end
        self._auctionBurstQueue.commodity[itemID] = itemID
    elseif kind == "item" and type(key) == "table" then
        local itemID = tonumber(key.itemID)
        if not itemID or itemID <= 0 then return end
        local keyID = tostring(itemID) .. ":" .. tostring(key.itemLevel or 0) .. ":" .. tostring(key.itemSuffix or 0)
        self._auctionBurstQueue.item[keyID] = {
            itemID = itemID,
            itemLevel = key.itemLevel,
            itemSuffix = key.itemSuffix,
        }
    end

    if self._auctionBurstPending then return end
    self._auctionBurstPending = true
    GoldMint:ScheduleGuardedCallback(self, "market auction result burst", 0.10, function()
        self._auctionBurstPending = false
        if not self._initialized then
            self._auctionBurstQueue = { commodity = {}, item = {} }
            return
        end
        local queue = self._auctionBurstQueue or { commodity = {}, item = {} }
        self._auctionBurstQueue = { commodity = {}, item = {} }
        for _, itemID in pairs(queue.commodity or {}) do
            Market:ScanAuctionResults("commodity", itemID)
        end
        for _, itemKey in pairs(queue.item or {}) do
            Market:ScanAuctionResults("item", itemKey)
        end
    end)
end

local function QueueBrowseResults(self)
    if self._browseBurstPending then return end
    self._browseBurstPending = true
    GoldMint:ScheduleGuardedCallback(self, "market browse result burst", 0.10, function()
        self._browseBurstPending = false
        if self._initialized then
            RecordBrowseResults()
        end
    end)
end

local function RefreshLoadedMarketItem(itemID)
    itemID = ToNumber(itemID)
    if not itemID then return false end
    local record = EnsureStore().items[itemID] or EnsureStore().items[tostring(itemID)]
    if not record then return false end

    local name
    if C_Item and C_Item.GetItemNameByID then
        local ok, value = pcall(C_Item.GetItemNameByID, itemID)
        if ok and value then name = value end
    end
    if not name and C_Item and C_Item.GetItemInfo then
        local ok, value = pcall(C_Item.GetItemInfo, itemID)
        if ok and value then name = value end
    end
    if name then
        record.name = name
        record.lastSeen = record.lastSeen or Now()
        return true
    end
    return false
end

function Market:Initialize()
    if self._initialized then return end
    self._initialized = true
    local store = EnsureStore()
    self:InvalidateTrackedItemsCache()
    -- Keep the previous snapshot across logins. It is explicitly displayed
    -- as last-known data until Blizzard provides a fresh owned-auction list.

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("ITEM_DATA_LOAD_RESULT")
    frame:RegisterEvent("COMMODITY_SEARCH_RESULTS_UPDATED")
    frame:RegisterEvent("COMMODITY_SEARCH_RESULTS_ADDED")
    frame:RegisterEvent("ITEM_SEARCH_RESULTS_UPDATED")
    frame:RegisterEvent("ITEM_SEARCH_RESULTS_ADDED")
    frame:RegisterEvent("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
    frame:RegisterEvent("AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
    frame:RegisterEvent("AUCTION_HOUSE_SHOW")
    frame:RegisterEvent("AUCTION_HOUSE_CLOSED")
    frame:RegisterEvent("OWNED_AUCTIONS_UPDATED")
    frame:RegisterEvent("TOKEN_MARKET_PRICE_UPDATED")

    frame:SetScript("OnEvent", function(_, event, ...)
        if event == "ITEM_DATA_LOAD_RESULT" then
            -- Capture the callback payload first. Do not pass any multi-return
            -- expression to tonumber(): its second return value can be a
            -- boolean, which Lua interprets as tonumber's optional base.
            local itemID, success = ...
            -- ITEM_DATA_LOAD_RESULT is (itemID, success). Never feed the
            -- multi-return event payload directly to tonumber(), because the
            -- boolean success value would be interpreted as tonumber's base.
            itemID = ToNumber(itemID)
            if not itemID or success == nil then
                return
            end
            if RefreshLoadedMarketItem(itemID) then
                self:InvalidateTrackedItemsCache()
                -- Repaint only the existing Market rows. Do not trigger a scan,
                -- valuation pass, or any other expensive login/AH work.
                if self._itemDataRefreshPending then return end
                self._itemDataRefreshPending = true
                GoldMint:ScheduleGuardedCallback(self, "market item data refresh", 0.05, function()
                    self._itemDataRefreshPending = false
                    if GoldMint.Dashboard and GoldMint.Dashboard.panels and GoldMint.Dashboard.panels.marketPage then
                        local page = GoldMint.Dashboard.panels.marketPage
                        if page:IsShown() and page.RefreshMarketRows then
                            page.RefreshMarketRows()
                        end
                    end
                end)
            end
        elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" or event == "COMMODITY_SEARCH_RESULTS_ADDED" then
            QueueAuctionResult(self, "commodity", select(1, ...))
        elseif event == "ITEM_SEARCH_RESULTS_UPDATED" or event == "ITEM_SEARCH_RESULTS_ADDED" then
            QueueAuctionResult(self, "item", select(1, ...))
        elseif event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
            QueueBrowseResults(self)
        elseif event == "AUCTION_HOUSE_SHOW" then
            if C_AuctionHouse and type(C_AuctionHouse.QueryOwnedAuctions) == "function" then
                pcall(C_AuctionHouse.QueryOwnedAuctions, {})
            end
            Market:RefreshOwnedAuctions()

            -- Do not launch a full TSM database scan automatically when the
            -- Auction House opens. TSM lookups can be expensive and a large
            -- automatic pass was causing noticeable frame-time spikes. The
            -- Market page's SCAN MARKET button remains the explicit opt-in
            -- refresh path.
            self._ahAutoScanStarted = false
        elseif event == "AUCTION_HOUSE_CLOSED" then
            self._ahAutoScanStarted = false
        elseif event == "OWNED_AUCTIONS_UPDATED" then
            Market:RefreshOwnedAuctions()
        elseif event == "TOKEN_MARKET_PRICE_UPDATED" then
            -- TOKEN_MARKET_PRICE_UPDATED supplies the live price as its first
            -- payload value.  Ignore placeholder/invalid values and fall back
            -- to the public API so the dashboard never displays "1" as the
            -- token price.
            local result = select(1, ...)
            local price = NormalizeTokenPrice(result)
            if not price or price < 1000 then
                if C_WowTokenPublic and type(C_WowTokenPublic.GetCurrentMarketPrice) == "function" then
                    local ok, current = pcall(C_WowTokenPublic.GetCurrentMarketPrice)
                    current = ok and NormalizeTokenPrice(current) or nil
                    if current and current >= 1000 then
                        price = current
                    end
                end
            end
            if price and price >= 1000 then
                Market:RecordTokenPrice(price)
            end
        end
    end)

    if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, CaptureTooltipItem)
    end

    -- Passive initial capture only. This records item/vendor information from
    -- the bags the player already has; it does not issue any AH queries.
    GoldMint:ScheduleGuardedCallback(self, "market initial scan", 1, function()
        Market:ScanBags()
        Market:RefreshTokenPrice()
    end, function() return Market._initialized end)

    if C_Timer and C_Timer.NewTicker then
        self._tokenTicker = C_Timer.NewTicker(300, function()
            if Market._initialized then
                Market:RefreshTokenPrice()
            end
        end)
    end
end
