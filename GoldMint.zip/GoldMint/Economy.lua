local ADDON_NAME, GoldMint = ...

GoldMint.Economy = {}
local Economy = GoldMint.Economy

local API_VERSION = 4
local REFRESH_DEBOUNCE = 0.15

local function Now()
    if type(GetTimePreciseSec) == "function" then
        return GetTimePreciseSec()
    end
    return time()
end

local function CountRecipesWithProfit()
    local total, profitable = 0, 0
    local recipes = GoldMintDB and GoldMintDB.recipes or {}

    for _, record in pairs(recipes) do
        if type(record) == "table" and type(record.profit) == "table" then
            total = total + 1
            if record.profit.profitable then
                profitable = profitable + 1
            end
        end
    end

    return total, profitable
end

local function CopyCharacters(characters)
    local result = {}
    for i, character in ipairs(characters or {}) do
        result[i] = {
            key = character.key,
            name = character.name,
            realm = character.realm,
            faction = character.faction,
            gold = tonumber(character.gold) or 0,
            lastSeen = tonumber(character.lastSeen) or 0,
        }
    end
    return result
end

function Economy:GetWallet()
    if not GoldMint.Ledger then
        return { totalGold = 0, characters = {}, updatedAt = time() }
    end
    return GoldMint.Ledger:GetAccountWallet()
end

function Economy:GetSession()
    if not GoldMint.Ledger then return nil end
    return GoldMint.Ledger:GetSession()
end

function Economy:GetMarket()
    if not GoldMint.Market then
        return { trackedItems = 0, ownedValue = 0, updatedAt = time() }
    end
    return {
        trackedItems = GoldMint.Market:GetTrackedCount(),
        ownedValue = GoldMint.Market:GetOwnedValue(),
        updatedAt = time(),
    }
end

function Economy:GetValuation()
    if not GoldMint.Valuation then
        local wallet = self:GetWallet()
        return {
            gold = wallet.totalGold or 0,
            items = 0,
            total = wallet.totalGold or 0,
            visibleCharacterItems = 0,
            visibleBankItems = 0,
            trackedMarketItems = 0,
            updatedAt = time(),
        }
    end
    return GoldMint.Valuation:GetStatus()
end

function Economy:GetCrafting()
    local total, profitable = CountRecipesWithProfit()
    return {
        recipesWithProfitData = total,
        profitableRecipes = profitable,
        updatedAt = time(),
    }
end

function Economy:GetMail()
    if not GoldMint.MailTracking then
        return {
            mailCount = 0,
            attachmentCount = 0,
            moneyTotal = 0,
            externalMoneyTotal = 0,
            auctionMoneyTotal = 0,
            unreadCount = 0,
            internalCount = 0,
            updatedAt = time(),
        }
    end

    local summary = GoldMint.MailTracking:GetSummary()
    if not summary then
        return {
            mailCount = 0,
            attachmentCount = 0,
            moneyTotal = 0,
            externalMoneyTotal = 0,
            auctionMoneyTotal = 0,
            unreadCount = 0,
            internalCount = 0,
            updatedAt = time(),
        }
    end

    return {
        mailCount = tonumber(summary.mailCount) or 0,
        attachmentCount = tonumber(summary.attachmentCount) or 0,
        moneyTotal = tonumber(summary.moneyTotal) or 0,
        externalMoneyTotal = tonumber(summary.externalMoneyTotal) or 0,
        auctionMoneyTotal = tonumber(summary.auctionMoneyTotal) or 0,
        unreadCount = tonumber(summary.unreadCount) or 0,
        internalCount = tonumber(summary.internalCount) or 0,
        lastScanAt = tonumber(summary.lastScanAt) or 0,
        mailboxOpen = summary.mailboxOpen == true,
        updatedAt = time(),
    }
end

function Economy:BuildStatus(reason)
    local wallet = self:GetWallet()
    local session = self:GetSession()
    local market = self:GetMarket()
    local valuation = self:GetValuation()
    local crafting = self:GetCrafting()
    local mail = self:GetMail()
    local goldMakingGuild = self:GetGoldMakingGuild()
    local milestones = GoldMint.Milestones and GoldMint.Milestones:GetSummary() or nil

    return {
        apiVersion = API_VERSION,
        updatedAt = Now(),
        reason = reason or "manual",

        wallet = {
            totalGold = tonumber(wallet.totalGold) or 0,
            characterCount = #(wallet.characters or {}),
            characters = CopyCharacters(wallet.characters),
            updatedAt = wallet.updatedAt,
        },

        session = session and {
            startedAt = session.startedAt,
            startedAtWall = session.startedAtWall,
            startingGold = tonumber(session.startingGold) or 0,
            endingGold = tonumber(session.endingGold) or 0,
            netGold = tonumber(session.netGold) or 0,
            income = tonumber(session.income) or 0,
            spending = tonumber(session.spending) or 0,
            goldPerHour = tonumber(session.goldPerHour) or 0,
            velocityGoldPerHour = tonumber(session.velocityGoldPerHour) or 0,
            goldMakingGuild = session.goldMakingGuild,
            goldMakingGuildActive = session.goldMakingGuildActive == true,
            transactionCount = #(session.transactions or {}),
        } or nil,

        market = market,
        valuation = valuation,
        crafting = crafting,
        mail = mail,
        goldMakingGuild = goldMakingGuild,
        milestones = milestones,
    }
end

function Economy:GetStatus(forceRefresh)
    if forceRefresh or not self._status or self._dirty then
        self:Refresh(forceRefresh and "forced" or "dirty")
    end
    return self._status
end

function Economy:GetAccountGold()
    return self:GetStatus().wallet.totalGold or 0
end

function Economy:GetGoldMakingGuild()
    if not GoldMint.Ledger or not GoldMint.Ledger.GetGoldMakingGuildWallet then
        return {
            selected = GoldMint.GetGoldMakingGuild and GoldMint:GetGoldMakingGuild() or nil,
            characterCount = 0,
            personalGold = 0,
            characters = {},
            updatedAt = time(),
        }
    end
    return GoldMint.Ledger:GetGoldMakingGuildWallet()
end

function Economy:GetAccountValue()
    return self:GetStatus().valuation.total or 0
end

function Economy:GetSessionGoldPerHour()
    local session = self:GetStatus().session
    return session and (tonumber(session.goldPerHour) or 0) or 0
end

function Economy:RegisterListener(callback)
    if type(callback) ~= "function" then return false end
    self._listeners = self._listeners or {}
    self._listeners[#self._listeners + 1] = callback
    return true
end

function Economy:UnregisterListener(callback)
    if type(callback) ~= "function" or not self._listeners then return false end
    for i = #self._listeners, 1, -1 do
        if self._listeners[i] == callback then
            table.remove(self._listeners, i)
            return true
        end
    end
    return false
end

function Economy:ScheduleRefresh(reason, delay)
    if not self._initialized then return nil end
    self._dirty = true

    -- Do not rebuild Economy while CraftSim is actively driving the profession
    -- UI or while Auctionator is driving the Auction House. Both addons can
    -- generate dense bag/profession/AH update bursts; GoldMint only needs the
    -- settled result after the external workflow finishes.
    if GoldMint.IsCraftSimActive and GoldMint:IsCraftSimActive() then
        self._refreshAfterProfession = true
        self._refreshPending = true
        self._refreshPendingReason = reason or self._refreshPendingReason or "scheduled"
        return self._status
    end
    if GoldMint.IsAuctionatorActive and GoldMint:IsAuctionatorActive() then
        self._refreshAfterAuctionHouse = true
        self._refreshPending = true
        self._refreshPendingReason = reason or self._refreshPendingReason or "scheduled"
        return self._status
    end

    self._refreshPending = true
    self._refreshPendingReason = reason or self._refreshPendingReason or "scheduled"
    if self._refreshTimer then return self._status end
    self._refreshTimer = true
    GoldMint:ScheduleGuardedCallback(self, "economy refresh", delay == nil and REFRESH_DEBOUNCE or delay, function()
        self._refreshTimer = false
        if not self._initialized then return end
        if GoldMint:IsMerchantOpen() then
            self._refreshAfterMerchantPending = true
            return
        end
        local pendingReason = self._refreshPendingReason or "scheduled"
        self._refreshPending = false
        self._refreshPendingReason = nil
        self:Refresh(pendingReason)
    end)
    return self._status
end

function Economy:Refresh(reason)
    if not self._initialized then return nil end
    if self._refreshing then return self._status end

    self._refreshing = true
    local status = self:BuildStatus(reason)
    self._status = status
    self._lastRefresh = Now()
    self._dirty = false

    local listeners = self._listeners
    if listeners then
        for i = #listeners, 1, -1 do
            local callback = listeners[i]
            local ok = pcall(callback, status, reason)
            if not ok then
                table.remove(listeners, i)
            end
        end
    end


    if GoldMintDB and GoldMintDB.economy then
        GoldMintDB.economy.lastRefresh = time()
        GoldMintDB.economy.lastReason = reason or "manual"
        GoldMintDB.economy.apiVersion = API_VERSION
    end

    self._refreshing = false
    return status
end

function Economy:Initialize()
    if self._initialized then return end
    self._initialized = true

    if GoldMintDB then
        GoldMintDB.economy = type(GoldMintDB.economy) == "table" and GoldMintDB.economy or {}
        GoldMintDB.economy.version = API_VERSION
        GoldMintDB.economy.apiVersion = API_VERSION
    end

    self._listeners = {}
    self._status = nil
    self._lastRefresh = 0
    self._refreshPending = false
    self._refreshPendingReason = nil
    self._refreshTimer = false
    self._dirty = true

    local frame = CreateFrame("Frame")
    self._eventFrame = frame
    frame:RegisterEvent("PLAYER_MONEY")
    frame:RegisterEvent("BANKFRAME_OPENED")
    frame:RegisterEvent("PLAYERBANKSLOTS_CHANGED")
    frame:RegisterEvent("PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED")
    frame:RegisterEvent("BANK_TABS_CHANGED")
    frame:RegisterEvent("GUILDBANKFRAME_OPENED")
    frame:RegisterEvent("GUILDBANK_UPDATE_MONEY")
    frame:RegisterEvent("GUILDBANK_UPDATE_TABS")
    frame:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED")
    frame:RegisterEvent("AUCTION_HOUSE_SHOW")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")

    frame:SetScript("OnEvent", function(_, event)
        -- Any event that would rebuild Economy is deferred while the merchant is
        -- visible. Core performs one consolidated refresh after MERCHANT_CLOSED.
        if GoldMint:IsMerchantOpen() then
            if event == "PLAYER_MONEY" then
                self._refreshAfterMerchantPending = true
                return
            end
        end
        -- Bank data is only reliable after the bank/account-bank event fires.
        -- Keep all current 12.1 bank types flowing through the same backend refresh.
        if event == "BANKFRAME_OPENED" and GoldMint.Valuation then
            GoldMint.Valuation:ScanCharacterBank()
            GoldMint.Valuation:ScanAccountBank()
        elseif event == "PLAYERBANKSLOTS_CHANGED" and GoldMint.Valuation then
            GoldMint.Valuation:ScanCharacterBank()
        elseif event == "PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED" and GoldMint.Valuation then
            GoldMint.Valuation:ScanAccountBank()
        elseif event == "BANK_TABS_CHANGED" and GoldMint.Valuation then
            GoldMint.Valuation:ScanAccountBank()
        elseif event == "GUILDBANK_UPDATE_MONEY" and GoldMint.Valuation then
            -- Money updates do not require a full item scan. Refresh the
            -- cached guild-bank gold immediately so a fresh deposit (such as
            -- 5g added while testing) cannot be missed by the scan cooldown.
            if GoldMint.Valuation.RefreshGuildBankGold then
                GoldMint.Valuation:RefreshGuildBankGold()
            end
        elseif (event == "GUILDBANKFRAME_OPENED" or event == "GUILDBANK_UPDATE_TABS" or event == "GUILDBANKBAGSLOTS_CHANGED") and GoldMint.Valuation then
            -- Guild-bank contents arrive asynchronously. Give Blizzard time to
            -- populate the selected tab before scanning it. A later slot event
            -- will mark an in-progress scan for another pass.
            C_Timer.After(0.50, function()
                if GoldMint.Valuation and GoldMint.Valuation.ScanGuildBank then
                    GoldMint.Valuation:ScanGuildBank()
                end
            end)
        end
        self:ScheduleRefresh("event:" .. event)
    end)

    -- No periodic Economy ticker. The old 15-second ticker rebuilt wallet,
    -- valuation, crafting, mail and milestone status even when nothing changed.
    -- Economy is now event-driven; ScheduleRefresh() marks it dirty and
    -- coalesces the actual rebuild.

    GoldMint:ScheduleGuardedCallback(self, "economy-initial-refresh", 0.1, function()
        if self._initialized then
            self:Refresh("initialized")
        end
    end)
end
